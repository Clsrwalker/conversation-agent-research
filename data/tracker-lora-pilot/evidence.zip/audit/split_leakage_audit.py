"""Read-only source/SFT leakage audit and bounded model near-duplicate review.

Auditor authored A and held-out scenarios, so this is not an independent gold
quality review. Candidate dispositions were written after reading raw dialogues.
No embeddings, model inference, training, truncation, or source mutation.
"""
from pathlib import Path
import collections, hashlib, json, math, re, sys, unicodedata
P=Path(__file__).resolve().parents[1];ROOT=P.parents[3]
sys.path.insert(0,str(ROOT/'experiments/deep_conversation/tracker_lora'))
from build_dataset import materialize,apply_prior_fault
def enc(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
def sha(x):return hashlib.sha256(x).hexdigest()
def readlines(p):return [json.loads(l) for l in p.read_text(encoding='utf-8-sig').splitlines() if l.strip()]

# Three raw-dialogue candidate comparisons for each held-out family, in ranked
# order using this script's lexical features. These are model judgments, not
# human review, nor a guarantee against all semantically paraphrased overlap.
NOTES={
'dev-001':['Jacket sleeve alteration versus desktop file grouping; shared preserve/change language does not identify the same task.','Sleeve-cap explanation versus dialect transcript annotation; constraints and consequences differ.','Stitching instructions versus weather-broadcast order and duration; no shared scenario facts.'],
'dev-002':['Math hint timing versus theater warm-up ownership; role and adoption language is common, tasks differ.','Quadratic tutoring versus escape-room hint-card accessibility; both discuss hints, but feedback timing and physical clue design differ.','Math exercise scope versus bus-route time/transfer restrictions; not a paraphrase.'],
'dev-003':['Inbox labels versus repair-quotation content; email is an artifact in the latter, an object of rule processing in the former.','Mail tagging versus warehouse label prefixes; both rename a label but have different conditions, owners and action boundaries.','Email triage versus desktop archiving; similar classification vocabulary but message actions and filename/shortcut rules differ.'],
'dev-004':['Vault export planning versus note-app export tests; shared export cancellation/reopening mechanism, but secrecy boundary and comparison request differ.','Vault migration versus pool checklist formats; export terminology and candidate ownership are unrelated.','Local vault handling versus read-only photo copies; shared data-preservation theme but distinct task and revision sequence.'],
'dev-005':['Circuit drawing conventions versus dialect explanations; only diagram/text preservation wording overlaps.','Circuit line styles versus warehouse prefix and shelf codes; physical subjects and owner structure differ.','Breadboard notation versus museum captions; proposal acceptance is shared, outputs and constraints differ.'],
'dev-006':['Keyboard base/layer separation versus map-copy privacy; separate formats do not form the same scenario.','Keyboard trigger change versus simulator controls; the latter changes the primary input device and has virtual camera constraints.','Keyboard legend versus talk handout; different underlying tasks despite separate-artifact wording.'],
'dev-007':['Electricity cumulative values versus bird-log location fields; both are records, but measurement/frequency and field cancellation differ.','Electricity notebook versus pronunciation practice; candidate rejection is a shared mechanism only.','Electricity estimates versus rollout screenshots; monitoring vocabulary and tentative fields do not make these the same scene.'],
'dev-008':['Ink owners versus survey owners; shared owner isolation, but product compatibility and color/waterproof constraints differ from counts and cancellation.','Ink selection versus volunteer website/PDF; no common requested artifact or revision.','Ink compatibility versus quartet recording privacy; separate-owner requests have distinct state histories.'],
'dev-009':['Weaving tactile key versus map high-contrast copy: similar unresolved-owner resolution, but sampler motif changes and portable tactile aids differ from map privacy and PDF format.','Weaving versus research workshop: ownership resolution is shared, but two session requirements and code checklist expansion are different.','Weaving motifs versus animated logo chime: unknown-owner candidate is shared, but chime cancellation and duration edits differ.'],
'dev-010':['Reminder windows versus weather reading times; both are schedules, but conditional notification fallback and missing measurements differ.','Calendar quiet hours versus announcement order/accessibility; no same workflow.','Reminder policy versus research sessions; common restore/explain phrasing without shared facts.'],
'test-001':['Calligraphy sheets versus thesis layout: both visual documents, but tracing/copying cells differ from citations and line numbers.','Calligraphy cells versus mock interview stages; structure and operations are unrelated.','Calligraphy mode versus Spanish correction timing; both learning, but script/examples and spoken practice constraints differ.'],
'test-002':['Tea log versus compost log: both measurements, but ownership of subjective taste, a tentative temperature field and Celsius adoption differ from temperature frequency and photo withdrawal.','Tea tasting versus synthetic dataset card: uncertain fields do not share output or decision facts.','Tea participants versus podcast disclaimer owner: both resolve attribution, but no matching scenario trajectory.'],
'test-003':['Desktop files versus travel photos: both filesystem organization, but shortcut exception and no actual moves differ from copy-only renaming/date fallback/city grouping.','Desktop grouping versus inbox labels: related organization theme, different entities, selection rules and authorized actions.','Desktop archive versus historical photo catalog: filename preservation overlaps, but date estimation and people grouping are distinct.'],
'test-004':['Morning packing versus rehearsal checklist: both restore a component, but timing deadline and evening-to-morning substitution differ.','Morning departure versus cycling commute: nearby daily-life theme, distinct route versus routine constraints.','Morning packing versus library registration: both time changes and restoration, but dependent scope differs.'],
'test-005':['Recipe scaling versus dance positions: subtask withdrawal/reopen is generic, not the same scene.','Recipe quantities versus email rules: unrelated domain and state values.','Recipe branch versus recruitment poster: cancellation is shared, content and requirements differ.'],
'test-006':['Pool large-print copy versus theater note: unresolved ownership is shared, but checklist substitution boundary and materials question differ.','Pool copy versus escape-room large-type hint card: both accessibility candidates, but the latter limits answer disclosure and changes puzzle digits, while the former preserves normal format and asks about paper.','Pool checklist versus shared dietary menu: multiple participants do not share task facts.'],
'test-007':['Vinyl editions versus ancestral photos: catalog theme overlaps; editions/inspection/unknown-year sorting differ from names, city/person grouping and date estimates.','Vinyl catalog versus live-stream Q&A: no common task beyond avoiding automatic merging.','Vinyl catalog versus software tests: no matching scenario despite checking terminology.'],
'test-008':['Fruit-tree observation versus compost observation: related scientific notebooks, but explicit no-intervention, bloom conditional and multi-tree identity differ from odor/temperature/photo-number rules.','Tree observations versus family photos: photos are evidence in both, but scope and transitions differ.','Tree observation versus photo organization: no same workflow or source facts.'],
'test-009':['Recursion explanation versus breadboard document: document-only boundary overlaps, but audience and cancellation differ.','Recursion examples versus oral-history directory: explanation questions shared, underlying output and record requirements differ.','Recursion teaching versus photo catalog: no substantive scenario match.'],
'test-010':['Room acoustic rug versus school outdoor venue: both reject a physical option, but household ownership/space/no-drilling constraints differ.','Acoustics versus photo catalog: uncertainty wording is generic.','Acoustics versus dataset provenance: no shared domain or intended deliverable.'],
'test-011':['Key-label privacy versus lost-property form privacy: address exclusion is common, but code representation/mapping separation differ from date/email fields.','Key labels versus pronunciation learning: unrelated decisions.','Keys versus weaving: portable artifact wording does not imply the same requirements.'],
'test-012':['Chores versus cat/plant handover: household theme and task separation overlap, but named participant assignments and a cancelled display copy differ from feeding/plant rules.','Chores versus allotment maps: owner isolation is generic.','Chores versus travel days: scheduling overlap, distinct cancellation and retained tasks.'],
'test-013':['Dream journal versus drone simulator: both optional feature discussions, but missing narrative and no interpretation differ from controls/camera settings.','Dream diary versus lost-property form: fields are common structure, but conditional missing recall and tentative mood rejection differ from contact policy.','Dream journal versus energy notebook: candidate field rejection shared, measured values versus subjective recall have different constraints.'],
'test-014':['Radio log versus property form: explicit fields but distinct quantities, privacy scope and question.','Radio reports versus oral-history quotations: fidelity rule shared, but UTC/local-time additions differ from booklet glossary restoration.','Radio log versus electricity notebook: measurements overlap, but timezone supplementation versus cumulative-value correction differs.'],
'test-015':['Decorative knots versus game teaching: instructional diagrams and official scopes are different from worked scoring examples/page limits.','Decorative knots versus bicycle checklist: cancel/reopen mechanism shared, but decorative-only safety scope and line-style requirement differ from metric/no-booking constraints.','Knots versus pet handover: no same scenario.'],
'test-016':['Appliance card versus board-game edit: named control correction and cancelled panel differ from card-name exception and discussion example.','Appliance card versus seedling packing: checklist component cancellation is common, but unplugging/manual-grounding differs from plant labels and restoring care inserts.','Appliance card versus email filter sandbox: no same artifacts or state evolution.'],
'test-017':['Rock catalog versus volunteer website: unknown-owner candidate and no-invented-content boundaries are shared, but photo column/mineral evidence/ID comparison differ from offline PDF and phone privacy.','Rock catalog versus public map: attribution-resolution pattern shared, mineral names/specimen IDs versus plot names/PDF differ.','Rock catalog versus animation: unknown-owner optional feature is generic, final events and constraints differ.'],
'test-018':['Browser groups versus recipe index: classification/fallback overlap, but pinned-tab exclusion, renamed review group and no automatic closing differ from ingredient-to-method grouping and multi-tag question.','Browser groups versus weaving: no task match.','Browser groups versus email sandbox: related digital organization, but project fallback/pinned tabs versus subject matches/TEST exception are different rules.'],
'test-019':['Camera exposure versus drone simulation: both retain a camera control, but real exposure-pair/ISO comparison differs from virtual device controls and checkpoint inspection.','Camera comparison versus astronomy event: visual observation theme only; club venue and weather backup are distinct.','Camera comparison versus tote pattern: explicit numeric controls alone do not identify a shared scenario.'],
'test-020':['Weather readings versus calendar reminders: shared daily times but missing-data policy and sketch restoration differ from quiet-hour fallback.','Weather diary versus zine print run: number changes and restoration are generic.','Weather readings versus meal rota: recurring schedule theme, but measurement missingness and sketch scope differ from leftovers/oven rules.'],
}
MANUAL=[
 ('dev-001','train-d-013','domain_overlap_distinct_scenario','Both involve sewing, but a sleeve-length correction with removable fitting stitches and cancelled explanation differs from a reversible tote, seam allowance, closure replacement and pocket cancellation. Domain-disjoint claims would be false.'),
 ('dev-003','train-d-021','workflow_overlap_distinct_scenario','Both are email classification workflows with a label rename and no deletion. Dev additionally revises tags-only to allow stars and distinguishes an archive explanation from adoption; train has TEST-subject exception, a second shipment rule and display-priority question. These are not mere name/number substitutions, but transfer is within a shared workflow.'),
 ('test-020','train-d-011','domain_overlap_distinct_scenario','Both are observation templates; weather diary missing-value handling and restored cloud sketches differ from compost odor conditions and withdrawn photo IDs. Measurement-log construction is shared.'),
 ('test-008','train-c-016','domain_overlap_distinct_scenario','Phenology observations and bird observations share natural-history logging; bloom condition/tree expansion/no interventions differ from withdrawing location while keeping date and precise-coordinate exclusion.'),
 ('test-018','dev-003','workflow_overlap_distinct_scenario','Browser grouping and mail triage are digital-organization tasks but differ in pinned exclusions/fallback groups versus subject conditions/star actions. Both resist assistant destructive-action suggestions.'),
]

def normalized_events(events):
 names={e['speaker'].lower() for e in events}
 t=' '.join(e['text'] for e in events if e['role']=='user')
 t=unicodedata.normalize('NFKC',t).lower()
 for n in sorted(names,key=len,reverse=True):t=t.replace(n,'PERSON')
 return re.sub(r'\d+(?:[./:]\d+)*','NUM',t)
def features(t):
 words=re.findall(r'[a-z]+',t);han=re.findall(r'[\u3400-\u9fff]+',t)
 return collections.Counter(['w:'+w for w in words]+['b:'+words[i]+' '+words[i+1] for i in range(len(words)-1)]+['z:'+s[i:i+2] for s in han for i in range(len(s)-1)])
def all_keys(x):
 if isinstance(x,dict):
  for k,v in x.items():yield k;yield from all_keys(v)
 elif isinstance(x,list):
  for v in x:yield from all_keys(v)

def main():
 source_paths=sorted((P/'data/source').glob('*.jsonl'));fault_paths=sorted((P/'data/faults').glob('*.json'))
 checked=source_paths+fault_paths+[P/'annotation/system_prompt.txt',P/'data/compiled/manifest.json',ROOT/'experiments/deep_conversation/intention_state.py',ROOT/'experiments/deep_conversation/tracker_lora/build_dataset.py']
 snapshots={str(p):sha(p.read_bytes()) for p in checked}
 families=[f for p in source_paths for f in readlines(p)];fm={f['family_id']:f for f in families};assert len(fm)==130
 faults={x['example_id']:x for p in fault_paths for x in json.loads(p.read_text(encoding='utf-8'))}
 assert len(faults)==65
 prompt=(P/'annotation/system_prompt.txt').read_text(encoding='utf-8').strip()
 rows=[]
 for f in families:
  for r in materialize(f,prompt):rows.append(apply_prior_fault(f,r,faults[r['example_id']],prompt) if r['example_id'] in faults else r)
 assert collections.Counter(r['split'] for r in rows)=={'train':500,'dev':50,'test':100}
 forbidden={'family_id','split','domain','scenario','tags','critical_checks','evidence_note','expected_post_state','expected_semantic_state','prior_fault_annotation','wrong_text','repair_text','rationale','example_id','authorship','provenance','metadata','previous_error'}
 row_checks=[]
 for r in rows:
  f=fm[r['family_id']];i=r['decision_index'];d=f['decisions'][i];packet=r['input'];cursor=d['through_seq']
  assert packet['conversation']==f['events'][:cursor+1]
  assert not (set(all_keys(packet))&forbidden)
  serialized=enc(packet).decode('utf-8')
  assert all(fid not in serialized for fid in fm)
  assert '.' not in serialized and '/data/source/' not in serialized
  assert r['sft']['prompt']==[{'role':'system','content':prompt},{'role':'user','content':enc(packet).decode('utf-8')}]
  assert r['sft']['completion']==[{'role':'assistant','content':enc(r['target']).decode('utf-8')}]
  assert packet['intention_state']['observed_event_seq']==cursor
  prev=f['decisions'][i-1]['through_seq'] if i else -1
  assert packet['intention_state']['processed_event_seq']==prev
  for intent in packet['intention_state']['intents']:
   assert max(intent['source_seqs'])<=prev
   for h in intent['history']:
    assert re.fullmatch(r'decision-\d+',h['patch_id'])
    assert max(h['source_seqs'])<=prev
  assert all(max(o['source_seqs'])<=cursor for o in r['target']['operations'])
  if r['example_id'] in faults:assert max(faults[r['example_id']]['repair_source_seqs'])<=prev
  row_checks.append(dict(example_id=r['example_id'],split=r['split'],input_sha256=sha(enc(packet)),target_sha256=sha(enc(r['target'])),prefix_and_scaffolding_checks='passed'))

 # A family remains in one split, and source prefixes are not reused across splits.
 def collisions(items):
  buckets=collections.defaultdict(list)
  for key,split,identifier in items:buckets[key].append((split,identifier))
  return [{'hash':k,'occurrences':v} for k,v in buckets.items() if len({s for s,_ in v})>1]
 exact_dialogue=collisions((sha(enc(f['events'])),f['split'],f['family_id']) for f in families)
 normalized_dialogue=collisions((sha(normalized_events(f['events']).encode()),f['split'],f['family_id']) for f in families)
 prefix=collisions((sha(normalized_events(r['input']['conversation']).encode()),r['split'],r['example_id']) for r in rows)
 exact_input=collisions((sha(enc(r['input'])),r['split'],r['example_id']) for r in rows)
 assert not exact_dialogue and not normalized_dialogue and not prefix and not exact_input

 # Check the actual disk exports against freshly replayed authoritative sources.
 disk=[]
 for split in ('train','dev','test'):
  selected=[r for r in rows if r['split']==split]
  for suffix,expected in [('records',[{k:v for k,v in r.items() if k!='sft'} for r in selected]),('sft',[r['sft'] for r in selected])]:
   path=P/f'data/compiled/{split}.{suffix}.jsonl';actual=readlines(path)
   assert actual==expected,(path,'compiled export is stale or inconsistent')
   snapshots[str(path)]=sha(path.read_bytes());disk.append(dict(path=str(path.relative_to(P)),rows=len(actual),sha256=snapshots[str(path)],fresh_source_equality=True))
 manifest=json.loads((P/'data/compiled/manifest.json').read_text(encoding='utf-8'))
 assert manifest['update_counts']=={'train':500,'dev':50,'test':100}
 assert manifest['status']=='approved_for_pilot'
 for name,record in manifest['files'].items():assert record['sha256']==sha((P/'data/compiled'/name).read_bytes())

 # Lexical shortlist: within-language sensitive, not a semantic embedding.
 ft={f['family_id']:features(normalized_events(f['events'])) for f in families}
 df=collections.Counter(k for c in ft.values() for k in c)
 vectors={fid:{k:(1+math.log(n))*math.log(1+len(families)/(1+df[k])) for k,n in c.items()} for fid,c in ft.items()}
 mags={fid:math.sqrt(sum(x*x for x in v.values())) for fid,v in vectors.items()}
 def sim(a,b):return sum(x*vectors[b].get(k,0) for k,x in vectors[a].items())/(mags[a]*mags[b])
 candidates=[]
 for f in families:
  if f['split']=='train':continue
  near=sorted([(sim(f['family_id'],g['family_id']),g) for g in families if g['split']!=f['split']],key=lambda x:-x[0])[:3]
  assert len(NOTES[f['family_id']])==3
  for rank,((score,g),note) in enumerate(zip(near,NOTES[f['family_id']]),1):
   candidates.append(dict(family_a=f['family_id'],family_b=g['family_id'],rank=rank,cosine=round(score,6),
    source_a_sha256=sha(enc(f)),source_b_sha256=sha(enc(g)),verdict='distinct_scenario_shared_mechanisms_possible',model_semantic_review=note,human_review=False))
 thematic=[dict(family_a=a,family_b=b,verdict=v,model_semantic_review=n,source_a_sha256=sha(enc(fm[a])),source_b_sha256=sha(enc(fm[b])),human_review=False) for a,b,v,n in MANUAL]
 old=P.parent/'tracker-lora-plan/data/examples.jsonl';old_checks={'file_exists':old.exists()}
 if old.exists():
  prior=readlines(old);old_norm={sha(normalized_events(x['input']['conversation']).encode()) for x in prior}
  overlaps=[r['example_id'] for r in rows if sha(normalized_events(r['input']['conversation']).encode()) in old_norm]
  assert not overlaps;old_checks.update(source_sha256=sha(old.read_bytes()),exposed_examples=len(prior),normalized_exact_prefix_matches=overlaps)
 op_signatures=collections.defaultdict(list)
 for f in families:
  signature=tuple(tuple(sorted(o['op'] for o in d['operations'])) for d in f['decisions'])
  op_signatures[signature].append(f['family_id'])
 shared_signatures=[dict(signature=s,families=ids) for s,ids in op_signatures.items() if len({fm[i]['split'] for i in ids})>1]
 for path,h in snapshots.items():assert sha(Path(path).read_bytes())==h,'File changed during audit: '+path
 report=dict(status='passed_structural_leakage_checks_with_generalization_limits',date='2026-10-24',timezone='America/Halifax',
  auditor='/root/tracker_corpus_a',independent_of_compiler_author=True,independent_of_all_corpus_authors=False,
  authorship_conflict='Auditor authored train-a and dev/test scenarios. This audit is not an independent gold-quality review; separate agent semantic reviews remain required.',human_review=False,
  counts=dict(families=130,updates=650,train=500,dev=50,test=100,prior_faults=65),
  methods=['Read-only replay of all current families and prior faults, with exact equality to all six on-disk record/SFT files.',
   'Exact source-prefix matching, arrived-evidence checks, previous-state cursor/history checks, strict metadata-key and neutral patch-ID checks on all 650 model inputs.',
   'Cross-split exact full-dialogue, normalized user-dialogue, normalized prefix and complete model-input collision checks. NFKC/lowercase, speaker-name replacement and numeric masking normalize names/numbers.',
   'TF-IDF cosine over English words/bigrams and Chinese character bigrams; three nearest foreign-split families per held-out family, 90 directed candidates, individually model-reviewed from raw dialogues.',
   'Five additional thematic/cross-language comparisons, including sewing and email workflows that lexical overlap misses.'],
  checks=dict(family_split_separation='passed',exact_cross_split_dialogue_collisions=exact_dialogue,normalized_cross_split_dialogue_collisions=normalized_dialogue,normalized_cross_split_prefix_collisions=prefix,exact_cross_split_input_collisions=exact_input,future_or_annotation_leakage_failures=0,disk_exports_fresh=True),
  manifest_sha256=sha((P/'data/compiled/manifest.json').read_bytes()),manifest_gate_status=manifest['status'],admission_sha256=manifest.get('admission_sha256'),
  disk_exports=disk,source_and_tool_hashes=snapshots,row_checks=row_checks,lexical_candidates=candidates,thematic_candidates=thematic,
  lexical_max_cross_split_cosine=max(c['cosine'] for c in candidates),shared_cross_split_operation_signatures=shared_signatures,original_24_exposed_check=old_checks,
  conclusion='No exact reuse or detected future/gold/scaffolding leakage in the pinned 650 exports. Reviewed candidates are different scenarios, but several share domains, workflows, operation patterns and synthetic authoring style. Treat results as family-held-out synthetic transfer, not domain-disjoint or real-user performance.',
  limitations=['No human semantic review occurred.','Lexical similarity is weak across languages and cannot rule out every semantic paraphrase; the thematic review is bounded rather than exhaustive cross-language embedding analysis.',
   'Both train and held-out data intentionally share intention-update mechanisms and several domains; arbitrary top-three selection is a diagnostic shortlist, not a proof of independence.',
   'All five prefixes from a family are correlated; 650 rows represent 130 scenario families.',
   'This checks export contents, not actual trainer completion-loss masks, token truncation, checkpoint selection, or whether a training process later accesses test data.',
   'Exact comparison with the earlier 24 exposed examples excludes literal normalized-prefix reuse, not all possible shared mechanisms or semantic motifs.',
   'The auditor authored some data, so source-quality independence must come from the separate reviewer admissions.'],
  new_model_inference_calls=0,source_mutations=0)
 (P/'audit/split-leakage-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'status':report['status'],'updates':650,'families':130,'lexical_candidates':len(candidates),'thematic_candidates':len(thematic),'max_cosine':report['lexical_max_cross_split_cosine'],'export_files_matched':len(disk),'shared_operation_signatures':len(shared_signatures)}))
if __name__=='__main__':main()
