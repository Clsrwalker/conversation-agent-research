"""Authoring conveniences only: no semantic scenario templates or expansion."""
from __future__ import annotations
import copy
import hashlib
import json
from pathlib import Path
import sys

ROOT = next(p for p in Path(__file__).resolve().parents if (p / 'experiments/deep_conversation/intention_state.py').exists())
sys.path.insert(0, str(ROOT / 'experiments/deep_conversation'))
from intention_state import IntentStore


def A(key, owner, text, status='active', sources=None):
    return dict(op='add', intent_id=key, owner=owner, text=text, status=status, source_seqs=sources)


def U(key, text=None, owner=None, status=None, sources=None):
    op = dict(op='update', intent_id=key, source_seqs=sources)
    op.update({k: v for k, v in dict(text=text, owner=owner, status=status).items() if v is not None})
    return op


def W(key, sources=None):
    return dict(op='withdraw', intent_id=key, source_seqs=sources)


def R(key, status='active', sources=None):
    return dict(op='reopen', intent_id=key, status=status, source_seqs=sources)


def step(messages, ops, note, checks):
    """Messages are (speaker, text) or (speaker, text, role); evidence stays explicit."""
    return messages, ops, note, checks


def family(identifier, split, language, domain, scenario, tags, steps):
    assert len(steps) == 5
    events, decisions = [], []
    with IntentStore(':memory:') as store:
        for ordinal, (messages, raw_ops, note, checks) in enumerate(steps):
            for message in messages:
                who, text, *role = message
                events.append(dict(seq=len(events), speaker=who, role=role[0] if role else 'user', text=text))
            through = events[-1]['seq']
            ops = copy.deepcopy(raw_ops)
            for op in ops:
                if op['source_seqs'] is None:
                    op['source_seqs'] = [through]
                else:
                    op['source_seqs'] = [through + s + 1 if s < 0 else s for s in op['source_seqs']]
            store.observe(events)
            before = store.snapshot()
            preserve = sorted({i['intent_id'] for i in before['intents']} - {op['intent_id'] for op in ops})
            store.commit_patch(f'decision-{ordinal}', before['version'], through, ops)
            decisions.append(dict(through_seq=through, operations=ops, evidence_note=note,
                                  critical_checks=checks, preserve_ids=preserve))
    return dict(family_id=identifier, split=split, language=language, domain=domain,
                scenario=scenario, tags=tags, events=events, decisions=decisions)


def save(filename, families):
    directory = Path(__file__).resolve().parent.parent
    path = directory / 'source' / filename
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(''.join(json.dumps(f, ensure_ascii=False, sort_keys=True) + '\n' for f in families), encoding='utf-8')
    check = {'kind': 'author self-check, not independent semantic review',
             'source': str(path.relative_to(directory)), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
             'families': len(families), 'decisions': sum(len(f['decisions']) for f in families),
             'runtime_replay': 'passed during authoring',
             'languages': {lang: sum(f['language'] == lang for f in families) for lang in ('zh', 'en')}}
    record = directory / 'authoring' / (path.stem + '-check.json')
    record.write_text(json.dumps(check, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(check))
