"""Serialize 25 individually authored fictional conversations; no content templates.

Helpers only allocate event/intent IDs, construct schema fields, replay state,
and write bookkeeping. Every dialogue and decision meaning below is authored.
"""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import sys

ROOT = next(p for p in Path(__file__).resolve().parents if (p/'experiments/deep_conversation/intention_state.py').exists())
HERE = Path(__file__).resolve().parent
OUT = HERE.parent/'source'
sys.path.insert(0, str(ROOT/'experiments/deep_conversation'))
from intention_state import IntentStore

def add(i, owner, text, seqs, status='active'):
    return dict(op='add', intent_id=f'i{i}', owner=owner, text=text, source_seqs=seqs, status=status)

def update(i, seqs, **fields):
    return dict(op='update', intent_id=f'i{i}', source_seqs=seqs, **fields)

def withdraw(i, seqs):
    return dict(op='withdraw', intent_id=f'i{i}', source_seqs=seqs)

def reopen(i, seqs):
    return dict(op='reopen', intent_id=f'i{i}', source_seqs=seqs)

FAMILIES = []

def family(n, language, domain, scenario, tags, dialogue, decisions):
    events = [dict(seq=i, speaker=s, role=('assistant' if s=='Assistant' else 'user'), text=t) for i,(s,t) in enumerate(dialogue)]
    records = []
    with IntentStore(':memory:') as store:
        for ordinal, (through, operations, note, checks) in enumerate(decisions):
            store.observe([e for e in events if e['seq']<=through])
            before = store.snapshot()
            touched = {x['intent_id'] for x in operations}
            preserve = [x['intent_id'] for x in before['intents'] if x['intent_id'] not in touched]
            store.commit_patch(f'setup-{ordinal}', before['version'], through, operations)
            records.append(dict(through_seq=through, operations=operations, evidence_note=note, preserve_ids=preserve, critical_checks=checks))
    FAMILIES.append(dict(family_id=f'train-b-{n:03d}', split='train', language=language, domain=domain, scenario=scenario, tags=tags, events=events, decisions=records))

family(1,'zh','科研复现协作','两位研究者协调复现报告的指标与各自附录，助理建议未自动采纳。',
 ['retention','multi_owner','proposal_not_adopted','local_revision','long_history'],[
 ('季然','帮我整理这次图分类复现的实验报告，训练随机种子固定为17，结果先报准确率。'),
 ('Assistant','我建议顺便增加一个跨数据集迁移实验。'),
 ('季然','这个提议我记下了，现在先不增加实验。'),
 ('季然','类别分布太偏了，把报告里的主指标换成宏平均F1，种子不变。'),
 ('Assistant','已记录宏平均F1这个说法。'),
 ('孟晴','我的附录需要单独列出训练用时，不要把它算进季然的主指标里。'),
 ('孟晴','只是补充我的附录要求。'),
 ('Assistant','那份运行日志还在读取中。'),
 ('季然','报告再补一段数据集获取方式；不用等读取结束才记这个要求。')],[
 (0,[add(1,'季然','整理图分类复现实验报告',[0]),add(2,'季然','复现实验训练随机种子固定为17',[0]),add(3,'季然','复现报告主指标使用准确率',[0])],'首次报告任务与两个独立约束。',['种子与主指标分别可修改。']),
 (2,[],'跨数据集实验仅是助理提议，用户明确不增加。',['不增加迁移实验；保留已有三项。']),
 (4,[update(3,[3],text='复现报告主指标使用宏平均F1')],'只修改主指标；助理复述不增加要求。',['固定种子17不变。']),
 (6,[add(4,'孟晴','孟晴的附录单独列出训练用时，不作为季然的主指标',[5])],'孟晴添加自己的附录需求。',['不可将附录归给季然或替换主指标。']),
 (8,[add(5,'季然','复现报告补充数据集获取方式说明',[8])],'读取未完成不影响新意图登记。',['保留两位研究者的需求；日志状态不等于完成。'])])

family(2,'zh','学校科技活动','科技展示由未定的室外候选转向确定室内方案，并处理家长问答。',
 ['uncertain','withdrawal','new_question','combined_change'],[
 ('周老师','帮我做四年级科技展示的活动方案，学生参加不能收报名费。'),
 ('周老师','我可能想把展示放在操场，还没决定；先留这个候选。'),
 ('Assistant','操场方案有天气风险。'),
 ('周老师','操场就不要了，明确改用学校图书馆。'),
 ('周老师','家长问我：电池实验和磁铁实验哪个更适合十分钟展示？帮我比较一下。'),
 ('周老师','对，方案还是不收报名费，这点没有变。')],[
 (0,[add(1,'周老师','制定四年级科技展示活动方案',[0]),add(2,'周老师','科技展示不向学生收报名费',[0])],'活动和免费参加约束均明确。',['费用约束独立保留。']),
 (1,[add(3,'周老师','科技展示可能设在操场，地点采用与否尚未确定',[1],'uncertain')],'明确提出尚未采用的场地候选。',['不能把操场写为确定场地。']),
 (3,[withdraw(3,[3]),add(4,'周老师','科技展示场地使用学校图书馆',[3])],'否决操场候选并确定不同地点；保留候选历史。',['操场记录withdrawn；图书馆active。']),
 (4,[add(5,'周老师','比较电池实验和磁铁实验对十分钟科技展示的适用性',[4])],'用户代转问题并明确请求助手比较，属于新的信息请求。',['不能因为活动地点不变而空操作。']),
 (5,[],'重复确认已存在的免费参加要求。',['不重复添加报名费约束。'])])

family(3,'zh','编辑出版','通讯编辑保留篇幅上限，在延期、广告撤销与恢复之间维护相同记录。',
 ['withdrawal','reopen','retention','quotation','long_history'],[
 ('方编辑','请拟本期社团通讯的编排表，周四发布，全文最多1800字，要留一块赞助商鸣谢。'),
 ('Assistant','有人在旧刊里写过“每篇越长越好”。'),
 ('方编辑','那是旧刊引用，不是本期要求，仍按刚才的字数上限。'),
 ('方编辑','发布推迟到周五，篇幅别跟着增加。'),
 ('方编辑','赞助商鸣谢暂时撤掉。'),
 ('Assistant','好的，鸣谢记录留在历史里。'),
 ('方编辑','负责人确认后又需要鸣谢了，恢复刚才那一块，内容范围原样。'),
 ('Assistant','已收到恢复的要求。')],[
 (0,[add(1,'方编辑','拟定本期社团通讯编排表',[0]),add(2,'方编辑','本期社团通讯周四发布',[0]),add(3,'方编辑','本期社团通讯全文不超过1800字',[0]),add(4,'方编辑','本期社团通讯保留一块赞助商鸣谢',[0])],'分别登记任务、日期、篇幅和鸣谢。',['不要合并独立可撤销的鸣谢与主任务。']),
 (2,[],'旧刊引文被明确否认为当前要求。',['1800字上限维持。']),
 (3,[update(2,[3],text='本期社团通讯周五发布')],'只将发布日期推迟。',['篇幅、鸣谢和编排任务保持。']),
 (5,[withdraw(4,[4])],'用户暂时撤销鸣谢；助理确认不另建意图。',['鸣谢历史保留，不能删除主任务。']),
 (7,[reopen(4,[6])],'恢复内容完全相同的鸣谢，沿用i4。',['不是创建新鸣谢记录。'])])

family(4,'zh','论文文档排版','论文排版约束修改与字体授权信息请求共存。',
 ['new_question','local_revision','retention','no_change'],[
 ('赵禾','帮我排这份论文，用A4纸，参考文献按APA格式。'),
 ('赵禾','另帮我解释一下：把开源字体嵌入PDF和把字体文件附在附件里，授权上有什么区别？'),
 ('赵禾','正文每页都要显示行号，参考文献页不用。'),
 ('赵禾','导师要求参考文献改成顺序编码制，其他排版要求不动。'),
 ('赵禾','谢谢，刚才的要求都先保持。')],[
 (0,[add(1,'赵禾','排版论文文档',[0]),add(2,'赵禾','论文使用A4纸',[0]),add(3,'赵禾','论文参考文献使用APA格式',[0])],'首次排版任务和明确格式。',['纸张与引文样式分别保留。']),
 (1,[add(4,'赵禾','解释开源字体嵌入PDF与附送字体文件的授权区别',[1])],'新增解释请求，不是替换排版任务。',['这是新问题，不能标成no-op。']),
 (2,[add(5,'赵禾','论文正文每页显示行号，参考文献页不显示行号',[2])],'行号是一个带范围排除的约束。',['不得把行号扩展到参考文献页。']),
 (3,[update(3,[3],text='论文参考文献使用顺序编码制')],'修改引用规范，不改其他要求。',['保留A4、行号范围及授权问题。']),
 (4,[],'感谢和维持原要求不产生修改。',['不得自动标论文排版完成。'])])

family(5,'zh','语言学习','西语口语练习采用助理提出的听说方案后改变纠错时机。',
 ['proposal_acceptance','proposal_not_adopted','withdrawal','long_history'],[
 ('叶舟','给我安排A2程度的西班牙语练习，错误等我说完一整段再指出。'),
 ('Assistant','我还可以要求每天写一篇长作文。'),
 ('叶舟','先不加作文，维持口头练习。'),
 ('Assistant','也可以把练习设为只听和说，不展示书面题目。'),
 ('叶舟','这个只听和说的版本就采用。'),
 ('叶舟','纠错方式改一下：我每说完一句就指出错误，不用等整段。'),
 ('Assistant','明白，按句子纠错。'),
 ('叶舟','只听和说的限制取消，我还是想保留阅读题出现的可能。')],[
 (0,[add(1,'叶舟','安排A2程度的西班牙语口语练习',[0]),add(2,'叶舟','西语练习等学习者说完一整段后再指出错误',[0])],'首轮确定口语任务和纠错时机。',['A2程度不能丢。']),
 (2,[],'用户不接受作文提议，也未改变已有口语任务。',['不能增加作文。']),
 (4,[add(3,'叶舟','西语练习只听和说，不展示书面题目',[3,4])],'接受有明确前文的只听说方案，证据需提案与接受。',['不能只引用“这个”而丢失所指。']),
 (6,[update(2,[5],text='西语练习每说完一句后就指出错误')],'纠错粒度从整段改为每句。',['i3听说限制此时仍有效。']),
 (7,[withdraw(3,[7])],'撤销只听说限制；允许阅读并不要求一定安排阅读。',['不要新增必须阅读的义务。'])])

family(6,'zh','展览策划','无闪烁展览中两人的无障碍需要被分别确认与保留。',
 ['owner_uncertainty','multi_owner','uncertain_to_active','retention','long_history'],[
 ('夏宁','请设计一段陶器展的参观路线，我需要能触摸的复制品，整个展区不要闪烁灯光。'),
 ('Assistant','复制品可以放在路线中段。'),
 ('夏宁','我们可能还要字幕，但现在不知道是谁需要，也不确定是否必须。'),
 ('夏宁','字幕这件事确认了，是我需要，所有播放的视频都必须有字幕。'),
 ('Assistant','字幕需求已明确归属。'),
 ('阿洛','我自己需要每个展柜配一段语音讲解，别把它当作夏宁的需求。'),
 ('Assistant','我可以同时保留两人的记录。'),
 ('夏宁','复制品那项先取消，字幕和不闪烁的要求还在。'),
 ('阿洛','我的语音讲解也照旧。')],[
 (0,[add(1,'夏宁','设计陶器展参观路线',[0]),add(2,'夏宁','陶器展提供可触摸的复制品',[0]),add(3,'夏宁','陶器展整个展区不使用闪烁灯光',[0])],'主任务与两个独立无障碍约束。',['不要把灯光约束限定为复制品区域。']),
 (2,[add(4,'__unresolved__','陶器展可能需要字幕；采用与否及需求归属待确认',[2],'uncertain')],'具体候选存在，但用户明确不知道owner和必要性。',['不可猜测团队归属。']),
 (4,[update(4,[3],owner='夏宁',text='陶器展播放的所有视频必须有字幕',status='active')],'同一候选在明确归属与采用后升级。',['沿用i4，不再留重复候选。']),
 (6,[add(5,'阿洛','陶器展每个展柜配一段语音讲解',[5])],'阿洛提出自己的明确需求。',['阿洛不是字幕需求owner。']),
 (8,[withdraw(2,[7])],'仅取消复制品；第8句重申而无新变更。',['字幕、不闪烁和阿洛语音讲解全部保留。'])])

family(7,'zh','客服流程','退款脚本保留人工批准，时间窗口调整不被助理声称执行所影响。',
 ['retention','execution_not_intent','quotation','local_revision'],[
 ('白荻','帮我写一份虚构文具店的退款客服流程：购买后30天内可申请，任何退款都必须先由人工批准。'),
 ('白荻','拆封过的商品再加一步：转交质检专员判断。'),
 ('Assistant','流程已经全部处理完成了。'),
 ('Assistant','培训材料里另有一句“自动退款让客户更开心”。'),
 ('白荻','那只是培训材料里的引文，我没有同意自动退款。'),
 ('白荻','申请窗口从30天缩到14天，人工批准和拆封品转交都照旧。')],[
 (0,[add(1,'白荻','撰写虚构文具店退款客服流程',[0]),add(2,'白荻','购买后30天内可申请退款',[0]),add(3,'白荻','任何退款先经人工批准',[0])],'分开窗口与人工批准条件。',['退款流程只是编写任务，不执行真实退款。']),
 (1,[add(4,'白荻','拆封商品退款申请转交质检专员判断',[1])],'带条件的确定流程要求。',['只对拆封商品适用。']),
 (2,[],'助理声称完成不撤销用户意图。',['不能withdraw全部记录。']),
 (4,[],'用户明确未接受自动退款引文。',['人工批准仍为active。']),
 (5,[update(2,[5],text='购买后14天内可申请退款')],'只改变申请窗口。',['质检转交和人工批准必须保留。'])])

family(8,'zh','音频字幕制作','播客字幕的填充词与时间码方案分别变化，未采纳的配乐不进入任务。',
 ['combined_change','proposal_not_adopted','retention','long_history'],[
 ('唐音','请为这期天文播客制作中文字幕，听不清的地方标成“听不清”，不要自行补词。'),
 ('唐音','时间码每30秒一个。'),
 ('Assistant','我建议加一段背景音乐。'),
 ('唐音','不加背景音乐，这次只处理字幕。'),
 ('唐音','把时间码改成每位发言人开始说话时标一次；口头的“嗯”“啊”可以删掉。'),
 ('Assistant','这会影响字幕的逐字程度。'),
 ('唐音','对，删掉纯填充词这个决定是确定的。'),
 ('唐音','刚才删填充词的要求取消，还是逐字保留；时间码的改法别退回去。'),
 ('唐音','其他内容按原来的字幕任务继续。')],[
 (0,[add(1,'唐音','为天文播客制作中文字幕',[0]),add(2,'唐音','字幕听不清之处标注“听不清”，不自行补词',[0])],'字幕任务和不猜测限制。',['中文目标不丢失。']),
 (1,[add(3,'唐音','播客字幕每30秒标一个时间码',[1])],'时间码频率作为独立约束。',['不影响不猜词约束。']),
 (3,[],'拒绝尚未采纳的配乐建议不需要撤销不存在的记录。',['不新增配乐意图。']),
 (6,[update(3,[4],text='播客字幕每位发言人开始说话时标一个时间码'),add(4,'唐音','播客字幕可删除纯口头填充词“嗯”“啊”',[4])],'同一句含时间码修改和允许省略填充词，后句确认无额外变更。',['可删是许可，不是必须删。']),
 (8,[update(4,[7],text='播客字幕逐字保留口头填充词“嗯”“啊”')],'用户不仅取消许可，而且明确要求逐字保留，更新同一规则。',['时间码维持按发言人起句。'])])

family(9,'zh','虚构招聘流程设计','面试练习流程分别修改技术题与候选人问答，保留匿名评分。',
 ['multi_task','combined_change','new_question','retention'],[
 ('陆策','设计一个虚构招聘练习流程，技术题环节20分钟，评分表只用候选人编号，不写姓名。'),
 ('陆策','再加一个候选人提问环节，留10分钟。'),
 ('陆策','技术题缩到15分钟，提问环节延到15分钟，匿名评分不能变。'),
 ('陆策','顺便解释一下，结构化评分表和面试官自由笔记各有什么局限？'),
 ('陆策','提问环节先取消，技术题的15分钟还保留。')],[
 (0,[add(1,'陆策','设计虚构招聘练习流程',[0]),add(2,'陆策','招聘练习技术题环节20分钟',[0]),add(3,'陆策','评分表只使用候选人编号，不写姓名',[0])],'无真实个人数据，记录练习流程约束。',['匿名评分独立于环节长度。']),
 (1,[add(4,'陆策','招聘练习候选人提问环节10分钟',[1])],'新环节及其时间作为单一环节要求。',['保留技术题时间。']),
 (2,[update(2,[2],text='招聘练习技术题环节15分钟'),update(4,[2],text='招聘练习候选人提问环节15分钟')],'一次修改两个不同环节。',['不改匿名评分。']),
 (3,[add(5,'陆策','解释结构化评分表与面试官自由笔记各自的局限',[3])],'新比较信息请求。',['不可因主流程未改而no-op。']),
 (4,[withdraw(4,[4])],'明确取消提问环节。',['不能撤销技术题或比较问题。'])])

family(10,'zh','软件测试计划','测试矩阵有条件的浏览器要求和延迟恢复的导出验证。',
 ['conditional_active','withdrawal','reopen','long_history'],[
 ('何璟','写一个离线笔记应用的测试计划，先包含导出文件的完整性检查。'),
 ('何璟','如果发布Web版，就必须测试Firefox；这条条件要求现在就确定。'),
 ('Assistant','也可以把所有浏览器都测一遍。'),
 ('何璟','全浏览器的建议先不采用。'),
 ('何璟','导出完整性这项暂停，不放进本轮计划。'),
 ('Assistant','本地启动检查已经跑过。'),
 ('何璟','知道了，启动检查不改变我刚才的范围。'),
 ('何璟','恢复导出文件完整性检查，检查内容和原来一样。'),
 ('Assistant','收到恢复要求。')],[
 (0,[add(1,'何璟','撰写离线笔记应用测试计划',[0]),add(2,'何璟','测试计划包含导出文件完整性检查',[0])],'确定主任务和导出检查。',['不是立即执行部署。']),
 (1,[add(3,'何璟','若发布Web版，测试计划必须包含Firefox测试',[1])],'条件本身已确定，因此active而非uncertain。',['不能去掉Web版条件。']),
 (3,[],'全浏览器提议未接受。',['不扩展到所有浏览器。']),
 (6,[withdraw(2,[4])],'暂停对应本轮范围的撤销；启动结果不恢复它。',['条件Firefox要求仍有效。']),
 (8,[reopen(2,[7])],'同内容显式恢复，沿用ID。',['不产生重复导出检查。'])])

family(11,'zh','软件部署计划','部署文档取消自动执行并改变回退触发阈值，独立记录另一人的检查需求。',
 ['multi_owner','local_revision','retention','no_change'],[
 ('戴澄','帮我写一个演练环境的部署步骤，默认先人工确认再切流，错误率超过2%就回退。'),
 ('袁沐','我的检查清单需要记录部署前后的配置差异。'),
 ('Assistant','为了省事，可以直接自动切流。'),
 ('戴澄','不用，人工确认这条保持。'),
 ('戴澄','回退阈值改成错误率超过1%；只是改文档，不要真的切流。'),
 ('袁沐','配置差异那项仍是我的需求，没有交给戴澄。')],[
 (0,[add(1,'戴澄','编写演练环境部署步骤',[0]),add(2,'戴澄','部署切流前必须人工确认',[0]),add(3,'戴澄','部署错误率超过2%时回退',[0])],'三项明确文档任务要求。',['阈值严格超过，而非大于等于。']),
 (1,[add(4,'袁沐','袁沐的检查清单记录部署前后的配置差异',[1])],'独立owner的新需求。',['不归给戴澄。']),
 (3,[],'不接受自动切流建议，人工确认已有记录无需更新。',['保留i2原样。']),
 (4,[update(3,[4],text='部署错误率超过1%时回退'),add(5,'戴澄','此次只修改部署文档，不实际执行切流',[4])],'阈值修改与执行范围限制同时发生。',['1%阈值不改变人工确认要求。']),
 (5,[],'袁沐重申已正确记录的归属。',['不能转移i4的owner。'])])

family(12,'zh','研究数据说明','数据卡从潜在双语需求到取消，分离数据描述与许可解释问题。',
 ['uncertain_to_withdrawn','new_question','scope_revision','long_history'],[
 ('沈弦','帮我给虚构的鸟鸣数据集写一张数据卡，明确样本只来自模拟录音。'),
 ('沈弦','我可能需要中英双语版，但还没决定，先作为候选。'),
 ('Assistant','我建议加真实野外采集地点。'),
 ('沈弦','不加，数据全部是模拟的。'),
 ('沈弦','双语候选不用了，只做中文数据卡。'),
 ('沈弦','另解释一下：数据的使用许可和录音生成程序的许可为什么要分别列？'),
 ('Assistant','我会把这个解释问题分开看。'),
 ('沈弦','数据卡的适用范围改写清楚：只用于方法演示，不用于物种分布推断。'),
 ('沈弦','模拟来源这一点继续保留。')],[
 (0,[add(1,'沈弦','为虚构鸟鸣数据集编写数据卡',[0]),add(2,'沈弦','数据卡明确样本全部来自模拟录音',[0])],'说明真实性范围而不编造实地来源。',['不把模拟数据说成真实鸟类记录。']),
 (1,[add(3,'沈弦','数据卡可能制作中英双语版，采用与否未定',[1],'uncertain')],'已知owner的具体候选。',['不得升级为active双语要求。']),
 (4,[withdraw(3,[4]),add(4,'沈弦','数据卡只制作中文版本',[4])],'明确取消双语候选，同时确定中文限定；中间建议被拒。',['不得添加真实采集地点。']),
 (6,[add(5,'沈弦','解释数据使用许可与录音生成程序许可需要分别列明的原因',[5])],'这是新增解释请求。',['解释请求不替代数据卡。']),
 (8,[add(6,'沈弦','数据卡明确数据只用于方法演示，不用于物种分布推断',[7])],'之前未有适用范围条目，尽管用户说改写也应add。',['保留模拟来源与中文版本。'])])

family(13,'en','research collaboration','A preregistration outline separates a primary endpoint, an optional analysis and a colleague’s appendix.',
 ['retention','uncertain_to_active','multi_owner','local_revision'],[
 ('Nora','Draft the preregistration outline for our fictional maze study. Make completion time the primary endpoint, and keep the analysis plan blinded to group names.'),
 ('Nora','I might want an error-count analysis as well, but I have not committed to it.'),
 ('Eli','For my appendix, I need a diagram of the randomization process.'),
 ('Nora','I have decided to include that error-count analysis as a secondary endpoint.'),
 ('Nora','Change the primary endpoint to successful completion proportion. Keep the secondary endpoint and the blinding rule.')],[
 (0,[add(1,'Nora','Draft the fictional maze-study preregistration outline',[0]),add(2,'Nora','Use completion time as the primary endpoint',[0]),add(3,'Nora','Keep the analysis plan blinded to group names',[0])],'Initial task with independent endpoint and blinding requirements.',['Blinding must survive endpoint changes.']),
 (1,[add(4,'Nora','Possible error-count analysis; inclusion not yet decided',[1],'uncertain')],'A concrete self-owned candidate is expressed.',['Do not make error count a settled endpoint yet.']),
 (2,[add(5,'Eli','Include a randomization-process diagram in Eli’s appendix',[2])],'Eli owns the separate appendix need.',['Do not attribute the diagram to Nora.']),
 (3,[update(4,[3],text='Include error-count analysis as a secondary endpoint',status='active')],'The same candidate becomes an adopted secondary endpoint.',['Retain i4 rather than duplicating it.']),
 (4,[update(2,[4],text='Use successful completion proportion as the primary endpoint')],'Only the primary endpoint is replaced.',['Keep secondary endpoint, blinding and Eli’s appendix.'])])

family(14,'en','school activity planning','A school theatre workshop changes participation format while preserving a no-audition rule.',
 ['proposal_not_adopted','combined_change','new_question','long_history'],[
 ('Rae','Plan a school theatre workshop open to all pupils, with no auditions. It should end with a short live performance.'),
 ('Assistant','An audition might make casting easier.'),
 ('Rae','That is just an option you suggested; I am keeping open participation.'),
 ('Rae','Replace the live performance with an audio drama, and add a session on making sound effects.'),
 ('Assistant','The performance format has changed.'),
 ('Rae','What are two ways to let pupils who do not want speaking parts contribute? Please explain the trade-offs.'),
 ('Assistant','I will consider that question.'),
 ('Rae','The no-audition rule still stands. Thanks.')],[
 (0,[add(1,'Rae','Plan a school theatre workshop open to all pupils',[0]),add(2,'Rae','Do not require auditions for the school theatre workshop',[0]),add(3,'Rae','End the theatre workshop with a short live performance',[0])],'Open participation and no auditions are explicit, with a separate final format.',['Do not infer selective casting.']),
 (2,[],'The suggested audition is not adopted.',['Keep no-audition requirement.']),
 (4,[update(3,[3],text='End the theatre workshop with an audio drama'),add(4,'Rae','Include a session on making sound effects in the workshop',[3])],'Format replacement and a new session occur together.',['Keep open participation.']),
 (6,[add(5,'Rae','Explain the trade-offs of two ways pupils without speaking parts can contribute',[5])],'A new actionable information request, not a participation-rule change.',['Do not omit the question.']),
 (7,[],'Reaffirms an existing rule and thanks the assistant.',['No duplicate no-audition record.'])])

family(15,'en','editorial publishing','An oral-history booklet retains exact quotations as editorial scope changes.',
 ['quotation','retention','withdrawal','reopen'],[
 ('Mara','Prepare an editing checklist for a fictional oral-history booklet. Keep quoted speech verbatim and include a glossary of local terms.'),
 ('Mara','A sample interview says, “rewrite everything in formal English.” That is the interviewee quoting an old teacher, not an instruction for this booklet.'),
 ('Mara','Drop the glossary from this edition; there is no space for it.'),
 ('Mara','Add a check that every photograph has a caption.'),
 ('Mara','We found extra pages. Restore the local-terms glossary exactly as originally planned.')],[
 (0,[add(1,'Mara','Prepare an editing checklist for the fictional oral-history booklet',[0]),add(2,'Mara','Keep quoted speech verbatim in the booklet',[0]),add(3,'Mara','Include a glossary of local terms in the booklet',[0])],'Task, quotation fidelity and glossary are independent.',['Do not normalize quotations into formal English.']),
 (1,[],'An explicitly disclaimed nested quotation is not an editorial requirement.',['Preserve verbatim speech.']),
 (2,[withdraw(3,[2])],'Remove glossary from current edition while keeping history.',['Do not cancel the editing checklist.']),
 (3,[add(4,'Mara','Check that every booklet photograph has a caption',[3])],'Adds a caption check.',['Verbatim quotation rule remains active.']),
 (4,[reopen(3,[4])],'Restores precisely the original glossary content.',['Same glossary ID must be reused.'])])

family(16,'en','document accessibility','A public handout separates accessible reading order, color and downloadable format decisions.',
 ['local_revision','proposal_acceptance','retention','no_change'],[
 ('Theo','Lay out the fictional museum handout as a two-column PDF. The reading order must remain correct for screen readers.'),
 ('Assistant','A single-column version could reduce reading-order mistakes.'),
 ('Theo','Use that single-column version, then. Keep the screen-reader requirement.'),
 ('Theo','Do not rely on color alone to distinguish the routes on the map.'),
 ('Theo','Also provide an editable source document along with the PDF.'),
 ('Theo','Yes, editable source plus PDF; I am only restating what I just asked.')],[
 (0,[add(1,'Theo','Lay out the fictional museum handout as a PDF',[0]),add(2,'Theo','Use a two-column layout for the museum handout',[0]),add(3,'Theo','Preserve correct screen-reader reading order in the handout',[0])],'PDF deliverable, layout choice and accessibility requirement are separate.',['Accessibility must not disappear with layout change.']),
 (2,[update(2,[1,2],text='Use a single-column layout for the museum handout')],'Elliptical adoption refers to the assistant’s proposed layout.',['Cite proposal and acceptance.']),
 (3,[add(4,'Theo','Do not distinguish routes in the handout map by color alone',[3])],'New accessible-map constraint.',['Do not turn this into a ban on all color.']),
 (4,[add(5,'Theo','Provide an editable source document along with the handout PDF',[4])],'Additional deliverable, not a replacement for PDF.',['PDF requirement stays active.']),
 (5,[],'Explicit restatement adds nothing.',['Do not duplicate editable-source requirement.'])])

family(17,'en','language learning','Pronunciation coaching keeps learner preferences separate from a tutor’s unaccepted homework suggestion.',
 ['uncertain_to_withdrawn','new_question','retention','long_history'],[
 ('Imani','Design short English pronunciation practice for me. Use workplace conversations, and avoid scoring me with a numeric accent rating.'),
 ('Assistant','You could memorize a poem as homework.'),
 ('Imani','I am not adopting the poem exercise.'),
 ('Imani','I might want recordings of my attempts, but I have not decided whether to include recording.'),
 ('Assistant','Recording could support later comparison.'),
 ('Imani','No recording after all; remove that tentative idea.'),
 ('Imani','Can you explain how word stress differs from sentence stress?'),
 ('Assistant','That is a distinct explanation request.'),
 ('Imani','Exactly. Keep the workplace situations and the no-rating preference.')],[
 (0,[add(1,'Imani','Design short English pronunciation practice',[0]),add(2,'Imani','Use workplace conversations in the pronunciation practice',[0]),add(3,'Imani','Avoid numeric accent ratings in the pronunciation practice',[0])],'Three settled needs; ratings are specifically numeric accent ratings.',['Do not remove all feedback.']),
 (2,[],'Poem homework was never accepted.',['No poem request is created.']),
 (4,[add(4,'Imani','Possible recording of pronunciation attempts; adoption undecided',[3],'uncertain')],'Self-owned concrete candidate remains uncertain despite assistant endorsement.',['Assistant cannot activate candidate.']),
 (5,[withdraw(4,[5])],'Explicit rejection removes the tentative idea.',['Keep workplace context and no-rating preference.']),
 (8,[add(5,'Imani','Explain the difference between word stress and sentence stress',[6])],'Information request is new; later acknowledgement is no extra change.',['Do not lose the explanatory question.'])])

family(18,'en','exhibition curation','An exhibition route changes its opening object without transferring ownership of a separate reading-level request.',
 ['multi_owner','combined_change','retention','proposal_not_adopted'],[
 ('Luca','Draft the route for our fictional printing exhibition. Start with the wooden press, and keep the route step-free.'),
 ('Sana','I need the labels written for readers around age twelve. That is my request, separate from Luca’s route choices.'),
 ('Assistant','I could make the route start upstairs to use a larger room.'),
 ('Luca','Do not adopt the upstairs idea.'),
 ('Luca','Start with the type case instead of the wooden press, and add a stop where visitors can handle replica type.'),
 ('Sana','Keep my label-reading level as it was; I have no further changes.')],[
 (0,[add(1,'Luca','Draft the route for the fictional printing exhibition',[0]),add(2,'Luca','Start the printing exhibition route with the wooden press',[0]),add(3,'Luca','Keep the exhibition route step-free',[0])],'Route opening and accessibility separately tracked.',['Step-free persists if opening changes.']),
 (1,[add(4,'Sana','Write exhibition labels for readers around age twelve',[1])],'Sana owns reading-level requirement.',['Do not attach it to Luca.']),
 (3,[],'Unaccepted upstairs idea adds no requirement.',['Do not weaken step-free access.']),
 (4,[update(2,[4],text='Start the printing exhibition route with the type case'),add(5,'Luca','Include a route stop where visitors can handle replica type',[4])],'Change first object and add a hands-on stop.',['Preserve step-free route and Sana’s labels.']),
 (5,[],'No further changes, explicit restatement of known requirement.',['Label owner remains Sana.'])])

family(19,'en','customer support process','A support playbook distinguishes promised reply times from a tentative weekend channel.',
 ['uncertain_to_active','local_revision','conditional_active','retention'],[
 ('Owen','Write a support playbook for a fictional puzzle shop. Promise an initial reply within two working days, not a guaranteed resolution.'),
 ('Owen','I may want a weekend chat channel; it is only a possibility for now.'),
 ('Owen','If an order is marked delivered but missing, the playbook must escalate it to a person. That conditional rule is settled.'),
 ('Owen','We have decided to include the weekend chat channel, but describe it as staffed only on Saturday mornings.'),
 ('Owen','Make the initial-reply target one working day. Do not change the escalation rule or turn it into a resolution deadline.')],[
 (0,[add(1,'Owen','Write the fictional puzzle-shop support playbook',[0]),add(2,'Owen','Promise an initial reply within two working days, not a guaranteed resolution',[0])],'Reply commitment includes explicit distinction from resolution.',['Do not claim guaranteed resolution.']),
 (1,[add(3,'Owen','Possible weekend support chat channel; adoption undecided',[1],'uncertain')],'Candidate is concrete but not adopted.',['Keep uncertain status.']),
 (2,[add(4,'Owen','Escalate to a person when an order is marked delivered but reported missing',[2])],'Settled conditional rule is active.',['Preserve both conditions of escalation trigger.']),
 (3,[update(3,[3],text='Include weekend support chat staffed only on Saturday mornings',status='active')],'Adoption resolves candidate with an explicit staffing limit.',['Do not infer Sunday availability.']),
 (4,[update(2,[4],text='Promise an initial reply within one working day, not a guaranteed resolution')],'Only response-time value changes.',['Keep non-resolution qualifier and escalation.'])])

family(20,'en','audio caption editing','A training-video transcript changes speaker labels and preserves uncertainty markers despite a producer’s quote.',
 ['quotation','local_revision','new_question','long_history'],[
 ('Aster','Create captions for this fictional workshop video. Identify speakers as Host and Guest, and mark unclear words rather than guessing.'),
 ('Assistant','A producer once wrote, “smooth out every hesitation and invent the missing words.”'),
 ('Aster','That quotation is not a direction for this video.'),
 ('Aster','Change the speaker labels to Presenter and Participant. The rule about unclear words stays.'),
 ('Assistant','The labels can be changed without altering the transcript policy.'),
 ('Aster','Add descriptions for important non-speech sounds, such as an alarm or applause.'),
 ('Aster','What is the difference between subtitles for translation and captions that include sound information?'),
 ('Assistant','I have received that question.'),
 ('Aster','Thanks, no further changes.')],[
 (0,[add(1,'Aster','Create captions for the fictional workshop video',[0]),add(2,'Aster','Label video speakers as Host and Guest',[0]),add(3,'Aster','Mark unclear words in captions rather than guessing them',[0])],'Captions, labels and uncertainty policy separate.',['No guessed transcript words.']),
 (2,[],'Quoted producer practice is explicitly disclaimed.',['Do not adopt invention of missing words.']),
 (4,[update(2,[3],text='Label video speakers as Presenter and Participant')],'Only speaker-label scheme changes.',['Preserve uncertainty markers.']),
 (5,[add(4,'Aster','Describe important non-speech sounds in captions, such as alarms and applause',[5])],'Adds sound information without claiming all sounds must be transcribed.',['Preserve important qualifier.']),
 (8,[add(5,'Aster','Explain translation subtitles versus captions that include sound information',[6])],'Question is an additional information request despite later no-change acknowledgement.',['Do not incorrectly return empty operations for the prefix.'])])

family(21,'en','fictional recruitment exercise','A mock hiring rubric changes assessment modality while preserving a no-personal-data boundary.',
 ['scope_revision','withdrawal','retention','no_change'],[
 ('Dev','Design a mock hiring exercise using fictional profiles only. Assess debugging through a written code-review task.'),
 ('Dev','Add a separate collaboration exercise in pairs.'),
 ('Dev','Replace the written code review with a narrated debugging walkthrough. Keep using fictional profiles.'),
 ('Dev','Cancel the pair exercise; the walkthrough should remain.'),
 ('Assistant','All candidates have passed and the hiring decision is complete.')],[
 (0,[add(1,'Dev','Design a mock hiring exercise',[0]),add(2,'Dev','Use fictional profiles only for the mock hiring exercise',[0]),add(3,'Dev','Assess debugging through a written code-review task',[0])],'Fictional exercise, not actual selection of people.',['No real personal profiles.']),
 (1,[add(4,'Dev','Include a separate pair collaboration exercise',[1])],'New distinct exercise.',['Do not alter written task yet.']),
 (2,[update(3,[2],text='Assess debugging through a narrated debugging walkthrough')],'Replaces modality under stable assessment requirement.',['Fictional-profile constraint stays.']),
 (3,[withdraw(4,[3])],'Cancel pair exercise only.',['Keep narrated walkthrough.']),
 (4,[],'Assistant claims about completion or decisions cannot erase user intent.',['No automatic withdrawal of exercise requirements.'])])

family(22,'en','software test planning','A serialization test plan retains backward compatibility while changing fixture scope and adding an explanation.',
 ['combined_change','new_question','retention','long_history'],[
 ('Mina','Draft tests for a fictional configuration serializer. Old version-one files must still load, and fixture files must contain no secrets.'),
 ('Assistant','We could drop old-format support to simplify the tests.'),
 ('Mina','Do not take that suggestion; backward compatibility is required.'),
 ('Mina','Add round-trip tests for nested lists.'),
 ('Assistant','I have noted nested lists.'),
 ('Mina','Broaden that round-trip test to nested lists and dictionaries, and include an empty-file test as a separate case.'),
 ('Mina','Could you explain why comparing parsed objects may be better than comparing raw JSON strings here?'),
 ('Assistant','I will treat that as a question about the testing method.'),
 ('Mina','Right. The secret-free fixture rule still applies.')],[
 (0,[add(1,'Mina','Draft tests for the fictional configuration serializer',[0]),add(2,'Mina','Ensure old version-one configuration files still load',[0]),add(3,'Mina','Keep all serializer fixture files free of secrets',[0])],'Test task and two enduring constraints.',['Version-one support is not optional.']),
 (2,[],'Simplification suggestion is rejected without changing existing requirements.',['No compatibility withdrawal.']),
 (4,[add(4,'Mina','Include serializer round-trip tests for nested lists',[3])],'New round-trip scope.',['No dictionary scope yet.']),
 (5,[update(4,[5],text='Include serializer round-trip tests for nested lists and dictionaries'),add(5,'Mina','Include a separate empty-file serializer test',[5])],'One scope extension and one new case.',['Preserve existing compatibility and secret-free fixtures.']),
 (8,[add(6,'Mina','Explain parsed-object comparison versus raw JSON-string comparison for these tests',[6])],'Information request remains unresolved after acknowledgement.',['Do not treat methodological question as irrelevant chat.'])])

family(23,'en','deployment planning','A staging rollout retains manual approval while a monitoring candidate is adopted then explicitly withdrawn.',
 ['uncertain_to_active','withdrawal','retention','execution_not_intent'],[
 ('Pax','Write a staging-only rollout plan for the fictional search service. Require manual approval before traffic is switched.'),
 ('Pax','I might want a dashboard screenshot at each stage, but I have not decided.'),
 ('Pax','Include those dashboard screenshots after all, one per rollout stage.'),
 ('Assistant','The rollout has finished successfully; all requirements can be cleared now.'),
 ('Pax','Remove the screenshot requirement. Keep the staging-only plan and manual approval.')],[
 (0,[add(1,'Pax','Write a staging-only rollout plan for the fictional search service',[0]),add(2,'Pax','Require manual approval before switching rollout traffic',[0])],'Plan scope is staging only, not permission for production changes.',['Keep manual approval independent.']),
 (1,[add(3,'Pax','Possible dashboard screenshot at each rollout stage; adoption undecided',[1],'uncertain')],'Concrete candidate with known owner.',['Do not activate based on possibility alone.']),
 (2,[update(3,[2],text='Include one dashboard screenshot per rollout stage',status='active')],'Explicit adoption resolves candidate.',['No duplicated screenshot record.']),
 (3,[],'Assistant claims cannot clear intent or establish actual execution.',['All active requests remain.']),
 (4,[withdraw(3,[4])],'Only screenshot requirement is cancelled.',['Preserve staging scope and approval.'])])

family(24,'en','research workshop coordination','Two collaborators preserve their own session materials while the organizer resolves an unknown-owner candidate.',
 ['owner_uncertainty','multi_owner','uncertain_to_active','retention'],[
 ('Jun','Plan our fictional reproducibility workshop. My session needs a checklist for sharing code.'),
 ('Bea','My session needs examples of how to document failed experiments.'),
 ('Jun','Someone may need a quiet discussion room, but I do not know who or whether it is necessary.'),
 ('Bea','The quiet room is for me, and I do need it for my session. Please make that a definite requirement.'),
 ('Jun','Change only my session material: use a checklist for sharing code and environment details, not code alone.')],[
 (0,[add(1,'Jun','Plan the fictional reproducibility workshop',[0]),add(2,'Jun','Provide a code-sharing checklist for Jun’s session',[0])],'Workshop task and Jun’s session need.',['Session ownership explicit.']),
 (1,[add(3,'Bea','Provide examples of documenting failed experiments for Bea’s session',[1])],'Bea has a separate content requirement.',['Do not assign it to Jun.']),
 (2,[add(4,'__unresolved__','Possible quiet discussion room; owner and necessity unresolved',[2],'uncertain')],'User explicitly denies knowing owner and adoption.',['Use sentinel, not an invented group.']),
 (3,[update(4,[3],owner='Bea',text='Provide a quiet discussion room for Bea’s session',status='active')],'Bea resolves both owner and necessity herself.',['Update existing candidate ID.']),
 (4,[update(2,[4],text='Provide a checklist for sharing code and environment details for Jun’s session')],'Only Jun’s material broadens.',['Preserve Bea’s failed-experiment examples and quiet room.'])])

family(25,'en','publication production','A zine production plan separates binding preference from print quantity and retains a settled conditional insert.',
 ['conditional_active','proposal_acceptance','local_revision','retention','long_history'],[
 ('Wren','Prepare a production plan for a fictional student zine. Print 60 copies, and use folded staples for binding.'),
 ('Wren','If the final issue has more than 32 pages, include a separate contents insert. That is a definite rule.'),
 ('Assistant','Thread stitching could replace the staples.'),
 ('Wren','Yes, use your stitching suggestion instead.'),
 ('Assistant','The binding proposal has been accepted.'),
 ('Wren','Reduce the print run to 45 copies. The page-count rule should not change.'),
 ('Assistant','Someone described a different zine as “digital only”.'),
 ('Wren','That phrase is about a different zine, not our production plan.'),
 ('Wren','I have no other changes.')],[
 (0,[add(1,'Wren','Prepare a production plan for the fictional student zine',[0]),add(2,'Wren','Print 60 copies of the student zine',[0]),add(3,'Wren','Bind the student zine with folded staples',[0])],'Quantity and binding are separately revisable.',['Print plan is not digital-only.']),
 (1,[add(4,'Wren','Include a separate contents insert if the final zine exceeds 32 pages',[1])],'Settled conditional requirement remains active.',['Strictly more than 32 pages; do not make unconditional.']),
 (4,[update(3,[2,3],text='Bind the student zine with thread stitching')],'Acceptance depends on proposal text.',['Retain print quantity and insert condition.']),
 (5,[update(2,[5],text='Print 45 copies of the student zine')],'Only quantity changes.',['Insert threshold stays at more than 32 pages.']),
 (8,[],'Different-zine quote is explicitly disclaimed; final no-change adds nothing.',['Do not cancel printing or binding.'])])

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    assert len(FAMILIES)==25
    assert [x['family_id'] for x in FAMILIES]==[f'train-b-{i:03d}' for i in range(1,26)]
    assert Counter(x['language'] for x in FAMILIES)=={'zh':12,'en':13}
    assert all(len(x['decisions'])==5 for x in FAMILIES)
    assert sum(len(x['events'])>=8 for x in FAMILIES)>=6
    sources=[ROOT/'experiments/deep_conversation/intention_state.py',ROOT/'experiments/deep_conversation/intent_roles.py',ROOT/'output/research/2026-10-24/tracker-lora-pilot/annotation/ANNOTATION_GUIDE.md',ROOT/'output/research/2026-10-24/tracker-lora-pilot/annotation/system_prompt.txt',ROOT/'output/research/2026-10-24/tracker-lora-pilot/AUTHORING.md']
    hashes={p.relative_to(ROOT).as_posix():digest(p) for p in sources}
    results=[]
    for f in FAMILIES:
        assert 5<=len(f['events'])<=14
        assert [e['seq'] for e in f['events']]==list(range(len(f['events'])))
        assert [d['through_seq'] for d in f['decisions']]==sorted({d['through_seq'] for d in f['decisions']})
        assert f['decisions'][-1]['through_seq']==f['events'][-1]['seq']
        checks=[]
        with IntentStore(':memory:') as store:
            for k,d in enumerate(f['decisions']):
                store.observe([e for e in f['events'] if e['seq']<=d['through_seq']])
                before=store.snapshot()
                assert all(o['source_seqs']==sorted(set(o['source_seqs'])) for o in d['operations'])
                assert all(max(o['source_seqs'])<=d['through_seq'] for o in d['operations'])
                after=store.commit_patch(f'setup-{k}',before['version'],d['through_seq'],d['operations'])
                b={i['intent_id']:i for i in before['intents']}; a={i['intent_id']:i for i in after['intents']}
                assert all(b[i]==a[i] for i in d['preserve_ids'])
                assert all(i['status']=='uncertain' for i in after['intents'] if i['owner']=='__unresolved__' and i['status']!='withdrawn')
                checks.append(dict(decision=k+1,through_seq=d['through_seq'],runtime_replay='passed',preserved_record_count=len(d['preserve_ids']),author_semantic_disposition='self_checked_pending_independent_review'))
        results.append(dict(family_id=f['family_id'],events=len(f['events']),decisions=checks))
    OUT.mkdir(parents=True,exist_ok=True)
    target=OUT/'train-b.jsonl'
    target.write_text(''.join(json.dumps(f,ensure_ascii=False,separators=(',',':'))+'\n' for f in FAMILIES),encoding='utf-8')
    report={'id':'train-b-author-self-check','date':'2026-10-24','timezone':'America/Halifax','created_at_utc':datetime.now(timezone.utc).isoformat(),'author':'tracker_annotation_v2','kind':'author_self_review_and_engineering_replay_not_independent_semantic_review','status':'authored_and_self_checked_independent_review_required','source':target.relative_to(ROOT).as_posix(),'source_sha256':digest(target),'builder_sha256':digest(Path(__file__)),'families':25,'updates':125,'languages':dict(Counter(f['language'] for f in FAMILIES)),'families_with_8_or_more_events':sum(len(f['events'])>=8 for f in FAMILIES),'total_events':sum(len(f['events']) for f in FAMILIES),'no_change_decisions':sum(not d['operations'] for f in FAMILIES for d in f['decisions']),'operations':dict(Counter(o['op'] for f in FAMILIES for d in f['decisions'] for o in d['operations'])),'authorship':'25 individually authored fictional dialogues; no translated families, external user data or content templates','helper_scope':'event/intent ID construction, schema serialization, store replay and bookkeeping only','human_review_performed':False,'independent_review_performed':False,'checks':results,'source_hashes_before':hashes,'source_hashes_after':{p.relative_to(ROOT).as_posix():digest(p) for p in sources},'failed_preparation_notes':['Initial attempt to read AUTHORING.md under data/ returned path not found; actual file was at pilot root. No data validation had run.'],'limitations':['Author self-review and store replay cannot independently establish semantic label quality.','Synthetic conversations are not naturally occurring user logs.','Five decisions from one family are correlated.','Unsupported same-turn reopen plus text/owner revision excluded as required.','No model inference or LoRA training was performed by this author.']}
    assert report['source_hashes_before']==report['source_hashes_after']
    (HERE/'train-b-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:report[k] for k in ('status','source_sha256','families','updates','languages','families_with_8_or_more_events','total_events','no_change_decisions','operations')},ensure_ascii=False))

if __name__=='__main__':
    main()
