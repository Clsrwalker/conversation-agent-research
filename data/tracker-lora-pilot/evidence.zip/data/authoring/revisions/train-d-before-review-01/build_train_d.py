"""Individually authored D scenarios. Helpers only serialize and replay labels."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import json,hashlib,sys
ROOT=next(p for p in Path(__file__).resolve().parents if (p/'experiments/deep_conversation/intention_state.py').exists())
P=ROOT/'output/research/2026-10-24/tracker-lora-pilot'
sys.path.insert(0,str(ROOT/'experiments/deep_conversation'))
from intention_state import IntentStore
F=[]
def A(i,o,t,s,status='active'):return dict(op='add',intent_id=f'i{i}',owner=o,text=t,source_seqs=s,status=status)
def U(i,s,**kw):return dict(op='update',intent_id=f'i{i}',source_seqs=s,**kw)
def W(i,s):return dict(op='withdraw',intent_id=f'i{i}',source_seqs=s)
def R(i,s):return dict(op='reopen',intent_id=f'i{i}',source_seqs=s)
def put(n,lang,domain,scenario,tags,dialogue,decisions):
 events=[dict(seq=i,speaker=o,role='assistant' if o=='Assistant' else 'user',text=t) for i,(o,t) in enumerate(dialogue)]
 ds=[]
 with IntentStore(':memory:') as st:
  for k,(seq,ops,note,crit) in enumerate(decisions):
   st.observe([e for e in events if e['seq']<=seq]);b=st.snapshot();touched={o['intent_id'] for o in ops}
   ds.append(dict(through_seq=seq,operations=ops,evidence_note=note,critical_checks=crit,preserve_ids=[x['intent_id'] for x in b['intents'] if x['intent_id'] not in touched]))
   st.commit_patch(f'setup-{k}',b['version'],seq,ops)
 F.append(dict(family_id=f'train-d-{n:03d}',split='train',language=lang,domain=domain,scenario=scenario,tags=tags,events=events,decisions=ds))

put(1,'zh','业余排球联赛','赛制和两队报到安排分别修订，未完成的解释问题保留。',['multi_owner','combined_change','new_question'],[
 ('钟越','帮我排一次业余排球联赛，采用单循环赛制，每场之间至少留十五分钟。'),
 ('苏蓓','我们蓝队的报到时间要放在上午十点以后。'),
 ('钟越','赛制换成双循环，但场间休息别缩短。'),
 ('苏蓓','蓝队报到限制取消，我们现在能早点到；不过更衣室需要一面可移动屏风。'),
 ('钟越','再给我解释下，胜场相同时比较局分和小分有什么区别？')],[
 (0,[A(1,'钟越','编排业余排球联赛',[0]),A(2,'钟越','排球联赛使用单循环赛制',[0]),A(3,'钟越','每场排球比赛之间至少间隔十五分钟',[0])],'赛制与休息时长分开。',['至少不能变成恰好十五分钟。']),
 (1,[A(4,'苏蓓','蓝队在上午十点以后报到',[1])],'仅蓝队限制，owner苏蓓。',['不改全联赛开始时间。']),
 (2,[U(2,[2],text='排球联赛使用双循环赛制')],'局部赛制修改。',['休息时间保留。']),
 (3,[W(4,[3]),A(5,'苏蓓','蓝队使用的更衣室需要可移动屏风',[3])],'取消报到限制并加屏风。',['不把早到变成必须早到。']),
 (4,[A(6,'钟越','解释胜场相同时比较局分和小分的区别',[4])],'新问题未选择排名规则。',['不能替用户设定并列名次处理。'])])

put(2,'zh','面包预订生产','预订批次的份量、领取窗口与可选包装独立变化。',['uncertain_to_active','retention','long_history'],[
 ('费祎','给虚构面包坊做周末预订生产表，先按每盒六个餐包，统一周六下午领取。'),
 ('费祎','包装可能要用可重复使用的盒子，我还在考虑。'),
 ('Assistant','包装供应商的目录已打开。'),
 ('费祎','先不用从目录里替我选具体款式。'),
 ('费祎','可重复使用的盒子确定采用，但不限定颜色。'),
 ('费祎','每盒改为四个餐包，领取时间也改到周日上午。'),
 ('Assistant','这会改变批次表里的份数。'),
 ('费祎','是的，四个一盒。'),
 ('费祎','另外把未领取的预订单单独列一栏。')],[
 (0,[A(1,'费祎','制作虚构面包坊周末预订生产表',[0]),A(2,'费祎','每盒装六个餐包',[0]),A(3,'费祎','预订统一周六下午领取',[0])],'初始生产、份量与时间。',['无真实订单或个人信息。']),
 (3,[A(4,'费祎','预订包装可能使用可重复使用盒子，采用未定',[1],'uncertain'),A(5,'费祎','不代替用户从包装目录选择具体款式',[3])],'候选包装与新增选择权限边界。',['不能自动选型号。']),
 (4,[U(4,[4],text='预订包装使用可重复使用的盒子，不限定颜色',status='active')],'确认材料但明确颜色无约束。',['不可凭空加颜色偏好。']),
 (7,[U(2,[5],text='每盒装四个餐包'),U(3,[5],text='预订统一周日上午领取')],'同句改份量和时间，复述不重复记录。',['保留包装与不代选款式。']),
 (8,[A(6,'费祎','生产表将未领取的预订单单独列一栏',[8])],'新增表内区分。',['不是要求取消未领订单。'])])

put(3,'zh','直播讨论区管理','直播规则在置顶方式变更时保留不公开联系方式的边界。',['quotation','scope_restriction','local_revision','new_question'],[
 ('柳砚','为虚构手工直播间拟一份讨论区规则，允许观众提问，但不要公开他们的联系方式。'),
 ('柳砚','重复问过的问题合并成一条置顶问答。'),
 ('柳砚','别的直播间写着“留下手机号才回答”，我只是拿它做反例，我们不采用。'),
 ('柳砚','问答不置顶了，改成每场结束后汇总；观众依然能在直播时提问。'),
 ('柳砚','解释一下，合并重复问题时怎样避免把不同意思的问题合在一起？')],[
 (0,[A(1,'柳砚','拟定虚构手工直播间讨论区规则',[0]),A(2,'柳砚','允许观众在直播中提问',[0]),A(3,'柳砚','不公开直播观众联系方式',[0])],'问答参与和信息边界分开。',['不要求提交真实联系方式。']),
 (1,[A(4,'柳砚','将重复问题合并成一条置顶问答',[1])],'重复问题处理方式。',['非删除全部重复提问者。']),
 (2,[],'未采纳反例，不改已有联系方式规则。',['不能创建手机号门槛。']),
 (3,[U(4,[3],text='将重复问题合并，在每场直播结束后汇总，不置顶')],'汇总时机替换置顶方式。',['直播中提问权保留。']),
 (4,[A(5,'柳砚','解释合并重复问题时如何避免混淆不同意思',[4])],'新方法解释请求。',['未授权任意合并语义不同的问题。'])])

put(4,'zh','三维资产委托','低多边形道具的尺寸、纹理和格式各自有界。',['retention','uncertain_to_withdrawn','combined_change'],[
 ('岑光','给我的虚构场景制作一个低多边形邮筒模型，高度一米，交付GLB。'),
 ('岑光','也许要加做旧纹理，但我还没想好。'),
 ('岑光','高度改为八十厘米，GLB仍然要。'),
 ('岑光','做旧不要了，用纯色材质，并且不加文字标志。'),
 ('岑光','谢谢，邮筒模型的要求就这些。')],[
 (0,[A(1,'岑光','为虚构场景制作低多边形邮筒模型',[0]),A(2,'岑光','邮筒模型高度一米',[0]),A(3,'岑光','邮筒模型交付GLB格式',[0])],'低多边形限定属于主任务。',['单位是米。']),
 (1,[A(4,'岑光','邮筒模型可能添加做旧纹理，采用未定',[1],'uncertain')],'具体候选。',['不能先实施做旧。']),
 (2,[U(2,[2],text='邮筒模型高度八十厘米')],'尺寸修订保留格式。',['不是八十米。']),
 (3,[W(4,[3]),A(5,'岑光','邮筒模型使用纯色材质',[3]),A(6,'岑光','邮筒模型不添加文字标志',[3])],'取消候选与两个明确约束同时发生。',['不遗漏文字禁令。']),
 (4,[],'感谢无新要求。',['不能声称资产已完成。'])])

put(5,'zh','舞蹈队形编排','独立舞者的出场需要与全队结尾队形分别撤销和恢复。',['multi_owner','reopen','long_history'],[
 ('南星','给这段虚构双人舞编一个走位草图，结尾两人背对观众，整段不使用地面翻滚。'),
 ('乔牧','我的第一次入场要从舞台左侧，不要替另一个人也定左侧。'),
 ('Assistant','有一段音乐暂时只有节拍，没有旋律。'),
 ('南星','知道了，走位要求先不变。'),
 ('南星','结尾背对观众那条先撤掉，结尾姿势暂时留空。'),
 ('乔牧','我从左侧入场这条仍然需要。'),
 ('南星','恢复刚才两人背对观众的结尾，不留空了。'),
 ('Assistant','我看到了恢复的消息。'),
 ('乔牧','我的入场改成舞台右侧，其他人的位置不要跟着改。')],[
 (0,[A(1,'南星','为虚构双人舞编走位草图',[0]),A(2,'南星','双人舞结尾两人背对观众',[0]),A(3,'南星','双人舞整段不使用地面翻滚',[0])],'主任务和动作/结尾要求。',['无翻滚限制独立。']),
 (3,[A(4,'乔牧','乔牧第一次从舞台左侧入场',[1])],'入场归本人，背景音乐信息不构成修改。',['不为其他舞者推断同侧。']),
 (5,[W(2,[4]),A(5,'南星','双人舞结尾姿势暂时留空',[4])],'撤销原结尾并明确占位状态。',['无翻滚和入场保留。']),
 (7,[R(2,[6]),W(5,[6])],'恢复原结尾并撤销留空。',['同ID恢复，不重复创建。']),
 (8,[U(4,[8],text='乔牧第一次从舞台右侧入场')],'只改乔牧入场侧。',['保留两人结尾和全段无翻滚。'])])

put(6,'zh','虚构广播栏目','栏目顺序变化不改变虚构数值需标示的要求。',['local_revision','new_question','long_history'],[
 ('苏霁','写一段三分钟的虚构天气广播脚本，先报气温再报降雨，所有数字都标明是演示数据。'),
 ('Assistant','开头可以加入一句主持人问候。'),
 ('苏霁','问候这点我先不决定。'),
 ('苏霁','顺序调过来，先降雨再气温。'),
 ('Assistant','模拟表格已摆好。'),
 ('苏霁','把总时长缩到两分钟，但数字仍须注明是演示数据。'),
 ('苏霁','另帮我说明，降雨概率和预计雨量分别表达什么，不要把二者混写。'),
 ('Assistant','这是两个不同的说明对象。'),
 ('苏霁','没别的了。')],[
 (0,[A(1,'苏霁','撰写虚构天气广播脚本',[0]),A(2,'苏霁','虚构天气广播总时长三分钟',[0]),A(3,'苏霁','天气广播先报气温再报降雨',[0]),A(4,'苏霁','天气广播所有数字注明是演示数据',[0])],'任务、时长、顺序和来源标示。',['不能当真实天气播报。']),
 (2,[],'问候未采纳。',['不创建问候要求。']),
 (4,[U(3,[3],text='天气广播先报降雨再报气温')],'只交换顺序。',['气温部分没有取消。']),
 (5,[U(2,[5],text='虚构天气广播总时长两分钟')],'缩短总时长保留其余。',['演示标记保留。']),
 (8,[A(5,'苏霁','解释降雨概率和预计雨量各自的含义并区分二者',[6])],'说明请求未被随后的结束语撤销。',['不标为no-op。'])])

put(7,'zh','游戏界面本地化','角色名保留规则允许一个明确例外，候选双语显示被否决。',['exception','uncertain','scope_preservation'],[
 ('裴岚','把虚构解谜游戏菜单翻成中文，按钮文案每个不超过六个汉字，角色名保留英文。'),
 ('裴岚','可能想在中文旁边也显示英文，但还没决定。'),
 ('裴岚','只有主角名Spark要译成“火花”，其他角色名别翻。'),
 ('裴岚','双语并排显示不用了，菜单只显示中文；角色名规则还是刚才那套。'),
 ('裴岚','帮我列出“Resume”可以怎样翻译，并比较各自适用场景，先不要替我选。')],[
 (0,[A(1,'裴岚','将虚构解谜游戏菜单翻译为中文',[0]),A(2,'裴岚','每个菜单按钮文案不超过六个汉字',[0]),A(3,'裴岚','游戏角色名保留英文',[0])],'字符上限与角色名独立。',['不限制为六个字恰好。']),
 (1,[A(4,'裴岚','菜单可能中英文并排显示，采用未定',[1],'uncertain')],'具体显示候选。',['不是已确定双语。']),
 (2,[U(3,[2],text='游戏角色名保留英文，唯主角Spark译为“火花”')],'对既有规则作单个例外。',['其他角色名继续英文。']),
 (3,[W(4,[3]),A(5,'裴岚','菜单只显示中文，角色名遵循已确定的英文及Spark例外规则',[3])],'撤销并排候选，保留特殊角色规则。',['不要把所有角色名翻中文。']),
 (4,[A(6,'裴岚','列出Resume的中文译法并比较适用场景，暂不代选',[4])],'新语言选择问题。',['不直接替换按钮文本。'])])

put(8,'zh','科幻故事构思','故事视角与结局保密范围分别变化，并保留角色动机。',['retention','combined_change','no_change'],[
 ('闻溪','帮我拟一个太空邮递员的短篇梗概，用第一人称，主角送信是为了兑现对姐姐的承诺。'),
 ('闻溪','结尾必须停在信送达之前，不要揭晓收信人。'),
 ('闻溪','改用第三人称限知视角，但主角的动机不变。'),
 ('闻溪','可以写到信已送达，不过收信人的身份仍然不能揭晓；再加一个中途丢失导航仪的障碍。'),
 ('闻溪','对，身份不揭晓，其他按刚才的来。')],[
 (0,[A(1,'闻溪','拟定太空邮递员短篇故事梗概',[0]),A(2,'闻溪','故事使用第一人称视角',[0]),A(3,'闻溪','主角送信的动机是兑现对姐姐的承诺',[0])],'任务、视角、动机。',['不能重写人物动机。']),
 (1,[A(4,'闻溪','故事结尾停在信送达之前',[1]),A(5,'闻溪','故事不揭晓收信人身份',[1])],'时间界限与身份悬念独立。',['不把两条绑死。']),
 (2,[U(2,[2],text='故事使用第三人称限知视角')],'视角局部修改。',['仍是限知而非全知。']),
 (3,[U(4,[3],text='故事结尾可以写到信已送达'),A(6,'闻溪','故事增加主角中途丢失导航仪的障碍',[3])],'放宽结尾进度但保持身份限制，增加障碍。',['可以不等于必须写到送达。']),
 (4,[],'重述现有悬念要求。',['不重复添加收信人限制。'])])

put(9,'zh','仓储货架编码','两位库管各自的标签需要保留，局部前缀调整不抹去扫码边界。',['multi_owner','local_revision','long_history'],[
 ('余森','给虚构零件仓库拟货架编码方案，东区编码以E开头，标签必须能直接读文字，不能只有条码。'),
 ('冯棠','我负责西区，西区编码用W开头。'),
 ('Assistant','东区目前分为三排。'),
 ('余森','三排这个背景我知道了。'),
 ('余森','东区前缀改成EA，西区不动。'),
 ('冯棠','西区标签还要显示层号。'),
 ('Assistant','标签样例正在整理。'),
 ('余森','东区暂时不用额外颜色区分，我只要求文字可读。'),
 ('冯棠','解释一下，固定长度编码和用连字符分隔编码各有什么优点？')],[
 (0,[A(1,'余森','拟定虚构零件仓库货架编码方案',[0]),A(2,'余森','东区货架编码以E开头',[0]),A(3,'余森','货架标签必须有可直接阅读的文字，不能只有条码',[0])],'全体可读要求独立于东区前缀。',['不是禁止附加条码。']),
 (3,[A(4,'冯棠','西区货架编码以W开头',[1])],'西区由冯棠提出，背景三排非新要求。',['保留东区前缀。']),
 (4,[U(2,[4],text='东区货架编码以EA开头')],'只更新东区。',['W不变。']),
 (7,[A(5,'冯棠','西区货架标签显示层号',[5]),A(6,'余森','东区标签暂不使用额外颜色区分',[7])],'西区字段与东区明确颜色边界。',['不能把东区限制扩展西区。']),
 (8,[A(7,'冯棠','解释固定长度编码与连字符分隔编码各自的优点',[8])],'新的比较问题。',['不直接选择编码结构。'])])

put(10,'zh','充电站界面原型','只做模拟界面的任务保留币种显示和取消流程。',['scope_boundary','proposal_acceptance','new_question'],[
 ('霍景','设计一个虚构充电站的付款界面原型，只做模拟，不连接支付服务；金额旁边写清币种。'),
 ('Assistant','可以在确认按钮旁边放取消按钮。'),
 ('霍景','采用你说的取消按钮，位置也照这个提议。'),
 ('霍景','金额改成先显示总价再显示单价，币种仍要明确。'),
 ('霍景','取消按钮不要放确认旁边了，改到页面左上角。'),
 ('霍景','顺便解释一下，用户点取消后保留输入与清空输入，体验上有什么区别？')],[
 (0,[A(1,'霍景','设计虚构充电站付款界面原型',[0]),A(2,'霍景','付款原型只做模拟，不连接支付服务',[0]),A(3,'霍景','金额旁明确显示币种',[0])],'明确不执行真实支付。',['币种不能省略。']),
 (2,[A(4,'霍景','在付款原型确认按钮旁设置取消按钮',[1,2])],'同意按钮与位置，双事件证据。',['不是自动连接支付。']),
 (3,[A(5,'霍景','付款原型先显示总价再显示单价',[3])],'前态无顺序要求，因此新增。',['不移除币种。']),
 (4,[U(4,[4],text='在付款原型页面左上角设置取消按钮')],'位置变化保留按钮。',['不删除取消入口。']),
 (5,[A(6,'霍景','比较取消后保留输入与清空输入的体验差异',[5])],'询问信息不选默认清除。',['两种选项都不能当已选。'])])

put(11,'zh','堆肥观察记录','观察表的单位调整不会把明确条件误当不确定。',['conditional_active','local_revision','withdrawal'],[
 ('岳禾','做一份虚构堆肥箱的观察记录模板，每天记一次温度，用摄氏度。'),
 ('岳禾','如果出现明显异味，就增加气味描述；这个条件规则确定采用。'),
 ('岳禾','再加一列照片编号，照片本身不要嵌进表里。'),
 ('岳禾','照片编号这列撤掉吧，温度和气味规则保留。'),
 ('岳禾','温度记录频率改成每周三次，还是摄氏度。')],[
 (0,[A(1,'岳禾','制作虚构堆肥箱观察记录模板',[0]),A(2,'岳禾','每天记录一次堆肥箱温度',[0]),A(3,'岳禾','堆肥箱温度使用摄氏度',[0])],'频率与单位独立。',['不生成真实观测值。']),
 (1,[A(4,'岳禾','出现明显异味时增加气味描述',[1])],'确定条件规则active。',['不能无条件要求每次气味描述。']),
 (2,[A(5,'岳禾','观察表增加照片编号列',[2]),A(6,'岳禾','照片本身不嵌入观察表',[2])],'照片索引与文件嵌入限制分别表达。',['不得嵌图。']),
 (3,[W(5,[3])],'只撤编号列；不嵌照片边界未撤销。',['保留温度、气味及照片不嵌入。']),
 (4,[U(2,[4],text='每周记录三次堆肥箱温度')],'只改频率。',['摄氏度保留。'])])

put(12,'zh','实体解谜关卡','谜题的提示候选从未知归属到确认，不能用强制解答替代提示。',['owner_uncertainty','uncertain_to_active','long_history'],[
 ('秦野','设计一个虚构密室的入门谜题，不用锁住出口，答案是三位数字。'),
 ('秦野','有人可能需要大字提示卡，但没说是谁，也还没确定。'),
 ('Assistant','可以直接把答案放在提示卡上。'),
 ('秦野','我不采用这个提议。'),
 ('叶嘉','大字提示卡是我需要的，确定要，请只提示思路，不直接写答案。'),
 ('Assistant','谜题草图已经画好。'),
 ('秦野','答案改成四位数字，不锁出口这条保持。'),
 ('叶嘉','提示卡仍然需要大字。'),
 ('秦野','另外给我解释，线性线索和可并行线索对合作解谜有何影响？')],[
 (0,[A(1,'秦野','设计虚构密室入门谜题',[0]),A(2,'秦野','密室谜题不锁住出口',[0]),A(3,'秦野','谜题答案为三位数字',[0])],'任务和两项约束。',['不能从游戏设定推断需真实锁门。']),
 (3,[A(4,'__unresolved__','可能需要大字提示卡，归属和采用与否待确认',[1],'uncertain')],'候选记录，不接受直接答案建议。',['不猜候选owner。']),
 (5,[U(4,[4],owner='叶嘉',text='提供叶嘉所需的大字提示卡',status='active'),A(5,'叶嘉','提示卡只提示思路，不直接写答案',[4])],'确认owner与采用并增加提示范围限制。',['不能把答案放卡上。']),
 (7,[U(3,[6],text='谜题答案为四位数字')],'答案长度变化；复述提示无新内容。',['保留出口不锁与大字提示。']),
 (8,[A(6,'秦野','解释线性线索与可并行线索对合作解谜的影响',[8])],'新增结构比较问题。',['不替用户改变线索结构。'])])

put(13,'en','sewing pattern brief','A reversible bag pattern changes closure without losing seam allowance or pocket scope.',['retention','combined_change','no_change'],[
 ('Ada','Draft a sewing pattern for a reversible tote bag. Include a one-centimetre seam allowance and one inside pocket.'),
 ('Ada','Give it a button closure.'),
 ('Ada','Replace the button with a fabric tie, and make that pocket large enough for a paperback.'),
 ('Ada','The inside pocket is no longer needed; keep the reversible construction and the tie.'),
 ('Ada','Yes, the same one-centimetre allowance. Nothing else to add.')],[
 (0,[A(1,'Ada','Draft a sewing pattern for a reversible tote bag',[0]),A(2,'Ada','Include a one-centimetre seam allowance',[0]),A(3,'Ada','Include one inside pocket in the tote bag',[0])],'Independent construction and pocket constraints.',['Reversible remains part of task.']),
 (1,[A(4,'Ada','Use a button closure on the tote bag',[1])],'New closure choice.',['Not a second pocket.']),
 (2,[U(4,[2],text='Use a fabric tie closure on the tote bag'),U(3,[2],text='Include one inside pocket large enough for a paperback')],'Closure replacement and pocket size added together.',['Seam allowance retained.']),
 (3,[W(3,[3])],'Cancel pocket including its dependent size.',['Tie and reversible construction survive.']),
 (4,[],'Already-recorded allowance reiterated.',['No duplicate or task completion.'])])

put(14,'en','drone simulator course','A simulator brief distinguishes camera motion from control input and treats a pause feature as tentative.',['uncertain_to_active','local_revision','new_question'],[
 ('Kian','Design a drone simulator course, entirely virtual. Use keyboard controls and keep the camera fixed behind the drone.'),
 ('Kian','I may want a pause-and-inspect feature, but I have not chosen it yet.'),
 ('Kian','Change the controls to a gamepad. The fixed rear camera should stay.'),
 ('Kian','Include pause-and-inspect after all, but only between checkpoints.'),
 ('Kian','Explain the difference between a fixed rear camera and an orbit camera before suggesting any camera change.')],[
 (0,[A(1,'Kian','Design an entirely virtual drone simulator course',[0]),A(2,'Kian','Use keyboard controls for the drone simulator',[0]),A(3,'Kian','Keep simulator camera fixed behind the drone',[0])],'Virtual scope and independent input/camera.',['Do not imply a real drone flight.']),
 (1,[A(4,'Kian','Possible pause-and-inspect feature; adoption undecided',[1],'uncertain')],'Concrete candidate.',['No active pause yet.']),
 (2,[U(2,[2],text='Use gamepad controls for the drone simulator')],'Input replacement only.',['Rear camera stays fixed.']),
 (3,[U(4,[3],text='Include pause-and-inspect only between checkpoints',status='active')],'Adopt with a limited availability condition.',['Do not enable it everywhere.']),
 (4,[A(5,'Kian','Explain fixed rear versus orbit camera before suggesting a camera change',[4])],'Question does not itself change camera.',['Keep i3 active.'])])

put(15,'en','API migration guide','A migration guide names one field exception while retaining a nonbreaking default.',['exception','quotation','long_history'],[
 ('Esme','Write a migration guide for our fictional widget API. Preserve existing request field names, and do not require clients to upgrade immediately.'),
 ('Assistant','The old README quotes a developer saying, "rename every field".'),
 ('Esme','That quote is not the policy for this migration.'),
 ('Esme','One exception: the field colour becomes color. All other request names stay.'),
 ('Assistant','The sample client has been opened.'),
 ('Esme','Add a side-by-side example of an old request and its migrated form.'),
 ('Esme','Actually the example should be JSON, not pseudocode.'),
 ('Assistant','No example format was previously selected.'),
 ('Esme','Correct; JSON is the format I want now.')],[
 (0,[A(1,'Esme','Write the fictional widget API migration guide',[0]),A(2,'Esme','Preserve existing request field names',[0]),A(3,'Esme','Do not require clients to upgrade immediately',[0])],'Task and compatibility policy.',['No forced immediate upgrade.']),
 (2,[],'Quoted broad renaming is not adopted.',['No rename-all rule.']),
 (4,[U(2,[3],text='Preserve existing request field names except rename colour to color')],'Single explicit exception.',['All other field names persist.']),
 (5,[A(4,'Esme','Include side-by-side old and migrated request examples in the guide',[5])],'New comparison example.',['Both versions required.']),
 (8,[A(5,'Esme','Use JSON, not pseudocode, for the migration request examples',[6])],'No prior format to update; new format constraint.',['Do not drop side-by-side examples.'])])

put(16,'en','playlist curation','A playlist changes pacing while preserving lyric exclusions and a separate comparison question.',['local_revision','withdrawal','new_question'],[
 ('Nell','Curate a fictional game-lobby playlist, about twenty minutes long. Use instrumental tracks only.'),
 ('Nell','Begin with something slow and end with something energetic.'),
 ('Nell','Reverse that pacing: energetic at the start, slow at the end.'),
 ('Nell','Drop the length target; keep it instrumental. Also explain what a seamless loop would require.'),
 ('Nell','Add a rule that the transition between tracks must not include spoken announcements.')],[
 (0,[A(1,'Nell','Curate a fictional game-lobby playlist',[0]),A(2,'Nell','Target about twenty minutes for the playlist',[0]),A(3,'Nell','Use instrumental tracks only in the playlist',[0])],'Approximate duration is not exact.',['No vocal tracks.']),
 (1,[A(4,'Nell','Begin the playlist slowly and end energetically',[1])],'Coupled pacing order.',['Do not lose either endpoint.']),
 (2,[U(4,[2],text='Begin the playlist energetically and end slowly')],'Full directional reversal.',['Instrumental unchanged.']),
 (3,[W(2,[3]),A(5,'Nell','Explain what making the playlist a seamless loop would require',[3])],'Duration withdrawn, loop question added.',['Not a confirmed seamless-loop requirement.']),
 (4,[A(6,'Nell','Do not include spoken announcements between playlist tracks',[4])],'New transition boundary, different from instrumental songs.',['Retain no-vocal track rule.'])])

put(17,'en','costume continuity','Two costumers retain independent continuity notes when a prop color changes.',['multi_owner','uncertain_to_withdrawn','long_history'],[
 ('Remy','Make a costume continuity sheet for a fictional detective film. The lead wears a grey scarf in every outdoor scene.'),
 ('Tali','My continuity sheet for the assistant character needs the pocket-watch chain visible in close-ups.'),
 ('Remy','I might add gloves to the lead’s costume, but that is undecided.'),
 ('Assistant','A reference photo shows a hat.'),
 ('Remy','That is background reference only.'),
 ('Remy','Change the lead’s scarf to blue, still in every outdoor scene.'),
 ('Tali','My chain visibility requirement stays as it is.'),
 ('Remy','Do not add the tentative gloves after all.'),
 ('Assistant','The continuity notes are still being assembled.')],[
 (0,[A(1,'Remy','Make the fictional detective-film costume continuity sheet',[0]),A(2,'Remy','Lead wears a grey scarf in every outdoor scene',[0])],'Film task and scoped garment.',['No claim about indoor scarf.']),
 (1,[A(3,'Tali','Keep assistant character’s pocket-watch chain visible in close-ups on Tali’s continuity sheet',[1])],'Separate owner and character.',['Do not apply scarf rule to assistant.']),
 (4,[A(4,'Remy','Possible gloves for the lead costume; adoption undecided',[2],'uncertain')],'Candidate comes from user; reference hat is not adopted.',['Do not add hat requirement.']),
 (6,[U(2,[5],text='Lead wears a blue scarf in every outdoor scene')],'Color replacement retains every-outdoor scope.',['Tali’s chain remains.']),
 (8,[W(4,[7])],'Only tentative gloves rejected; progress not completion.',['Retain blue scarf.'])])

put(18,'en','robot maze simulation','A virtual robot challenge changes stopping conditions without accidentally changing the allowed sensor.',['conditional_active','combined_change','retention'],[
 ('Bo','Specify a virtual robot maze challenge. The robot may use a distance sensor, but no camera.'),
 ('Bo','Stop a run when it reaches the red square; if it gets stuck for ten seconds, stop that run too.'),
 ('Bo','The goal square is now green instead of red. Keep the ten-second stuck rule.'),
 ('Bo','Allow a compass as well as the distance sensor, and give me a short explanation of how compass drift could affect the route.'),
 ('Bo','Do not change anything else based on that explanation yet.')],[
 (0,[A(1,'Bo','Specify a virtual robot maze challenge',[0]),A(2,'Bo','Allow a distance sensor but no camera for the virtual robot',[0])],'Virtual task and sensing boundary.',['Distance sensor is allowed, not mandatory.']),
 (1,[A(3,'Bo','Stop a maze run when the robot reaches the red square',[1]),A(4,'Bo','Stop a maze run if the robot remains stuck for ten seconds',[1])],'Two definite stopping conditions.',['Stuck rule active despite conditional wording.']),
 (2,[U(3,[2],text='Stop a maze run when the robot reaches the green square')],'Only goal color changes.',['Stuck duration retained.']),
 (3,[U(2,[3],text='Allow a distance sensor and a compass, but no camera, for the virtual robot'),A(5,'Bo','Briefly explain how compass drift could affect the robot route',[3])],'Sensing permission broadened without losing camera ban; new question.',['No camera remains.']),
 (4,[A(6,'Bo','Do not make further challenge changes based on the drift explanation without a later decision',[4])],'Explicit new restriction on acting on advice.',['This is more than an acknowledgement.'])])

put(19,'en','motion graphics brief','An animation retains reduced motion while a tentative sound cue receives an explicit owner.',['owner_uncertainty','uncertain_to_active','local_revision'],[
 ('Opal','Create a brief for a looping logo animation. Avoid rapid flashing, and make the loop eight seconds long.'),
 ('Opal','Someone may want a chime at the end, but I do not know who or whether it is approved.'),
 ('Finn','That was my suggestion, and I now want it included. Keep the chime quiet.'),
 ('Opal','Make the loop twelve seconds instead. Do not bring back rapid flashing.'),
 ('Finn','Cancel my chime request entirely; the visual animation should continue.')],[
 (0,[A(1,'Opal','Create a looping logo animation brief',[0]),A(2,'Opal','Avoid rapid flashing in the logo animation',[0]),A(3,'Opal','Make the logo animation loop eight seconds long',[0])],'Visual task, flashing and duration independent.',['No sound initially required.']),
 (1,[A(4,'__unresolved__','Possible end-of-loop chime; owner and adoption unresolved',[1],'uncertain')],'Unknown owner concrete candidate.',['Do not assign to Opal.']),
 (2,[U(4,[2],owner='Finn',text='Include a quiet chime at the end of the logo loop',status='active')],'Finn confirms adoption and volume.',['Keep same candidate ID.']),
 (3,[U(3,[3],text='Make the logo animation loop twelve seconds long')],'Only loop duration changes.',['Keep no rapid flashing.']),
 (4,[W(4,[4])],'Whole chime request including quietness withdrawn.',['Visual animation unaffected.'])])

put(20,'en','recipe index taxonomy','An index changes category rules while leaving recipes untouched.',['retention','new_question','long_history'],[
 ('Leni','Build an index for a fictional recipe collection. Group entries by main ingredient, and do not rewrite the recipes themselves.'),
 ('Leni','Also tag entries that require an oven.'),
 ('Assistant','One recipe title contains the phrase "delete the old version".'),
 ('Leni','That phrase is part of a title, not an instruction to edit the collection.'),
 ('Leni','Change the main grouping to cooking method. Keep main ingredient as a tag instead.'),
 ('Assistant','The index headings have been drafted.'),
 ('Leni','What are the trade-offs between allowing several tags per recipe and forcing one category?'),
 ('Assistant','That is a choice of indexing strategy.'),
 ('Leni','I am not changing the tagging rule based on that answer yet.')],[
 (0,[A(1,'Leni','Build an index for the fictional recipe collection',[0]),A(2,'Leni','Group recipe index entries by main ingredient',[0]),A(3,'Leni','Do not rewrite the recipes themselves',[0])],'Index task separate from recipe content.',['No recipe rewriting.']),
 (1,[A(4,'Leni','Tag recipe index entries that require an oven',[1])],'Separate attribute.',['Do not exclude oven recipes.']),
 (3,[],'Title quotation is explicitly non-actionable.',['Do not delete collection content.']),
 (5,[U(2,[4],text='Group recipe index entries by cooking method'),A(5,'Leni','Retain main ingredient as a recipe index tag',[4])],'Grouping changes while ingredient information retained as tag.',['Oven tags stay.']),
 (8,[A(6,'Leni','Explain trade-offs of several recipe tags versus one required category',[6])],'New question; no strategy adopted from reply.',['Do not remove current tags.'])])

put(21,'en','mail-filter sandbox','Sandbox rules distinguish classification from destructive actions and preserve exceptions.',['exception','scope_restriction','local_revision'],[
 ('Arlo','Design a mail-filter sandbox using fictional messages. Label messages containing “invoice” as Billing, but never delete a message.'),
 ('Arlo','Exclude subjects beginning TEST from the Billing rule even if they contain invoice.'),
 ('Arlo','Rename the Billing label to Accounts; keep the TEST exception.'),
 ('Arlo','Add a separate label for messages containing “shipment”. Do not forward anything outside the sandbox.'),
 ('Arlo','Explain how a message matching both rules should be displayed; do not choose a priority for me yet.')],[
 (0,[A(1,'Arlo','Design a mail-filter sandbox using fictional messages',[0]),A(2,'Arlo','Label messages containing invoice as Billing',[0]),A(3,'Arlo','Never delete a message in the mail-filter sandbox',[0])],'Classification and nondeletion separate.',['No real mailbox access.']),
 (1,[U(2,[1],text='Label messages containing invoice as Billing, except subjects beginning TEST')],'Scoped exception belongs to existing rule.',['TEST exception only billing rule.']),
 (2,[U(2,[2],text='Label messages containing invoice as Accounts, except subjects beginning TEST')],'Label rename preserves matching condition and exception.',['Do not label TEST invoice Accounts.']),
 (3,[A(4,'Arlo','Add a separate label for messages containing shipment',[3]),A(5,'Arlo','Do not forward any message outside the sandbox',[3])],'Independent classification and new boundary.',['No invented label name.']),
 (4,[A(6,'Arlo','Explain display options for messages matching both rules without selecting a priority',[4])],'Question not priority adoption.',['Do not silently suppress one label.'])])

put(22,'en','fictional station announcements','Announcement order changes without erasing platform-specific accessibility information.',['multi_owner','combined_change','long_history'],[
 ('Mae','Write templates for a fictional railway station. Announce destination before departure time, and say platform numbers as whole numbers.'),
 ('Ivo','For my accessibility template, include whether the route to the platform has steps.'),
 ('Assistant','A historic recording starts with a sponsor message.'),
 ('Mae','Interesting recording, but it does not change these templates.'),
 ('Mae','Put departure time before destination instead.'),
 ('Ivo','My template also needs to mention the lift when one is available.'),
 ('Assistant','The lift sentence can be conditional.'),
 ('Ivo','Exactly, mention it only when a lift is available; that rule is settled.'),
 ('Mae','Add a separate template for a platform change announcement.')],[
 (0,[A(1,'Mae','Write fictional railway-station announcement templates',[0]),A(2,'Mae','Announce destination before departure time',[0]),A(3,'Mae','Say platform numbers as whole numbers',[0])],'Ordering and number treatment separate.',['No real train schedules fabricated.']),
 (3,[A(4,'Ivo','Ivo’s accessibility template states whether the platform route has steps',[1])],'New owner-specific template feature; sponsor quote not adopted.',['Do not insert sponsor message.']),
 (4,[U(2,[4],text='Announce departure time before destination')],'Swap order only.',['Whole-number platform rule stays.']),
 (7,[A(5,'Ivo','Mention a lift in Ivo’s accessibility template only when a lift is available',[5,7])],'Settled conditional active requirement, including only restriction.',['Not uncertain and not unconditional lift claim.']),
 (8,[A(6,'Mae','Add a separate platform-change announcement template',[8])],'Distinct additional deliverable.',['Do not overwrite accessibility template.'])])

put(23,'en','nursery shipping preparation','A seedling shipping checklist restores a cancelled insert without changing the handling boundary.',['reopen','retention','new_question'],[
 ('Kit','Draft a packing checklist for fictional nursery seedlings. Keep each plant’s variety label attached, and include a care-card insert.'),
 ('Kit','Remove the care-card insert for now; leave the variety labels alone.'),
 ('Kit','Add a check that no loose soil escapes from the container during packing.'),
 ('Kit','Restore the same care-card insert. Also explain the difference between cushioning the pot and compressing the plant canopy.'),
 ('Kit','The explanation is for staff training, not permission to compress the canopy.')],[
 (0,[A(1,'Kit','Draft the fictional nursery-seedling packing checklist',[0]),A(2,'Kit','Keep each plant’s variety label attached',[0]),A(3,'Kit','Include a care-card insert with the seedlings',[0])],'Checklist and independent label/insert.',['No plant identity removal.']),
 (1,[W(3,[1])],'Only insert withdrawn.',['Variety labels remain.']),
 (2,[A(4,'Kit','Check that loose soil does not escape the container during packing',[2])],'New handling check.',['Not a requirement to remove all soil.']),
 (3,[R(3,[3]),A(5,'Kit','Explain cushioning the pot versus compressing the plant canopy',[3])],'Exact insert restored; comparison added.',['No same-turn reopen revision.']),
 (4,[U(5,[4],text='Explain cushioning the pot versus compressing the plant canopy for staff training, without treating it as permission to compress the canopy')],'Clarifies use and boundary of explanation.',['Do not add canopy compression as work.'])])

put(24,'en','race bib numbering','A mock race identity system keeps prefixes distinct for two categories and cancels only decorative detail.',['multi_owner','withdrawal','retention'],[
 ('Joss','Specify bib numbers for a fictional fun run. Adult entries start with A, and numbers must be readable in black and white.'),
 ('Uma','For the junior category I manage, start numbers with J.'),
 ('Joss','Add a small star in the corner of adult bibs.'),
 ('Uma','Change only the junior prefix to JR. Keep adult entries as they were.'),
 ('Joss','Remove the adult-bib star. The A prefix and black-and-white readability remain.')],[
 (0,[A(1,'Joss','Specify bib numbers for a fictional fun run',[0]),A(2,'Joss','Adult bib numbers start with A',[0]),A(3,'Joss','Bib numbers remain readable in black and white',[0])],'Category prefix independent of readability.',['No real entrant identities.']),
 (1,[A(4,'Uma','Junior bib numbers start with J',[1])],'Uma owns junior category requirement.',['Do not change adult prefix.']),
 (2,[A(5,'Joss','Place a small star in the corner of adult bibs',[2])],'Decoration scope adult only.',['Not on juniors by default.']),
 (3,[U(4,[3],text='Junior bib numbers start with JR')],'Only junior prefix revised.',['Adult A and star remain at this point.']),
 (4,[W(5,[4])],'Only star removed.',['Keep prefixes and readable monochrome numbers.'])])

put(25,'en','interactive fiction branching','A dialogue tree changes branch access while retaining a reversible choice and a distinct hint request.',['conditional_active','local_revision','long_history'],[
 ('Zev','Outline a dialogue tree for a fictional spaceport clerk. Let players back out before paying the fictional docking fee, and never end the game for choosing a rude reply.'),
 ('Zev','If the player has the blue pass, show a shortcut through the conversation.'),
 ('Assistant','A rude answer could trigger an instant game over.'),
 ('Zev','That contradicts the rule already given; keep the rule.'),
 ('Zev','The shortcut should require the gold pass instead of the blue one.'),
 ('Assistant','The pass check has changed in the outline.'),
 ('Zev','Add a branch where the clerk explains the fee before the player chooses whether to pay.'),
 ('Zev','How can we hint at the shortcut without revealing its exact condition? Give me two approaches.'),
 ('Assistant','I have received the request for two approaches.')],[
 (0,[A(1,'Zev','Outline a fictional spaceport-clerk dialogue tree',[0]),A(2,'Zev','Allow players to back out before paying the fictional docking fee',[0]),A(3,'Zev','Never end the game for selecting a rude reply',[0])],'Task, reversible prepayment choice and no game-over rule.',['No real payment execution.']),
 (1,[A(4,'Zev','Show a conversation shortcut if the player has the blue pass',[1])],'Settled condition active.',['Not an uncertain shortcut.']),
 (3,[],'Contradictory suggestion rejected; existing prohibition restated.',['Do not create instant game over.']),
 (6,[U(4,[4],text='Show a conversation shortcut if the player has the gold pass'),A(5,'Zev','Include a branch explaining the fee before the player decides whether to pay',[6])],'Condition changes and explanatory branch added.',['Retain ability to back out.']),
 (8,[A(6,'Zev','Give two approaches to hinting at the shortcut without revealing its exact condition',[7])],'New design-information request.',['No hint method selected yet.'])])

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 assert len(F)==25 and Counter(f['language'] for f in F)=={'zh':12,'en':13}
 assert [f['family_id'] for f in F]==[f'train-d-{i:03d}' for i in range(1,26)]
 assert all(len(f['decisions'])==5 for f in F)
 assert sum(len(f['events'])>=8 for f in F)>=6
 checks=[]
 for f in F:
  assert 5<=len(f['events'])<=14 and f['decisions'][-1]['through_seq']==len(f['events'])-1
  assert [d['through_seq'] for d in f['decisions']]==sorted(set(d['through_seq'] for d in f['decisions']))
  ds=[]
  with IntentStore(':memory:') as st:
   for k,d in enumerate(f['decisions']):
    st.observe([e for e in f['events'] if e['seq']<=d['through_seq']]);b=st.snapshot()
    assert all(o['source_seqs']==sorted(set(o['source_seqs'])) and max(o['source_seqs'])<=d['through_seq'] for o in d['operations'])
    a=st.commit_patch(f'setup-{k}',b['version'],d['through_seq'],d['operations'])
    bb={i['intent_id']:i for i in b['intents']};aa={i['intent_id']:i for i in a['intents']}
    assert all(bb[i]==aa[i] for i in d['preserve_ids'])
    ds.append({'decision_index':k,'runtime_replay':'passed','preserved_records':len(d['preserve_ids']),'author_semantic_check':'completed; independent review pending'})
  checks.append({'family_id':f['family_id'],'decisions':ds})
 target=P/'data/source/train-d.jsonl';target.parent.mkdir(parents=True,exist_ok=True)
 target.write_text(''.join(json.dumps(f,ensure_ascii=False,separators=(',',':'))+'\n' for f in F),encoding='utf-8')
 report={'id':'train-d-author-self-check','date':'2026-10-24','timezone':'America/Halifax','created_at_utc':datetime.now(timezone.utc).isoformat(),'author':'tracker_annotation_v2','kind':'author_self_review_and_engineering_replay_not_independent_semantic_review','status':'authored_and_self_checked_independent_review_required','source_sha256':sha(target),'builder_sha256':sha(Path(__file__)),'annotation_guide_sha256':sha(P/'annotation/ANNOTATION_GUIDE.md'),'common_prompt_sha256':sha(P/'annotation/system_prompt.txt'),'families':25,'updates':125,'languages':dict(Counter(f['language'] for f in F)),'events':sum(len(f['events']) for f in F),'families_with_8_or_more_events':sum(len(f['events'])>=8 for f in F),'no_change_decisions':sum(not d['operations'] for f in F for d in f['decisions']),'operations':dict(Counter(o['op'] for f in F for d in f['decisions'] for o in d['operations'])),'human_review_performed':False,'independent_review_performed':False,'authorship':'25 individually written fictional scenarios; no translated sibling inflation or content templates','helper_scope':'event/intent IDs, field construction, serialization, replay and bookkeeping','checks':checks,'limitations':['Synthetic pilot, not real user logs or representative deployment coverage.','Five decisions in one family are correlated.','Self review is not independent semantic review.','No training, inference or runtime edits performed by this author.','Unsupported same-patch reopen plus text/owner revision excluded.']}
 (P/'data/authoring/train-d-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({k:report[k] for k in ('source_sha256','families','updates','languages','events','families_with_8_or_more_events','no_change_decisions','operations')}))
if __name__=='__main__':main()
