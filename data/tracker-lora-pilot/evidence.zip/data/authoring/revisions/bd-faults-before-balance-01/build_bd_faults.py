"""Curated plausible text mistakes; no additional examples are created."""
from pathlib import Path
from datetime import datetime,timezone
import json,copy,hashlib,sys
ROOT=next(p for p in Path(__file__).resolve().parents if (p/'experiments/deep_conversation/intention_state.py').exists())
P=ROOT/'output/research/2026-10-24/tracker-lora-pilot'
sys.path.insert(0,str(ROOT/'experiments/deep_conversation'))
from intention_state import IntentStore

# Each item was selected against its supplied arrived dialogue and prior state.
B=[
 (1,5,2,'复现实验训练随机种子固定为71',[0],'digit_transposition','The original request explicitly fixed seed 17; 71 is a plausible transposition, unrelated to the newly added dataset-access paragraph.'),
 (2,4,2,'科技展示向学生收报名费',[0],'negation_drop','The original instruction says students pay no registration fee; a dropped negation must be repaired while adding the comparison question.'),
 (3,5,3,'本期社团通讯全文不超过180字',[0],'digit_omission','The stated cap is 1800 characters; a dropped zero should not survive when the acknowledgement block is reopened.'),
 (4,5,2,'论文使用A3纸',[0],'format_value_substitution','The original A4 request is still valid; a mistaken A3 entry requires correction even on a thanks turn.'),
 (5,4,1,'安排B2程度的西班牙语口语练习',[0],'level_value_substitution','A2 remains explicitly supported; changing correction timing does not authorize a higher learner level.'),
 (6,5,3,'陶器展整个展区使用闪烁灯光',[0],'negation_drop','The original no-flashing requirement is independent of the tactile-copy cancellation; a missing negation must be restored.'),
 (7,5,3,'任何退款无需人工批准',[0],'polarity_reversal','Human approval was mandatory; shrinking the refund window must not perpetuate a reversed approval rule.'),
 (8,5,2,'字幕听不清之处自行补词',[0],'scope_and_negation_loss','The arrived original explicitly requires unclear markers and forbids guessing; a remembered paraphrase must not reverse it while filler policy changes.'),
 (9,5,2,'招聘练习技术题环节50分钟',[2],'digit_substitution','The latest arrived technical-task revision says 15 minutes; cancelling the question segment does not alter that duration.'),
 (10,5,3,'若发布桌面版，测试计划必须包含Firefox测试',[1],'condition_scope_substitution','The settled Firefox condition was Web release, not desktop release; reopening export tests leaves that condition unchanged.'),
 (11,5,3,'部署错误率超过10%时回退',[4],'decimal_scale_error','The latest user threshold is over 1%; the later ownership reminder should still permit repair from that arrived threshold.'),
 (12,5,2,'数据卡明确样本全部来自真实录音',[0],'source_scope_substitution','The data is explicitly simulated; a source-type misremembering must be corrected alongside the new usage limitation.')]
D=[
 (1,5,3,'每场排球比赛之间至少间隔五分钟',[0],'numeric_value_substitution','The original minimum interval is fifteen minutes; the ranking-method question does not change it.'),
 (2,5,2,'每盒装十四个餐包',[5],'digit_insertion','The latest arrived quantity is four per box; an inserted ten must be repaired while adding an uncollected-order column.'),
 (3,5,3,'公开直播观众联系方式',[0],'negation_drop','The original public-contact prohibition remains; a missing negation is repairable from raw dialogue.'),
 (4,5,2,'邮筒模型高度八十米',[2],'unit_substitution','The latest requested height is eighty centimetres, not metres; thanks does not excuse the unit mistake.'),
 (5,5,3,'双人舞整段使用地面翻滚',[0],'negation_drop','The no-floor-roll constraint is independent of Qiao’s entry side; restore its missing negation.'),
 (6,5,4,'天气广播所有数字注明是真实观测数据',[0],'evidence_type_substitution','The fictional script must label numbers as demonstration data; a later concept question does not turn them into observations.'),
 (7,5,2,'每个菜单按钮文案不超过十六个汉字',[0],'digit_insertion','The arrived button cap is six Chinese characters; preserve it when adding the Resume translation comparison.'),
 (8,5,3,'主角送信的动机是兑现对哥哥的承诺',[0],'entity_relation_substitution','The original motive names the sister; the later acknowledgement does not change that relationship.'),
 (9,5,4,'西区货架编码以E开头',[1],'cross_scope_value_copy','The west prefix is W and belongs to Feng; accidentally copying the east prefix is repairable without merging owners.'),
 (10,5,2,'付款原型连接支付服务',[0],'negation_and_scope_loss','The task is simulation-only without payment-service connection; the comparison question must not retain a reversed scope boundary.'),
 (11,5,3,'堆肥箱温度使用华氏度',[0],'unit_substitution','Celsius is explicit and reaffirmed; changing recording frequency must not change units.'),
 (12,5,2,'密室谜题锁住出口',[0],'negation_drop','The original says not to lock the exit; a mistaken negative omission is corrected while adding a clue-structure question.'),
 (13,5,2,'Include a ten-centimetre seam allowance',[0],'numeric_value_substitution','The original and latest reaffirmed allowance is one centimetre; ten is an accidental scale error.')]

def projection(s):return [{k:i[k] for k in ('intent_id','owner','text','status')} for i in s['intents']]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 out=P/'data/faults';out.mkdir(parents=True,exist_ok=True);reports=[]
 for part,specs in [('b',B),('d',D)]:
  source=P/f'data/source/train-{part}.jsonl';sourcehash=sha(source)
  families={f['family_id']:f for f in map(json.loads,source.read_text(encoding='utf-8').splitlines())};rows=[];checks=[]
  for num,step,ident,wrong,seqs,etype,why in specs:
   fid=f'train-{part}-{num:03d}';f=families[fid];d=f['decisions'][step-1];iid=f'i{ident}'
   assert iid not in {o['intent_id'] for o in d['operations']}
   with IntentStore(':memory:') as st:
    for k,prev in enumerate(f['decisions'][:step-1]):
     st.observe([e for e in f['events'] if e['seq']<=prev['through_seq']]);b=st.snapshot();st.commit_patch(f'setup-{k}',b['version'],prev['through_seq'],prev['operations'])
    st.observe([e for e in f['events'] if e['seq']<=d['through_seq']]);before=st.snapshot();good=next(i for i in before['intents'] if i['intent_id']==iid)
    assert good['status'] in ('active','uncertain') and good['text']!=wrong
    repair=good['text'];after=st.commit_patch('decision-0',before['version'],d['through_seq'],d['operations'])
   assert all(s<=d['through_seq'] for s in seqs)
   entry=dict(example_id=f'{fid}-{step}',intent_id=iid,wrong_text=wrong,repair_text=repair,repair_source_seqs=seqs,error_type=etype,rationale=why)
   changed=copy.deepcopy(f);candidates=[(j,k) for j,pd in enumerate(changed['decisions'][:step-1]) for k,o in enumerate(pd['operations']) if o['intent_id']==iid and 'text' in o]
   j,k=candidates[-1];changed['decisions'][j]['operations'][k]['text']=wrong
   with IntentStore(':memory:') as st:
    for ordinal,prev in enumerate(changed['decisions'][:step-1]):
     st.observe([e for e in f['events'] if e['seq']<=prev['through_seq']]);b=st.snapshot();st.commit_patch(f'setup-{ordinal}',b['version'],prev['through_seq'],prev['operations'])
    st.observe([e for e in f['events'] if e['seq']<=d['through_seq']]);bad=st.snapshot()
    assert next(i for i in bad['intents'] if i['intent_id']==iid)['text']==wrong
    patched=st.commit_patch('decision-0',bad['version'],d['through_seq'],d['operations']+[dict(op='update',intent_id=iid,text=repair,source_seqs=seqs)])
    assert projection(after)==projection(patched)
   rows.append(entry);checks.append(dict(example_id=entry['example_id'],wrong_text=wrong,repair_text=repair,arrived_evidence=[e for e in f['events'] if e['seq'] in seqs],ordinary_target_does_not_touch_id=True,repair_reproduces_gold_semantics=True,author_review='self_checked_not_independent'))
  assert sha(source)==sourcehash
  path=out/f'train-{part}.json';path.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
  reports.append({'source':source.relative_to(P).as_posix(),'source_sha256':sourcehash,'fault_file':path.relative_to(P).as_posix(),'fault_sha256':sha(path),'faults':len(rows),'distinct_families':len({r['example_id'].rsplit('-',1)[0] for r in rows}),'checks':checks})
 report={'date':'2026-10-24','timezone':'America/Halifax','created_at_utc':datetime.now(timezone.utc).isoformat(),'kind':'fault_author_self_check_not_independent_review','author':'tracker_annotation_v2','status':'proposed_and_replayed_pending_independent_semantic_review','human_review_performed':False,'ordinary_sources_modified':False,'extra_training_rows_created':0,'total_faults':25,'b_faults':12,'d_faults':13,'reports':reports,'limitations':['Plausible authored stress errors are not observed deployment-error frequencies.','The latest prior text-bearing operation is corrupted, not the user conversation.','Repair targets must be independently reviewed before inclusion.']}
 (P/'data/authoring/train-bd-faults-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({k:report[k] for k in ('status','total_faults','b_faults','d_faults','extra_training_rows_created')}))
if __name__=='__main__':main()
