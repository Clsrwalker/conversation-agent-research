"""Twenty-five individually authored scenarios; no content template expansion."""
from common import A, U, W, R, step as S, family as F, save

cases = [
F('train-c-001','train','zh','community poster','社区花园招募海报修改印刷与联系要求',['retention','combined_change','quotation'],[
S([('岚','帮我做社区花园招募海报，A4竖版，报名请大家发邮件。')],[A('i1','岚','制作社区花园招募海报'),A('i2','岚','海报采用A4竖版'),A('i3','岚','海报报名方式为邮件')],'任务、版式和报名渠道可分别修改。',['三项均保留为独立需求']),
S([('助手','可以放一个扫码报名入口。','assistant'),('岚','先保留邮件。另外把字做大一点，老人看得清。')],[A('i4','岚','海报文字要足够大，便于老人阅读')],'邮件已存在；助手二维码建议未采纳。',['不新增二维码要求','保留邮件和A4竖版']),
S([('岚','印刷店说横版更适合展示架，改A4横版吧；字大一点这条别动。')],[U('i2','海报采用A4横版')],'仅版式被明确替换。',['保留大字要求','保留邮件报名']),
S([('同伴','我看到隔壁海报写了“电话报名”，只是说一下，不提改动。'),('岚','知道了，咱们现有方案继续。'),('助手','我把版本记录整理好了。','assistant'),('岚','收到。')],[],'引用其他海报且明示不改；确认和进度不新增要求。',['不可把电话引入现有报名方式']),
S([('岚','邮箱暂时停用了，把邮件报名那条撤掉。海报先不印，先给我电子预览就好。')],[W('i3'),A('i5','岚','海报暂不印刷，先提供电子预览')],'撤销渠道不撤销海报；新交付阶段明确。',['保留A4横版和大字','不虚构替代报名渠道'])]),
F('train-c-002','train','zh','shared cooking','聚餐菜单的个人禁忌与待确认饮食选择',['multi_owner','uncertainty_resolution'],[
S([('宁','帮我们列周末聚餐菜单，我不吃花生。'),('乔','我这边需要全素菜。')],[A('i1','宁','列周末聚餐菜单',sources=[0]),A('i2','宁','宁的餐食不能含花生',sources=[0]),A('i3','乔','乔的餐食须为全素',sources=[1])],'需求归属依各自发言，不能泛化所有人。',['宁的花生限制归宁','乔的全素限制归乔']),
S([('宁','我还可能需要无麸质，检查结果没出来，先别当成确定禁忌。')],[A('i4','宁','宁可能需要无麸质餐食，尚未确认','uncertain')],'具体潜在需求明确但未确定。',['不能把候选变active']),
S([('助手','我可以把所有人的菜都做成全素。','assistant')],[],'未获用户采纳的建议。',['不能把乔的限制推广到所有人']),
S([('宁','结果出来了，我没有无麸质要求，取消那个待确认项；花生仍然不能有。')],[W('i4')],'明确否决候选，花生维持。',['保留宁花生和乔全素']),
S([('乔','我的全素要求保持。请另给我一份不依赖烤箱的做法。')],[A('i5','乔','给乔提供不依赖烤箱的做法')],'重复全素不再更新，新烹饪要求独立加入。',['不删除宁的约束'])]),
F('train-c-003','train','zh','data import','库存CSV导入的编码、编号和重复行政策',['local_revision','new_question','retention'],[
S([('浩','写一个库存CSV导入脚本，商品编号前面的零必须保留，输入编码是UTF-8。')],[A('i1','浩','编写库存CSV导入脚本'),A('i2','浩','导入时保留商品编号前导零'),A('i3','浩','输入CSV使用UTF-8编码')],'格式约束分开。',['编号不得转整数丢零']),
S([('浩','重复的整行先保留，别自动去重。')],[A('i4','浩','导入保留完全重复的行，不自动去重')],'新增重复处理政策。',['编码和前导零不变']),
S([('助手','可以先按编号转成数字再匹配。','assistant'),('浩','这个建议不采用，编号还是原字符串。'),('助手','明白，原字符串。','assistant'),('浩','嗯。')],[],'用户重申既有前导零约束且拒绝建议。',['不增加数字转换']),
S([('浩','上游改成GB18030了，只换输入编码，其他处理原样。')],[U('i3','输入CSV使用GB18030编码')],'仅输入编码替换。',['保留重复行','保留前导零']),
S([('浩','保留重复行会不会让汇总翻倍？先解释影响，不要据此改脚本。')],[A('i5','浩','解释保留重复行是否会导致库存汇总翻倍，不据此修改脚本')],'新解释请求并非授权改去重政策。',['不能撤销i4'])]),
F('train-c-004','train','zh','library scheduling','图书馆亲子活动时间与儿童报名材料',['combined_change','cancellation'],[
S([('梅','安排图书馆亲子朗读活动，周六上午十点开始，控制在四十五分钟。')],[A('i1','梅','安排图书馆亲子朗读活动'),A('i2','梅','朗读活动周六上午十点开始'),A('i3','梅','朗读活动时长四十五分钟')],'时间与时长独立。',['开始时间不等同持续时间']),
S([('梅','要有报名表，但不要收孩子的家庭住址。')],[A('i4','梅','制作朗读活动报名表'),A('i5','梅','报名表不收集孩子家庭住址')],'交付物与隐私约束分开。',['不可推断不收集全部信息']),
S([('助手','场地有人用到十点半。','assistant'),('梅','那改十一点，缩到半小时。')],[U('i2','朗读活动周六上午十一点开始',sources=[3]),U('i3','朗读活动时长三十分钟',sources=[3])],'用户明确同时修改两个时间维度。',['仍是周六','保留地址限制']),
S([('梅','报名表先不做了，现场直接入场。')],[W('i4'),A('i6','梅','朗读活动允许现场直接入场')],'明确撤销交付物，新入场方式加入；地址限制未明说撤销。',['不自动撤销其他仍记录的约束']),
S([('梅','后来还是决定做报名表，恢复原先那项，也继续不收家庭住址。')],[R('i4')],'原ID恢复，地址限制未改变；现场直接入场没有被明确取消。',['不无依据撤销i6','保留新时间时长'])]),
F('train-c-005','train','zh','photo archive','家庭照片整理与只读原件保护',['conditional','proposal_acceptance'],[
S([('朔','帮我整理旅行照片，原文件只能读，所有改名都在副本上做。')],[A('i1','朔','整理旅行照片'),A('i2','朔','原照片只读，所有改名仅在副本进行')],'操作范围保护为完整约束。',['不得改动原件']),
S([('助手','副本按拍摄日期建文件夹如何？','assistant'),('朔','采用这个分法。')],[A('i3','朔','照片副本按拍摄日期分文件夹',sources=[1,2])],'接受短语需要提案与接受原文。',['不能仅凭助手提案在前一轮生效']),
S([('朔','如果照片没有拍摄日期，就放入“待确认”，别拿文件修改时间顶替。')],[A('i4','朔','缺拍摄日期的照片放入待确认目录，不用文件修改时间代替')],'明确条件规则是active，不是uncertain。',['保留条件和禁止替代']),
S([('朔','好的，继续这个方案。'),('助手','我已经列出目录。','assistant'),('朔','收到，目前没有补充。'),('助手','已记录。','assistant')],[],'确认和助手进度都不更改意图。',['不标完成或撤销整理任务']),
S([('朔','目录改成按城市分，原件保护和缺日期处理都照旧。')],[U('i3','照片副本按城市分文件夹')],'只变分组维度，其他规则被明确保留。',['不能丢掉待确认规则'])]),
F('train-c-006','train','zh','commute comparison','通勤路线比较的硬条件和兴趣询问',['preference_strength','new_question'],[
S([('卓','比较三条公交通勤路线，单程不能超过四十五分钟，尽量少换乘。')],[A('i1','卓','比较三条公交通勤路线'),A('i2','卓','通勤单程不超过四十五分钟'),A('i3','卓','通勤尽量少换乘，是偏好而非硬限制')],'时长硬条件和换乘偏好强度不同。',['保留尽量语气']),
S([('卓','我想知道骑车这条路坡多不多，暂时不把骑车加入方案比较。')],[A('i4','卓','回答骑车路线是否多坡，暂不把骑车加入公交方案比较')],'信息请求不扩展主比较范围。',['主任务仍是三条公交路线']),
S([('助手','可以将比较改成公交加骑车。','assistant')],[],'建议没有获得采纳。',['不改i1']),
S([('卓','时长可以放宽到五十五分钟，但换乘现在必须最多一次。')],[U('i2','通勤单程不超过五十五分钟'),U('i3','通勤最多换乘一次，是硬限制')],'数值和偏好强度同时变化。',['不能只修改时间漏掉强度']),
S([('卓','坡度那个问题不用答了，公交比较照常继续。')],[W('i4')],'仅撤销信息请求。',['不取消路线比较'])]),
F('train-c-007','train','zh','museum visit','家庭参观路线中未确定的轮椅需求',['unresolved_owner','uncertainty_resolution'],[
S([('舒','规划一个博物馆半日参观路线，下午一点前结束。')],[A('i1','舒','规划博物馆半日参观路线'),A('i2','舒','博物馆参观下午一点前结束')],'明确任务与结束截止。',['不改成一点开始']),
S([('舒','群里提到可能有人需要无台阶路线，但还没说明是谁，也没最终确认。')],[A('i3','__unresolved__','可能有人需要无台阶参观路线，归属与是否需要均未确定','uncertain')],'报告未定需要，不赋给舒。',['owner未知','不是已确定全员要求']),
S([('遥','是我需要，推婴儿车不能走台阶，按这个安排。')],[U('i3','遥的参观路线须无台阶，方便推婴儿车',owner='遥',status='active')],'本人确认归属和需求，沿原ID更新。',['不新增重复无台阶记录']),
S([('舒','谢谢，半天安排不变。')],[],'确认保持，无新增。',['保留遥的要求']),
S([('遥','另外给我标出有电梯的入口。')],[A('i4','遥','标出博物馆有电梯的入口')],'新请求补充而非替换无台阶。',['不删除截止时间'])]),
F('train-c-008','train','zh','home network','家庭网络排查中的只诊断边界',['negative_scope','retention'],[
S([('辛','帮我写路由器断线排查清单，只做诊断，不恢复出厂设置。')],[A('i1','辛','编写路由器断线排查清单'),A('i2','辛','排查仅做诊断，不恢复路由器出厂设置')],'任务与禁止破坏性动作分开。',['诊断限制不等于已授权改配置']),
S([('辛','请优先检查有线连接，Wi-Fi放后面。')],[A('i3','辛','先检查有线连接，再检查Wi-Fi')],'新增排查顺序。',['原设置保护仍在']),
S([('助手','论坛有人建议直接重置。','assistant'),('辛','那只是论坛建议，我没同意。')],[],'显式拒绝引文建议。',['不能撤销禁止重置']),
S([('辛','顺序反过来吧，先排Wi-Fi；只诊断仍然有效。')],[U('i3','先检查Wi-Fi，再检查有线连接')],'仅顺序变化。',['保留i2']),
S([('辛','再解释一下双重NAT是什么意思，用一段话就行。')],[A('i4','辛','用一段话解释双重NAT的含义')],'独立解释请求不授权网络操作。',['不标诊断任务完成'])]),
F('train-c-009','train','zh','volunteer allocation','志愿者班次归属不可代改',['multi_owner','quotation','owner_authority'],[
S([('蓝','给我排周六上午的签到岗。'),('泽','我只负责下午的引导岗。')],[A('i1','蓝','蓝承担周六上午签到岗',sources=[0]),A('i2','泽','泽只承担周六下午引导岗',sources=[1])],'各自声明班次。',['禁止交换owner']),
S([('蓝','我改周日上午签到，泽的安排别动。')],[U('i1','蓝承担周日上午签到岗')],'只改蓝。',['泽仍周六下午']),
S([('蓝','我听别人说泽想改上午，但我不确定，先别据此改他的班次。'),('助手','目前记录的是泽周六下午引导。','assistant'),('蓝','对，先保留那条。')],[],'未证实转述且明确不修改，不新增泽需求。',['不撤销i2']),
S([('泽','我确认改周六上午引导，还是引导岗。')],[U('i2','泽只承担周六上午引导岗')],'本人修改有依据，保留岗位和日期。',['蓝仍周日上午签到']),
S([('蓝','还请把我的班次单独发成一行文本，方便我复制。')],[A('i3','蓝','把蓝的班次单独整理成一行可复制文本')],'新增交付形式仅对蓝。',['不能将泽班次强行加入同一行'])]),
F('train-c-010','train','zh','repair quotation','家具维修询价的范围与分项预算',['combined_change','negative_scope'],[
S([('凡','帮我拟一封椅子维修询价邮件，只询价，不替我预约维修。')],[A('i1','凡','拟椅子维修询价邮件'),A('i2','凡','只询价，不预约维修')],'写作任务不等于实际发送或预约。',['不要创建发送授权']),
S([('凡','邮件里要问人工费和材料费各是多少。')],[A('i3','凡','询价邮件分别询问人工费和材料费')],'分项报价需求明确。',['不把分项合成总价请求']),
S([('助手','是否附上我的预计预算？','assistant'),('凡','先不用写预算。')],[A('i4','凡','询价邮件不写预算')],'用户明确新增不披露预算约束。',['不是单纯ack']),
S([('凡','椅子不用修了，改问书桌抽屉维修，其他邮件要求照旧。')],[U('i1','拟书桌抽屉维修询价邮件')],'对象变更，询价及预算边界保留。',['保留人工材料分项','不预约']),
S([('凡','预算那条限制取消，可以在邮件里写预算，但金额我还没定。')],[W('i4')],'撤销禁止披露并不产生确定预算数额。',['不虚构金额或预约'])]),
F('train-c-011','train','zh','reading club','读书会纪要的匿名与暂定翻译需求',['uncertainty','proposal_rejection'],[
S([('伊','整理读书会纪要，不要出现参与者真名。')],[A('i1','伊','整理读书会纪要'),A('i2','伊','纪要不得出现参与者真名')],'匿名是硬约束。',['不从原始speaker自动写进纪要']),
S([('伊','可能要给外地朋友一版英文，但我还没决定，请先记作待定。')],[A('i3','伊','读书会纪要可能需要英文版，尚未决定','uncertain')],'本人潜在需求，可归本人但uncertain。',['英文版不可当成已批准交付']),
S([('助手','我可以顺便把大家的职业也列进去。','assistant'),('伊','不用加职业，原来的匿名要求继续。')],[A('i4','伊','纪要不列参与者职业')],'明确不加职业是新独立约束，不只是重申匿名。',['不得丢弃匿名']),
S([('伊','英文版确定要，长度控制在一页。')],[U('i3','提供读书会纪要英文版',status='active'),A('i5','伊','英文版纪要长度不超过一页')],'确定候选并新增只约束英文版的长度。',['中文版不被无据限制一页']),
S([('伊','谢谢，就按刚才这些要求。')],[],'确认，无语义变化。',['保留全部仍有效需求'])]),
F('train-c-012','train','zh','garden inventory','种子记录中的单位更换和候选照片字段',['local_revision','uncertainty_withdrawal'],[
S([('苇','给社区种子库做一张记录表，数量按克记，保质期必须单独一列。')],[A('i1','苇','制作社区种子库记录表'),A('i2','苇','种子数量单位为克'),A('i3','苇','保质期单独成列')],'数量单位可替换，保质期独立。',['不丢单独列要求']),
S([('苇','小包装不好称，数量改成袋，但保质期那列留着。')],[U('i2','种子数量单位为袋')],'只修改计量单位。',['不将袋当新增并保留旧克单位']),
S([('苇','照片列可能有用，我还要问保管员，先列为待确认。')],[A('i4','苇','记录表可能增加照片列，待保管员确认','uncertain')],'候选字段未确定。',['不升级active']),
S([('助手','照片可用链接节省空间。','assistant'),('苇','保管员回复了，照片列完全不用。')],[W('i4')],'明确否决候选；助手实现建议无效。',['不添加照片链接']),
S([('苇','再加一列领用人昵称，不要身份证信息。')],[A('i5','苇','种子记录表增加领用人昵称列'),A('i6','苇','种子记录表不包含身份证信息')],'增加字段与禁止敏感字段分别记录。',['数量仍按袋'])]),
F('train-c-013','train','zh','oral history archive','口述史整理对原话与不明授权的处理',['quotation','conditional','new_question'],[
S([('澄','帮我给口述史录音做文字目录，原话保留方言，不改成普通话。')],[A('i1','澄','为口述史录音制作文字目录'),A('i2','澄','目录中的原话保留方言，不改为普通话')],'表达保真约束独立。',['不自作规范化']),
S([('澄','如果一段听不清，就标“听不清”，不要补猜的内容。')],[A('i3','澄','听不清的录音段标记听不清，不猜补内容')],'明确条件规则是active。',['不可把未知内容填成事实']),
S([('助手','录音里有人说“把我的名字写上”。','assistant'),('澄','那是录音引文，不是现在给你的指令。')],[],'引用音频人物的话不成为当前请求。',['不新增公开姓名任务']),
S([('澄','方言词旁边加括注解释，但原话还是别改。')],[A('i4','澄','在原方言词旁添加括注解释')],'补充注释不替换方言保留。',['i2继续有效']),
S([('澄','顺便说明逐字稿和文字目录的区别，先不用做逐字稿。')],[A('i5','澄','解释逐字稿与文字目录的区别，暂不制作逐字稿')],'说明新问题，范围限制明确。',['不得将主任务改为逐字稿'])]),
F('train-c-014','train','en','board game rules','A host revises a teach sheet without changing game rules',['retention','new_question','cancellation'],[
S([('Mara','Write a teaching sheet for our board game night. Keep it to one page and use the official rules only.')],[A('i1','Mara','Write a board-game teaching sheet'),A('i2','Mara','Keep the teaching sheet to one page'),A('i3','Mara','Use only the official game rules')],'Task, length and authority are separate.',['Do not invent house rules']),
S([('Mara','Add a short example of scoring a tie.')],[A('i4','Mara','Include a short example of scoring a tie')],'Example supplements existing requirements.',['Retain official rules and one-page limit']),
S([('Assistant','We could simplify by ignoring ties.','assistant'),('Mara','No, keep the official rule.')],[],'Rejected suggestion and restatement cause no update.',['Do not withdraw tie example']),
S([('Mara','Make it two pages so the type is readable. Also explain to me why the tie rule exists.')],[U('i2','Keep the teaching sheet to two pages'),A('i5','Mara','Explain why the game has its tie rule')],'Length revision and separate question both matter.',['The explanation request must not be dropped']),
S([('Mara','Forget that separate explanation; the example in the sheet is enough.')],[W('i5')],'Withdraw only the separate question.',['Keep scoring example i4'])]),
F('train-c-015','train','en','laundry room notice','Apartment notice switches channel and preserves language',['combined_change','reopen'],[
S([('Idris','Draft a laundry-room notice in English and Spanish. It should remind people to empty the lint filter.')],[A('i1','Idris','Draft a laundry-room notice reminding users to empty the lint filter'),A('i2','Idris','Provide the notice in English and Spanish')],'One notice task and independent language requirement.',['Both languages requested']),
S([('Idris','Please include a QR code linking to the building handbook.')],[A('i3','Idris','Include a QR code linking to the building handbook')],'New feature has a specific destination.',['Do not replace bilingual text with code']),
S([('Idris','Drop the QR code for now; the handbook link is being fixed.')],[W('i3')],'Explicit temporary withdrawal.',['Retain original ID and history']),
S([('Idris','The link works again. Put the QR code back, and make this an email draft instead of a wall notice.')],[R('i3'),U('i1','Draft an email reminding laundry-room users to empty the lint filter')],'Reopen unchanged code and revise independent artifact.',['Retain English and Spanish']),
S([('Assistant','I have prepared a draft.','assistant'),('Idris','Thanks.')],[],'Progress prose and thanks do not prove fulfillment or cancel intent.',['No completion operation'])]),
F('train-c-016','train','en','bird observation','Observation log separates uncertainty from confirmation',['uncertainty_resolution','negative_scope'],[
S([('Nora','Design a bird-observation log. Include location and date, but never exact nest coordinates.')],[A('i1','Nora','Design a bird-observation log with location and date'),A('i2','Nora','Never record exact nest coordinates')],'Location must respect narrower exclusion.',['Do not erase general location field']),
S([('Nora','I might need an audio-note field; I have not decided whether we will record sound.')],[A('i3','Nora','An audio-note field may be needed; recording sound has not been decided','uncertain')],'Concrete possible feature stays uncertain.',['Do not authorize recording']),
S([('Assistant','A photo field would also help.','assistant')],[],'Unaccepted suggestion creates no user requirement.',['Do not add photo field']),
S([('Nora','Yes to audio notes. Make them optional, not mandatory.')],[U('i3','Include an optional audio-note field',status='active')],'Acceptance resolves uncertainty while preserving optionality.',['Do not make field required']),
S([('Nora','Remove location altogether. Keep the date and the rule against exact nest coordinates.')],[U('i1','Design a bird-observation log with date and without a location field')],'Revise parent artifact wording; explicit prohibition stays.',['Keep optional audio notes'])]),
F('train-c-017','train','en','bike maintenance checklist','Checklist scope excludes execution and later restores a section',['withdrawal','reopen','scope'],[
S([('Theo','Prepare a bicycle maintenance checklist, with a separate tire-pressure section. I only want instructions, not a service booking.')],[A('i1','Theo','Prepare a bicycle maintenance checklist'),A('i2','Theo','Include a separate tire-pressure section'),A('i3','Theo','Provide instructions only; do not book a service')],'Artifact, section and action boundary.',['No service booking authorization']),
S([('Theo','Leave the tire-pressure section out temporarily; I already have one.')],[W('i2')],'Withdraw section, retain whole checklist.',['Do not withdraw i1']),
S([('Assistant','I could call the local shop.','assistant'),('Theo','Please stick to the original no-booking boundary.')],[],'Rejected proposal restates boundary.',['No new calling task']),
S([('Theo','I lost the old sheet. Restore the tire-pressure section as previously requested.')],[R('i2')],'Restore existing requirement with stable ID.',['No replacement ID']),
S([('Theo','Use metric units everywhere in the checklist.')],[A('i4','Theo','Use metric units throughout the bicycle maintenance checklist')],'Add cross-cutting unit constraint.',['Keep separate section and no booking'])]),
F('train-c-018','train','en','neighborhood survey','Survey priorities differ between participants',['multi_owner','owner_authority','new_question'],[
S([('Asha','Draft my neighborhood survey about street lighting. My version should have five questions.'),('Ben','For my separate survey on playgrounds, I need eight questions.')],[A('i1','Asha','Draft Asha\'s street-lighting neighborhood survey',sources=[0]),A('i2','Asha','Asha\'s survey should have five questions',sources=[0]),A('i3','Ben','Draft Ben\'s playground survey',sources=[1]),A('i4','Ben','Ben\'s survey should have eight questions',sources=[1])],'Distinct artifacts and owners.',['No merging question counts']),
S([('Asha','Increase mine to six. Ben\'s should stay as he requested.')],[U('i2','Asha\'s survey should have six questions')],'Mine resolves from speaker identity.',['Ben still eight']),
S([('Ben','What is the downside of multiple-choice questions? Just explain; do not revise either survey yet.')],[A('i5','Ben','Explain disadvantages of multiple-choice questions without revising either survey')],'New informational request without task modification.',['Do not mark whole turn no-change']),
S([('Assistant','Open questions might be better for everyone.','assistant'),('Asha','That is a suggestion, not a decision from me.'),('Ben','I have not adopted it either.')],[],'Suggestion is not accepted.',['No automatic change of survey format']),
S([('Ben','Cancel my survey. I still want the answer about question formats.')],[W('i3'),W('i4')],'Cancel own survey and its scoped count; keep separate information request explicitly.',['Asha unchanged','Retain i5'])]),
F('train-c-019','train','en','packing checklist','Conditional item is a settled rule, not an uncertain need',['conditional','local_revision'],[
S([('Owen','Make a packing checklist for a two-day cabin stay. No checked luggage.')],[A('i1','Owen','Make a packing checklist for a two-day cabin stay'),A('i2','Owen','Packing must fit without checked luggage')],'Main trip and baggage constraint.',['Two days stays in task']),
S([('Owen','If rain is forecast, include a rain shell; otherwise leave it off.')],[A('i3','Owen','Include a rain shell only if rain is forecast')],'Settled conditional rule is active.',['Do not set uncertain merely because conditional']),
S([('Owen','The cabin stay is now three days. The luggage limit stays.')],[U('i1','Make a packing checklist for a three-day cabin stay')],'Duration changed only.',['Keep no checked luggage']),
S([('Assistant','A second pair of boots may be useful.','assistant'),('Owen','Not adding that. Thanks.')],[],'Explicit rejection does not create a boots request.',['No new boots constraint unless broader refusal stated']),
S([('Owen','Include the rain shell regardless of forecast now.')],[U('i3','Always include a rain shell regardless of forecast')],'Replace condition rather than keep both rules.',['Keep duration three days'])]),
F('train-c-020','train','en','puzzle event','Event instructions preserve accessibility through schedule changes',['delayed_revision','combined_change'],[
S([('Leah','Plan a puzzle afternoon starting at 2 pm. Offer printed instructions in large type.')],[A('i1','Leah','Plan a puzzle afternoon'),A('i2','Leah','Start the puzzle afternoon at 2 pm'),A('i3','Leah','Offer printed instructions in large type')],'Accessibility is independently persistent.',['Large type is not optional suggestion']),
S([('Leah','Have teams of three, please.')],[A('i4','Leah','Use teams of three for the puzzle afternoon')],'New grouping requirement.',['Preserve print accessibility']),
S([('Assistant','The venue has movable tables.','assistant'),('Leah','Good to know.'),('Assistant','I have noted the room layout.','assistant'),('Leah','No changes to my instructions yet.')],[],'Background and progress do not establish new requirements.',['No invented table layout request']),
S([('Leah','Move the start to 3 pm and teams to pairs. The printed large-type instructions are still needed.')],[U('i2','Start the puzzle afternoon at 3 pm'),U('i4','Use teams of two for the puzzle afternoon')],'Two explicit modifications with preservation.',['Do not regenerate i3']),
S([('Leah','Also tell me how long a practice round should last; do not set a duration until I choose.')],[A('i5','Leah','Recommend a practice-round duration for Leah to choose, without treating it as fixed')],'Advice request not a confirmed duration constraint.',['No invented duration'])]),
F('train-c-021','train','en','pet care handover','Feeding handover retains distinct owners and instructions',['multi_task','retention'],[
S([('Jules','Write a cat-sitting handover. Feed Miso wet food at 7 am, and keep the balcony door shut.')],[A('i1','Jules','Write a cat-sitting handover'),A('i2','Jules','Feed Miso wet food at 7 am'),A('i3','Jules','Keep the balcony door shut')],'Task and two independent instructions.',['Do not merge door rule into feeding record']),
S([('Jules','For the plant-care note, water only the herbs, not the cactus.')],[A('i4','Jules','Write a plant-care note: water herbs only, not the cactus')],'Separate task with a scoped negative.',['Cat feeding unaffected']),
S([('Jules','Change Miso\'s breakfast to 8 am, same food. Leave the plant note alone.')],[U('i2','Feed Miso wet food at 8 am')],'Only time modified; food retained.',['Keep cactus exclusion']),
S([('Assistant','I can tell the sitter the balcony may be opened.','assistant'),('Jules','No, keep the door shut as agreed.')],[],'Rejects contradiction and repeats current requirement.',['No door reopening']),
S([('Jules','The plant note is no longer needed. Keep all the cat instructions.')],[W('i4')],'Withdraw separate task only.',['Preserve i1 i2 i3'])]),
F('train-c-022','train','en','public map','Map privacy and unknown request ownership',['unresolved_owner','uncertainty_resolution'],[
S([('Eli','Create a public map of the community allotments, using plot numbers instead of names.')],[A('i1','Eli','Create a public map of community allotments'),A('i2','Eli','Use plot numbers instead of personal names on the public map')],'Public artifact with privacy constraint.',['No inferred address sharing']),
S([('Eli','Someone on the committee may need a high-contrast version. I do not know who, and it is not confirmed.')],[A('i3','__unresolved__','A committee member may need a high-contrast map; owner and need are unconfirmed','uncertain')],'Unknown owner must not become Eli.',['Retain explicit uncertainty']),
S([('Rae','That was me, and yes, please provide high contrast.')],[U('i3','Provide Rae a high-contrast map',owner='Rae',status='active')],'Owner and adoption resolved by own statement.',['Keep original ID']),
S([('Assistant','I could label each plot with the gardener\'s name.','assistant'),('Eli','That conflicts with the plot-number plan; leave it as agreed.')],[],'Rejected name proposal, no new state.',['Retain privacy constraint']),
S([('Rae','Make my high-contrast copy a PDF. Eli\'s public map can keep its existing format.')],[A('i4','Rae','Provide Rae\'s high-contrast map copy as a PDF')],'Format applies only to Rae copy.',['Do not impose PDF on all outputs'])]),
F('train-c-023','train','en','meal rota','Rota exclusions and correction of a decision',['local_revision','reopen','retention'],[
S([('Pia','Build a weekday dinner rota. Tuesdays must be leftovers, and no meal should require an oven.')],[A('i1','Pia','Build a weekday dinner rota'),A('i2','Pia','Tuesday dinner must use leftovers'),A('i3','Pia','No dinner in the rota should require an oven')],'Day rule separate from appliance restriction.',['Weekday scope retained']),
S([('Pia','Actually, drop the Tuesday-leftovers rule.')],[W('i2')],'Explicit cancellation of a subrequirement.',['Do not cancel the rota']),
S([('Pia','Bring that Tuesday rule back after all.')],[R('i2',sources=[0,2])],'Elliptical reference resolves to same withdrawn item.',['Preserve original Tuesday wording']),
S([('Assistant','Roasting would make Friday easy.','assistant'),('Pia','No oven, as before.')],[],'Proposal rejected; existing restriction restated.',['No roasting requirement']),
S([('Pia','The leftovers day should be Wednesday now. Keep everything else.')],[U('i2','Wednesday dinner must use leftovers')],'Reopened active record can now be revised in later turn.',['Tuesday rule replaced, not duplicated'])]),
F('train-c-024','train','en','lost property form','Form asks for safe details and avoids invented requirements',['negative_scope','new_question','quotation'],[
S([('Sam','Draft a lost-property form for the makerspace. Ask for item description and approximate loss date, not a home address.')],[A('i1','Sam','Draft a makerspace lost-property form with item description and approximate loss date'),A('i2','Sam','Do not ask for a home address on the form')],'Requested fields and exclusion explicit.',['Do not demand an exact date']),
S([('Sam','Add an optional contact email field.')],[A('i3','Sam','Add an optional contact email field to the form')],'Optionality must remain.',['Do not make email required']),
S([('Sam','A sample form says "passport number required"; I am only quoting it, not adopting that field.')],[],'Explicitly disclaimed quotation.',['Do not add passport number']),
S([('Sam','Would an anonymous claim code work instead? Explain the tradeoff before changing the form.')],[A('i4','Sam','Explain the tradeoff of an anonymous claim code before changing the form')],'New unanswered question, email policy unchanged.',['No automatic switch to claim code']),
S([('Sam','I decided to keep the email field but make it required. The address exclusion still stands.')],[U('i3','Add a required contact email field to the form')],'Changes strength of one field only.',['Keep no home address','Explanation request not explicitly withdrawn'])]),
F('train-c-025','train','en','walking tour script','Tour script audience and uncertain translation',['uncertainty','combined_change','retention'],[
S([('Cleo','Write a walking-tour script for local residents. Keep the language nontechnical and finish at the old mill.')],[A('i1','Cleo','Write a walking-tour script for local residents'),A('i2','Cleo','Use nontechnical language in the tour script'),A('i3','Cleo','Finish the walking tour at the old mill')],'Audience, style and endpoint independent.',['Endpoint not confused with start']),
S([('Cleo','We may need a French version; attendance is not settled, so treat that as tentative.')],[A('i4','Cleo','A French version of the tour script may be needed; attendance is unsettled','uncertain')],'Concrete possible deliverable remains tentative.',['No confirmed translation yet']),
S([('Assistant','The old mill has a new sign.','assistant'),('Cleo','Interesting.'),('Assistant','I have noted that background.','assistant'),('Cleo','Nothing to add to the plan yet.')],[],'Background acknowledgement has no new request.',['Do not invent sign-description task']),
S([('Cleo','It is now for visiting teenagers, and the endpoint is the library. Still use nontechnical language.')],[U('i1','Write a walking-tour script for visiting teenagers'),U('i3','Finish the walking tour at the library')],'Two revisions, style preserved.',['French candidate still unresolved']),
S([('Cleo','No French version is needed after all. Add a short pronunciation guide for the place names instead.')],[W('i4'),A('i5','Cleo','Add a short pronunciation guide for place names in the tour script')],'Withdraw tentative deliverable and add different aid.',['Keep new audience and endpoint'])])
]

if __name__ == '__main__':
    save('train-c.jsonl', cases)
