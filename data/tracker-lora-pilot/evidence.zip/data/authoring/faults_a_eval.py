"""Author deliberate prior-text faults; independent review is still required."""
from pathlib import Path
import json, sys, hashlib
P=Path(__file__).resolve().parents[2];ROOT=P.parents[3]
sys.path.insert(0,str(ROOT/'experiments/deep_conversation'))
from intention_state import IntentStore
SPECS={
'train-a':[
 ('train-a-001',2,'i4','社区维修角向居民收取参加费用',[0],'polarity','A dropped negation could turn explicit free participation into a charge; the original statement already says residents participate free.'),
 ('train-a-002',3,'i2','旧码头语音导览总时长不超过三分钟',[0],'numeric_value','A nearby duration is a plausible transcription error; the earlier user explicitly capped the guide at two minutes.'),
 ('train-a-003',4,'i6','咖啡店销售表使用 CSV 格式',[1],'cross_task_value','The flower-shop format can contaminate the separate coffee-shop record; 许晴 explicitly requested XLSX earlier.'),
 ('train-a-006',5,'i3','磁铁课实验可以使用电池',[0],'polarity','Dropping 不 from the settled classroom constraint would permit batteries; arrived opening evidence forbids them.'),
 ('train-a-007',2,'i2','逐字稿中受访者姓名保留真实姓名',[0],'polarity','A tracker may mistakenly carry raw speaker names into the record; the original instruction requires aliases.'),
 ('train-a-011',3,'i3','骑车通勤单程时长不超过六十分钟',[1],'numeric_value','A mistaken time cap can appear in an otherwise valid state; the earlier stated cap is forty minutes.'),
 ('train-a-014',4,'i5','Make the indoor star-map workshop suitable only for experienced observers',[4],'audience_scope','The audience restriction reverses complete-beginner suitability; the workshop audience was explicitly set in an arrived message.'),
 ('train-a-015',2,'i3','Overwrite an existing export destination file when exporting',[0],'polarity','Negation loss can invert destination protection; the first request says never overwrite an existing file.'),
 ('train-a-017',5,'i2','Kitchen trolley width must not exceed forty-five centimetres',[4],'numeric_value','Transposing the revised width digits yields a plausible wrong cap; the previous correction explicitly states fifty-four.'),
 ('train-a-019',3,'i3','Keep the walkthrough at five steps or fewer',[0],'boundary_strength','Under five can be incorrectly normalized to five or fewer; the original strict bound is already visible.'),
 ('train-a-023',4,'i6','Replace missing bicycle counts with zero',[4],'polarity','An automatic-imputation assumption contradicts the earlier explicit empty-cell policy.'),
 ('train-a-024',5,'i2','Allow powered tools in the bookbinding workshop',[0],'scope','A convenient-tool assumption may broaden a hand-tools-only constraint; the original request supplies the correction.'),
],
'dev':[
 ('dev-002',2,'i2','每题开始前直接展示解法，然后让陶作答',[0],'ordering','A common tutoring shortcut reverses the requested independent-attempt-before-hint order; the opening gives the correct timing.'),
 ('dev-004',4,'i2','迁移文件上传云端后再处理',[0],'polarity','The state may incorrectly adopt cloud processing despite the arrived local-only instruction.'),
 ('dev-005',3,'i4','示意图导线不添加文字标签',[1,2],'polarity','The accepted two-part proposal includes text labels; dropping that part can become a negated record.'),
 ('dev-006',5,'i2','Replace the keyboard number row with default function keys',[0],'proposal_contamination','A previously unaccepted assistant proposal could contaminate the state; the original invariant keeps the number row unchanged.'),
 ('dev-009',3,'i2','Use pictures rather than stripes in Ada’s sampler',[0],'alternative_reversal','The original explicit stripe-versus-picture choice is reversed; arrived opening evidence is sufficient to repair it.'),
],
'test':[
 ('test-001',3,'i3','每字范字旁留两个临写空格',[1],'numeric_value','The recorded practice-cell count is off by one; the prior user requested three cells.'),
 ('test-002',2,'i2','记录每泡浸泡时长，单位分钟',[0],'unit','Minutes in place of seconds is a plausible unit-normalization error; the opening explicitly says seconds.'),
 ('test-003',4,'i2','所有原文件名统一加日期前缀',[0],'proposal_contamination','An unaccepted renaming suggestion may overwrite the original no-renaming requirement; the user opening retains original names.'),
 ('test-005',5,'i2','省略南瓜汤浓稠度说明',[0],'polarity','The state drops a retained instruction while other recipe work changes; source text explicitly preserves consistency guidance.'),
 ('test-007',4,'i4','未经检查的唱片品相默认记为良好',[1],'unsupported_default','A filled-in condition default conflicts with the prior policy to mark uninspected condition unknown.'),
 ('test-011',2,'i2','Print street addresses on spare-key labels',[0],'polarity','A lost negation reverses the label privacy restriction; earlier user evidence directly forbids addresses.'),
 ('test-014',3,'i4','Include a transmitter-power field instead of operating band in the contact log',[1],'field_substitution','Related radio fields can be confused, but the arrived instruction requested operating band, not a replacement power field.'),
 ('test-016',4,'i2','Tell the user to leave the sewing machine plugged in while cleaning',[0],'polarity','The stored safety wording is inverted; the supplied user request explicitly retains unplug-before-cleaning.'),
 ('test-018',5,'i2','Put pinned tabs into their project groups',[0],'scope','A broad grouping rule may accidentally absorb pinned tabs; the original independent exclusion is already visible.'),
 ('test-020',3,'i2','Fill missed weather readings by copying the previous value',[0],'polarity','Carry-forward imputation is a plausible default that directly contradicts the explicit missing-reading policy.'),
]}

def main():
 out=P/'data/faults';out.mkdir(parents=True,exist_ok=True); summaries=[]
 for stem,specs in SPECS.items():
  fs={f['family_id']:f for f in map(json.loads,(P/f'data/source/{stem}.jsonl').read_text(encoding='utf-8').splitlines())}
  faults=[];positions={str(i):0 for i in range(2,6)};langs={'zh':0,'en':0}
  for fid,pos,iid,wrong,seqs,kind,why in specs:
   f=fs[fid];idx=pos-1;target=f['decisions'][idx]
   assert iid not in {o['intent_id'] for o in target['operations']}
   with IntentStore(':memory:') as st:
    last=-1
    for di,d in enumerate(f['decisions'][:idx]):
     st.observe(f['events'][last+1:d['through_seq']+1]);st.commit_patch(f'decision-{di}',di,d['through_seq'],d['operations']);last=d['through_seq']
    record=next(r for r in st.snapshot()['intents'] if r['intent_id']==iid)
    assert record['status'] in ['active','uncertain'] and wrong!=record['text']
    assert max(seqs)<=last
    faults.append(dict(example_id=f'{fid}-{pos}',intent_id=iid,wrong_text=wrong,repair_text=record['text'],repair_source_seqs=seqs,error_type=kind,rationale=why))
   positions[str(pos)]+=1;langs[f['language']]+=1
  assert len({s[0] for s in specs})==len(specs)
  dest=out/f'{stem}.json';dest.write_text(json.dumps(faults,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
  summaries.append(dict(split=stem,count=len(faults),languages=langs,decision_positions=positions,source_sha256=hashlib.sha256(dest.read_bytes()).hexdigest()))
 (P/'data/authoring/a-eval-fault-self-check.json').write_text(json.dumps(dict(status='authored_pending_independent_review',human_review=False,checks='Every selected record exists active/uncertain before the target, target does not touch it, correct repair text is exact pre-state text, all repair evidence precedes the target decision, at most one fault per family.',summaries=summaries),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(summaries))

if __name__=='__main__':main()
