"""Curated plausible text mistakes; no additional examples are created."""
from pathlib import Path
from datetime import datetime,timezone
import json,copy,hashlib,sys
ROOT=next(p for p in Path(__file__).resolve().parents if (p/'experiments/deep_conversation/intention_state.py').exists())
P=ROOT/'output/research/2026-10-24/tracker-lora-pilot'
sys.path.insert(0,str(ROOT/'experiments/deep_conversation'))
from intention_state import IntentStore

# Each item was selected against its supplied arrived dialogue and prior state.
B=[
 (1,2,2,'复现实验训练随机种子固定为71',[0],'digit_transposition','Seed 17 was explicit; repair a transposition while the unaccepted experiment suggestion otherwise changes nothing.'),
 (3,3,3,'本期社团通讯全文不超过180字',[0],'digit_omission','The cap is 1800 characters; moving the publication day does not authorize dropping a zero.'),
 (5,4,1,'安排B2程度的西班牙语口语练习',[0],'level_value_substitution','A2 remains explicit; new correction timing must not raise the learner level.'),
 (7,5,3,'任何退款无需人工批准',[0],'polarity_reversal','Human approval is mandatory; a new refund window must not retain reversed approval.'),
 (9,2,3,'评分表只使用候选人姓名，不写编号',[0],'identity_field_reversal','The fictional exercise requires candidate codes rather than names; adding a question segment leaves anonymity unchanged.'),
 (11,3,1,'编写生产环境部署步骤',[0],'environment_scope_substitution','The original task is an exercise environment, not production; declining automatic switching does not change scope.'),
 (13,2,3,'Keep the analysis plan unblinded to group names',[0],'polarity_reversal','Nora explicitly requires blinding; an optional error-count candidate does not reverse it.'),
 (15,3,2,'Rewrite quoted speech in formal English in the booklet',[0],'quotation_policy_reversal','The original instruction preserves quoted speech verbatim; withdrawing the glossary does not accept the disclaimed formal-English quotation.'),
 (17,4,3,'Use numeric accent ratings in the pronunciation practice',[0],'negation_drop','The user avoids numeric accent ratings; rejecting the recording candidate does not cancel that preference.'),
 (19,5,4,'Escalate every order to a person',[2],'condition_omission','Only orders marked delivered but reported missing trigger the escalation; a shorter reply target must not broaden it to every order.'),
 (21,2,2,'Use real applicant profiles for the mock hiring exercise',[0],'fictional_scope_substitution','The arrived task explicitly permits fictional profiles only; adding pair collaboration does not authorize real profiles.'),
 (23,4,2,'Switch rollout traffic without manual approval',[0],'negation_and_authorization_reversal','The assistant completion claim does not change the requirement for manual approval before switching.')]
D=[
 (2,3,2,'每盒装十六个餐包',[0],'digit_insertion','At this decision the latest arrived box size is six; the later four-per-box instruction has not arrived and cannot be used.'),
 (4,4,2,'邮筒模型高度八十米',[2],'unit_substitution','The latest height is eighty centimetres; choosing plain material does not alter that unit.'),
 (6,2,4,'天气广播所有数字注明是真实观测数据',[0],'evidence_type_substitution','The initial fictional script marks all values as demonstration data; an unaccepted greeting is otherwise no change.'),
 (8,5,3,'主角送信的动机是兑现对哥哥的承诺',[0],'entity_relation_substitution','The original motive names the sister; later acknowledgement leaves that relationship unchanged.'),
 (10,2,2,'付款原型连接支付服务',[0],'negation_and_scope_loss','The original prototype is simulation-only without a payment connection; accepting cancel-button placement does not authorize live services.'),
 (12,4,2,'密室谜题锁住出口',[0],'negation_drop','The original says not to lock the exit; changing answer length must not retain a missing negation.'),
 (13,3,2,'Include a ten-centimetre seam allowance',[0],'numeric_value_substitution','The original allowance is one centimetre; changing closure and pocket size does not multiply it by ten.'),
 (15,2,3,'Require clients to upgrade immediately',[0],'negation_drop','The original migration plan does not require an immediate upgrade; a disclaimed renaming quote cannot change that.'),
 (17,5,3,'Keep assistant character’s pocket-watch chain visible in wide shots on Tali’s continuity sheet',[1],'shot_scope_substitution','Tali required visibility in close-ups, not wide shots; Remy cancelling gloves does not change Tali’s requirement.'),
 (19,4,2,'Use rapid flashing in the logo animation',[0],'polarity_reversal','The no-rapid-flashing rule survives the duration change.'),
 (21,2,3,'Delete matching messages in the mail-filter sandbox',[0],'action_scope_reversal','The original explicitly never deletes a message; adding a subject exception cannot permit deletion.'),
 (23,3,2,'Remove each plant’s variety label before packing',[0],'action_polarity_reversal','The user says keep variety labels attached; adding a soil-containment check leaves this intact.'),
 (25,5,2,'Prevent players from backing out before paying the fictional docking fee',[0],'choice_polarity_reversal','The original requires allowing a prepayment exit; a shortcut-hint question does not reverse it.')]

def projection(s):return [{k:i[k] for k in ('intent_id','owner','text','status')} for i in s['intents']]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 out=P/'data/faults';out.mkdir(parents=True,exist_ok=True);reports=[]
 for part,specs in [('b',B),('d',D)]:
  source=P/f'data/source/train-{part}.jsonl';sourcehash=sha(source)
  families={f['family_id']:f for f in map(json.loads,source.read_text(encoding='utf-8').splitlines())};rows=[];checks=[]
  for num,step,ident,wrong,seqs,etype,why in specs:
   fid=f'train-{part}-{num:03d}';f=families[fid];d=f['decisions'][step-1];iid=f'i{ident}'
   assert iid not in {o['intent_id'] for o in d['operations']}
   with IntentStore(':memory:') as st:
    for k,prev in enumerate(f['decisions'][:step-1]):
     st.observe([e for e in f['events'] if e['seq']<=prev['through_seq']]);b=st.snapshot();st.commit_patch(f'setup-{k}',b['version'],prev['through_seq'],prev['operations'])
    st.observe([e for e in f['events'] if e['seq']<=d['through_seq']]);before=st.snapshot();good=next(i for i in before['intents'] if i['intent_id']==iid)
    assert good['status'] in ('active','uncertain') and good['text']!=wrong
    repair=good['text'];after=st.commit_patch('decision-0',before['version'],d['through_seq'],d['operations'])
   assert all(s<=d['through_seq'] for s in seqs)
   entry=dict(example_id=f'{fid}-{step}',intent_id=iid,wrong_text=wrong,repair_text=repair,repair_source_seqs=seqs,error_type=etype,rationale=why)
   changed=copy.deepcopy(f);candidates=[(j,k) for j,pd in enumerate(changed['decisions'][:step-1]) for k,o in enumerate(pd['operations']) if o['intent_id']==iid and 'text' in o]
   j,k=candidates[-1];changed['decisions'][j]['operations'][k]['text']=wrong
   with IntentStore(':memory:') as st:
    for ordinal,prev in enumerate(changed['decisions'][:step-1]):
     st.observe([e for e in f['events'] if e['seq']<=prev['through_seq']]);b=st.snapshot();st.commit_patch(f'setup-{ordinal}',b['version'],prev['through_seq'],prev['operations'])
    st.observe([e for e in f['events'] if e['seq']<=d['through_seq']]);bad=st.snapshot()
    assert next(i for i in bad['intents'] if i['intent_id']==iid)['text']==wrong
    patched=st.commit_patch('decision-0',bad['version'],d['through_seq'],d['operations']+[dict(op='update',intent_id=iid,text=repair,source_seqs=seqs)])
    assert projection(after)==projection(patched)
   rows.append(entry);checks.append(dict(example_id=entry['example_id'],wrong_text=wrong,repair_text=repair,arrived_evidence=[e for e in f['events'] if e['seq'] in seqs],ordinary_target_does_not_touch_id=True,repair_reproduces_gold_semantics=True,author_review='self_checked_not_independent'))
  assert sha(source)==sourcehash
  path=out/f'train-{part}.json';path.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
  from collections import Counter
  reports.append({'source':source.relative_to(P).as_posix(),'source_sha256':sourcehash,'fault_file':path.relative_to(P).as_posix(),'fault_sha256':sha(path),'faults':len(rows),'distinct_families':len({r['example_id'].rsplit('-',1)[0] for r in rows}),'languages':dict(Counter(families[r['example_id'].rsplit('-',1)[0]]['language'] for r in rows)),'decision_positions':dict(Counter(int(r['example_id'].rsplit('-',1)[1]) for r in rows)),'checks':checks})
 report={'date':'2026-10-24','timezone':'America/Halifax','created_at_utc':datetime.now(timezone.utc).isoformat(),'kind':'fault_author_self_check_not_independent_review','author':'tracker_annotation_v2','status':'proposed_and_replayed_pending_independent_semantic_review','human_review_performed':False,'ordinary_sources_modified':False,'extra_training_rows_created':0,'total_faults':25,'b_faults':12,'d_faults':13,'reports':reports,'limitations':['Plausible authored stress errors are not observed deployment-error frequencies.','The latest prior text-bearing operation is corrupted, not the user conversation.','Repair targets must be independently reviewed before inclusion.']}
 (P/'data/authoring/train-bd-faults-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({k:report[k] for k in ('status','total_faults','b_faults','d_faults','extra_training_rows_created')}))
if __name__=='__main__':main()
