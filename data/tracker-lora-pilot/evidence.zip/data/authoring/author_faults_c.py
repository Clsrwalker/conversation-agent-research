"""Thirteen individually specified plausible pre-state errors, no extra rows."""
import json
from pathlib import Path
import sys
from common import ROOT
sys.path.insert(0, str(ROOT / 'experiments/deep_conversation/tracker_lora'))
from build_dataset import materialize, apply_prior_fault

STUDY = Path(__file__).resolve().parents[2]
prompt = (STUDY / 'annotation/system_prompt.txt').read_text(encoding='utf-8').strip()
families = {f['family_id']: f for f in map(json.loads, (STUDY/'data/source/train-c.jsonl').read_text(encoding='utf-8').splitlines())}
specs = [
('001','i2','海报采用A3横版','size_value','原文只从A4竖版改为A4横版，A3是先前误记，需保持横向并修复尺寸。'),
('003','i3','输入CSV使用UTF-8编码','stale_value','上游已明确改GB18030，最新一轮只是解释重复行影响，不能沿用过期UTF-8。'),
('004','i2','朗读活动周六上午十点开始','stale_value','时间已经改十一点，恢复报名表不撤销此前改时；十点是错误旧值。'),
('005','i2','所有照片改名直接在原文件上进行','negation_scope','原始用户明确原件只读、改名仅副本；新增缺日期处理规则不授权修改原件。'),
('007','i2','博物馆参观下午一点开始','temporal_relation','原文说一点前结束，不是开始；无台阶需求的归属确认不改变截止。'),
('012','i2','种子数量单位为克','stale_unit','原文已将数量改为袋，新增待确认照片字段不恢复克单位。'),
('014','i2','Keep the teaching sheet to one page','stale_value','User already revised to two pages; cancelling a separate explanation does not restore the old limit.'),
('016','i4','Record exact nest coordinates in the bird-observation log','negation','The original user expressly prohibited exact nest coordinates; the new possible audio field does not relax it.'),
('017','i3','Book a bicycle service after providing the instructions','scope','Original evidence requests instructions only and explicitly no service booking; dropping a checklist section does not change that.'),
('018','i2','Asha\'s survey should have eight questions','cross_owner_value','Asha changed her count to six; eight belongs to Ben, whose separate survey is now being cancelled.'),
('019','i1','Make a packing checklist for a two-day cabin stay','stale_value','The stay was explicitly changed to three days; declining a second pair of boots does not revert it.'),
('021','i2','Feed Miso dry food at 8 am','value_retention','The user changed only breakfast time and explicitly said same food, namely wet food.'),
('024','i3','Include an exact loss-date field on the lost-property form','precision_strength','Original request says approximate loss date; the new question about claim codes does not authorize an exact-date requirement.')]
faults=[]
decision_positions = {'001': 4, '003': 5, '004': 5, '005': 3, '007': 3, '012': 3,
                      '014': 5, '016': 2, '017': 2, '018': 5, '019': 4, '021': 4, '024': 4}
for number, key, wrong, kind, rationale in specs:
    family = families['train-c-'+number]
    row = materialize(family,prompt)[decision_positions[number]-1]
    original = next(i for i in row['input']['intention_state']['intents'] if i['intent_id'] == key)
    fault={'example_id':row['example_id'],'intent_id':key,'wrong_text':wrong,
           'repair_text':original['text'],'repair_source_seqs':[0, 2] if number == '021' else original['source_seqs'],
           'error_type':kind,'rationale':rationale + ' The repair relies on prior arrived evidence and is independent of the selected current update.'}
    apply_prior_fault(family,row,fault,prompt)
    faults.append(fault)
out=STUDY/'data/faults/train-c.json'
out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(json.dumps(faults,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'author':'root','faults':len(faults),'self_replay':'passed','independent_review':'pending'}))
