"""Freeze a truthful running-training milestone; no model calls or live exports."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
from datetime import datetime, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
STUDY=Path(__file__).resolve().parent.parent
ROOT=next(p for p in STUDY.parents if (p/'experiments/deep_conversation/intention_state.py').exists())

def read(p):
    return json.loads(p.read_text(encoding='utf-8'))

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def write(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def main():
    out=STUDY/'publication'
    assert not (out/'milestone.json').exists(),'Preserve this snapshot; use a new version for later results.'
    manifest=read(STUDY/'data/compiled/manifest.json')
    audit=read(STUDY/'audit/split-leakage-audit.json')
    assert manifest['status']=='approved_for_pilot'
    assert audit['manifest_sha256']==sha(STUDY/'data/compiled/manifest.json')
    assert audit['checks']['future_or_annotation_leakage_failures']==0
    lock=read(STUDY/'evaluation/protocol-lock.json')
    assert lock['status']=='frozen_before_test_collection'
    for x in lock['files'].values():
        assert sha(Path(x['path']))==x['sha256']
    formal=read(STUDY/'training/formal-pilot-01/result.json')
    assert formal['configuration']['epochs']==1 and formal['mode']=='train'
    assert formal['status']=='running','Update the milestone wording for a terminal result.'
    assert formal['runner_sha256']==sha(ROOT/'experiments/deep_conversation/tracker_lora/train_tracker.py')
    evidence=[]
    for directory in ('annotation','data','review','audit','evaluation'):
        for path in sorted((STUDY/directory).rglob('*')):
            if path.is_file() and path.suffix in {'.json','.jsonl','.py','.md','.txt'} and '__pycache__' not in path.parts:
                assert 'PRIVATE-' not in path.name
                evidence.append(path.relative_to(STUDY).as_posix())
    training=STUDY/'training'
    selected=['base-model-manifest.json','loss-mask-check.json','loss-mask-check-autocast.json',
              'gate-negative-check.json','corpus-lengths-650-01/result.json',
              'seed-length-check/result.json','seed-length-check-02/result.json',
              'smoke-384-01/result.json','smoke-384-02/result.json',
              'smoke-2048-01/result.json','smoke-2048-01/interruption.json','smoke-2048-offload-01/result.json',
              'formal-pilot-01/result.json']
    selected += [p.relative_to(training).as_posix() for p in (training/'corpus-lengths-650-01').glob('*.lengths.json')]
    selected += [p.relative_to(training).as_posix() for p in (training/'smoke-2048-01').glob('*termination*.json')]
    for rel in selected:
        src=training/rel
        assert src.is_file(),src
        dest=out/'snapshot/training'/rel
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(src,dest)
        evidence.append(dest.relative_to(STUDY).as_posix())
    source_log=training/'formal-pilot-01.log'
    log_text=source_log.read_text(encoding='utf-8',errors='replace')
    (out/'snapshot/training/formal-pilot-01/log-at-milestone.txt').write_text(log_text,encoding='utf-8')
    evidence.append('publication/snapshot/training/formal-pilot-01/log-at-milestone.txt')
    for rel in ('intention_state.py','tracker_lora/build_dataset.py','tracker_lora/train_tracker.py',
                'tracker_lora/collect_ab.py','tracker_lora/evaluate_tracker.py'):
        src=ROOT/'experiments/deep_conversation'/rel
        dest=out/'snapshot/code'/rel
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(src,dest)
        evidence.append(dest.relative_to(STUDY).as_posix())
    evidence += ['publication/sources.json','publication/freeze_milestone.py','publication/publication-attempts.json']
    now=datetime.now(timezone.utc)
    try:
        halifax=now.astimezone(ZoneInfo('America/Halifax'))
    except ZoneInfoNotFoundError:
        # Windows ships its time-zone database separately from Python's tzdata.
        local_iso=subprocess.check_output(['powershell','-NoProfile','-Command',
          "[TimeZoneInfo]::ConvertTimeBySystemTimeZoneId([DateTimeOffset]::UtcNow, 'Atlantic Standard Time').ToString('o')"],text=True).strip()
        halifax=datetime.fromisoformat(local_iso)
        now=halifax.astimezone(timezone.utc)
    validation={
      'id':'tracker-lora-pilot-validation','date':halifax.date().isoformat(),
      'type':'grouped_data_and_training_engineering_validation','status':'passed_completed_checks_training_running',
      'snapshot_at_utc':now.isoformat(),'snapshot_at_halifax':halifax.isoformat(),
      'tested_manifest_sha256':sha(STUDY/'data/compiled/manifest.json'),
      'checks':[
        {'check':'Independent model review of ordinary decisions','result':'passed','count':650,'evidence':'review/admission.json'},
        {'check':'Independent model review of replacement error cases','result':'passed','count':65,'evidence':'review/admission.json'},
        {'check':'Exact input/target replay and unchanged-record preservation','result':'passed','count':650,'evidence':'audit/split-leakage-audit.json'},
        {'check':'Split, prefix, metadata and evidence leakage checks','result':'passed_with_generalization_limits','evidence':'audit/split-leakage-audit.json'},
        {'check':'Actual tokenizer lengths and completion-only masks','result':'passed_no_truncation','count':650,'evidence':'publication/snapshot/training/corpus-lengths-650-01/result.json'},
        {'check':'Completion-tail loss against full masked causal loss','result':'passed','evidence':'publication/snapshot/training/loss-mask-check-autocast.json'},
        {'check':'Unapproved training manifest rejection','result':'passed','evidence':'publication/snapshot/training/gate-negative-check.json'},
        {'check':'14B 384-token synthetic training, save/reload','result':'passed_after_dtype_fix','evidence':'publication/snapshot/training/smoke-384-02/result.json'},
        {'check':'14B 2048-token / 160-completion synthetic training with activation offload','result':'passed','evidence':'publication/snapshot/training/smoke-2048-offload-01/result.json'},
        {'check':'Formal training on reviewed 500 updates','result':'running_not_completed','evidence':'publication/snapshot/training/formal-pilot-01/result.json'},
        {'check':'Held-out adapter comparison and semantic scoring','result':'not_started','evidence':'evaluation/protocol-lock.json'}],
      'failed_or_stopped_attempts':[
        {'attempt':'seed-length-check','outcome':'Tokenizer return-type mismatch, corrected before subsequent length checks.','evidence':'publication/snapshot/training/seed-length-check/result.json'},
        {'attempt':'smoke-384-01','outcome':'fp32 norm / bf16 head mismatch before optimizer step, fixed with shared explicit bf16 autocast.','evidence':'publication/snapshot/training/smoke-384-01/result.json'},
        {'attempt':'smoke-2048-01','outcome':'Controlled runtime-budget stop with no optimizer step observed; not a natural OOM. The original running result is retained; the separate interruption receipt records termination. Offload retry tested separately.','evidence':'publication/snapshot/training/smoke-2048-01/interruption.json'}],
      'remaining':['Formal epoch, adapter save/reload and held-out scoring are unfinished at this snapshot.',
        'Own-state rollout, final-answer benefit, long-history and real-user generalization remain untested.',
        'All authored labels and reviews are model-produced, not human adjudication.']}
    write(out/'validation.json',validation)
    write(out/'milestone.json',{
      'id':'tracker-lora-pilot-milestone','date':validation['date'],'type':'reviewed_data_and_running_training',
      'snapshot_at_utc':now.isoformat(),'snapshot_at_halifax':validation['snapshot_at_halifax'],
      'status':'data_reviewed_formal_training_running','quality_results':None,
      'training_status_text':'The formal 500-update, one-epoch run has started and is still running at this snapshot. The adapter has not yet passed final save/reload or held-out evaluation.',
      'setup_failure_text':'All 650 examples passed the final token-length check without truncation. A 384-token smoke initially failed on a dtype mismatch, then passed after shared bf16 autocast was added. A 2,048-token run was stopped after exceeding its runtime budget without an observed optimizer step. A separate 2,048-token / 160-completion smoke with activation offload passed two optimizer steps and exact adapter save/reload. These are engineering checks, not tracker-quality results.',
      'manifest_sha256':sha(STUDY/'data/compiled/manifest.json'),
      'counts':{'training_updates':500,'training_families':100,'development_updates':50,'test_updates':100,
                'ordinary_decisions_independently_model_reviewed':650,'replacement_error_cases_reviewed':65,
                'formal_training_runs_started':1,'formal_training_runs_completed':0,'test_model_calls':0},
      'evidence_files':{name:sha(STUDY/name) for name in sorted(evidence)},
      'export_files':sorted(evidence),
      'reading_records':['audit/split-leakage-audit.json','evaluation/protocol.json','evaluation/protocol-lock.json','publication/sources.json'],
      'not_exported':['Base or adapter weights','Mutable live logs or job handles','Credentials','Machine-local source paths; download copies are sanitized'],
      'limits':validation['remaining']})
    print(json.dumps({'status':'frozen','files':len(evidence),'formal_training':'running','quality_results':None}))

if __name__=='__main__':
    main()
