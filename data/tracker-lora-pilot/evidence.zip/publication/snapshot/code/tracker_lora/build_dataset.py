"""Materialize authored conversation families; never call a language model.

Runtime replay validates executable transitions, NOT semantic labels. Independent
review admissions and exact source hashes form a separate formal-training gate.
"""
from __future__ import annotations
import argparse
import collections
import copy
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'experiments/deep_conversation'))
from intention_state import IntentStore

STUDY = ROOT / 'output/research/2026-10-24/tracker-lora-pilot'


def encode(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def project(state):
    return [{k: row[k] for k in ('intent_id', 'owner', 'text', 'status')}
            for row in state['intents']]


def materialize(family, prompt):
    assert family['split'] in {'train', 'dev', 'test'}
    assert family['language'] in {'zh', 'en'}
    events = family['events']
    assert len(events) >= 5
    assert [e['seq'] for e in events] == list(range(len(events)))
    assert all(e['role'] in {'user', 'assistant'} and e['text'].strip()
               and e['speaker'].strip() for e in events)
    decisions = family['decisions']
    assert len(decisions) == 5
    throughs = [d['through_seq'] for d in decisions]
    assert throughs == sorted(set(throughs)) and throughs[-1] == events[-1]['seq']
    rows = []
    with IntentStore(':memory:') as state:
        for ordinal, decision in enumerate(decisions):
            through = decision['through_seq']
            arrived = [e for e in events if e['seq'] <= through]
            state.observe(arrived)
            before = state.snapshot()
            ops = decision['operations']
            assert isinstance(ops, list)
            assert decision['evidence_note'].strip()
            assert decision['critical_checks'] and all(decision['critical_checks'])
            touched = {op['intent_id'] for op in ops}
            previous_ids = {i['intent_id'] for i in before['intents']}
            assert set(decision['preserve_ids']) == previous_ids - touched, (
                family['family_id'], ordinal, 'preserve_ids must enumerate all untouched records',
                sorted(previous_ids - touched), decision['preserve_ids'])
            for op in ops:
                assert op['intent_id'].startswith('i') and op['intent_id'][1:].isdigit()
                assert set(op['source_seqs']) <= {e['seq'] for e in arrived}
                if op.get('owner') == '__unresolved__':
                    assert op.get('status') == 'uncertain'
            after = state.commit_patch(f'decision-{ordinal}', before['version'], through, ops)
            before_by_id = {i['intent_id']: i for i in before['intents']}
            after_by_id = {i['intent_id']: i for i in after['intents']}
            for key in decision['preserve_ids']:
                assert before_by_id[key] == after_by_id[key]
            packet = {'conversation': arrived, 'intention_state': before, 'tool_receipts': []}
            target = {'operations': ops}
            # Family identity, split, tags, expected state, notes and scenario
            # description deliberately stay outside the training prompt.
            sft = {'prompt': [{'role': 'system', 'content': prompt},
                              {'role': 'user', 'content': encode(packet)}],
                   'completion': [{'role': 'assistant', 'content': encode(target)}]}
            rows.append({'example_id': f"{family['family_id']}-{ordinal + 1}",
                         'family_id': family['family_id'], 'split': family['split'],
                         'language': family['language'], 'domain': family['domain'],
                         'tags': family['tags'], 'decision_index': ordinal,
                         'input': packet, 'target': target,
                         'expected_post_state': after,
                         'expected_semantic_state': project(after),
                         'preserve_ids': decision['preserve_ids'],
                         'evidence_note': decision['evidence_note'],
                         'critical_checks': decision['critical_checks'],
                         'sft': sft})
    return rows


def apply_prior_fault(family, ordinary, fault, prompt):
    """Replay a plausible historical misrecording, then require evidence repair.

The normal source family stays frozen. This replaces one training/eval decision
input, not its conversation; no extra rows or error markers enter the model.
"""
    index = ordinary['decision_index']
    assert index > 0
    key = fault['intent_id']
    before_by_id = {i['intent_id']: i for i in ordinary['input']['intention_state']['intents']}
    original = before_by_id[key]
    assert original['status'] in {'active', 'uncertain'}
    assert key in ordinary['preserve_ids'], 'Do not mix repair and revision of same ID'
    assert fault['repair_text'] == original['text']
    assert fault['wrong_text'] != fault['repair_text'] and fault['wrong_text'].strip()
    assert fault['error_type'] and fault['rationale']
    previous_through = family['decisions'][index-1]['through_seq']
    assert fault['repair_source_seqs'] and max(fault['repair_source_seqs']) <= previous_through
    candidates = [(i, j) for i, d in enumerate(family['decisions'][:index])
                  for j, op in enumerate(d['operations'])
                  if op['intent_id'] == key and op['op'] in {'add', 'update'} and 'text' in op]
    assert candidates
    replace_at = candidates[-1]
    with IntentStore(':memory:') as state:
        for ordinal, d in enumerate(family['decisions'][:index]):
            state.observe([e for e in family['events'] if e['seq'] <= d['through_seq']])
            ops = copy.deepcopy(d['operations'])
            if ordinal == replace_at[0]:
                ops[replace_at[1]]['text'] = fault['wrong_text']
            state.commit_patch(f'decision-{ordinal}', state.snapshot()['version'], d['through_seq'], ops)
        arrived = ordinary['input']['conversation']
        state.observe(arrived)
        faulty_before = state.snapshot()
        assert next(i for i in faulty_before['intents'] if i['intent_id'] == key)['text'] == fault['wrong_text']
        repair = {'op': 'update', 'intent_id': key, 'text': fault['repair_text'],
                  'source_seqs': fault['repair_source_seqs']}
        target = {'operations': copy.deepcopy(ordinary['target']['operations']) + [repair]}
        post = state.commit_patch(f'decision-{index}', faulty_before['version'],
                                  faulty_before['observed_event_seq'], target['operations'])
        assert project(post) == ordinary['expected_semantic_state']
        preserve = [i for i in ordinary['preserve_ids'] if i != key]
        for identifier in preserve:
            before_record = next(i for i in faulty_before['intents'] if i['intent_id'] == identifier)
            after_record = next(i for i in post['intents'] if i['intent_id'] == identifier)
            assert before_record == after_record
    row = copy.deepcopy(ordinary)
    row['input']['intention_state'] = faulty_before
    row['target'] = target
    row['expected_post_state'] = post
    row['preserve_ids'] = preserve
    row['prior_fault_annotation'] = fault
    row['tags'] = sorted(set(row['tags'] + ['fallible_prior_state']))
    row['sft'] = {'prompt': [{'role': 'system', 'content': prompt},
                             {'role': 'user', 'content': encode(row['input'])}],
                  'completion': [{'role': 'assistant', 'content': encode(target)}]}
    return row


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--require-complete', action='store_true')
    args = parser.parse_args()
    prompt_path = STUDY / 'annotation/system_prompt.txt'
    prompt = prompt_path.read_text(encoding='utf-8').strip()
    source_paths = sorted((STUDY / 'data/source').glob('*.jsonl'))
    assert source_paths, 'No authored source files'
    families, origins = [], {}
    for path in source_paths:
        for line in path.read_text(encoding='utf-8-sig').splitlines():
            if not line.strip():
                continue
            family = json.loads(line)
            assert family['family_id'] not in origins, 'Duplicate family ID'
            origins[family['family_id']] = {'path': str(path.relative_to(STUDY)),
                                           'family_sha256': hashlib.sha256(encode(family).encode()).hexdigest()}
            families.append(family)
    rows = [row for family in families for row in materialize(family, prompt)]
    family_map = {f['family_id']: f for f in families}
    fault_paths = sorted((STUDY / 'data/faults').glob('*.json'))
    faults = {}
    for path in fault_paths:
        for fault in json.loads(path.read_text(encoding='utf-8-sig')):
            assert fault['example_id'] not in faults
            faults[fault['example_id']] = fault
    assert set(faults) <= {r['example_id'] for r in rows}, 'Fault refers to nonexistent decision'
    rows = [apply_prior_fault(family_map[r['family_id']], r, faults[r['example_id']], prompt)
            if r['example_id'] in faults else r for r in rows]
    assert len({r['example_id'] for r in rows}) == len(rows)
    hashes = [hashlib.sha256(encode(r['input']).encode()).hexdigest() for r in rows]
    assert len(set(hashes)) == len(hashes), 'Duplicate model input'
    dialogue_hashes = [hashlib.sha256(encode(f['events']).encode()).hexdigest() for f in families]
    assert len(set(dialogue_hashes)) == len(dialogue_hashes), 'Duplicate family dialogue'
    counts = dict(collections.Counter(r['split'] for r in rows))
    gate = {'status': 'incomplete', 'reason': 'All required source and independent review records not yet admitted.'}
    if args.require_complete:
        assert counts == {'train': 500, 'dev': 50, 'test': 100}, counts
        admission_path = STUDY / 'review/admission.json'
        admission = json.loads(admission_path.read_text(encoding='utf-8'))
        assert admission['status'] == 'approved_for_pilot'
        assert set(admission['families']) == set(origins)
        for family_id, record in admission['families'].items():
            assert record['family_sha256'] == origins[family_id]['family_sha256']
            assert record['verdict'] == 'accept' and record['decisions_reviewed'] == 5
            assert record['independent_of_author'] is True
        assert dict(collections.Counter(r['split'] for r in rows if 'prior_fault_annotation' in r)) == {'train': 50, 'dev': 5, 'test': 10}
        assert set(admission['fault_examples']) == set(faults)
        for identifier, record in admission['fault_examples'].items():
            assert record['fault_sha256'] == hashlib.sha256(encode(faults[identifier]).encode()).hexdigest()
            assert record['verdict'] == 'accept' and record['independent_of_author'] is True
        gate = {'status': 'approved_for_pilot', 'admission_sha256': sha(admission_path),
                'kind': 'independent model review; no human annotation claim'}
    output = STUDY / 'data/compiled'
    output.mkdir(parents=True, exist_ok=True)
    files = {}
    for split in ('train', 'dev', 'test'):
        selected = [r for r in rows if r['split'] == split]
        for suffix, records in [('records', [{k: v for k, v in r.items() if k != 'sft'} for r in selected]),
                                ('sft', [r['sft'] for r in selected])]:
            path = output / f'{split}.{suffix}.jsonl'
            path.write_text(''.join(encode(r) + '\n' for r in records), encoding='utf-8')
            files[path.name] = {'sha256': sha(path), 'rows': len(records)}
    manifest = {'date': '2026-10-24', 'timezone': 'America/Halifax',
                'status': gate['status'], 'authorship': 'fictional model-authored scenarios',
                'human_validated': False, 'training_gate': gate,
                'update_counts': counts,
                'family_counts': dict(collections.Counter(f['split'] for f in families)),
                'languages': dict(collections.Counter(r['language'] for r in rows)),
                'domains': dict(collections.Counter(f['domain'] for f in families)),
                'operations': dict(collections.Counter(op['op'] for r in rows for op in r['target']['operations'])),
                'empty_updates': sum(not r['target']['operations'] for r in rows),
                'preserved_records_checked': sum(len(r['preserve_ids']) for r in rows),
                'family_sources': origins,
                'source_files': {str(p.relative_to(STUDY)): sha(p) for p in source_paths + fault_paths},
                'fault_variants': dict(collections.Counter(r['split'] for r in rows if 'prior_fault_annotation' in r)),
                'fault_kinds': dict(collections.Counter(f['error_type'] for f in faults.values())),
                'system_prompt_sha256': sha(prompt_path),
                'runtime_sha256': sha(ROOT / 'experiments/deep_conversation/intention_state.py'),
                'compiler_sha256': sha(Path(__file__)), 'files': files,
                'training_sft_sha256': files['train.sft.jsonl']['sha256'],
                'admission_sha256': gate.get('admission_sha256'),
                'quality_limit': 'Replay and uniqueness checks cannot establish semantic correctness or empirical training benefit.',
                'new_model_inference_calls': 0}
    if args.require_complete:
        assert admission['training_sft_sha256'] == manifest['training_sft_sha256']
    write_json(output / 'manifest.json', manifest)
    print(json.dumps({k: manifest[k] for k in ('status', 'update_counts', 'family_counts', 'operations', 'empty_updates')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
