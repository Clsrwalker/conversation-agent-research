"""Single-GPU pinned-base QLoRA runner. Never truncates data; completion-only loss.

Smoke is a synthetic infrastructure test, not a tracker quality result.
Formal training requires the caller to supply a reviewed-data receipt.
"""
from __future__ import annotations

import argparse
import contextlib
import gc
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import random
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone

os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
os.environ.setdefault("HF_HUB_DISABLE_IMPLICIT_TOKEN", "1")

ROOT = Path(__file__).resolve().parents[3]
DEFAULT_OUTPUT = ROOT / "output/research/2026-10-24/tracker-lora-pilot/training"
REVISION = "cf98f3b3bbb457ad9e2bb7baf9a0125b6b88caa8"
MODEL_ID = "Qwen/Qwen2.5-14B-Instruct"
MODEL_PATH = Path(__file__).parent / "model-cache/Qwen2.5-14B-Instruct" / REVISION

def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")

def emit(event, **kw):
    print(json.dumps({"event": event, "utc": datetime.now(timezone.utc).isoformat(), **kw}, ensure_ascii=False), flush=True)

def tokenize_row(tokenizer, row):
    prompt = row["prompt"]
    completion = row["completion"]
    if not isinstance(prompt, list) or not isinstance(completion, list):
        raise ValueError("Expected conversational prompt/completion lists")
    if len(completion) != 1 or completion[0]["role"] != "assistant":
        raise ValueError("Expected exactly one assistant completion")
    json.loads(completion[0]["content"])
    prefix = tokenizer.apply_chat_template(prompt, tokenize=True, add_generation_prompt=True, return_dict=False)
    full = tokenizer.apply_chat_template(prompt + completion, tokenize=True, add_generation_prompt=False, return_dict=False)
    if full[:len(prefix)] != prefix:
        raise ValueError("Chat template prefix boundary changed; no masking assumptions allowed")
    if len(full) <= len(prefix):
        raise ValueError("No supervised completion tokens")
    return {"input_ids": full, "prompt_tokens": len(prefix), "completion_tokens": len(full) - len(prefix)}

def load_rows(args):
    if args.mode == "smoke":
        return [{"prompt": [{"role": "system", "content": "Return a JSON object only."},
                            {"role": "user", "content": "This is a synthetic infrastructure check. Return an empty operations array."}],
                 "completion": [{"role": "assistant", "content": '{"operations":[]}'}]}]
    if not args.data:
        raise ValueError("--data is required")
    return [json.loads(x) for x in Path(args.data).read_text(encoding="utf-8").splitlines() if x.strip()]

def validate_training_gate(data_path, manifest_path, admission_path):
    """Reject stale, incomplete or unreviewed inputs before loading trainable weights."""
    data_path, manifest_path, admission_path = map(Path, (data_path, manifest_path, admission_path))
    manifest = json.loads(manifest_path.read_text(encoding="utf8"))
    admission = json.loads(admission_path.read_text(encoding="utf8"))
    assert manifest["status"] == "approved_for_pilot", "Manifest is not approved"
    assert admission["status"] == "approved_for_pilot", "Admission is not approved"
    assert manifest["training_gate"]["status"] == "approved_for_pilot"
    data_hash = sha(data_path)
    assert manifest["training_sft_sha256"] == data_hash
    assert admission["training_sft_sha256"] == data_hash
    assert manifest["files"]["train.sft.jsonl"]["sha256"] == data_hash
    assert manifest["admission_sha256"] == sha(admission_path)
    assert manifest["training_gate"]["admission_sha256"] == sha(admission_path)
    assert manifest["update_counts"] == {"train": 500, "dev": 50, "test": 100}
    assert manifest["files"]["train.sft.jsonl"]["rows"] == 500
    assert set(admission["families"]) == set(manifest["family_sources"])
    for family_id, review in admission["families"].items():
        assert review["family_sha256"] == manifest["family_sources"][family_id]["family_sha256"]
        assert review["verdict"] == "accept" and review["decisions_reviewed"] == 5
        assert review["independent_of_author"] is True
    study = manifest_path.parents[2]
    for relative, expected in manifest["source_files"].items():
        assert sha(study / relative) == expected, f"Source changed: {relative}"
    assert manifest["fault_variants"] == {"train": 50, "dev": 5, "test": 10}
    faults = {}
    for relative in manifest["source_files"]:
        if relative.replace("\\", "/").startswith("data/faults/") and relative.endswith(".json"):
            for fault in json.loads((study / relative).read_text(encoding="utf-8-sig")):
                assert fault["example_id"] not in faults
                faults[fault["example_id"]] = fault
    assert len(faults) == 65 and set(admission["fault_examples"]) == set(faults)
    for example_id, review in admission["fault_examples"].items():
        canonical = json.dumps(faults[example_id], ensure_ascii=False, sort_keys=True, separators=(',', ':'))
        assert review["fault_sha256"] == hashlib.sha256(canonical.encode()).hexdigest()
        assert review["verdict"] == "accept" and review["independent_of_author"] is True
    assert sha(study / "annotation/system_prompt.txt") == manifest["system_prompt_sha256"]
    assert sha(ROOT / "experiments/deep_conversation/intention_state.py") == manifest["runtime_sha256"]
    assert sha(Path(__file__).with_name("build_dataset.py")) == manifest["compiler_sha256"]
    for filename, evidence in manifest["files"].items():
        assert sha(manifest_path.parent / filename) == evidence["sha256"], f"Compiled file changed: {filename}"
    return {"status": "passed", "manifest_sha256": sha(manifest_path),
            "admission_sha256": sha(admission_path), "training_sft_sha256": data_hash,
            "admitted_families": len(admission["families"]), "admitted_training_rows": 500,
            "independently_reviewed_fault_examples": len(faults)}

def quantized_base():
    import torch
    from transformers import AutoModelForCausalLM, BitsAndBytesConfig
    quantization = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                                     bnb_4bit_use_double_quant=True, bnb_4bit_compute_dtype=torch.bfloat16)
    return AutoModelForCausalLM.from_pretrained(str(MODEL_PATH), local_files_only=True,
        quantization_config=quantization, dtype=torch.bfloat16, device_map={"": 0},
        attn_implementation="sdpa", trust_remote_code=False)

def measured_memory():
    import torch
    free, total = torch.cuda.mem_get_info()
    return {"free_bytes": free, "total_bytes": total,
            "allocated_bytes": torch.cuda.memory_allocated(), "reserved_bytes": torch.cuda.memory_reserved(),
            "peak_allocated_bytes": torch.cuda.max_memory_allocated(), "peak_reserved_bytes": torch.cuda.max_memory_reserved()}

def prepare_frozen_base(model, gradient_checkpointing=False):
    """Common base precision for both training and adapter-off/on evaluation."""
    import torch
    large_frozen = {id(p) for module in [model.get_input_embeddings(), model.get_output_embeddings()]
                    for p in module.parameters()}
    for parameter in model.parameters():
        parameter.requires_grad = False
        if (id(parameter) not in large_frozen and parameter.__class__.__name__ != "Params4bit"
                and parameter.dtype in (torch.float16, torch.bfloat16)):
            parameter.data = parameter.data.to(torch.float32)
    if gradient_checkpointing:
        model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
    return model

def completion_loss(model, encoded, activation_offload=False):
    import torch
    import torch.nn.functional as F
    ids = torch.tensor([encoded["input_ids"]], device="cuda", dtype=torch.long)
    n = encoded["completion_tokens"]
    # Only materialize logits needed for completion supervision; full prompt loss is excluded.
    manager = torch.autograd.graph.save_on_cpu(pin_memory=True) if activation_offload else contextlib.nullcontext()
    with manager, torch.autocast("cuda", dtype=torch.bfloat16):
        logits = model(input_ids=ids, attention_mask=torch.ones_like(ids), use_cache=False,
                       logits_to_keep=n + 1).logits
        if logits.shape[1] != n + 1:
            raise RuntimeError("Backend ignored logits_to_keep; refuse unexpected memory/loss path")
        targets = ids[:, -n:]
        loss = F.cross_entropy(logits[:, :-1, :].float().reshape(-1, logits.shape[-1]), targets.reshape(-1))
    return loss

def run(args):
    import torch
    from transformers import AutoTokenizer
    from peft import LoraConfig, get_peft_model
    import bitsandbytes as bnb
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    if (out / "result.json").exists():
        raise FileExistsError("Run output already has a result; preserve it and choose a new directory")
    (out / "runner_source.py").write_bytes(Path(__file__).read_bytes())
    result = {"date": "2026-10-24", "timezone": "America/Halifax", "mode": args.mode,
              "kind": "synthetic_plumbing_not_quality" if args.mode == "smoke" else args.mode,
              "status": "running", "pid": os.getpid(), "base_model": MODEL_ID, "base_revision": REVISION,
              "runner_sha256": sha(__file__),
              "python": sys.version, "inherits_system_site_packages": True,
              "versions": {x: importlib.metadata.version(x) for x in ["torch", "transformers", "peft", "bitsandbytes", "accelerate", "huggingface-hub", "safetensors"]},
              "configuration": vars(args), "gpu": torch.cuda.get_device_name(0),
              "quantization": {"load_in_4bit": True, "type": "nf4", "double_quant": True, "compute_dtype": "bfloat16"},
              "frozen_embeddings_and_head_dtype": "bfloat16",
              "forward_autocast": "cuda_bfloat16",
              "started_at_utc": datetime.now(timezone.utc).isoformat()}
    write(out / "result.json", result)
    try:
        random.seed(args.seed)
        torch.manual_seed(args.seed)
        torch.cuda.manual_seed_all(args.seed)
        tokenizer = AutoTokenizer.from_pretrained(str(MODEL_PATH), local_files_only=True, trust_remote_code=False)
        raw = load_rows(args)
        if args.mode == "smoke":
            if args.smoke_completion_tokens > 6:
                operation = {"op": "add", "intent_id": "i0", "owner": "synthetic", "text": "synthetic requirement",
                             "source_seqs": [0], "status": "active"}
                raw[0]["prompt"][-1]["content"] = "Synthetic infrastructure-only check: return the artificial add operation. This is not tracker training data."
                raw[0]["completion"][0]["content"] = json.dumps({"operations": [operation]}, separators=(',', ':'))
                initial_completion = tokenize_row(tokenizer, raw[0])["completion_tokens"]
                if initial_completion > args.smoke_completion_tokens:
                    raise ValueError("Requested synthetic completion length is too short")
                operation["text"] += " x" * (args.smoke_completion_tokens - initial_completion)
                raw[0]["completion"][0]["content"] = json.dumps({"operations": [operation]}, separators=(',', ':'))
            # Fill a synthetic prompt to the declared sequence length so the memory
            # probe actually exercises that length, without truncating real evidence.
            first = tokenize_row(tokenizer, raw[0])
            missing = args.max_length - len(first["input_ids"])
            if missing < 0:
                raise ValueError("Smoke max length is shorter than the synthetic fixture")
            raw[0]["prompt"][-1]["content"] += " x" * missing
            write(out / "synthetic-input.json", raw[0])
        encoded = [tokenize_row(tokenizer, row) for row in raw]
        lengths = [len(x["input_ids"]) for x in encoded]
        result["data"] = {"count": len(raw), "sha256": sha(args.data) if args.data else None,
                          "min_tokens": min(lengths), "max_tokens": max(lengths),
                          "mean_tokens": sum(lengths) / len(lengths),
                          "over_limit": sum(x > args.max_length for x in lengths),
                          "tokens_2048_exceeded": sum(x > 2048 for x in lengths),
                          "tokens_4096_exceeded": sum(x > 4096 for x in lengths),
                          "truncated_rows": 0}
        write(out / "lengths.json", [{"row": i, "total_tokens": len(x["input_ids"]),
              "prompt_tokens": x["prompt_tokens"], "supervised_completion_tokens": x["completion_tokens"]} for i, x in enumerate(encoded)])
        result["mask_check"] = {"chat_prefix_exact_for_all_rows": True,
             "prompt_supervised_tokens": 0, "padding_supervised_tokens": 0,
             "completion_supervised_tokens": sum(x["completion_tokens"] for x in encoded),
             "implementation": "causal completion tail logits only; target tokens plus template assistant end supervised"}
        emit("tokenized", **result["data"])
        if max(lengths) > args.max_length:
            raise ValueError("Rows exceed requested max_length. No truncation is permitted; revise the context policy first.")
        if args.mode == "inspect":
            result["status"] = "passed"
            return
        if args.mode == "train":
            if not args.review_receipt or not Path(args.review_receipt).is_file():
                raise ValueError("Formal training needs a reviewed-data receipt")
            manifest = args.manifest or str(Path(args.data).parent / "manifest.json")
            result["review_gate"] = validate_training_gate(args.data, manifest, args.review_receipt)
        base_receipt_path = DEFAULT_OUTPUT / "base-model-manifest.json"
        base_receipt = json.loads(base_receipt_path.read_text(encoding="utf8"))
        assert base_receipt["status"] == "downloaded_and_verified", "Base download/hash verification not complete"
        assert base_receipt["revision"] == REVISION and base_receipt["model_id"] == MODEL_ID
        for item in base_receipt["files"]:
            assert (MODEL_PATH / item["rfilename"]).stat().st_size == item["actual_bytes"]
        result["base_download_receipt_sha256"] = sha(base_receipt_path)
        write(out / "run-config.json", {key: result[key] for key in ["base_model", "base_revision", "runner_sha256",
            "versions", "configuration", "quantization", "frozen_embeddings_and_head_dtype", "forward_autocast",
            "data", "mask_check", "base_download_receipt_sha256"]} | {"review_gate": result.get("review_gate")})
        result["memory_before_load"] = measured_memory()
        model = quantized_base()
        emit("base_loaded", memory=measured_memory())
        # Explicit variant of PEFT's prepare routine: freeze all base weights, upcast
        # non-quantized small parameters (including norms), but preserve large frozen
        # embedding/head in bf16. Calling the stock helper first would transiently
        # allocate both fp32 matrices, defeating this memory-constrained recipe.
        model = prepare_frozen_base(model, gradient_checkpointing=True)
        config = LoraConfig(r=args.rank, lora_alpha=args.rank * 2, lora_dropout=0.05,
                            target_modules="all-linear", bias="none", task_type="CAUSAL_LM")
        model = get_peft_model(model, config)
        model.config.use_cache = False
        parameters = [p for p in model.parameters() if p.requires_grad]
        result["trainable_parameters"] = sum(p.numel() for p in parameters)
        result["frozen_base_parameters_have_grad"] = any(p.requires_grad for n,p in model.named_parameters() if "lora_" not in n)
        assert not result["frozen_base_parameters_have_grad"]
        optimizer = bnb.optim.AdamW8bit(parameters, lr=args.learning_rate, weight_decay=0.0,
                                      betas=(0.9, 0.999), eps=1e-8)
        result["optimizer"] = "bitsandbytes.optim.AdamW8bit"
        result["optimizer_configuration"] = {"learning_rate": args.learning_rate, "weight_decay": 0.0,
                                             "betas": [0.9, 0.999], "eps": 1e-8,
                                             "schedule": "constant", "gradient_clip_norm": 1.0}
        result["memory_before_training"] = measured_memory()
        torch.cuda.reset_peak_memory_stats()
        model.train()
        losses = []
        updates = 0
        steps = 0
        train_started = time.perf_counter()
        epochs = args.epochs if args.mode == "train" else 2
        for epoch in range(epochs):
            order = list(range(len(encoded)))
            random.Random(args.seed + epoch).shuffle(order)
            for pos, index in enumerate(order):
                loss = completion_loss(model, encoded[index], args.activation_offload)
                if not torch.isfinite(loss):
                    raise ValueError("Non-finite training loss")
                divisor = min(args.gradient_accumulation, len(order) - (pos // args.gradient_accumulation) * args.gradient_accumulation)
                (loss / divisor).backward()
                losses.append(float(loss.detach()))
                steps += 1
                if (pos + 1) % args.gradient_accumulation == 0 or pos + 1 == len(order):
                    norm = torch.nn.utils.clip_grad_norm_(parameters, 1.0)
                    if not torch.isfinite(norm):
                        raise ValueError("Non-finite gradient norm")
                    optimizer.step()
                    optimizer.zero_grad(set_to_none=True)
                    updates += 1
                    emit("optimizer_step", epoch=epoch, update=updates, microsteps=steps,
                         loss=losses[-1], grad_norm=float(norm), elapsed_seconds=time.perf_counter()-train_started,
                         memory=measured_memory())
                if args.max_steps and updates >= args.max_steps:
                    break
            if args.max_steps and updates >= args.max_steps:
                break
        result["training"] = {"microsteps": steps, "optimizer_steps": updates,
                              "losses": losses, "elapsed_seconds": time.perf_counter()-train_started}
        result["memory_training_peak"] = measured_memory()
        adapter = out / "adapter"
        model.peft_config["default"].base_model_name_or_path = MODEL_ID
        model.peft_config["default"].revision = REVISION
        model.save_pretrained(str(adapter), safe_serialization=True)
        tokenizer.save_pretrained(str(adapter))
        del optimizer
        gc.collect()
        torch.cuda.empty_cache()
        model.eval()
        probe = torch.tensor([encoded[0]["input_ids"]], device="cuda", dtype=torch.long)
        with torch.no_grad(), torch.autocast("cuda", dtype=torch.bfloat16):
            before = model(input_ids=probe, use_cache=False, logits_to_keep=1).logits.float().cpu()
            with model.disable_adapter():
                baseline = model(input_ids=probe, use_cache=False, logits_to_keep=1).logits.float().cpu()
        model.load_adapter(str(adapter), adapter_name="reloaded", is_trainable=False)
        model.set_adapter("reloaded")
        model.eval()
        with torch.no_grad(), torch.autocast("cuda", dtype=torch.bfloat16):
            after = model(input_ids=probe, use_cache=False, logits_to_keep=1).logits.float().cpu()
        difference = float((before - after).abs().max())
        result["save_reload"] = {"max_abs_logit_difference": difference,
                                 "match": bool(torch.equal(before, after)),
                                 "enabled_vs_disabled_max_abs_logit_difference": float((before-baseline).abs().max()),
                                 "base_reused_same_object": True,
                                 "adapter_files": {p.name: sha(p) for p in adapter.iterdir() if p.is_file()}}
        if difference > 1e-5:
            raise ValueError("Reloaded adapter logits differ from saved adapter")
        if result["save_reload"]["enabled_vs_disabled_max_abs_logit_difference"] <= 0:
            raise ValueError("Optimizer did not produce an observable adapter effect")
        result["status"] = "passed"
        emit("completed", status=result["status"], save_reload=result["save_reload"])
    except BaseException as exc:
        result["status"] = "failed"
        result["error"] = {"type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}
        emit("failed", error=result["error"])
        raise
    finally:
        result["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
        write(out / "result.json", result)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["inspect", "smoke", "train"])
    parser.add_argument("--data")
    parser.add_argument("--review-receipt")
    parser.add_argument("--manifest")
    parser.add_argument("--output", default=str(DEFAULT_OUTPUT / "smoke-01"))
    parser.add_argument("--max-length", type=int, default=384)
    parser.add_argument("--rank", type=int, default=16)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--gradient-accumulation", type=int, default=1)
    parser.add_argument("--epochs", type=int, default=2)
    parser.add_argument("--max-steps", type=int, default=0)
    parser.add_argument("--seed", type=int, default=20261024)
    parser.add_argument("--activation-offload", action="store_true")
    parser.add_argument("--smoke-completion-tokens", type=int, default=6)
    run(parser.parse_args())
