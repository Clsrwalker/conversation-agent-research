"""Collect same-base adapter-off/on outputs. Scoring belongs to a separate reviewer.

Receives only SFT prompt messages as generation input; completions are never fed.
Writes each result durably so an interrupted collection can resume without
silently repeating completed assigned rows. Does not label quality itself.
"""
import argparse
import hashlib
import contextlib
from datetime import datetime, timezone
import gc
import json
import os
from pathlib import Path
import time
import traceback

from train_tracker import MODEL_ID, MODEL_PATH, REVISION, emit, measured_memory, prepare_frozen_base, quantized_base, sha, write

def main(args):
    import torch
    from transformers import AutoTokenizer
    from peft import PeftModel
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    adapter = Path(args.adapter)
    config = {"base_id": MODEL_ID, "base_revision": REVISION, "data_sha256": sha(args.data),
              "collector_sha256": sha(__file__),
              "base_loading_implementation_sha256": sha(Path(__file__).with_name("train_tracker.py")),
              "base_generation_config_sha256": sha(MODEL_PATH / "generation_config.json"),
              "adapter_weights_sha256": sha(adapter / "adapter_model.safetensors"),
              "adapter_config_sha256": sha(adapter / "adapter_config.json"),
              "max_prompt_tokens": args.max_prompt_tokens, "max_new_tokens": args.max_new_tokens,
              "seed": args.seed, "do_sample": False, "repetition_penalty": 1.0, "num_beams": 1, "limit": args.limit,
              "system_prompt_sha256": sha(args.system_prompt) if args.system_prompt else None,
              "cache_implementation": args.cache_implementation,
              "kind": "one_step_generation_collection_not_semantic_score",
              "base_representation": "same_object_nf4_double_quant_bfloat16_compute_norms_fp32"}
    frozen = out / "collection-config.json"
    if frozen.exists():
        if json.loads(frozen.read_text(encoding="utf8")) != config:
            raise ValueError("Existing collection configuration differs; use a new output directory")
    else:
        write(frozen, config)
    (out / "collector_source.py").write_bytes(Path(__file__).read_bytes())
    output_file = out / "outputs.jsonl"
    prior = [json.loads(line) for line in output_file.read_text(encoding="utf8").splitlines()] if output_file.exists() else []
    completed = {(row["row_index"], row["arm"]) for row in prior}
    tokenizer = AutoTokenizer.from_pretrained(str(MODEL_PATH), local_files_only=True, trust_remote_code=False)
    rows = [json.loads(line) for line in Path(args.data).read_text(encoding="utf8").splitlines() if line.strip()]
    if args.limit:
        rows = rows[:args.limit]
    if rows and "prompt" not in rows[0]:
        if not args.system_prompt:
            raise ValueError("Records input requires --system-prompt; annotation targets are excluded")
        system = Path(args.system_prompt).read_text(encoding="utf8").strip()
        prompt_rows = [{"prompt": [{"role": "system", "content": system},
            {"role": "user", "content": json.dumps(row["input"], ensure_ascii=False, sort_keys=True, separators=(',', ':'))}]} for row in rows]
    else:
        prompt_rows = rows
    prompts = [tokenizer.apply_chat_template(row["prompt"], tokenize=True, return_dict=False,
                                            add_generation_prompt=True) for row in prompt_rows]
    if any(len(ids) > args.max_prompt_tokens for ids in prompts):
        raise ValueError("Prompt exceeds declared context limit; no truncation is allowed")
    model = prepare_frozen_base(quantized_base())
    model = PeftModel.from_pretrained(model, str(adapter), is_trainable=False)
    model.eval()
    if model.is_gradient_checkpointing:
        model.gradient_checkpointing_disable()
    assigned = len(rows) * 2
    emit("collection_started", assigned_calls=assigned, completed_prior=len(completed), pid=os.getpid())
    for index, ids in enumerate(prompts):
        # Alternate order to reduce systematic warmup/order effects; decoding remains deterministic.
        arms = ["adapter_disabled", "tracker_lora_enabled"] if index % 2 == 0 else ["tracker_lora_enabled", "adapter_disabled"]
        for arm in arms:
            if (index, arm) in completed:
                continue
            torch.manual_seed(args.seed)
            torch.cuda.manual_seed_all(args.seed)
            record = {"row_index": index, "arm": arm, "started_at_utc": datetime.now(timezone.utc).isoformat(),
                      "input_tokens": len(ids), "model": MODEL_ID, "revision": REVISION,
                      "example_id": rows[index].get("example_id"), "family_id": rows[index].get("family_id"),
                      "input_messages_sha256": hashlib.sha256(json.dumps(prompt_rows[index]["prompt"], ensure_ascii=False,
                          sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
                      "input_token_ids_sha256": hashlib.sha256(json.dumps(ids, separators=(',', ':')).encode()).hexdigest(),
                      "adapter_weights_sha256": config["adapter_weights_sha256"], "status": "running"}
            write(out / "current-call.json", record)
            started = time.perf_counter()
            try:
                inputs = torch.tensor([ids], device="cuda", dtype=torch.long)
                manager = model.disable_adapter() if arm == "adapter_disabled" else contextlib.nullcontext()
                with manager, torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
                    layers = [module for module in model.modules() if hasattr(module, "lora_A")]
                    disabled = sum(bool(module.disable_adapters) for module in layers)
                    assert layers and disabled == (len(layers) if arm == "adapter_disabled" else 0)
                    record["actual_adapter_state"] = {"active_adapter_names": model.active_adapters,
                        "lora_layer_count": len(layers), "disabled_lora_layers": disabled}
                    generated = model.generate(input_ids=inputs, attention_mask=torch.ones_like(inputs),
                        do_sample=False, repetition_penalty=1.0, num_beams=1,
                        max_new_tokens=args.max_new_tokens, use_cache=True,
                        cache_implementation=args.cache_implementation, logits_to_keep=1,
                        pad_token_id=tokenizer.eos_token_id)
                tokens = generated[0, len(ids):].tolist()
                text = tokenizer.decode(tokens, skip_special_tokens=True)
                record.update(status="completed", output_tokens=len(tokens), output_text=text,
                              hit_token_cap=len(tokens) >= args.max_new_tokens)
                try:
                    parsed = json.loads(text)
                    record["strict_json_object"] = isinstance(parsed, dict)
                    record["parsed_json"] = parsed
                except json.JSONDecodeError:
                    record["strict_json_object"] = False
                del generated, inputs
            except Exception as exc:
                record.update(status="failed", error={"type": type(exc).__name__, "message": str(exc),
                                                       "traceback": traceback.format_exc()})
                gc.collect()
                torch.cuda.empty_cache()
            record["elapsed_seconds"] = time.perf_counter() - started
            record["memory"] = measured_memory()
            with output_file.open("a", encoding="utf8") as stream:
                stream.write(json.dumps(record, ensure_ascii=False) + "\n")
                stream.flush()
                os.fsync(stream.fileno())
            completed.add((index, arm))
            emit("call_recorded", row_index=index, arm=arm, status=record["status"],
                 elapsed_seconds=record["elapsed_seconds"], completed=len(completed), assigned=assigned)
    write(out / "collection-result.json", {"status": "collection_completed", "assigned_calls": assigned,
          "records": len(completed), "outputs_sha256": sha(output_file), "quality_scored": False})

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True)
    parser.add_argument("--adapter", required=True)
    parser.add_argument("--system-prompt")
    parser.add_argument("--output", required=True)
    parser.add_argument("--max-prompt-tokens", type=int, default=2048)
    parser.add_argument("--max-new-tokens", type=int, default=512)
    parser.add_argument("--seed", type=int, default=20261024)
    parser.add_argument("--cache-implementation", choices=["dynamic", "offloaded"], default="dynamic")
    parser.add_argument("--limit", type=int, default=0)
    main(parser.parse_args())
