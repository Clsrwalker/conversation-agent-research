"""Record root's independent reading of each B/D fault and arrived evidence."""
import hashlib
import json
from pathlib import Path
import sys
STUDY=Path(__file__).resolve().parent.parent
ROOT=next(p for p in STUDY.parents if (p/'experiments/deep_conversation/intention_state.py').exists())
sys.path.insert(0,str(ROOT/'experiments/deep_conversation/tracker_lora'))
from build_dataset import encode, materialize, apply_prior_fault, sha, write_json
NOTES={
'train-b-001-2':'The opening fixes seed 17; neither the assistant suggestion nor its rejection revises the seed.',
'train-b-003-3':'The opening cap is 1800 characters and the current date revision explicitly retains that cap.',
'train-b-005-4':'The opening names A2, and subsequent acceptance concerns oral-only presentation, not difficulty.',
'train-b-007-5':'The opening requires human approval, the quotation is disclaimed and the final window change retains approval.',
'train-b-009-2':'Only candidate codes, not names, is explicit; adding the question segment leaves the restriction intact.',
'train-b-011-3':'The opening specifies a rehearsal environment; refusing automatic switching does not authorize production.',
'train-b-013-2':'Blinding to group names is explicit; a candidate error-count analysis does not reverse it.',
'train-b-015-3':'Verbatim quotation is explicit, rewriting is quoted and disclaimed; removing the glossary does not change quotation policy.',
'train-b-017-4':'Numeric ratings are expressly avoided; cancelling recording is independent.',
'train-b-019-5':'The full marked-delivered-but-missing condition appears at seq 2; one-day initial reply is independent.',
'train-b-021-2':'The source expressly requires fictional profiles only; pair collaboration does not allow real profiles.',
'train-b-023-4':'Manual approval remains required; an assistant completion claim is not withdrawal authority.',
'train-d-002-3':'Six per box is the latest arrived count. The later count of four is excluded from this prefix.',
'train-d-004-4':'Seq 2 explicitly changes height to eighty centimetres; material changes do not change height or units.',
'train-d-006-2':'Every number must be disclosed as demonstration data; greeting discussion changes nothing about provenance.',
'train-d-008-5':'Sister is the explicit original relationship; viewpoint and ending changes retain the motive.',
'train-d-010-2':'Simulation only and no payment connection are explicit; accepting button placement does not authorize a service connection.',
'train-d-012-4':'No locked exit is expressed initially and reaffirmed at the current revision; answer length is independent.',
'train-d-013-3':'One-centimetre allowance is explicit; closure and pocket changes do not change its value.',
'train-d-015-2':'No immediate client upgrade is explicit; a quoted field-renaming policy is disclaimed.',
'train-d-017-5':'Tali explicitly requires chain visibility in close-ups, retains it, and Remy withdraws only the glove candidate.',
'train-d-019-4':'No rapid flashing is explicit and reaffirmed; duration changes independently.',
'train-d-021-2':'Never delete messages is explicit; a Billing-label exception does not authorize deletion.',
'train-d-023-3':'Variety labels remain attached; cancelling an insert and adding a soil check do not remove labels.',
'train-d-025-5':'The prepayment opt-out is explicit; the new hint question does not prohibit backing out.'}
prompt=(STUDY/'annotation/system_prompt.txt').read_text(encoding='utf-8').strip()
for shard in ('b','d'):
    source=STUDY/f'data/source/train-{shard}.jsonl'
    families={f['family_id']:f for f in map(json.loads,source.read_text(encoding='utf-8').splitlines())}
    fault_path=STUDY/f'data/faults/train-{shard}.json'
    records=[]
    for fault in json.loads(fault_path.read_text(encoding='utf-8')):
        fid, position=fault['example_id'].rsplit('-',1)
        family=families[fid]
        normal=materialize(family,prompt)[int(position)-1]
        repaired=apply_prior_fault(family,normal,fault,prompt)
        evidence=[e for e in normal['input']['conversation'] if e['seq'] in fault['repair_source_seqs']]
        assert len(evidence)==len(fault['repair_source_seqs'])
        records.append({'example_id':fault['example_id'],
          'fault_sha256':hashlib.sha256(encode(fault).encode()).hexdigest(),
          'family_sha256':hashlib.sha256(encode(family).encode()).hexdigest(),
          'author':'/root/tracker_annotation_v2','reviewer':'/root',
          'independent_of_author':True,'verdict':'accept',
          'semantic_review_note':NOTES[fault['example_id']],
          'raw_supporting_events':evidence,'fault':fault,
          'arrived_evidence_only':True,'ordinary_target_does_not_touch_id':True,
          'local_plausible_memory_error':True,
          'runtime_repaired_semantics_equal_ordinary_gold':repaired['expected_semantic_state']==normal['expected_semantic_state'],
          'preserved_ids_checked':repaired['preserve_ids']})
    report={'status':'accepted','date':'2026-10-24','timezone':'America/Halifax',
      'kind':'independent model semantic review of authored error cases, not human gold or measured model quality',
      'source_sha256':sha(source),'fault_file_sha256':sha(fault_path),'faults':records,
      'faults_reviewed':len(records),'human_review_performed':False,
      'coverage_limit':'All injected faults change record text only; omitted records and wrong-owner/status corruption are not covered.'}
    path=STUDY/f'review/train-{shard}-fault-review.json'
    write_json(path,report)
    print(path.name,len(records),'accepted')
