"""Independent semantic decisions authored after reading all A conversations.
Runtime replay is a separate engineering check, not the source of verdicts.
"""
from pathlib import Path
from datetime import datetime, timezone
import json, hashlib, copy, sys
ROOT=next(p for p in Path(__file__).resolve().parents if (p/'experiments/deep_conversation/intention_state.py').exists())
sys.path.insert(0,str(ROOT/'experiments/deep_conversation'))
from intention_state import IntentStore
P=ROOT/'output/research/2026-10-24/tracker-lora-pilot'
def canonical(x): return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

NOTES={
1:['Indoor, free, Saturday and event goal are separate and supported.','Booking remains an unaccepted assistant proposal.','Only Saturday changes to Sunday; indoor and free survive.','Quiet waiting and no participant names both captured; progress is not completion.','Only quiet area is cancelled; all other conditions survive.'],
2:['Chinese guide and two-minute cap both captured.','Text-support possibility is correctly uncertain.','Proposal and acceptance jointly establish synchronous captions.','Separate delivery is new; foghorn remains unaccepted.','SRT/VTT comparison is a new question, not format selection.'],
3:['Flower-shop owner, weekly grouping and CSV are separate.','Coffee-shop daily XLSX request belongs to second owner.','Contact hiding applies to flower shop only; no common format accepted.','Monthly flower reporting and coffee waste figure are correctly scoped.','Assistant preparation plus acknowledgement cannot erase report needs.'],
4:['Two meal tasks and the portable-breakfast requirement are distinct.','No-cheese preference is dinner-only and not labelled medical allergy.','Whole breakfast cancellation withdraws task and scoped portability.','Original breakfast task and portability restored under same IDs.','Only dinner flavor changes; no cheese and breakfast remain.'],
5:['Map, poster and water marker all captured.','Poster title and QR exclusion do not affect map.','Disclaimed neighbor quote cannot remove water marker.','Accessibility advice is a new information request, no method selected.','Whole poster branch and its constraints withdrawn; map entry added.'],
6:['Grade-four class, group handling and no-battery restriction supported.','Transparent per-group bags are separately revisable.','Opening adopted through exact proposal and acceptance; electromagnet proposal remains unaccepted.','Material recovery and magnet counting both in target.','Demonstration format changes and group bags withdrawn; no batteries persists.'],
7:['Transcript, participant pseudonyms and original place names captured.','One-minute timestamps explicit.','Oral repetition and non-normalization explicit.','Question preserved without treating an example notation as adopted.','Village exception should preserve all unaffected place-name types, not silently narrow them to cities.'],
8:['Episode editing and natural pauses captured.','Unknown-owner candidate text must explicitly retain unresolved ownership.','Nested quote about a previous advertisement is correctly ignored.','Both ownership and adoption resolved by Lu’s arrived statements.','Noise-reduction question is new and does not authorize changing pauses.'],
9:['Cat identity, initial photo and fictional contact retained.','Rejected-slogan reference needs the proposal source as well as rejection.','Phone replaces public email and exclusion is retained.','New internal checklist, its separation and photo revision all captured.','Thanks does not mark tasks complete.'],
10:['Original file names and initial grouping survive task abstraction.','Approximate-date column is uncertain.','Estimated label and blank-if-unknown retained upon acceptance.','Grouping changed and place column added; reminder against guessing is already covered.','Two options requested without selecting one.'],
11:['Weekday bike route and preferred separated lanes supported.','Forty-minute maximum explicit.','Saturday bus errand is a separate task.','Tunnel avoidance added and only bus errand withdrawn.','The move becomes effective next week; target must retain that timing.'],
12:['Materials, print medium and font threshold separate.','Borrowing, renewal and reservation all captured.','QR entry accepted with proposal evidence.','Web medium, staff contact and clickable catalog link independently updated.','Screen-reader explanation is new, not permission to change website.'],
13:['Wednesday agenda and act order captured.','Unattributed warm-up candidate needs unresolved-owner wording, while Zhu’s cue sheet is active.','Jiang settles both owner and warm-up adoption.','Only Zhu’s cue sheet withdrawn.','Original cue sheet reopened with same scope.'],
14:['Observing task, venue and white-light restriction supported.','Indoor backup remains uncertain despite assistant suggestion.','Workshop adopted and beginner audience added separately.','Venue changes, backup and dark-sky constraints stay.','Unaccepted souvenir suggestion adds no request.'],
15:['CLI goal, JSON format and no-overwrite supported.','Stable-ID ordering added; force flag not adopted.','Tradeoff explanation added without changing output format.','Explicit NDJSON change retains order and no-overwrite.','Dry run is new and expressly nonwriting.'],
16:['Slides, duration, pilot inclusion and exploratory qualification captured.','Numerical sources added; quoted stronger claim rejected.','Removing pilot result also removes its scoped label; study design replaces it.','Handout and pilot-reference inclusion scoped separately.','Draft acknowledgement cannot erase deliverables.'],
17:['Trolley, maximum width and locking wheels captured.','Wood top remains tentative.','Top becomes stainless steel and width tightens; distinct constraints preserved.','Load-rating question is additional information need.','Minimum two shelves adds without replacing existing constraints.'],
18:['Agenda, starting movement, recording and its sharing boundary separate.','Pia owns cello-entrance list.','Entire recording plan cancelled with its dependent boundary; other tasks retained.','Two marking-method explanation requested, not an adopted method.','Exact original recording and privacy boundary restored.'],
19:['Walkthrough, first-time audience and strict under-five cap captured.','Sam’s troubleshooting sheet is a separate deliverable.','Accepted sample opening and expired-invite instruction belong to respective owners.','Audience changes; cap and Sam’s sheet retained.','No merge adopted, so no state change.'],
20:['Packing list, object accession labels and each-crate arrows separate.','Before-packing photo requirement supported.','Old sticker explicitly not authority to strip accession labels.','New-crate exception must preserve prior orientation rule for other crates or clarify all crates are new.','Condition check must precede display setup in unpacking checklist.'],
21:['Rules edit and exact card-name preservation supported.','Game command is not document-deletion instruction; no change.','Discussion-only example and final-rulebook exclusion both captured.','One-card exception preserves all other names and adds exact rename.','Glossary is an additional requirement.'],
22:['Two-day visit, short walks and day-one garden supported.','Boat conditional on remaining seated represented jointly.','Boat and scoped seated condition withdrawn; day two open added.','Explicit garden on day two supersedes open-day requirement; museum added day one.','Same boat option and seated condition restored; no second withdrawal of already withdrawn open-day record.'],
23:['Clean copy, immutable source and original names supported.','Deduplication remains pending.','Three-field explanation and blank-missing-count policy both captured.','Explicit evidence-based adoption resolves deduplication candidate.','Single column-name exception preserves others and specifies replacement.'],
24:['Main workshop, hand tools and optional session supported; optional participation is not uncertain preparation.','Pre-cut sheets added; electric cutter remains unaccepted.','Collage instruction belongs only to optional cover session.','Cancelling entire optional session withdraws its material constraint as well.','Cotton binding and large-print instructions belong to main workshop.'],
25:['Website copy, shift times and no phones captured.','Unattributed offline candidate needs explicit unresolved-owner text.','Owner resolution should also remove unresolved-owner language introduced by correction while retaining uncertain adoption.','Offline PDF adopted and its own phone exclusion added under Miles.','Synchronization explanation is new, shared headings not adopted.']}

ISSUES={
(7,5):dict(rule='preserve_unaffected_scope',severity='required_semantic_correction',reason='Original i3 preserves every place name. Seq 8 changes village-level names and reiterates cities, without withdrawing other place-name types.',intent_id='i3',replacement_fields={'text':'逐字稿中村级地名替换为代号，其他地名（包括市名）保留原文'}),
(8,2):dict(rule='OWNER-3',severity='required_contract_correction',reason='The reserved unresolved owner must be explained in the text; current wording only expresses possible adoption.',intent_id='i3',replacement_fields={'text':'访谈播客片头可能需要免责声明，采用与否及需求归属均待确认'}),
(9,2):dict(rule='EVIDENCE-1',severity='required_evidence_correction',reason='Seq 2 says “这句话”, which needs seq 1 to identify the exact forbidden slogan.',intent_id='i5',replacement_fields={'source_seqs':[1,2]}),
(11,5):dict(rule='preserve_temporal_scope',severity='required_semantic_correction',reason='The office moves next week, not immediately. Target omitted the stated effective period.',intent_id='i1',replacement_fields={'text':'规划工作日骑车到办公室的通勤路线，下周起终点改为河西园区办公室'}),
(13,2):dict(rule='OWNER-3',severity='required_contract_correction',reason='Unresolved-owner candidate text should identify both unknown attribution and uncertain adoption.',intent_id='i3',replacement_fields={'text':'周三排练前可能增加十分钟热身，需求归属及采用与否待确认'}),
(20,4):dict(rule='preserve_unaffected_scope',severity='required_semantic_correction',reason='Original rule covers each crate, whereas seq 4 replaces arrows only for new crates. Old/other crate scope is silently dropped.',intent_id='i3',replacement_fields={'text':'Print THIS SIDE UP instead of an orientation arrow on each new exhibit crate; retain orientation arrows on other exhibit crates'},alternative_source_clarification='If the intended scenario has only new crates in scope, revise seq 4 to explicitly say all crates for this shipment are new, then independently review the clarified example.'),
(25,2):dict(rule='OWNER-3',severity='required_contract_correction',reason='Candidate text should state unresolved owner, not only uncertain need.',intent_id='i4',replacement_fields={'text':'An offline version of volunteer information may be needed; adoption and requirement ownership are unresolved'}),
(25,3):dict(rule='UNCERTAIN-2',severity='required_dependent_correction',reason='After fixing decision 2, resolving owner alone leaves contradictory unresolved-owner text. Text must retain adoption uncertainty but remove attribution uncertainty.',intent_id='i4',replacement_fields={'text':'Miles may need an offline version of volunteer information; adoption remains undecided'})}

def main():
    path=P/'data/source/train-a.jsonl'; sourcehash=sha(path)
    families=[json.loads(s) for s in path.read_text(encoding='utf-8').splitlines() if s]
    results=[]
    for n,f in enumerate(families,1):
        assert f['family_id']==f'train-a-{n:03d}'
        checks=[]
        with IntentStore(':memory:') as store:
            for k,d in enumerate(f['decisions'],1):
                store.observe([e for e in f['events'] if e['seq']<=d['through_seq']])
                before=store.snapshot(); after=store.commit_patch(f'setup-{k}',before['version'],d['through_seq'],d['operations'])
                b={x['intent_id']:x for x in before['intents']}; a={x['intent_id']:x for x in after['intents']}
                touched={o['intent_id'] for o in d['operations']}
                assert set(d['preserve_ids'])==set(b)-touched
                assert all(b[i]==a[i] for i in d['preserve_ids'])
                issue=copy.deepcopy(ISSUES.get((n,k)))
                if issue:
                    proposed=copy.deepcopy(d['operations'])
                    next(o for o in proposed if o['intent_id']==issue['intent_id']).update(issue['replacement_fields'])
                    issue['proposed_complete_operations']=proposed
                checks.append({'decision_index':k,'through_seq':d['through_seq'],'verdict':'requires_correction' if issue else 'accepted','semantic_check':NOTES[n][k-1],'checks':{'arrived_sources_and_runtime_transition':'passed','unchanged_records':'passed','minimal_semantic_scope':'correction_required' if issue else 'accepted','ownership_status_and_new_question_checked':True},'pre_state_projection':[{key:x[key] for key in ('intent_id','owner','text','status')} for x in before['intents']],'post_state_projection':[{key:x[key] for key in ('intent_id','owner','text','status')} for x in after['intents']],'issue':issue})
        results.append({'family_id':f['family_id'],'canonical_family_sha256':canonical(f),'verdict':'requires_correction' if any(c['issue'] for c in checks) else 'accepted','decisions':checks})
    assert sha(path)==sourcehash
    out={'id':'train-a-independent-model-semantic-review','date':'2026-10-24','timezone':'America/Halifax','created_at_utc':datetime.now(timezone.utc).isoformat(),'reviewer':'tracker_annotation_v2, author of B but not A','kind':'independent_model_review_not_human_review','human_review_performed':False,'source_path':path.relative_to(ROOT).as_posix(),'source_sha256':sourcehash,'status':'corrections_required','source_modified':False,'canonical_family_hash_rule':'sha256(UTF-8 JSON with sort_keys=True, ensure_ascii=False, separators=(comma,colon))','summary':{'families_reviewed':25,'decisions_reviewed':125,'accepted_decisions':117,'decisions_requiring_correction':8,'families_requiring_correction':7,'runtime_replay_passed_decisions':125},'families':results,'review_notes':['Every raw arrived dialogue, target operation and resulting semantic pre/post-state was considered.','The source initially printed through a Python stream with a non-UTF-8 encoding; Chinese rows were re-read from UTF-8 before semantic decisions were finalized.','Correction suggestions do not edit the author source. Re-review must bind to the new source and per-family hashes.','Runtime replay and semantic review are separate evidence; structural success does not make incorrect scope or source labels acceptable.']}
    (P/'review/train-a-review.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(out['summary']))

if __name__=='__main__': main()
