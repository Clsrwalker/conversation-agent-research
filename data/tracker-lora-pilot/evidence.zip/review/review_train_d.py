"""Root independent semantic review, after reading all 125 dialogue decisions."""
import hashlib
import json
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
STUDY=HERE.parent
ROOT=next(p for p in STUDY.parents if (p/'experiments/deep_conversation/intention_state.py').exists())
sys.path.insert(0,str(ROOT/'experiments/deep_conversation/tracker_lora'))
from build_dataset import encode, materialize
NOTES={
1:['Task, single round robin and minimum gap separate.','Team arrival need has Su ownership.','Double round robin replaces format only.','Arrival limit withdrawn; changing-room screen added.','Scoring comparison is a new information request.'],
2:['Production table, box count and pickup slot independent.','Candidate packaging uncertain; CORRECTED selection boundary retains temporary scope.','Reusable boxes confirmed without a color restriction.','Both box size and pickup slot change; confirmation adds nothing.','Uncollected-order column added.'],
3:['Rules, audience questions and contact privacy separate.','Duplicate-question consolidation requested.','Other-room quotation explicitly disclaimed.','Posting timing changes; consolidation and live questions retained.','New question about avoiding semantic overmerging.'],
4:['Low-poly mailbox, scale and format captured.','Weathered texture uncertain.','Eighty centimetres replaces one metre; GLB stays.','Reject weathering, add solid material and no-text constraint.','Thanks is true no-change.'],
5:['Blocking sketch, ending orientation and no floor rolls.','Qiao left entry only; music background irrelevant.','Ending withdrawn and temporary blank endpoint recorded.','Restore original ending and withdraw blank endpoint.','Only Qiao entry side changes.'],
6:['Script length, order and simulated-number disclaimer separate.','Assistant greeting proposal not adopted or endorsed as user desire.','Rain before temperature replaces order.','Duration shrinks, simulated-data disclosure retained.','Separate probability/amount explanation requested.'],
7:['Chinese menu, character cap and English names.','Bilingual layout uncertain.','Spark-only exception preserves other English names.','Reject bilingual candidate; Chinese-only menu retains name exception.','Resume translation options requested without delegated selection.'],
8:['Plot, viewpoint and sibling-promise motive independent.','Pre-delivery ending and anonymous recipient separate.','Limited third-person replaces viewpoint only.','Delivery ending now permitted; navigator loss added; identity stays hidden.','Reaffirmation no change.'],
9:['Warehouse plan, east prefix and readable text.','West prefix belongs to Feng; aisle count background.','Only east prefix changes.','West level display and east no-extra-color scope both captured.','Encoding-method explanation belongs to Feng.'],
10:['Prototype, simulation-only boundary and currency display.','Cancel button acceptance cites proposal and acceptance.','Display order is new although user says change.','Cancel button moves without being cancelled.','Question about input preservation is not a chosen policy.'],
11:['Template, cadence and Celsius independent.','Settled odor condition active.','Photo ID field and no embedded image rule separate.','Remove photo ID only; image exclusion still applies to active table.','Cadence changes, unit persists.'],
12:['Puzzle, no locked exit and answer length captured.','Unknown-owner large-type candidate; answer-giving suggestion rejected.','Ye confirms ownership/adoption and thought-only hint scope.','Answer length changes, large type and open exit preserved.','New comparison question, not a clue-structure selection.'],
13:['Reversible bag, seam allowance and one pocket independent.','Button closure added.','Tie replaces button, pocket size changes without losing count.','Pocket removed, reversible construction and tie stay.','Allowance repetition no-change.'],
14:['Virtual-only course, keyboard and fixed rear camera.','Pause feature uncertain.','Gamepad replaces keyboard, camera unchanged.','Pause adopted only between checkpoints.','Camera explanation does not authorize camera change.'],
15:['Migration guide, names and no immediate upgrade.','Old quote disclaimed.','Single colour/color exception preserves all other names.','Old/new request examples added.','JSON format newly specified; no invented prior pseudocode choice.'],
16:['Playlist, approximate length and instrumental-only.','Start/end pacing relation added.','Pacing reversed.','Length removed and seamless-loop explanation added.','No spoken announcements is additional transition-specific constraint.'],
17:['Continuity sheet and outdoor grey scarf.','Chain visibility belongs to Tali.','Gloves uncertain; reference-photo hat not adopted.','Blue scarf replaces grey, outdoor scope and other owner preserved.','Gloves candidate rejected.'],
18:['Virtual maze and allowed/prohibited sensors.','Goal and stuck-time termination separate.','Green goal replaces red; time rule persists.','Compass added without losing camera exclusion; drift question added.','Explicit new no-further-change boundary recorded.'],
19:['Loop brief, no rapid flashing and eight seconds.','Chime owner/adoption unresolved.','Finn confirms quiet chime and own requirement.','Twelve seconds replaces eight; flashing boundary retained.','Finn cancels chime only.'],
20:['Index, grouping and no rewriting recipes.','Oven tag added.','Title phrase not executed as instruction.','Grouping changes while ingredient becomes separate tag.','Tradeoff question added; report of no choice does not change tagging.'],
21:['Fictional sandbox, invoice rule and no deletion.','TEST-subject exception retained within rule.','Accounts replaces Billing, exception stays.','Shipment label and external-forward prohibition both captured.','Display-options question does not establish priority.'],
22:['Templates, order and whole-number pronunciation.','Ivo accessibility need separate; historic recording irrelevant.','Time/destination order reversed.','CORRECTED conditional lift rule preserves if-available and otherwise exclusion.','Additional platform-change template requested.'],
23:['Packing, attached labels and care insert.','Care insert withdrawn, variety labels stay.','Loose-soil containment check added.','Original insert restored plus staff explanation question.','Clarifies explanatory purpose and lack of action permission.'],
24:['Bib specification, adult prefix and monochrome readability.','Junior prefix belongs to Uma.','Adult corner star added.','Junior prefix changes only.','Adult star withdrawn, prefixes and readability remain.'],
25:['Dialogue tree, payment opt-out and no rude-reply game-over.','Blue-pass conditional shortcut active.','Contradictory assistant proposal rejected.','Gold replaces blue; fee explanation branch added.','Two hinting approaches requested without revealing exact condition.']}
source=STUDY/'data/source/train-d.jsonl'
prompt=(STUDY/'annotation/system_prompt.txt').read_text(encoding='utf-8').strip()
families={}
for f in map(json.loads,source.read_text(encoding='utf-8').splitlines()):
    number=int(f['family_id'].rsplit('-',1)[1])
    decisions=[]
    for row in materialize(f,prompt):
        i=row['decision_index']
        sources={s for op in row['target']['operations'] for s in op['source_seqs']}
        decisions.append({'decision_index':i,'example_id':row['example_id'],'verdict':'accept',
                          'semantic_review_note':NOTES[number][i],
                          'supporting_events':[e for e in row['input']['conversation'] if e['seq'] in sources],
                          'runtime_replay':'passed','preserved_ids_checked':row['preserve_ids'],
                          'expected_semantic_state':row['expected_semantic_state']})
    families[f['family_id']]={'family_sha256':hashlib.sha256(encode(f).encode()).hexdigest(),
                             'author':'/root/tracker_annotation_v2','reviewer':'/root',
                             'independent_of_author':True,'verdict':'accept','decisions_reviewed':5,
                             'decisions':decisions}
report={'status':'accepted_after_corrections','date':'2026-10-24','reviewer':'/root',
        'kind':'independent model semantic review; not human validation or model-output evaluation',
        'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'system_prompt_sha256':hashlib.sha256((STUDY/'annotation/system_prompt.txt').read_bytes()).hexdigest(),
        'families':families,'total_decisions':125,
        'initial_findings':[{'family':'train-d-002','decision_index':1,'issue':'temporary scope dropped','resolved':True},
                            {'family':'train-d-022','decision_index':3,'issue':'conditional directions should be explicit','resolved':True}],
        'prior_source_and_changes':'data/authoring/train-d-revisions.json',
        'limitations':['Synthetic model-authored/model-reviewed labels.','Some domains overlap dev; only families are held out.']}
(HERE/'train-d-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':report['status'],'families':len(families),'decisions':125,'source_sha256':report['source_sha256']}))
