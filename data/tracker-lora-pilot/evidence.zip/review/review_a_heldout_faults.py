"""Independent review of A/dev/test authored stress mistakes and causal repair."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import json,copy,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from review_dev_test import P,HERE,IntentStore,sha,canon

SEMANTICS={
'train-a':[
 'Opening explicitly says resident participation is free; charging is a natural negation/polarity error, repaired while booking remains unaccepted.',
 'Two-minute cap is explicit in the original guide request; three is a nearby unsupported duration. Caption confirmation does not alter the cap.',
 'Coffee-shop XLSX is expressly owned by the second speaker. CSV is plausible cross-task contamination from the flower shop, not a legitimate format revision.',
 'No batteries remains explicit even when group work becomes teacher demonstration. Allowing batteries reverses an independent restriction.',
 'Original transcript request uses pseudonyms. Real names invert that privacy instruction, unrelated to new timestamp requirement.',
 'Forty-minute route limit has arrived before the separate bus task. Sixty is unsupported but a plausible value substitution.',
 'Complete-beginner workshop suitability is explicit before venue change; experienced-observers-only reverses the audience scope.',
 'Never overwrite is in the initial request. An overwrite default contradicts it even though format and sort changes may arrive later.',
 'Width was already corrected to fifty-four centimetres. Forty-five is a transposition; adding shelf count does not revise width.',
 'Under five is a strict bound. Five or fewer is a plausible but incorrect normalization, preserved independently of examples and support content.',
 'Missing counts must remain empty. Zero imputation contradicts the prior explicit policy, even when duplicate removal is confirmed.',
 'Hand-tools-only scope remains active after decorative-session cancellation; allowing powered tools is an unsupported relaxation.'
],
'dev':[
 'Independent attempt before hints is the original order; showing a solution first reverses it. At decision 2 the later stuck-only change has not arrived and is correctly not used for repair.',
 'Local files and no cloud upload are explicit in the opening and reaffirmed before reopening export. Cloud-first processing contradicts this boundary.',
 'Both proposal and acceptance establish text labels. Negating labels is wrong, and repair includes both arrived supporting seqs.',
 'The number row must remain unchanged. Function keys were an unaccepted proposal; repairing that contamination preserves the existing Caps Lock temporary layer.',
 'Ada originally requests stripes rather than pictures; this is the right pre-state at the owner-resolution decision. Later checkerboard replacement is not used early.'
],
'test':[
 'Three copying spaces were explicitly requested before tracing is removed. Two is a plausible off-by-one count and not a new preference.',
 'Seconds, not minutes, are specified in the opening tea record. Repair leaves the other participant’s subjective impressions separate.',
 'All filenames must remain unchanged; date-prefix renaming was unaccepted. Expanding archive inclusion does not permit renaming.',
 'Texture guidance is explicitly preserved independently of serving-count revisions and cancelled dip. Omitting it reverses that requirement.',
 'Only inspected record condition may be stated; uninspected means unknown. Defaulting to good invents evidence and is repairable from prior raw words.',
 'Addresses are explicitly forbidden on key labels. The later arbitrary-code correction concerns i1; this i2 repair remains independently supported.',
 'The user asks for operating band. Transmitter power is related vocabulary but a different field, so the substitution is a plausible unsupported memory error.',
 'Unplug-before-cleaning is explicitly in the user’s supplied instruction. The inverted plugged-in wording is an authored error to correct, not endorsed equipment advice.',
 'Pinned tabs are excluded from groups in the opening. Broad grouping can accidentally swallow that exception; repair must restore it without changing the projectless label.',
 'Missed weather readings must be marked missing, not copied forward. This prior rule survives cloud-sketch withdrawal and later scheduling changes.'
]}

def proj(s):return [{k:i[k] for k in ('intent_id','owner','text','status')} for i in s['intents']]
def main():
 for part in ('train-a','dev','test'):
  fp=P/f'data/faults/{part}.json';sp=P/f'data/source/{part}.jsonl';fh=sha(fp);sh=sha(sp)
  faults=json.loads(fp.read_text(encoding='utf-8'));families={f['family_id']:f for f in map(json.loads,sp.read_text(encoding='utf-8').splitlines())}
  assert len(faults)==len(SEMANTICS[part]);results=[]
  for q,(fault,note) in enumerate(zip(faults,SEMANTICS[part])):
   fid,idx=fault['example_id'].rsplit('-',1);step=int(idx);f=families[fid];d=f['decisions'][step-1];iid=fault['intent_id']
   assert iid not in {o['intent_id'] for o in d['operations']}
   with IntentStore(':memory:') as st:
    for k,old in enumerate(f['decisions'][:step-1]):
     st.observe([e for e in f['events'] if e['seq']<=old['through_seq']]);b=st.snapshot();st.commit_patch(f'setup-{k}',b['version'],old['through_seq'],old['operations'])
    st.observe([e for e in f['events'] if e['seq']<=d['through_seq']]);before=st.snapshot();record=next(i for i in before['intents'] if i['intent_id']==iid)
    assert record['status'] in ('active','uncertain') and record['text']==fault['repair_text'] and record['text']!=fault['wrong_text']
    assert all(s<=d['through_seq'] for s in fault['repair_source_seqs'])
    assert fault['repair_source_seqs']==sorted(set(fault['repair_source_seqs']))
    gold=st.commit_patch('decision-0',before['version'],d['through_seq'],d['operations'])
   altered=copy.deepcopy(f);positions=[(j,k) for j,prev in enumerate(altered['decisions'][:step-1]) for k,o in enumerate(prev['operations']) if o['intent_id']==iid and 'text' in o]
   j,k=positions[-1];altered['decisions'][j]['operations'][k]['text']=fault['wrong_text']
   with IntentStore(':memory:') as st:
    for n,old in enumerate(altered['decisions'][:step-1]):
     st.observe([e for e in f['events'] if e['seq']<=old['through_seq']]);b=st.snapshot();st.commit_patch(f'setup-{n}',b['version'],old['through_seq'],old['operations'])
    st.observe([e for e in f['events'] if e['seq']<=d['through_seq']]);bad=st.snapshot();assert next(i for i in bad['intents'] if i['intent_id']==iid)['text']==fault['wrong_text']
    fixed=st.commit_patch('decision-0',bad['version'],d['through_seq'],d['operations']+[dict(op='update',intent_id=iid,text=fault['repair_text'],source_seqs=fault['repair_source_seqs'])])
    assert proj(fixed)==proj(gold)
   results.append({'example_id':fault['example_id'],'canonical_fault_sha256':canon(fault),'canonical_family_sha256':canon(f),'verdict':'accepted','wrong_text':fault['wrong_text'],'correct_pre_state_record':record,'repair_text':fault['repair_text'],'repair_source_seqs':fault['repair_source_seqs'],'raw_supporting_events':[e for e in f['events'] if e['seq'] in fault['repair_source_seqs']],'semantic_assessment':note,'checks':{'plausible_local_memory_error_not_random_marker':True,'wrong_text_not_supported_as_current_requirement':True,'repair_equals_independently_reviewed_correct_pre_state':True,'support_arrived_by_current_decision':True,'no_future_user_evidence_used':True,'existing_active_or_uncertain_id':True,'ordinary_target_does_not_touch_id':True,'latest_prior_text_operation_injected':True,'actual_runtime_repair_matches_normal_gold_semantics':True},'modified_prior_decision_index_zero_based':j,'modified_prior_operation_index':k})
  assert sha(fp)==fh and sha(sp)==sh
  report={'id':f'{part}-independent-model-fault-review','date':'2026-10-24','timezone':'America/Halifax','created_at_utc':datetime.now(timezone.utc).isoformat(),'reviewer':'tracker_annotation_v2; did not author these fault proposals or source families','kind':'independent_model_semantic_and_runtime_review_of_authored_stress_cases','status':'accepted','human_review_performed':False,'source_modified':False,'fault_file_sha256':fh,'normal_source_sha256':sh,'summary':{'faults_reviewed':len(faults),'accepted':len(results),'rejected':0,'runtime_repair_replays_passed':len(results),'additional_examples':0,'language_counts':dict(Counter(families[x['example_id'].rsplit('-',1)[0]]['language'] for x in faults)),'decision_positions':dict(Counter(x['example_id'].rsplit('-',1)[1] for x in faults))},'faults':results,'limitations':['Plausibility is a model judgment; these are designed stress cases, not measured deployment-error distributions.','Selection is balanced across languages and distributed among decisions, but not representative sampling.','No base or LoRA evaluation output was read; no training hyperparameters were changed.','Runtime acceptance alone is not the semantic review; each note above compares arrived raw evidence with wrong and correct meanings.']}
  (HERE/f'{part}-fault-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(part,json.dumps(report['summary']))
if __name__=='__main__':main()
