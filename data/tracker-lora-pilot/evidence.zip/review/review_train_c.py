"""Independent model semantic review, with supporting state replay.

Semantic judgments below were individually authored after reading every arrived
conversation and decision. Replay verifies serialization, not semantic truth.
"""
from pathlib import Path
import hashlib
import json
import sys

P=Path(__file__).resolve().parents[1]
ROOT=P.parents[3]
sys.path.insert(0,str(ROOT/'experiments'/'deep_conversation'))
from intention_state import IntentStore
def sha(b): return hashlib.sha256(b).hexdigest()
def canon(x): return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')

NOTES={
1:[
 'The opening independently requests a garden poster, A4 portrait, and email registration; all belong to 岚.',
 'The larger readable type is newly requested; retaining email is a restatement, and the assistant QR proposal is unaccepted.',
 'A4 landscape replaces portrait under i2; email and larger type stay untouched.',
 'The telephone example is explicitly non-actionable; later acknowledgement and assistant progress do not change any intent.',
 'Email registration is explicitly withdrawn; electronic preview instead of printing is added without inventing another registration channel.'],
2:[
 '宁 owns the menu and personal peanut restriction; 乔 independently owns the vegan requirement. These do not apply to everyone automatically.',
 'The gluten-free candidate is concrete but not adopted and therefore uncertain; other dietary constraints remain active.',
 'An assistant-only offer to make every dish vegan cannot broaden 乔’s request to all participants.',
 '宁 explicitly withdraws only the gluten-free candidate; peanut exclusion and 乔’s vegan need remain.',
 '乔 adds an oven-free preparation request while retaining vegan food and the other participant’s restrictions.'],
3:[
 'The import task, leading-zero preservation and UTF-8 input are supported; zero preservation is not yet an explicit general raw-string fidelity rule.',
 'Full duplicate rows must remain; this is separate from encoding and product-ID preservation.',
 'The new instruction 编号还是原字符串 adds raw-string fidelity beyond preserving leading zeros, so an empty patch loses a supported requirement.',
 'GB18030 replaces UTF-8 only; duplicate rows and the ID-preservation requirement must remain after the earlier correction.',
 'The new question is captured without withdrawing duplicate retention or changing the script.'],
4:[
 'The original 控制在四十五分钟 is a duration ceiling; labeling it an exact forty-five-minute duration strengthens the request.',
 'The form and its exclusion of children’s home addresses are distinct, form-scoped needs.',
 'The user changes start time to Saturday eleven and duration to half an hour; the Saturday context and form privacy are retained.',
 'Cancelling the whole registration form also deactivates its form-only field constraint i5; leaving i5 active is a dangling obligation.',
 'Once i5 is properly withdrawn in the preceding decision, explicit restoration of the original form and address exclusion must reopen both. Walk-in admission need not be withdrawn without contrary evidence.'],
5:[
 'Read-only originals and copy-only renaming are a coupled source-protection rule alongside the organization task.',
 'The date-folder proposal is adopted only when the user accepts it; both proposal and acceptance are cited.',
 'Missing capture dates receive a pending-confirmation folder and must not be substituted with modification timestamps.',
 'Acknowledgements and assistant directory preparation do not establish completion or cancellation.',
 'City grouping replaces date grouping, while the user explicitly preserves the missing-date handling despite that unusual combination.'],
6:[
 'Three bus routes, a forty-five-minute maximum and a soft preference for fewer transfers are faithfully separated.',
 'Cycling slope is a new information request, explicitly excluded from changing the bus comparison scope.',
 'The assistant cannot broaden the route comparison without acceptance.',
 'The duration cap becomes fifty-five minutes and the transfer preference becomes a hard maximum of one transfer; both changes are captured.',
 'Only the slope question is withdrawn; the bus comparison and revised constraints remain.'],
7:[
 'The half-day museum itinerary and before-one-pm finish are captured without reversing start and end.',
 'The step-free candidate is uncertain in both owner and adoption, and the record explicitly states both uncertainties.',
 '遥 establishes her own stroller-related need, resolving the same stable candidate to active without guessing a wheelchair requirement.',
 '舒’s thanks and repeated half-day scope do not remove 遥’s independent accessibility constraint.',
 '遥 asks for elevator entrances; this supplements step-free access without deleting the finish deadline.'],
8:[
 'The diagnostic checklist and no-factory-reset boundary are active; execution or configuration change is not authorized.',
 'The explicit wired-before-Wi-Fi order is recorded independently of the diagnostic boundary.',
 'A forum reset suggestion is explicitly disclaimed and cannot override the existing restriction.',
 'The investigation order reverses while diagnosis-only and no-reset remain.',
 'A one-paragraph double-NAT explanation is an additional information request, not evidence the diagnostic work has finished.'],
9:[
 '蓝 and 泽 have separate named shifts, with Saturday supplied by the shared scheduling context; ownership is not merged.',
 '蓝 changes only their own shift to Sunday morning; 泽’s afternoon role stays unchanged.',
 'The reported rumor is explicitly not a request to change 泽’s shift, and no direct adoption occurs.',
 '泽 directly confirms the Saturday-morning change while keeping the guiding role; 蓝’s Sunday shift remains.',
 '蓝 requests a separately copyable one-line rendering of their own shift, not both participants’ schedules.'],
10:[
 'The repair inquiry draft is separate from the prohibition on booking service; drafting does not authorize sending.',
 'The requested price breakdown is labor versus materials, not merely a single total.',
 'The user gives a new explicit no-budget-content instruction, not just a neutral acknowledgement.',
 'Desk-drawer repair replaces chair repair while inquiry-only, fee breakdown and no-budget constraints remain.',
 'The prohibition on mentioning budget is withdrawn. Permission to mention an undecided amount does not establish an amount or a mandatory budget field.'],
11:[
 'Book-club minutes and exclusion of real participant names are independently represented.',
 'The English version is a concrete unadopted deliverable, correctly uncertain.',
 'The user explicitly excludes occupations; that new exclusion supplements the existing anonymity rule.',
 'The English version becomes active and receives its own one-page maximum; that limit is not generalized to all versions.',
 'Thanks and restatement preserve all five requirements without a completion claim.'],
12:[
 'Seed-record task, grams as the quantity unit and a separate shelf-life column are all captured.',
 'Bags replaces grams under the same unit ID; shelf-life structure remains.',
 'The possible photo column is pending the custodian’s response and remains uncertain.',
 'The user rejects the photo column entirely; an assistant link suggestion cannot keep it active.',
 'Nickname column and exclusion of identity-card information are independent additions; bags and shelf life remain.'],
13:[
 'The requested artifact is a textual directory of oral history, with dialect quotations preserved rather than normalized.',
 'Unclear audio is marked as unclear rather than guessed; the coupled conditional rule is active.',
 'The voice-recording quote is explicitly not a current instruction, so no name-publication requirement is added.',
 'Parenthetical dialect explanations supplement rather than replace the original dialect wording.',
 'The user asks to compare transcript and textual directory without requesting a transcript deliverable.'],
14:[
 'Teaching-sheet task, one-page scope and official-rules-only boundary are captured.',
 'The tie-scoring example is an independent requested component.',
 'The user rejects ignoring ties and restates the official-rule boundary; the tie example remains.',
 'The two-page revision and separate why-ties explanation are captured, but the explicit readability purpose so the type is readable is omitted as a persistent constraint.',
 'The separate explanation is cancelled while the worked tie example remains; a corrected readability requirement must also survive this cancellation.'],
15:[
 'The lint-filter reminder and bilingual English/Spanish output are supported; no unstated translation is added.',
 'The handbook QR code supplements rather than replaces bilingual text.',
 'The user explicitly withdraws the QR requirement temporarily; failure of a link alone would not have authorized this.',
 'The same QR requirement is restored and the main artifact changes to an email draft without dropping either language.',
 'Assistant draft preparation and thanks do not withdraw requirements or mark the task complete.'],
16:[
 'Location and date are independent required fields, yet both are embedded in the main-task record. The final turn independently removes location, demonstrating the need for atomic field records.',
 'The audio-note field is correctly uncertain and does not authorize recording sound.',
 'The assistant photo suggestion remains unaccepted and therefore creates no user requirement.',
 'The audio-note field is now adopted, while optionality of filling it is correctly retained in active text.',
 'The semantic result removes location and retains date/privacy/audio, but the target should operate on a separate location-field record after the atomicity repair rather than rewriting the main task.'],
17:[
 'Maintenance checklist, a separate tire-pressure section and an instructions-only/no-booking boundary are distinct requirements.',
 'Only the tire-pressure section is temporarily withdrawn.',
 'The user restates the no-booking boundary; no shop-calling task is accepted.',
 'The exact prior tire-pressure section is reopened under its existing ID with no forbidden same-patch revision.',
 'Metric units is a new checklist-wide constraint; it does not replace the section or execution boundary.'],
18:[
 'Asha’s lighting survey with five questions and Ben’s playground survey with eight questions are separate owner-scoped tasks.',
 'Only Asha’s count becomes six; Ben’s eight stays intact.',
 'Ben’s new question about multiple choice is represented without modifying either survey.',
 'Neither participant accepts the open-question proposal; no format change is justified.',
 'Ben cancels his survey and its dependent question-count requirement but explicitly retains his information request; Asha is unaffected.'],
19:[
 'The two-day cabin checklist and no-checked-luggage constraint are both captured.',
 'The active conditional rule is correct in status, but only if is less explicit than the original if-rain include / otherwise omit rule; preserve both branches in target text.',
 'Only trip duration becomes three days; luggage and rain condition remain.',
 'The extra-boots proposal is not adopted and does not create a new blanket prohibition on boots.',
 'The rain shell becomes unconditional; the earlier conditional rule is replaced rather than duplicated.'],
20:[
 'Puzzle event, two-pm start and printed large-type instructions are separate explicit needs.',
 'Teams of three is a new grouping requirement.',
 'Room-table background, acknowledgement and assistant notes do not imply a requested table layout.',
 'Start time and team size change together while print accessibility remains byte-for-byte unchanged.',
 'The user asks for a practice-duration recommendation but reserves the choice; no fixed duration is invented.'],
21:[
 'Cat handover, wet-food feeding at seven and the closed-balcony-door instruction are distinct tasks/constraints.',
 'A separate plant-care note limits watering to herbs and excludes the cactus; no cat requirement changes.',
 'Feeding moves to eight with the same wet food; the plant instruction remains.',
 'The assistant door-opening suggestion is rejected, merely restating the already recorded closed-door instruction.',
 'Only the separate plant note is cancelled, so its coupled plant-specific content is withdrawn with it; cat instructions remain.'],
22:[
 'The public allotment map and plot-numbers-instead-of-names policy are captured without inventing an address rule.',
 'The high-contrast need has unresolved owner and adoption, both stated in the uncertain record.',
 'Rae identifies herself and confirms high contrast; the same record is assigned to Rae and activated.',
 'The name-label suggestion is rejected and cannot displace the plot-number policy.',
 'PDF format applies to Rae’s high-contrast copy only, not every map output.'],
23:[
 'Weekday rota, Tuesday leftovers and no-oven requirement are separate.',
 'Only Tuesday leftovers is cancelled, not the meal rota.',
 'The same Tuesday rule is explicitly reopened; no changed value is smuggled into reopen.',
 'The roasting suggestion is not adopted and the no-oven requirement is restated.',
 'On a later turn the active leftovers rule moves to Wednesday, preserving the rota and oven exclusion.'],
24:[
 'Description and approximate loss-date fields are independent requirements and should be split out from the main form task under the atomic-record convention.',
 'The email field is optional, a settled field policy rather than uncertain adoption.',
 'Quoted passport-number wording is explicitly not adopted.',
 'The anonymous-code tradeoff is a new information request; the user has not selected the code as a replacement.',
 'Only the email-field requirement becomes mandatory; the address exclusion and unanswered explanation request remain.'],
25:[
 'The tour-script task for local residents, nontechnical style and old-mill endpoint are all captured.',
 'The French version is a concrete tentative deliverable, not an active translation request.',
 'Background about the mill sign and acknowledgement introduce no new work.',
 'Audience changes to visiting teenagers and endpoint to the library; simple language and the uncertain French version remain.',
 'The French candidate is explicitly withdrawn and a pronunciation guide is independently added, preserving the revised audience and endpoint.'],
}

ISSUES=[
dict(issue_id='C003-STRING',family_id='train-c-003',decision_indices=[2],severity='medium',kind='omitted_new_constraint',quote='这个建议不采用，编号还是原字符串。',problem='The empty patch retains only leading-zero preservation; raw-string preservation is stronger.',suggestion='Update i2 with source_seqs [3] to 导入时保留商品编号的原始字符串及前导零. Recompute downstream histories and preservation lists.'),
dict(issue_id='C004-DURATION',family_id='train-c-004',decision_indices=[0],severity='medium',kind='strengthened_quantity',quote='控制在四十五分钟',problem='The target states an exact forty-five-minute duration rather than a ceiling.',suggestion='Change the initial i3 text to 朗读活动时长不超过四十五分钟. Preserve the later explicit half-hour revision.'),
dict(issue_id='C004-DEPENDENCY',family_id='train-c-004',decision_indices=[3,4],severity='high',kind='dangling_cancelled_task_constraint',quote='报名表先不做了，现场直接入场。 / 恢复原先那项，也继续不收家庭住址。',problem='The form is withdrawn but its form-only address constraint remains active; the next restoration consequently fails to reopen that dependent condition.',suggestion='Decision 3 withdraw i4 and i5, then add walk-in i6. Decision 4 reopen both i4 and i5. Preserve i6 because a registration form does not necessarily prohibit walk-ins. Update evidence notes and critical_checks.'),
dict(issue_id='C014-READABILITY',family_id='train-c-014',decision_indices=[3],severity='medium',kind='omitted_purpose_constraint',quote='Make it two pages so the type is readable.',problem='Two pages does not itself require the type to be readable; a stated purpose relevant to layout is lost.',suggestion='Add an independent active requirement to use readable type in the teaching sheet, source [4], and retain it after the separate explanation is cancelled.'),
dict(issue_id='C016-ATOMIC-FIELDS',family_id='train-c-016',decision_indices=[0,4],severity='medium',kind='atomicity_contract',quote='Include location and date / Remove location altogether. Keep the date',problem='Two independently revisable field requirements are embedded in the main task. The final turn revises location independently, so this violates the frozen atomic-record convention.',suggestion='Split the main log task, location-field policy and date-field requirement in decision 0, keeping nest-coordinate exclusion separate. At the final turn update only location policy to no location field, retaining date and the main task. Rebuild IDs/history consistently through the family.'),
dict(issue_id='C019-CONDITION',family_id='train-c-019',decision_indices=[1],severity='low',kind='condition_direction_ambiguity',quote='If rain is forecast, include a rain shell; otherwise leave it off.',problem='Only if is a necessary-condition phrasing and can omit the positive if-rain branch; keep the explicit two-branch rule.',suggestion='Use Include a rain shell if rain is forecast; otherwise leave it off. Keep status active, not uncertain.'),
dict(issue_id='C024-ATOMIC-FIELDS',family_id='train-c-024',decision_indices=[0],severity='medium',kind='atomicity_contract',quote='Ask for item description and approximate loss date',problem='The main form task and two independently revisable fields are bundled into one record.',suggestion='Represent the form task, item-description field and approximate-loss-date field separately; keep no-home-address and email policies separate. Preserve the approximate qualifier and rebuild later states.'),
]

def main():
    source=P/'data/source/train-c.jsonl'
    source_bytes=source.read_bytes()
    families=[json.loads(s) for s in source_bytes.decode('utf-8').splitlines()]
    rows=[json.loads(s) for s in (P/'data/compiled/train.records.jsonl').read_text(encoding='utf-8').splitlines()]
    rows={(r['family_id'],r['decision_index']):r for r in rows if r['family_id'].startswith('train-c-')}
    assert len(rows)==125 and len(families)==25
    reports=[]
    semantic_corrections=0
    for f in families:
        n=int(f['family_id'][-3:])
        assert len(NOTES[n])==len(f['decisions'])==5
        per=[]
        with IntentStore(':memory:') as st:
            prev=-1
            for di,d in enumerate(f['decisions']):
                r=rows[(f['family_id'],di)]
                assert r['input']['conversation']==f['events'][:d['through_seq']+1]
                st.observe(f['events'][prev+1:d['through_seq']+1])
                before=st.snapshot()
                assert before==r['input']['intention_state']
                assert r['target']=={'operations':d['operations']}
                after=st.commit_patch(f'decision-{di}',di,d['through_seq'],d['operations'])
                assert after==r['expected_post_state']
                bi={x['intent_id']:x for x in before['intents']}; ai={x['intent_id']:x for x in after['intents']}
                preserved=sorted([i for i in bi if bi[i]==ai[i]])
                assert preserved==sorted(d['preserve_ids'])==sorted(r['preserve_ids'])
                relevant=[i['issue_id'] for i in ISSUES if i['family_id']==f['family_id'] and di in i['decision_indices']]
                prior=[i['issue_id'] for i in ISSUES if i['family_id']==f['family_id'] and min(i['decision_indices'])<di]
                if relevant: semantic_corrections+=1
                cited=sorted(set(s for op in d['operations'] for s in op['source_seqs']))
                per.append(dict(decision_index=di,through_seq=d['through_seq'],verdict='correction_required' if relevant else 'accepted_local_semantics',
                    semantic_review=NOTES[n][di],issue_ids=relevant,requires_rebuild_after_prior_corrections=prior,
                    critical_checks=[dict(check=c,assessment='reviewed; see semantic note and linked corrections' if relevant else 'supported by the reviewed dialogue and resulting state') for c in d['critical_checks']],
                    evidence_quotes=[dict(seq=e['seq'],speaker=e['speaker'],role=e['role'],text=e['text']) for e in f['events'] if e['seq'] in cited],
                    preserve_ids=d['preserve_ids'],preservation_actual_equal=True,
                    input_and_expected_post_state_match_runtime=True,
                    pre_state_sha256=sha(canon(before)),post_state_sha256=sha(canon(after)),
                    compiled_record_sha256=sha(canon(r))))
                prev=d['through_seq']
        issues=[i['issue_id'] for i in ISSUES if i['family_id']==f['family_id']]
        reports.append(dict(family_id=f['family_id'],source_sha256=sha(canon(f)),hash_method="SHA256 UTF-8 canonical JSON: sort_keys=True, ensure_ascii=False, separators=(',', ':')",verdict='corrections_required' if issues else 'accepted',issue_ids=issues,decisions=per))
    assert source.read_bytes()==source_bytes,'Author changed source during review; rerun against the frozen snapshot.'
    (P/'review/train-c-source-reviewed.jsonl').write_bytes(source_bytes)
    result=dict(status='corrections_required',author='root',reviewer='/root/tracker_corpus_a',independent=True,human_review=False,
        annotation_version='v2',review_date='2026-10-24',source_path='data/source/train-c.jsonl',source_file_sha256=sha(source_bytes),
        annotation_sha256=sha((P/'annotation/ANNOTATION_GUIDE.md').read_bytes()),system_prompt_sha256=sha((P/'annotation/system_prompt.txt').read_bytes()),
        method='Independent per-decision semantic review of all 25 original conversations, operations and intended states, followed by exact runtime/compiled-state checks. Replay is not treated as semantic proof.',
        summary=dict(families=25,decisions=125,issue_groups=len(ISSUES),decisions_requiring_direct_correction=semantic_corrections,
            families_accepted=sum(r['verdict']=='accepted' for r in reports),families_requiring_correction=sum(r['verdict']!='accepted' for r in reports),runtime_checks_passed=125),
        issues=ISSUES,families=reports,release_gate_passed=False,
        limitations=['Fictional model-authored corpus; this is independent model review, not human adjudication.','Corrected families must be recompiled and independently rechecked against fresh canonical hashes before training.'])
    (P/'review/train-c-review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result['summary']))

if __name__=='__main__': main()
