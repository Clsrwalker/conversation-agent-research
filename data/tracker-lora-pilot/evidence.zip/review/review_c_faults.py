"""Independent semantic/evidence review of root-authored prior-state faults."""
from pathlib import Path
import json, hashlib, sys
P=Path(__file__).resolve().parents[1];ROOT=P.parents[3]
sys.path.insert(0,str(ROOT/'experiments/deep_conversation/tracker_lora'))
from build_dataset import materialize,apply_prior_fault
def canon(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
def sha(x):return hashlib.sha256(x).hexdigest()
NOTES={
'train-c-001-4':'A3 is a plausible size-value error after the portrait-to-landscape change. Seq 3 explicitly says A4 landscape, so the repair preserves orientation while restoring size.',
'train-c-003-5':'UTF-8 is an authentic earlier value that became stale after seq 6 explicitly changed input to GB18030. The current duplicate-row question does not revise encoding.',
'train-c-004-5':'The original ten-am start is stale after seq 3 changes it to eleven. Restoring registration material does not undo that time correction; Saturday remains unchanged context.',
'train-c-005-3':'In-place renaming is a plausible reversed preservation boundary. Seq 0 expressly restricts renaming to copies and keeps originals read-only; the new missing-date rule does not permit writes.',
'train-c-007-3':'Confusing a before-one-pm finish with a one-pm start is a realistic temporal-relation error. Seq 0 directly supplies the correct deadline; access ownership resolution is independent.',
'train-c-012-3':'Grams is the stale original unit; seq 1 explicitly replaces it with bags. The new tentative photo field does not reintroduce mass-based quantities.',
'train-c-014-5':'One page is stale after the accepted two-page revision in seq 4. Cancelling only the separate explanation leaves the layout limit and readable-type goal intact.',
'train-c-016-2':'A dropped negation can reverse nest-coordinate privacy. The opening explicitly prohibits exact coordinates, and the possible audio field does not authorize them.',
'train-c-017-2':'Booking a service goes beyond the user’s instructions-only boundary. Seq 0 directly prohibits booking; cancelling a section does not change that boundary.',
'train-c-018-5':'Eight is Ben’s count mistakenly copied to Asha. Asha explicitly increases hers to six at seq 2; Ben’s later cancellation does not change Asha’s separate survey.',
'train-c-019-4':'Two days is stale after seq 2 changes the cabin stay to three. Declining a boot suggestion does not revert the trip length.',
'train-c-021-4':'Dry instead of wet food is a plausible value-retention failure when time changes. Repair text is correct, but seq 2 only says same food: seq 0 is required to establish wet food.',
'train-c-024-4':'Exact date strengthens the user’s approximate date requirement. Seq 0 supplies the precision, and the claim-code question does not change that field.',
}
def main():
 path=P/'data/faults/train-c.json'; raw=path.read_bytes();faults=json.loads(raw)
 fs={f['family_id']:f for f in map(json.loads,(P/'data/source/train-c.jsonl').read_text(encoding='utf-8').splitlines())}
 prompt=(P/'annotation/system_prompt.txt').read_text(encoding='utf-8').strip()
 reports=[]
 for fault in faults:
  eid=fault['example_id'];fid,pos=eid.rsplit('-',1);di=int(pos)-1;f=fs[fid]
  ordinary=materialize(f,prompt)[di];changed=apply_prior_fault(f,ordinary,fault,prompt)
  assert changed['expected_semantic_state']==ordinary['expected_semantic_state']
  assert max(fault['repair_source_seqs'])<=f['decisions'][di-1]['through_seq']
  assert changed['input']['conversation']==f['events'][:f['decisions'][di]['through_seq']+1]
  assert set(changed['input'])=={'conversation','intention_state','tool_receipts'}
  assert fault['intent_id'] not in {op['intent_id'] for op in ordinary['target']['operations']}
  assert changed['target']['operations'][-1]['text']==fault['repair_text']
  issue=eid=='train-c-021-4'
  reports.append(dict(example_id=eid,author='root',reviewer='/root/tracker_corpus_a',independent=True,human_review=False,
   fault_sha256=sha(canon(fault)),canonical_fault_sha256=sha(canon(fault)),family_sha256=sha(canon(f)),
   verdict='correction_required' if issue else 'accepted',semantic_review=NOTES[eid],
   supporting_quotes=[dict(seq=e['seq'],speaker=e['speaker'],role=e['role'],text=e['text']) for e in f['events'] if e['seq'] in fault['repair_source_seqs']],
   natural_error_plausible=True,repair_text_correct=True,selected_id_preexists_untouched=True,
   no_future_evidence=True,annotation_metadata_not_in_input=True,actual_fault_replay_reaches_ordinary_gold=True,
   input_sha256=sha(canon(changed['input'])),target_sha256=sha(canon(changed['target'])),
   issue=dict(rule='EVIDENCE-1',reason='same food at seq 2 does not identify wet food without seq 0',recommended_repair_source_seqs=[0,2],additional_supporting_quote=f['events'][0]['text']) if issue else None))
 assert path.read_bytes()==raw
 (P/'review/train-c-faults-reviewed-source.json').write_bytes(raw)
 result=dict(status='corrections_required',source_file_sha256=sha(raw),source_path='data/faults/train-c.json',
  canonical_hash_rule="sha256 UTF-8 JSON sort_keys=True ensure_ascii=False separators=(',',':')",author='root',reviewer='/root/tracker_corpus_a',independent=True,human_review=False,
  summary=dict(reviewed=13,accepted=12,correction_required=1,runtime_replays_passed=13),faults=reports,
  limitations=['Independent model review, not human annotation.','Fault frequency is a designed stress condition, not observed deployment prevalence.','Successful replay verifies transition execution, not semantic labels by itself.'])
 (P/'review/train-c-faults-review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(result['summary']))
if __name__=='__main__':main()
