"""Bind accepted correction reviews to current dev/test families and downstream states."""
from pathlib import Path
from datetime import datetime,timezone
import json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from review_dev_test import P,HERE,IntentStore,sha,canon,DEV_NOTES,TEST_NOTES
RESOLUTIONS={
 ('dev',1,4):'Explanation and temporary sleeve-cap prohibition are now separate records i4/i5.',
 ('dev',1,5):'Only explanation i4 is withdrawn; sleeve-cap boundary i5 remains active and preserved.',
 ('dev',7,3):'Daily frequency and kilowatt-hour units retained while changing to cumulative reading values.',
 ('dev',7,4):'Candidate column withdrawn and a distinct no-estimation prohibition is recorded with proposal/reference evidence.',
 ('dev',7,5):'Date field added; cumulative daily readings and new no-estimation prohibition retained.',
 ('test',11,1):'Spare-key label task explicitly preserves arbitrary code choice alongside the street-address prohibition.'}
def main(split):
 source=P/f'data/source/{split}.jsonl';prior=json.loads((HERE/f'{split}-review.json').read_text(encoding='utf-8'))
 old=[json.loads(l) for l in (HERE/f'{split}-source-reviewed.jsonl').read_text(encoding='utf-8').splitlines() if l]
 new=[json.loads(l) for l in source.read_text(encoding='utf-8').splitlines() if l]
 notes=DEV_NOTES if split=='dev' else TEST_NOTES;results=[];confirmed=0
 for n,(f,orig,pf) in enumerate(zip(new,old,prior['families']),1):
  assert f['family_id']==orig['family_id'] and f['events']==orig['events'];ds=[]
  with IntentStore(':memory:') as st:
   for k,(d,od,pd) in enumerate(zip(f['decisions'],orig['decisions'],pf['decisions']),1):
    if pd['issue']:
     assert d['operations']==pd['issue']['proposed_operations'];confirmed+=1
     if 'required_preserve_ids' in pd['issue']:assert d['preserve_ids']==pd['issue']['required_preserve_ids']
    else:assert d['operations']==od['operations']
    st.observe([e for e in f['events'] if e['seq']<=d['through_seq']]);b=st.snapshot();a=st.commit_patch(f'setup-{k}',b['version'],d['through_seq'],d['operations'])
    bb={i['intent_id']:i for i in b['intents']};aa={i['intent_id']:i for i in a['intents']};touched={o['intent_id'] for o in d['operations']}
    assert set(d['preserve_ids'])==set(bb)-touched and all(bb[i]==aa[i] for i in d['preserve_ids'])
    ds.append({'decision_index':k,'through_seq':d['through_seq'],'verdict':'accepted','semantic_check':RESOLUTIONS.get((split,n,k),notes[n][k-1]),'checks':{'arrived_raw_events_unchanged':True,'requested_corrections_confirmed':bool(pd['issue']),'actual_state_replay':'passed','untouched_records_preserved':True,'downstream_semantics_rechecked':True},'post_state_projection':[{key:i[key] for key in ('intent_id','owner','text','status')} for i in a['intents']]})
  results.append({'family_id':f['family_id'],'canonical_family_sha256':canon(f),'verdict':'accepted','decisions':ds})
 assert len(new)==len(old)==len(prior['families'])
 report={'id':f'{split}-independent-model-rereview','date':'2026-10-24','timezone':'America/Halifax','created_at_utc':datetime.now(timezone.utc).isoformat(),'reviewer':'tracker_annotation_v2; not author of dev/test','kind':'independent_model_semantic_rereview','human_review_performed':False,'source_modified':False,'source_sha256':sha(source),'previous_review_sha256':sha(HERE/f'{split}-review.json'),'annotation_guide_sha256':sha(P/'annotation/ANNOTATION_GUIDE.md'),'status':'accepted_after_corrections','summary':{'families_reviewed':len(new),'decisions_reviewed':5*len(new),'accepted_decisions':5*len(new),'corrections_confirmed':confirmed,'runtime_replays_passed':5*len(new),'raw_events_changed':0},'families':results,'limitations':['Read source and target annotations only; no baseline/adapter output viewed and no hyperparameter decisions made.','Family-disjoint evaluation does not imply domain-disjoint evaluation.','All held-out conversations are short; this review does not establish long-history coverage.','Fault variants require a separate independent review.']}
 (HERE/f'{split}-rereview.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(report['summary']))
if __name__=='__main__':main(sys.argv[1])
