"""Independent per-decision semantic notes, separate from executable replay."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,copy,sys
ROOT=next(p for p in Path(__file__).resolve().parents if (p/'experiments/deep_conversation/intention_state.py').exists())
P=ROOT/'output/research/2026-10-24/tracker-lora-pilot';HERE=P/'review'
sys.path.insert(0,str(ROOT/'experiments/deep_conversation'))
from intention_state import IntentStore
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canon(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
DEV_NOTES={
1:['Sleeve-adjustment task and removable basting both supported.','Two-centimetre reduction added.','Corrected measurement changes to one centimetre while basting stays.','Separate explanation request from temporary prohibition on changing sleeve cap.','Cancelling only explanation must not cancel the sleeve-cap boundary.'],
2:['Independent attempt and initial error-triggered hints captured.','One question per turn added; full solutions unaccepted.','Factoring scope and temporary exclusion of formula preserved.','Hint trigger changes to learner declaring stuck; independent attempt retained.','Final acknowledgement adds no new requirement.'],
3:['Label-only and no automatic deletion captured.','Receipt-in-subject predicate limited to matching messages.','Comparison question and temporary no-archive boundary captured.','Only label name changes, match stays.','Action boundary broadened to labels plus stars, deletion/archive still forbidden.'],
4:['Local-only migration instructions and export step supported.','Only export step cancelled.','Existing no-upload boundary reaffirmed, online converter rejected.','Original export step reopened under same ID.','Plain-language comparison added without selecting backup type.'],
5:['Document-only diagram task, no device control supported.','Both color and text-label conventions accepted through proposal and acceptance.','Quoted power step does not authorize device action.','Color replaced with line styles; text labels remain.','Symbol legend added as separate deliverable.'],
6:['Remapping task preserves number row.','Media actions restricted to temporary Fn layer.','Default function-key proposal rejected, existing rule retained.','Temporary trigger changes to holding Caps Lock, base layer still unmodified.','Separate printable key legend added.'],
7:['Notebook and daily kilowatt-hour readings captured.','Appliance column is an undecided candidate.','Cumulative rather than daily-consumption values should retain original daily recording frequency.','Withdraw appliance column and record explicit new prohibition on estimating appliance breakdown.','Date field added; all correctly retained constraints must survive.'],
8:['Nell owns journal ink selection and blue constraint.','Arun owns separate waterproof sketching bottle.','Nell alone changes blue to green.','Compatibility explanation precedes product choice, no new product selected.','Combining purchases remains unaccepted.'],
9:['Ada owns sampler and no-picture stripe choice.','Unconfirmed unknown owner candidate correctly explicit.','Bo confirms owner and adoption of tactile key.','Checkerboard replaces stripes while no-pictures retained.','Portability belongs to Bo’s key, not Ada’s sampler.'],
10:['Policy task and absolute quiet-hours interval captured.','Before-noon conditional reminder timing preserves fallback.','Special rule cancelled, quiet hours remain.','Original rule restored; no exception to already absolute quiet hours.','Timezone explanation added without deciding behavior.']}

def review(split,notes,issues):
 source=P/f'data/source/{split}.jsonl';digest=sha(source)
 fs=[json.loads(l) for l in source.read_text(encoding='utf-8').splitlines() if l]
 assert len(fs)==len(notes)
 archive=HERE/f'{split}-source-reviewed.jsonl';archive.write_bytes(source.read_bytes())
 results=[]
 for n,f in enumerate(fs,1):
  assert f['family_id']==f'{split}-{n:03d}';ds=[]
  with IntentStore(':memory:') as st:
   for k,d in enumerate(f['decisions'],1):
    st.observe([e for e in f['events'] if e['seq']<=d['through_seq']]);b=st.snapshot();a=st.commit_patch(f'setup-{k}',b['version'],d['through_seq'],d['operations'])
    bb={i['intent_id']:i for i in b['intents']};aa={i['intent_id']:i for i in a['intents']}
    assert all(bb[i]==aa[i] for i in d['preserve_ids'])
    issue=issues.get((n,k))
    ds.append({'decision_index':k,'through_seq':d['through_seq'],'verdict':'requires_correction' if issue else 'accepted','semantic_check':notes[n][k-1],'issue':issue,'checks':{'arrived_evidence_and_runtime_transition':'passed','record_preservation':'passed','independent_semantics':'correction_required' if issue else 'accepted'},'pre_state_projection':[{key:i[key] for key in ('intent_id','owner','text','status')} for i in b['intents']],'post_state_projection':[{key:i[key] for key in ('intent_id','owner','text','status')} for i in a['intents']]})
  results.append({'family_id':f['family_id'],'canonical_family_sha256':canon(f),'verdict':'requires_correction' if any(d['issue'] for d in ds) else 'accepted','decisions':ds})
 assert sha(source)==digest
 report={'id':f'{split}-independent-model-semantic-review','date':'2026-10-24','timezone':'America/Halifax','created_at_utc':datetime.now(timezone.utc).isoformat(),'reviewer':'tracker_annotation_v2, not this split author','kind':'independent_model_review_not_human_review','human_review_performed':False,'source_modified':False,'source_sha256':digest,'snapshot_path':archive.relative_to(P).as_posix(),'annotation_guide_sha256':sha(P/'annotation/ANNOTATION_GUIDE.md'),'status':'corrections_required' if issues else 'accepted','summary':{'families_reviewed':len(fs),'decisions_reviewed':len(fs)*5,'accepted_decisions':len(fs)*5-len(issues),'decisions_requiring_correction':len(issues),'runtime_replay_passed_decisions':len(fs)*5},'families':results,'limits':['This reviewer read annotation inputs/targets and replayed states only; no model baseline or adapter evaluation output was consulted.','Model review is not human annotation.','Normal trajectories only; deliberate fault variants need separate review.']}
 (HERE/f'{split}-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(report['summary']))

DEV_ISSUES={
(1,4):{'rule':'atomic_independent_constraints','reason':'Explanation and temporary no-sleeve-cap change have different lifetimes. Split them so later cancellation of explanation does not remove the boundary.','proposed_operations':[{'op':'add','intent_id':'i4','owner':'苏','text':'解释袖山不能同比缩短的原因','source_seqs':[3],'status':'active'},{'op':'add','intent_id':'i5','owner':'苏','text':'暂不修改夹克袖山','source_seqs':[3],'status':'active'}]},
(1,5):{'rule':'preserve_unaffected_scope','reason':'Seq 4 cancels only explanation; retain temporary sleeve-cap boundary.','proposed_operations':[{'op':'withdraw','intent_id':'i4','source_seqs':[4]}],'required_preserve_ids':['i1','i2','i3','i5']},
(7,3):{'rule':'preserve_frequency','reason':'Cumulative versus daily-consumption value is revised, but original daily reading frequency is not cancelled.','proposed_operations':[{'op':'update','intent_id':'i2','source_seqs':[2],'text':'Record daily cumulative electricity meter readings in kilowatt-hours'}]},
(7,4):{'rule':'NEGATIVE-1','reason':'Do not estimate one is a persistent new prohibition separate from abandoning an unconfirmed column.','proposed_operations':[{'op':'withdraw','intent_id':'i3','source_seqs':[4]},{'op':'add','intent_id':'i5','owner':'Esme','text':'Do not estimate an individual-appliance electricity breakdown','source_seqs':[3,4],'status':'active'}],'downstream_change':'Keep existing future date-field ID i4; final decision preserve_ids must include i5.'}}

TEST_NOTES={
1:['Regular-script pages and one tracing model per character captured.','Three copying spaces are explicitly per character.','Tracing replaced by view-only model; blank spaces preserved.','Running-script suggestion remains unaccepted.','Copying-versus-recall explanation requested without changing exercise.'],
2:['Oolong record and per-infusion seconds supported.','A-Tang’s aroma feeling remains subjective and independently owned.','Temperature field is uncertain.','Thermometer arrival plus explicit adoption confirms Celsius temperature column.','Only subjective attribute changes from aroma to mouthfeel; attribution and subjective status remain.'],
3:['Archiving plan and filename invariance captured.','Shortcut exception and other-file archive branch both preserved.','Date-prefix proposal rejected, existing invariance restated.','All files now included; plan-only/no-real-moving boundary added.','Separate preexecution checklist is new.'],
4:['Morning process, departure deadline and ten-minute packing captured.','Morning packing withdrawn and evening replacement added.','Deadline moves to before 7:45; other arrangements stay.','Original morning block restored and evening replacement withdrawn; lunch proposal unaccepted.','Trial acknowledgement adds no new change.'],
5:['Four-person original scaled to two, texture guidance preserved.','Separate two-person dip and no-garlic constraint captured.','Soup alone changes to three portions, original base remains four.','Entire dip branch and garlic constraint withdrawn; soup remains.','Seasoning-scaling explanation requested without altering the recipe.'],
6:['Pool-bag checklist and no-glass restriction captured.','Unattributed large-print candidate explicitly uncertain.','Global replacement suggestion unaccepted while candidate unresolved.','Qin confirms separate large-print version, not replacement of ordinary version.','Material comparison requested without selecting either.'],
7:['Catalog, separate editions and artist sorting supported.','Unchecked condition stays unknown, no guessed grading.','Friend’s merged-edition quote explicitly unaccepted.','Only ordering changes to release year; edition distinction retained.','Two missing-year sorting options requested without selection.'],
8:['Pear-tree observation-only template, no pruning/fertilizing supported.','Both flower and no-flower branches of settled condition retained.','User adds photo candidate, fertilizing remains unaccepted.','Photo column adopted with at-most-one limit per observation.','Scope expands to apple and pear while keeping per-tree records separate.'],
9:['Beginner recursion explanation, directory example and no executable code supported.','Call hierarchy diagram added.','Recursion-versus-loop choice explanation defers performance testing.','Audience now has loop knowledge; directory example preserved.','Diagram alone withdrawn, both explanations and no-code boundary remain.'],
10:['Echo-reduction planning and no wall drilling supported.','Yu separately owns clear yoga space by the window.','Thick rug remains a candidate.','Rug withdrawn; other owner’s space preserved.','Curtain versus freestanding-screen comparison requested without choosing.'],
11:['Arbitrary code choice must be explicit, not merely coded labels with addresses excluded.','Letters and separate code-to-door map added independently.','Address suggestion rejected, existing prohibition reaffirmed.','Two-digit numbers replace letters; mapping remains separate.','Key-blank differentiation question retains address exclusion.'],
12:['Chore list and Gus’s Monday recycling supported.','Vera owns Thursday kitchen task with Monday exclusion.','Gus alone moves recycling to Tuesday.','Fridge copy added; Vera’s reaffirmation makes no change.','Only fridge copy cancelled.'],
13:['Journal and definite missing-memory blank rule captured.','Mood field remains tentative.','Mood candidate rejected; distinct date field added.','Unrequested interpretation suggestion not adopted.','Memory-versus-reflection explanation requested without adding a field.'],
14:['Contact log, UTC and exact received reports supported.','Operating band added.','Bad sample quote does not permit rounding.','Local time and offset added alongside UTC, not replacing it.','Abbreviation question does not select shorthand.'],
15:['Decorative craft-cord scope expressly excludes load-bearing application.','Numbered square-knot diagram added.','Only diagram removed for first draft.','Original diagram restored; climbing proposal rejected under existing scope.','Line-style distinguishability added without assuming a color ban.'],
16:['Manual-based quick card and unplug-before-cleaning retained from explicit user words.','Separate uneven-stitch troubleshooting panel added.','No prior control-name record exists, so stated correction is added rather than update unknown ID.','Troubleshooting panel withdrawn, card and unplugging unchanged.','Comparison question does not authorize creating maintenance schedule.'],
17:['Rock catalog, existing specimen identifiers and no guessing captured.','Unattributed photo candidate states both uncertainties.','Assistant mineral guess does not establish a name or alter current no-guess rule.','Lena resolves owner and adoption of photo column.','Identifier explanation requested before any change.'],
18:['Tab plan and pinned-tab exclusion supported.','Project grouping and projectless fallback branch captured.','Explicit new no-auto-close prohibition recorded.','Fallback label renamed without changing grouping predicate.','Saving-content explanation requested with no saving yet.'],
19:['Same indoor scene and fixed camera position are distinct held conditions.','Both initial shutter speeds and ISO400 captured.','Outdoor suggestion remains unaccepted.','Only 1/60 replaced by 1/125; 1/30 and ISO400 remain.','Motion-blur field added without presupposing a winning condition.'],
20:['Weather diary and explicit missing-not-carry-forward convention supported.','Daily noon observation and separate sketch space added.','Only sketch space withdrawn.','Two daily observation times replace one noon time; missing rule retained.','Exact original sketch space restored with same ID.']}
TEST_ISSUES={(11,1):{'rule':'preserve_code_semantics','reason':'Use arbitrary codes is an explicit criterion; coded labels plus address exclusion alone does not preserve arbitrary-code choice.','proposed_operations':[{'op':'add','intent_id':'i1','owner':'Mae','text':'Design spare-key labels using arbitrary codes','source_seqs':[0],'status':'active'},{'op':'add','intent_id':'i2','owner':'Mae','text':'Never put street addresses on spare-key labels','source_seqs':[0],'status':'active'}]}}

if __name__=='__main__':
 if len(sys.argv)>1 and sys.argv[1]=='test':review('test',TEST_NOTES,TEST_ISSUES)
 else:review('dev',DEV_NOTES,DEV_ISSUES)
