"""Original synthetic development/test conversations, never training rows.
Each scenario is authored individually; helpers only serialize operations.
No model inference, selection, or evaluation is performed here.
"""
import json, sys
from pathlib import Path
P=Path(__file__).resolve().parents[2]
ROOT=P.parents[3]
sys.path.insert(0,str(ROOT/'experiments/deep_conversation'))
from intention_state import IntentStore
def A(i,o,t,s,status='active'):return dict(op='add',intent_id=f'i{i}',owner=o,text=t,source_seqs=s,status=status)
def U(i,s,**kw):return dict(op='update',intent_id=f'i{i}',source_seqs=s,**kw)
def W(i,s):return dict(op='withdraw',intent_id=f'i{i}',source_seqs=s)
def R(i,s):return dict(op='reopen',intent_id=f'i{i}',source_seqs=s)
def D(s,ops,note,checks):return dict(through_seq=s,operations=ops,evidence_note=note,critical_checks=checks)
FS=[]
def F(split,n,lang,domain,scenario,tags,events,ds):
 known=set()
 for d in ds:
  touched={o['intent_id'] for o in d['operations']}
  d['preserve_ids']=sorted(known-touched,key=lambda s:int(s[1:]))
  known.update(o['intent_id'] for o in d['operations'] if o['op']=='add')
 FS.append(dict(family_id=f'{split}-{n:03}',split=split,language=lang,domain=domain,scenario=scenario,tags=tags,
  provenance='fictional_model_authored_heldout_family_not_real_user_log',
  events=[dict(seq=i,speaker=o,role=r,text=t) for i,(o,r,t) in enumerate(events)],decisions=ds))

F('dev',1,'zh','sewing pattern alteration','A jacket pattern changes sleeve length while preserving a reversible fitting approach',
 ['retention','local_revision','new_question','withdrawal'],[
 ('苏','user','帮我写夹克纸样的修改说明，先改袖长，所有试缝都用可拆的大针脚。'),
 ('苏','user','袖长缩短两厘米。'),
 ('苏','user','量错了，应该缩短一厘米，试缝方式不变。'),
 ('苏','user','顺便解释为什么袖山不能按同样比例缩短，先别改袖山。'),
 ('苏','user','袖山原理我自己查到了，那个解释不用写了，袖长说明继续。')],[
 D(0,[A(1,'苏','编写夹克纸样袖长修改说明',[0]),A(2,'苏','试缝使用可拆的大针脚',[0])],'The alteration target and reversible fitting method are distinct.',['Do not infer a sleeve-length amount yet.']),
 D(1,[A(3,'苏','夹克袖长缩短两厘米',[1])],'A concrete alteration amount is supplied.',['Keep centimetres and shortening direction.']),
 D(2,[U(3,[2],text='夹克袖长缩短一厘米')],'The measured amount is corrected without changing the fitting method.',['Do not retain two centimetres.']),
 D(3,[A(4,'苏','解释袖山不能同比缩短的原因，暂不修改袖山',[3])],'A new explanation is requested with no cap alteration authorized.',['Do not label the question no change.']),
 D(4,[W(4,[4])],'Only the explanation is cancelled.',['Retain sleeve-shortening instructions and removable stitching.'])])

F('dev',2,'zh','mathematics tutoring','Learner changes when hints are shown without turning an example into a solution request',
 ['local_revision','unaccepted_proposal','retention','no_change'],[
 ('陶','user','陪我练二次方程，先让我自己做，答错后再给提示。'),
 ('助手','assistant','也可以每题开始前直接展示解法。'),
 ('陶','user','不采用那个办法。每次只出一道题。'),
 ('陶','user','我想先练能因式分解的题，暂时不练求根公式。'),
 ('陶','user','提示时机改一下：我主动说卡住时再提示，不要一答错就提示。'),
 ('陶','user','好，就这些规则。')],[
 D(0,[A(1,'陶','练习二次方程',[0]),A(2,'陶','先让陶独立作答，答错后再提示',[0])],'Topic and hint timing are independent.',['Do not supply all solutions upfront.']),
 D(2,[A(3,'陶','二次方程练习每次只出一道题',[2])],'The user adds pacing and rejects pre-displayed solutions.',['Keep independent attempt before hints.']),
 D(3,[U(1,[3],text='练习可因式分解的二次方程，暂不练求根公式')],'The exercise scope narrows.',['Do not change one-question pacing.']),
 D(4,[U(2,[4],text='先让陶独立作答，仅在其主动表示卡住时提示')],'Explicit request replaces incorrect-answer-triggered hints.',['Do not treat every wrong answer as a hint request.']),
 D(5,[],'The final acknowledgement repeats the existing rules.',['Preserve all three records.'])])

F('dev',3,'zh','email inbox triage','User changes a label rule while preserving the manual deletion boundary',
 ['conditional','combined_change','retention','new_question'],[
 ('雯','user','给我设计邮件整理规则，只打标签，不自动删除邮件。'),
 ('雯','user','主题含“收据”的邮件打上报销标签；其他邮件别套这个规则。'),
 ('雯','user','再解释一下归档和删除有什么区别，先不要增加归档动作。'),
 ('助手','assistant','我建议把收据邮件自动归档。'),
 ('雯','user','那条建议我没同意。标签名称改成凭证，匹配条件仍是主题含“收据”。'),
 ('雯','user','除了标签还要给匹配邮件加星标，但仍不要删或归档。')],[
 D(0,[A(1,'雯','设计邮件整理规则',[0]),A(2,'雯','邮件规则仅打标签，不自动删除邮件',[0])],'The initial action boundary is tags only.',['Do not add execution authorization for deletion.']),
 D(1,[A(3,'雯','仅给主题含“收据”的邮件打报销标签',[1])],'This is an active conditional label rule.',['Preserve matching scope.']),
 D(2,[A(4,'雯','解释归档与删除的区别，暂不添加归档动作',[2])],'The question is a separate need with a no-change boundary.',['Do not silently archive.']),
 D(4,[U(3,[4],text='仅给主题含“收据”的邮件打凭证标签')],'Only the label name changes; the assistant archive proposal is unaccepted.',['Keep the subject-match condition.']),
 D(5,[U(2,[5],text='邮件规则允许打标签和加星标，不自动删除或归档邮件'),A(5,'雯','给主题含“收据”的匹配邮件加星标',[1,5])],'Adding stars requires revising tags-only and recording the star rule.',['Do not leave an incompatible tags-only constraint active.','The matched-mail reference uses the earlier condition.'])])

F('dev',4,'zh','password vault migration planning','An export task is cancelled and restored without authorizing cloud upload',
 ['withdrawal','reopen','retention','new_question'],[
 ('纪','user','帮我写密码库迁移步骤，只用本地文件，不上传云端。先包含导出旧库这一项。'),
 ('纪','user','导出步骤先去掉，我以为已经有备份。'),
 ('助手','assistant','可以上传一个样本到在线转换器。'),
 ('纪','user','不，仍然只能本地处理。'),
 ('纪','user','备份找不到了，把原来的导出旧库步骤恢复。'),
 ('纪','user','另外用通俗话解释加密备份和普通 CSV 导出的区别，暂不替我选。')],[
 D(0,[A(1,'纪','编写密码库迁移步骤',[0]),A(2,'纪','迁移仅用本地文件，不上传云端',[0]),A(3,'纪','迁移步骤包含导出旧密码库',[0])],'Planning, locality and export step are distinct.',['No actual secret access or upload is requested.']),
 D(1,[W(3,[1])],'Only the export step is removed.',['Keep the migration plan and local-only boundary.']),
 D(3,[],'The online suggestion is rejected by restating local-only.',['Do not authorize a sample upload.']),
 D(4,[R(3,[4])],'The original export step is restored.',['Use the same ID; do not pick an export format.']),
 D(5,[A(4,'纪','通俗比较加密备份与普通 CSV 导出，暂不代选',[5])],'This is an information request, not a selected export method.',['Keep the local-only boundary.'])])

F('dev',5,'zh','electronics breadboard documentation','A wiring diagram changes notation while retaining its non-execution scope',
 ['acceptance','local_revision','retention','quotation'],[
 ('任','user','为这个教学面包板画接线示意图，只做文档，不控制任何设备。'),
 ('助手','assistant','导线可以用颜色区分并加文字标签。'),
 ('任','user','采用你说的颜色加文字标签。'),
 ('任','user','图注里出现“接通电源”只是步骤说明，不是让我现在通电。'),
 ('任','user','打印机只能黑白，导线改成不同线型，文字标签保留。'),
 ('任','user','再附一张符号对照表。')],[
 D(0,[A(1,'任','绘制教学面包板接线示意图',[0]),A(2,'任','仅制作接线文档，不控制设备',[0])],'The drawing task has an explicit non-execution boundary.',['Do not infer permission to energize hardware.']),
 D(2,[A(3,'任','用颜色区分示意图导线',[1,2]),A(4,'任','为示意图导线添加文字标签',[1,2])],'The user accepts two separable parts of the notation proposal.',['Capture proposal and acceptance.']),
 D(3,[],'Quoted procedure wording is explicitly not a live hardware instruction.',['Keep document-only scope.']),
 D(4,[U(3,[4],text='用不同线型区分示意图导线')],'Line styles replace color coding while text labels persist.',['Do not drop text labels.']),
 D(5,[A(5,'任','附接线示意图符号对照表',[5])],'A separate legend is requested.',['Do not interpret it as device configuration.'])])

F('dev',6,'en','mechanical keyboard remapping','A shortcut policy separates a temporary layer from the permanent key map',
 ['multi_task','local_revision','retention','no_change'],[
 ('Luca','user','Draft a keyboard remapping plan. Keep the number row unchanged.'),
 ('Luca','user','Put media controls on a temporary Fn layer, not on the base layer.'),
 ('Assistant','assistant','The number row could become function keys by default.'),
 ('Luca','user','That would break my original condition; leave it as agreed.'),
 ('Luca','user','Change the temporary layer trigger from Fn to holding Caps Lock. Media controls stay temporary.'),
 ('Luca','user','Give me a separate printable key legend as well.')],[
 D(0,[A(1,'Luca','Draft a keyboard remapping plan',[0]),A(2,'Luca','Keep the keyboard number row unchanged',[0])],'The plan and number-row invariant are separate.',['Do not execute remapping.']),
 D(1,[A(3,'Luca','Place media controls only on a temporary Fn layer, not the base layer',[1])],'Trigger and temporary placement define this layer policy.',['Do not overwrite base-layer number keys.']),
 D(3,[],'The proposed number-row replacement is rejected.',['Preserve all existing requirements.']),
 D(4,[U(3,[4],text='Place media controls only on a temporary layer activated by holding Caps Lock, not the base layer')],'Only the temporary trigger changes.',['Retain hold behavior and temporary scope.']),
 D(5,[A(4,'Luca','Provide a separate printable keyboard key legend',[5])],'A second artifact is explicitly requested.',['Keep remapping constraints.'])])

F('dev',7,'en','home energy notebook','Resident distinguishes a tentative appliance field from an adopted measurement unit',
 ['uncertainty_resolution','local_revision','retention'],[
 ('Esme','user','Design a home electricity notebook with daily readings in kilowatt-hours.'),
 ('Esme','user','I might want a column for individual appliances, but I am not sure I can measure them.'),
 ('Esme','user','Actually the meter provides cumulative readings, not daily consumption. Record those and keep the unit.'),
 ('Assistant','assistant','A guessed appliance breakdown could fill the extra column.'),
 ('Esme','user','No appliance column after all. Do not estimate one.'),
 ('Esme','user','Add a field for the date of each meter reading.')],[
 D(0,[A(1,'Esme','Design a home electricity notebook',[0]),A(2,'Esme','Record daily electricity readings in kilowatt-hours',[0])],'The measured quantity and unit are explicit.',['Do not confuse energy with instantaneous watts.']),
 D(1,[A(3,'Esme','An individual-appliance measurement column may be needed; adoption is undecided',[1],status='uncertain')],'A concrete optional candidate is not adopted.',['Do not assume appliance measurements exist.']),
 D(2,[U(2,[2],text='Record cumulative electricity meter readings in kilowatt-hours')],'Cumulative readings replace daily consumption while the unit persists.',['Retain kilowatt-hours.']),
 D(4,[W(3,[4])],'The user rejects the appliance field; an assistant guess cannot justify keeping it.',['Do not invent appliance estimates.']),
 D(5,[A(4,'Esme','Include the date of each electricity meter reading',[5])],'Reading date is a separate required field.',['Do not revert to daily consumption values.'])])

F('dev',8,'en','fountain pen selection','Two writers maintain their own ink requirements while asking a shared compatibility question',
 ['multi_owner','retention','new_question','local_revision'],[
 ('Nell','user','Help me choose fountain-pen ink for my journal. Mine must be blue.'),
 ('Arun','user','I need a separate bottle for sketching; mine must be waterproof.'),
 ('Nell','user','Change my color to green. Do not alter Arun’s choice.'),
 ('Arun','user','Explain whether waterproof ink can be used in every fountain pen before selecting a product for me.'),
 ('Assistant','assistant','Both of you could choose the same green ink.'),
 ('Nell','user','I have not agreed to combining the purchases.')],[
 D(0,[A(1,'Nell','Help select fountain-pen ink for Nell’s journal',[0]),A(2,'Nell','Nell’s journal ink must be blue',[0])],'The journal selection and color belong to Nell.',['Do not infer waterproofing.']),
 D(1,[A(3,'Arun','Select a separate waterproof ink bottle for Arun’s sketching',[1])],'Arun’s different purpose and requirement must remain separately owned.',['Do not impose blue on Arun.']),
 D(2,[U(2,[2],text='Nell’s journal ink must be green')],'Only Nell’s color changes.',['Keep Arun’s separate waterproof request.']),
 D(3,[A(4,'Arun','Explain waterproof-ink compatibility with fountain pens before selecting Arun’s product',[3])],'A compatibility question is new and does not withdraw waterproofing.',['Do not choose a product from the question alone.']),
 D(5,[],'The assistant shared-purchase idea remains unaccepted.',['Keep both owner scopes and separate purchase.'])])

F('dev',9,'en','hand weaving sampler','Learner resolves an unattributed request and keeps their own motif constraint',
 ['unresolved_owner','uncertainty_resolution','retention','combined_change'],[
 ('Ada','user','Plan a hand-weaving sampler for me using stripes, not pictures.'),
 ('Ada','user','Someone in the group may need a tactile key to the patterns. I cannot identify who, and they have not confirmed it.'),
 ('Bo','user','That was my note. I do need the tactile key.'),
 ('Ada','user','For my sampler, replace the stripes with checkerboard blocks. Bo’s key stays separate.'),
 ('Bo','user','Make my key portable enough to keep beside the loom.')],[
 D(0,[A(1,'Ada','Plan Ada’s hand-weaving sampler',[0]),A(2,'Ada','Use stripes rather than pictures in Ada’s sampler',[0])],'The initial motif is distinct from the sampler task.',['Do not invent a weaving machine task.']),
 D(1,[A(3,'__unresolved__','A tactile pattern key may be needed; requester and adoption are unconfirmed',[1],status='uncertain')],'Both owner and need remain unresolved.',['Do not assign the note to Ada.']),
 D(2,[U(3,[2],owner='Bo',text='Provide Bo a tactile key to weaving patterns',status='active')],'Bo confirms ownership and adoption of the same candidate.',['Do not create a duplicate key.']),
 D(3,[U(2,[3],text='Use checkerboard blocks rather than pictures in Ada’s sampler')],'The stripe choice changes but the original no-pictures boundary remains.',['Do not change Bo’s key.']),
 D(4,[A(4,'Bo','Make Bo’s tactile pattern key portable for use beside the loom',[4])],'Portability is Bo’s separate constraint.',['Keep Ada’s checkerboard choice.'])])

F('dev',10,'en','calendar notification policy','Quiet hours survive a reminder cancellation and explicit restoration',
 ['conditional','withdrawal','reopen','retention'],[
 ('Finn','user','Write a calendar reminder policy for me. Never send reminders during my quiet hours, 9 pm to 7 am.'),
 ('Finn','user','For appointments before noon, remind me the previous evening if that is outside quiet hours; otherwise use the last allowed time.'),
 ('Finn','user','Remove the special before-noon rule for now.'),
 ('Assistant','assistant','I can ignore quiet hours for important appointments.'),
 ('Finn','user','No exceptions to quiet hours. Restore the before-noon rule exactly as I gave it.'),
 ('Finn','user','Explain what should happen when I change time zones; do not decide that policy yet.')],[
 D(0,[A(1,'Finn','Write Finn’s calendar reminder policy',[0]),A(2,'Finn','Never send reminders during quiet hours from 9 pm to 7 am',[0])],'The quiet-hours window is exact and cross-midnight.',['Do not reverse the time interval.']),
 D(1,[A(3,'Finn','For appointments before noon, remind the previous evening outside quiet hours, otherwise at the last allowed time',[1])],'This is an adopted conditional reminder rule.',['Do not label conditional adoption uncertain.']),
 D(2,[W(3,[2])],'Only the special appointment rule is removed.',['Keep quiet hours.']),
 D(4,[R(3,[4])],'The user restores the same rule and rejects exceptions to quiet hours.',['Do not add an important-appointment override.']),
 D(5,[A(4,'Finn','Explain timezone-change options for reminders without choosing a policy',[5])],'A new explanation is requested without a selected timezone rule.',['Do not silently reinterpret quiet hours.'])])

F('test',1,'zh','calligraphy practice sheets','Practice sheets distinguish tracing from copying and preserve a specified script style',
 ['local_revision','retention','new_question','no_change'],[
 ('墨','user','给我做楷书练习页，每个字先给一个可描红的范字。'),
 ('墨','user','范字旁留三个空格让我临写。'),
 ('墨','user','描红去掉，换成只看不能描的范字；临写空格不动。'),
 ('助手','assistant','行书可能更有趣。'),
 ('墨','user','我暂时没有换字体的意思。'),
 ('墨','user','解释一下临写和默写的区别，先别把练习改成默写。')],[
 D(0,[A(1,'墨','制作楷书练习页',[0]),A(2,'墨','每字提供一个可描红范字',[0])],'Script and exemplar mode are separate.',['Do not choose cursive style.']),
 D(1,[A(3,'墨','每字范字旁留三个临写空格',[1])],'Three practice cells are independently required.',['Keep exact cell count.']),
 D(2,[U(2,[2],text='每字提供一个仅供观看、不可描红的范字')],'Exemplar mode changes without removing copying cells.',['Preserve regular script and three cells.']),
 D(4,[],'A suggested script change is explicitly unaccepted.',['Keep 楷书.']),
 D(5,[A(4,'墨','解释临写与默写的区别，暂不改为默写练习',[5])],'The comparison is an information need.',['Do not replace the existing exercise.'])])

F('test',2,'zh','tea brewing journal','A tea tasting record keeps per-person preferences separate from measured quantities',
 ['multi_owner','local_revision','uncertainty_resolution'],[
 ('乔木','user','帮我做乌龙茶冲泡记录，我要记录每泡的浸泡秒数。'),
 ('阿棠','user','我还想有一栏写自己的香气感受，别把我的感受写成客观测量。'),
 ('乔木','user','我可能也要记水温，但温度计还没到，先作为待定栏。'),
 ('乔木','user','温度计到了，水温栏确定要，用摄氏度。'),
 ('阿棠','user','我的栏目改成口感感受，不写香气了；主观描述这一点继续保留。')],[
 D(0,[A(1,'乔木','制作乌龙茶冲泡记录',[0]),A(2,'乔木','记录每泡浸泡时长，单位秒',[0])],'Task and measured duration are distinct.',['Do not infer brewing recommendations.']),
 D(1,[A(3,'阿棠','记录阿棠个人香气感受，并标明是主观描述而非客观测量',[1])],'Personal qualitative observations belong to 阿棠.',['Do not assign subjective impressions to 乔木.']),
 D(2,[A(4,'乔木','冲泡记录可能增加水温栏，是否采用待定',[2],status='uncertain')],'The concrete temperature field is undecided.',['Do not invent values or a unit yet.']),
 D(3,[U(4,[3],text='冲泡记录包含摄氏水温栏',status='active')],'The field is adopted with an explicit Celsius unit.',['Do not use Fahrenheit.']),
 D(4,[U(3,[4],text='记录阿棠个人口感感受，并标明是主观描述而非客观测量')],'The sensory dimension changes; ownership and subjectivity remain.',['Keep measured seconds and Celsius separate.'])])

F('test',3,'zh','desktop file archiving','A temporary shortcut rule is removed without discarding a filename invariant',
 ['conditional','withdrawal','retention','combined_change'],[
 ('柯','user','给我写桌面文件归档方案，原文件名都别改。'),
 ('柯','user','如果是快捷方式就留在桌面；其他文件移进归档目录。'),
 ('助手','assistant','文件名统一加日期会更整齐。'),
 ('柯','user','不要加日期，按原名字来。'),
 ('柯','user','快捷方式也不例外了，所有文件都进归档目录；只做方案，不真的移动。'),
 ('柯','user','再列出执行前应该核对的项目，单独给我一份检查单。')],[
 D(0,[A(1,'柯','编写桌面文件归档方案',[0]),A(2,'柯','保持所有原文件名不变',[0])],'Planning does not itself authorize actual file moves.',['Keep original names.']),
 D(1,[A(3,'柯','快捷方式留在桌面，其余文件移入归档目录',[1])],'The adopted classification rule is conditional, not uncertain.',['Keep both branches.']),
 D(3,[],'The user repeats the filename invariant and rejects date prefixes.',['Do not add renaming.']),
 D(4,[U(3,[4],text='所有桌面文件均纳入归档目录，包括快捷方式'),A(4,'柯','只提供归档方案，不实际移动文件',[4])],'The exception is removed and an explicit non-execution boundary is added.',['Do not keep shortcuts exempt.']),
 D(5,[A(5,'柯','另附归档执行前核对项目检查单',[5])],'A separate checklist is requested.',['Do not mistake checking plans for moving files.'])])

F('test',4,'zh','personal morning routine','A user restores a small routine component after a separate timing revision',
 ['withdrawal','reopen','retention','local_revision'],[
 ('遥辰','user','帮我排一个早晨出门流程，八点前要出门，流程里留十分钟收拾书包。'),
 ('遥辰','user','书包改成前一晚收，早晨那十分钟取消。'),
 ('遥辰','user','出门截止改为七点四十五，其他安排继续。'),
 ('助手','assistant','可以早晨同时准备午餐。'),
 ('遥辰','user','那个建议先不采纳。书包还是早晨收吧，恢复原来十分钟那项。'),
 ('遥辰','user','好，就先按这个试。')],[
 D(0,[A(1,'遥辰','安排早晨出门流程',[0]),A(2,'遥辰','早晨八点前出门',[0]),A(3,'遥辰','早晨流程留十分钟收拾书包',[0])],'The deadline and packing block can change independently.',['Do not equate leaving time with waking time.']),
 D(1,[W(3,[1]),A(4,'遥辰','前一晚收拾书包',[1])],'The morning block is cancelled and replaced with an evening task.',['Do not keep both packing slots active.']),
 D(2,[U(2,[2],text='早晨七点四十五前出门')],'Only the deadline changes.',['Keep evening packing for now.']),
 D(4,[R(3,[4]),W(4,[4])],'Returning packing to the original morning slot restores i3 and supersedes the evening alternative.',['Do not add lunch preparation.','Keep the earlier revised deadline.']),
 D(5,[],'Acknowledgement changes no requirements.',['Retain ten-minute packing and seven-forty-five deadline.'])])

F('test',5,'zh','recipe quantity scaling','A recipe conversion preserves texture guidance while a subrecipe is cancelled',
 ['multi_task','scope_cancellation','retention','local_revision'],[
 ('乐','user','把四人份南瓜汤配方换算成两人份，浓稠度说明保留。'),
 ('乐','user','另外把配套面包蘸酱也换成两人份，蘸酱不要蒜。'),
 ('乐','user','汤改成三人份，蘸酱仍是两人份。'),
 ('乐','user','蘸酱整个不做了，只要汤的换算。'),
 ('乐','user','再解释一下哪些调味量不适合机械按比例减，先不改我的汤配方。')],[
 D(0,[A(1,'乐','将四人份南瓜汤配方换算为两人份',[0]),A(2,'乐','保留南瓜汤浓稠度说明',[0])],'Scaling target and consistency guidance are distinct.',['Do not remove texture notes.']),
 D(1,[A(3,'乐','将配套面包蘸酱换算为两人份',[1]),A(4,'乐','面包蘸酱不加蒜',[1])],'A separate subrecipe has its own exclusion.',['Do not apply no-garlic to the soup without evidence.']),
 D(2,[U(1,[2],text='将四人份南瓜汤配方换算为三人份')],'Only soup servings change.',['Keep sauce at two servings.']),
 D(3,[W(3,[3]),W(4,[3])],'The whole sauce branch is cancelled including its garlic constraint.',['Keep the soup and texture guidance.']),
 D(4,[A(5,'乐','解释不宜机械按比例缩减的调味量，暂不更改汤配方',[4])],'The explanation request is separate from the settled soup conversion.',['Do not restore sauce or alter quantities automatically.'])])

F('test',6,'zh','swimming pool bag checklist','An uncertain accessibility-related aid is attributed after the checklist is otherwise unchanged',
 ['unresolved_owner','uncertainty_resolution','retention','new_question'],[
 ('赵禾','user','帮我们列游泳馆随身包清单，不要列玻璃容器。'),
 ('赵禾','user','群里有条未署名留言，说可能需要一张大字版清单，还没确认。先留为待确认。'),
 ('助手','assistant','我可以把普通清单全改成大字。'),
 ('赵禾','user','普通清单先不改，那条留言还没搞清楚。'),
 ('秦朵','user','留言是我的，我需要单独的大字版，普通版不用替换。'),
 ('秦朵','user','防水纸和覆膜有什么区别？先解释，不要替我选材料。')],[
 D(0,[A(1,'赵禾','列出游泳馆随身包清单',[0]),A(2,'赵禾','随身包清单不包含玻璃容器',[0])],'The pack list and container exclusion are settled.',['Do not infer an exercise prescription.']),
 D(1,[A(3,'__unresolved__','可能需要大字版随身包清单，归属和采用与否均未确认',[1],status='uncertain')],'The anonymous candidate is neither assigned nor activated.',['Do not assign it to the reporting speaker.']),
 D(3,[],'The user keeps the original version and uncertainty; the assistant cannot replace it.',['Do not activate i3.']),
 D(4,[U(3,[4],owner='秦朵',text='为秦朵另提供大字版随身包清单，不替换普通版',status='active')],'The requester resolves attribution and asks for an additional version.',['Retain the ordinary checklist and glass exclusion.']),
 D(5,[A(4,'秦朵','解释防水纸与覆膜的区别，暂不代选材料',[5])],'This question does not select a production material.',['Do not convert discussion into a material constraint.'])])

F('test',7,'zh','vinyl collection catalog','Collector keeps edition distinctions while revising a grouping method',
 ['local_revision','retention','quotation','new_question'],[
 ('闻溪','user','给我的唱片做目录，同一专辑不同版次分别记，先按艺人排序。'),
 ('闻溪','user','品相只记录我实际检查过的，没检查的写未知。'),
 ('闻溪','user','朋友说“同专辑留一条就够了”，我只是转述，并没有采用。'),
 ('闻溪','user','目录改按发行年份排序，不改版次分开的原则。'),
 ('闻溪','user','没找到发行年份时怎么排序比较合理？给两个办法，先不选。')],[
 D(0,[A(1,'闻溪','制作唱片收藏目录',[0]),A(2,'闻溪','同专辑的不同版次分别记录',[0]),A(3,'闻溪','唱片目录按艺人排序',[0])],'Edition identity and ordering are independently mutable.',['Do not deduplicate different editions.']),
 D(1,[A(4,'闻溪','只记录实际检查过的品相，未检查的标未知',[1])],'Missing inspection is not a positive condition rating.',['Do not invent a grade.']),
 D(2,[],'The friend’s merge suggestion is explicitly only a quotation.',['Keep separate editions.']),
 D(3,[U(3,[3],text='唱片目录按发行年份排序')],'The ordering key changes but edition and inspection constraints remain.',['Do not use purchase date instead.']),
 D(4,[A(5,'闻溪','提供两种缺发行年份唱片的排序办法，暂不代选',[4])],'A new options request leaves the missing-year policy undecided.',['Do not impose one of the unchosen rules.'])])

F('test',8,'zh','fruit tree phenology notebook','Observation notes separate a confirmed condition from a proposed intervention',
 ['conditional','retention','unaccepted_proposal','combined_change'],[
 ('应','user','给院里的梨树做物候观察记录模板，只记录观察，不安排修剪或施肥。'),
 ('应','user','如果开花了就记第一次见花日期；没开花就标未见花。'),
 ('助手','assistant','可以加上每周施肥计划。'),
 ('应','user','我没有要施肥计划。照片栏可能需要，先待定。'),
 ('应','user','照片栏确定要，每次最多放一张。'),
 ('应','user','把记录对象扩展到苹果树，梨树也保留，同一棵树的记录别混到另一棵。')],[
 D(0,[A(1,'应','制作梨树物候观察记录模板',[0]),A(2,'应','模板仅记录观察，不安排修剪或施肥',[0])],'This is an observation artifact with an explicit no-intervention boundary.',['Do not infer horticultural treatment.']),
 D(1,[A(3,'应','见花时记录首次见花日期，未开花时标未见花',[1])],'Both branches form an active observation rule.',['Do not label absence of bloom uncertain data.']),
 D(3,[A(4,'应','观察记录可能增加照片栏，采用与否待定',[3],status='uncertain')],'The user raises a concrete candidate while rejecting the intervention proposal.',['Do not add fertilization.']),
 D(4,[U(4,[4],text='观察记录包含照片栏，每次最多一张',status='active')],'The photo field is adopted with a per-observation limit.',['Do not change at most one to exactly one.']),
 D(5,[U(1,[5],text='制作梨树和苹果树的物候观察记录模板'),A(5,'应','不同树木的观察记录分别保存，不混合',[5])],'The scope expands rather than replaces the pear tree, and identity separation is added.',['Keep no-intervention, flower rule and photo cap.'])])

F('test',9,'zh','programming lesson explanation','A recursion explanation changes audience while keeping a deliberately deferred implementation',
 ['local_revision','new_question','withdrawal','retention'],[
 ('安白','user','给刚学编程的人解释递归，用树状目录做例子，不要写可运行代码。'),
 ('安白','user','加一张调用层次示意图。'),
 ('安白','user','再解释递归和循环怎么选，先不用展开性能测试。'),
 ('安白','user','读者其实学过循环了，调整解释面向这个基础；目录例子保留。'),
 ('安白','user','调用层次图先去掉，文字解释和那个选择问题都保留。')],[
 D(0,[A(1,'安白','向编程初学者解释递归',[0]),A(2,'安白','递归解释使用树状目录例子',[0]),A(3,'安白','递归说明不包含可运行代码',[0])],'Audience, example and output boundary are separate.',['Do not implement a directory walker.']),
 D(1,[A(4,'安白','添加递归调用层次示意图',[1])],'The visual aid is an additional deliverable component.',['Keep no runnable code.']),
 D(2,[A(5,'安白','解释如何选择递归或循环，暂不展开性能测试',[2])],'The comparison is a new question, not a request to benchmark.',['Do not drop it as no change.']),
 D(3,[U(1,[3],text='向已学过循环的编程学习者解释递归')],'Only audience assumptions change.',['Keep tree-directory example.']),
 D(4,[W(4,[4])],'Only the call-level diagram is removed.',['Retain the explanation, comparison question and code boundary.'])])

F('test',10,'zh','room acoustic treatment planning','Two household members preserve different constraints when a tentative rug is rejected',
 ['multi_owner','uncertainty_resolution','retention','new_question'],[
 ('明','user','帮我列书房减少回声的布置方案，不要在墙上钻孔。'),
 ('羽','user','我还要保留靠窗那块练瑜伽的空地，方案别占那里。'),
 ('明','user','厚地毯可能有用，但我还不确定要不要铺，先作为候选。'),
 ('明','user','地毯不要了，清理起来麻烦。羽要留的空地继续留。'),
 ('羽','user','窗帘和独立吸音屏各有什么取舍？请比较一下，先别替我们选。')],[
 D(0,[A(1,'明','列出书房减少回声的布置方案',[0]),A(2,'明','书房布置不在墙上钻孔',[0])],'The acoustic goal and mounting restriction are separate.',['Do not schedule construction.']),
 D(1,[A(3,'羽','书房靠窗的瑜伽空地保持空闲',[1])],'A second participant owns the space-use constraint.',['Do not attribute it to 明.']),
 D(2,[A(4,'明','书房可能铺厚地毯，采用与否未定',[2],status='uncertain')],'A concrete unadopted option is uncertain.',['Do not require a rug.']),
 D(3,[W(4,[3])],'Only the rug candidate is rejected.',['Keep the open area and no-drilling restriction.']),
 D(4,[A(5,'羽','比较窗帘与独立吸音屏的取舍，暂不代选',[4])],'The comparison does not select either furnishing.',['Keep ownership and existing restrictions.'])])

F('test',11,'en','spare key labeling','Resident replaces a code scheme while retaining separation from address information',
 ['local_revision','retention','new_question','no_change'],[
 ('Mae','user','Design labels for my spare keys. Use arbitrary codes, never street addresses.'),
 ('Mae','user','Use letters for the codes and keep the code-to-door list in a separate document.'),
 ('Assistant','assistant','Printing the address directly would be more convenient.'),
 ('Mae','user','I am not changing the no-address rule.'),
 ('Mae','user','Use two-digit numbers instead of letters; the mapping document stays separate.'),
 ('Mae','user','Explain how I could tell two identical-looking key blanks apart without adding an address.')],[
 D(0,[A(1,'Mae','Design coded labels for spare keys',[0]),A(2,'Mae','Never put street addresses on spare-key labels',[0])],'The code-label task has an address exclusion.',['Do not expose an address.']),
 D(1,[A(3,'Mae','Use letter codes on spare-key labels',[1]),A(4,'Mae','Keep the code-to-door mapping in a separate document',[1])],'Code representation and separation are independent.',['Do not print the mapping on the key.']),
 D(3,[],'The existing privacy rule is restated against an assistant proposal.',['No address exception is adopted.']),
 D(4,[U(3,[4],text='Use two-digit numeric codes on spare-key labels')],'Numbers replace letters while separate mapping remains.',['Keep two digits, not arbitrary-length numbers.']),
 D(5,[A(5,'Mae','Explain how to distinguish identical-looking key blanks without using addresses',[5])],'The new question is captured within the address boundary.',['Do not silently choose an identification method.'])])

F('test',12,'en','household chore allocation','Housemates alter only their own contributions and cancel a shared display artifact',
 ['multi_owner','multi_task','withdrawal','retention'],[
 ('Gus','user','Make a household chore list. Put me down for taking out recycling on Monday.'),
 ('Vera','user','I will clean the kitchen on Thursday, not Monday.'),
 ('Gus','user','Move my recycling job to Tuesday. Vera’s day stays hers.'),
 ('Gus','user','Also create a fridge copy of the chore list.'),
 ('Vera','user','I can still do Thursday.'),
 ('Gus','user','The fridge copy is no longer needed; keep the chore list itself.')],[
 D(0,[A(1,'Gus','Create a household chore list',[0]),A(2,'Gus','Assign Gus recycling removal on Monday',[0])],'The list and Gus’s assignment are distinct.',['Do not assign other people.']),
 D(1,[A(3,'Vera','Assign Vera kitchen cleaning on Thursday, not Monday',[1])],'Vera establishes her own task/day.',['Do not transfer Gus’s day to Vera.']),
 D(2,[U(2,[2],text='Assign Gus recycling removal on Tuesday')],'Only Gus’s day changes.',['Keep Vera Thursday.']),
 D(4,[A(4,'Gus','Create a fridge copy of the chore list',[3])],'A second output is requested; Vera’s repeated availability adds nothing.',['Do not duplicate Vera’s assignment.']),
 D(5,[W(4,[5])],'Only the fridge artifact is cancelled.',['Keep both chores and the underlying list.'])])

F('test',13,'en','dream journal template','Journal author distinguishes a tentative field from a definite conditional blank',
 ['conditional','uncertainty_resolution','retention','new_question'],[
 ('Rory','user','Make a dream-journal template. If I recall no dream, leave the narrative field blank rather than inventing a prompt answer.'),
 ('Rory','user','I may want a mood field, but I am undecided.'),
 ('Rory','user','No mood field. Include a date field instead.'),
 ('Assistant','assistant','A dream interpretation could be added automatically.'),
 ('Rory','user','I have not asked for interpretations.'),
 ('Rory','user','Explain the difference between recording a memory and later adding a reflection; do not add another field yet.')],[
 D(0,[A(1,'Rory','Create a dream-journal template',[0]),A(2,'Rory','When no dream is recalled, leave the narrative field blank instead of inventing content',[0])],'The blank-on-no-recall condition is settled.',['Do not interpret the absence of recall as a request for invented text.']),
 D(1,[A(3,'Rory','A mood field may be needed; adoption is undecided',[1],status='uncertain')],'A concrete field candidate is pending.',['Do not make it active.']),
 D(2,[W(3,[2]),A(4,'Rory','Include a date field in the dream journal',[2])],'The candidate is rejected while a different field is requested.',['Do not repurpose the mood ID as date.']),
 D(4,[],'Automatic interpretation is not accepted.',['Keep the blank rule and date field.']),
 D(5,[A(5,'Rory','Explain memory recording versus later reflection without adding a new journal field yet',[5])],'The new informational request does not change template fields.',['Do not diagnose or interpret dreams.'])])

F('test',14,'en','amateur radio contact log','Operator changes display timezone while retaining original signal reports',
 ['local_revision','retention','quotation','new_question'],[
 ('Kit','user','Make an amateur-radio contact log template with times shown in UTC. Keep received signal reports exactly as stated.'),
 ('Kit','user','Add a field for the operating band.'),
 ('Kit','user','A sample log says "round every report up"; I am quoting it as a bad example, not adopting it.'),
 ('Kit','user','Show local time as well as UTC, with the offset next to local time. Do not replace the UTC column.'),
 ('Kit','user','Explain why a time-zone abbreviation can be ambiguous before I choose any shorthand.')],[
 D(0,[A(1,'Kit','Create an amateur-radio contact log template',[0]),A(2,'Kit','Show contact times in UTC',[0]),A(3,'Kit','Preserve received signal reports exactly as stated',[0])],'UTC display and report fidelity are independent.',['Do not upgrade reported signal values.']),
 D(1,[A(4,'Kit','Include an operating-band field in the contact log',[1])],'Band is a new field.',['Do not infer a frequency allocation or operating permission.']),
 D(2,[],'The rounding instruction is explicitly a rejected quotation.',['Keep exact reports.']),
 D(3,[A(5,'Kit','Also show local contact time with its UTC offset beside it',[3])],'Local time supplements UTC rather than replacing it.',['Do not withdraw i2.']),
 D(4,[A(6,'Kit','Explain ambiguity of timezone abbreviations before choosing shorthand',[4])],'The question does not settle an abbreviation.',['Keep explicit offsets and UTC.'])])

F('test',15,'en','decorative knot practice','Learner cancels and restores a diagram without broadening a craft exercise into load-bearing advice',
 ['withdrawal','reopen','retention','combined_change'],[
 ('Alma','user','Write instructions for practicing decorative knots with craft cord. These are display samples, not load-bearing uses.'),
 ('Alma','user','Include a numbered step diagram for the square knot.'),
 ('Alma','user','Remove that diagram for the first draft; text is enough for now.'),
 ('Assistant','assistant','I could explain using the knot to secure climbing equipment.'),
 ('Alma','user','No, keep the decorative-only scope. Restore the original square-knot diagram.'),
 ('Alma','user','Make the cord paths in the diagram distinguishable by line style, not color alone.')],[
 D(0,[A(1,'Alma','Write craft-cord decorative-knot practice instructions',[0]),A(2,'Alma','Limit knot instructions to display samples, not load-bearing uses',[0])],'The decorative scope is explicit.',['Do not infer safety-rated application guidance.']),
 D(1,[A(3,'Alma','Include a numbered step diagram for the square knot',[1])],'A diagram is independently requested.',['Keep numbered steps.']),
 D(2,[W(3,[2])],'Only the diagram is temporarily removed.',['Retain text instructions and decorative boundary.']),
 D(4,[R(3,[4])],'The same diagram is restored and a load-bearing proposal rejected.',['Do not create climbing guidance.']),
 D(5,[A(4,'Alma','Distinguish cord paths by line style in the diagram, not color alone',[5])],'The visualization gains a non-color-only requirement.',['Do not erase the diagram numbering.'])])

F('test',16,'en','appliance quick-reference card','Owner revises a control name while retaining an explicit unplugging instruction',
 ['local_revision','retention','scope_cancellation','new_question'],[
 ('June','user','Draft a quick-reference card for my sewing machine from the supplied manual. Keep the manual’s instruction to unplug before cleaning.'),
 ('June','user','Add a separate troubleshooting panel for uneven stitches.'),
 ('June','user','In the card, call the control the stitch-length dial, not the tension dial; I mixed those names up.'),
 ('June','user','Drop the uneven-stitch troubleshooting panel entirely; the reference card still matters.'),
 ('June','user','Explain how a quick-reference card differs from a maintenance schedule. Do not create a schedule yet.')],[
 D(0,[A(1,'June','Draft a sewing-machine quick-reference card from the supplied manual',[0]),A(2,'June','Retain the manual’s unplug-before-cleaning instruction in the card',[0])],'The card is grounded in the supplied manual with a specific retained instruction.',['Do not invent a maintenance procedure.']),
 D(1,[A(3,'June','Add a separate troubleshooting panel for uneven stitches',[1])],'The panel is a distinct component.',['Keep the reference card.']),
 D(2,[A(4,'June','Refer to the specified control as the stitch-length dial, not the tension dial',[2])],'No previous control-name record exists; the explicit correction creates a naming requirement from arrived evidence.',['Do not invent an unseen prior mislabeled state.']),
 D(3,[W(3,[3])],'Only the panel is cancelled.',['Keep manual grounding, control name and unplugging instruction.']),
 D(4,[A(5,'June','Explain quick-reference card versus maintenance schedule without creating a schedule',[4])],'A comparison question is not a new schedule task.',['Do not withdraw the card.'])])

F('test',17,'en','rock specimen catalog','Collector resolves unknown attribution without treating an assistant identification as established',
 ['unresolved_owner','uncertainty_resolution','retention','new_question'],[
 ('Pax','user','Catalog our rock samples. Use the specimen numbers we already assigned, and do not guess mineral names.'),
 ('Pax','user','There is an unsigned note suggesting a magnified-photo column might be needed. We do not know whose request it is or whether it was agreed.'),
 ('Assistant','assistant','The shiny one is probably mica.'),
 ('Pax','user','That is a guess, not a confirmed identification. Keep the unknown names unknown.'),
 ('Lena','user','The note was mine. Please include a magnified-photo column.'),
 ('Lena','user','What is the difference between a specimen number and a catalog accession number? Explain before changing any identifiers.')],[
 D(0,[A(1,'Pax','Catalog the rock samples',[0]),A(2,'Pax','Keep the previously assigned specimen numbers',[0]),A(3,'Pax','Do not guess unidentified mineral names',[0])],'Identifiers and evidential restraint are separate.',['Do not convert visual guesses into labels.']),
 D(1,[A(4,'__unresolved__','A magnified-photo column may be needed; requester and adoption are unresolved',[1],status='uncertain')],'The unsigned note supplies a concrete candidate with two uncertainties.',['Do not assign it to Pax.']),
 D(3,[],'The assistant guess is explicitly unconfirmed; the existing no-guess rule is restated.',['Do not add a mica identification requirement.']),
 D(4,[U(4,[4],owner='Lena',text='Include a magnified-photo column in the rock catalog',status='active')],'Lena identifies and adopts the pending request.',['Keep the stable photo-column ID.']),
 D(5,[A(5,'Lena','Explain specimen numbers versus accession numbers before changing identifiers',[5])],'The question does not authorize renumbering.',['Preserve assigned specimen numbers.'])])

F('test',18,'en','browser session organization','Researcher separates tab grouping from a proposed automatic close action',
 ['retention','local_revision','conditional','new_question'],[
 ('Will','user','Plan how to organize my browser tabs. Keep pinned tabs outside the groups.'),
 ('Will','user','Group the others by project, and if a tab has no project put it in Unsorted.'),
 ('Assistant','assistant','I can close all tabs in Unsorted at the end of the day.'),
 ('Will','user','No automatic closing. The group is for review, not disposal.'),
 ('Will','user','Rename Unsorted to To review. The grouping rule stays project-based.'),
 ('Will','user','Explain whether saving a tab group also saves a page’s contents; do not save anything yet.')],[
 D(0,[A(1,'Will','Plan browser-tab organization',[0]),A(2,'Will','Keep pinned tabs outside tab groups',[0])],'Pinned tabs have an independent grouping exclusion.',['Do not move them into a project group.']),
 D(1,[A(3,'Will','Group unpinned tabs by project; put projectless tabs in Unsorted',[1])],'The fallback is a settled conditional grouping rule.',['Do not invent project associations.']),
 D(3,[A(4,'Will','Do not close browser tabs automatically',[3])],'The user gives an explicit no-auto-close boundary.',['Do not interpret review as deletion.']),
 D(4,[U(3,[4],text='Group unpinned tabs by project; put projectless tabs in To review')],'Only the fallback group name changes.',['Retain project grouping and pinned-tab exclusion.']),
 D(5,[A(5,'Will','Explain whether saving a tab group saves page contents, without saving anything yet',[5])],'The explanation is a new request, not permission to save.',['Keep automatic closing prohibited.'])])

F('test',19,'en','camera exposure comparison','Photographer changes one experiment setting while holding comparison conditions fixed',
 ['local_revision','retention','unaccepted_proposal','combined_change'],[
 ('Sana','user','Plan a camera exposure comparison using the same indoor scene. Keep the camera position fixed.'),
 ('Sana','user','Compare shutter speeds of one-thirtieth and one-sixtieth of a second, with ISO held at 400.'),
 ('Assistant','assistant','We could move outdoors for brighter light.'),
 ('Sana','user','I have not chosen a different scene.'),
 ('Sana','user','Use one-one-hundred-and-twenty-fifth instead of one-sixtieth. Keep the other speed and ISO unchanged.'),
 ('Sana','user','Include a place to note motion blur, but do not assume either setting wins.')],[
 D(0,[A(1,'Sana','Plan an exposure comparison using the same indoor scene',[0]),A(2,'Sana','Keep camera position fixed during the comparison',[0])],'Scene identity and camera position are controls.',['Do not move the experiment outdoors.']),
 D(1,[A(3,'Sana','Compare shutter speeds of 1/30 s and 1/60 s',[1]),A(4,'Sana','Hold ISO at 400 in the exposure comparison',[1])],'The compared pair and controlled ISO are independently tracked.',['Preserve units and reciprocal values.']),
 D(3,[],'The outdoor proposal is not adopted.',['Keep the indoor scene and fixed position.']),
 D(4,[U(3,[4],text='Compare shutter speeds of 1/30 s and 1/125 s')],'Only the second member of the pair changes.',['Do not replace both speeds or ISO.']),
 D(5,[A(5,'Sana','Include a motion-blur observation field without presuming a winning exposure setting',[5])],'The outcome is to be observed rather than predetermined.',['Do not label a setting superior without results.'])])

F('test',20,'en','local weather observation diary','Observer changes reporting frequency without losing a settled missing-data convention',
 ['conditional','retention','local_revision','withdrawal','reopen'],[
 ('Drew','user','Create a local weather diary. When I miss a reading, record missing rather than copying the previous value.'),
 ('Drew','user','Plan one observation at noon each day. Include a separate cloud-sketch space.'),
 ('Drew','user','The cloud sketch can go for now; keep the numerical observations.'),
 ('Drew','user','Change the schedule to 9 am and 6 pm every day. The missing-reading rule stays.'),
 ('Drew','user','Bring back the original cloud-sketch space too, with no other changes.')],[
 D(0,[A(1,'Drew','Create a local weather observation diary',[0]),A(2,'Drew','Mark missed readings as missing instead of copying the previous value',[0])],'The missing-data convention is an active conditional rule.',['Do not fill a gap with invented measurements.']),
 D(1,[A(3,'Drew','Schedule one weather observation at noon daily',[1]),A(4,'Drew','Include a separate cloud-sketch space',[1])],'Schedule and drawing component are independent.',['Do not confuse sketches with measured values.']),
 D(2,[W(4,[2])],'Only the sketch space is removed.',['Keep numerical observations and missing-data policy.']),
 D(3,[U(3,[3],text='Schedule weather observations at 9 am and 6 pm daily')],'Two new daily times replace noon.',['Do not retain noon as a third required reading.']),
 D(4,[R(4,[4])],'The exact original sketch space is restored while the newer schedule persists.',['Keep 9 am/6 pm and missing-data policy.'])])

def write_and_check():
 for split,count,zhcount in [('dev',10,5),('test',20,10)]:
  fs=[f for f in FS if f['split']==split]
  if not fs:continue
  assert len(fs)==count,(split,len(fs))
  assert sum(f['language']=='zh' for f in fs)==zhcount
  for f in fs:
   assert len(f['decisions'])==5 and 5<=len(f['events'])<=14
   assert f['decisions'][-1]['through_seq']==len(f['events'])-1
   with IntentStore(':memory:') as st:
    last=-1
    for di,d in enumerate(f['decisions']):
     assert d['through_seq']>last
     before={r['intent_id']:r for r in st.snapshot()['intents']}
     st.observe(f['events'][last+1:d['through_seq']+1])
     after=st.commit_patch(f'decision-{di}',di,d['through_seq'],d['operations'])
     ai={r['intent_id']:r for r in after['intents']}
     assert sorted(i for i in before if before[i]==ai[i])==sorted(d['preserve_ids'])
     last=d['through_seq']
  path=P/f'data/source/{split}.jsonl'
  path.write_text(''.join(json.dumps(f,ensure_ascii=False)+'\n' for f in fs),encoding='utf-8')
  print(json.dumps(dict(split=split,families=len(fs),decisions=5*len(fs),status='author_self_replay_passed_independent_review_pending',provenance='synthetic_heldout_family_not_real_user_traffic')))

if __name__=='__main__':write_and_check()
