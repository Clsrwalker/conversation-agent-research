"""Original fictional scenario authoring; metadata never enters model input.

Helpers serialize individually authored dialogues/operations and calculate the
complete unchanged-ID list. They do not generate scenarios by substitution.
"""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[6]
OUT = Path(__file__).resolve().parents[1] / 'source' / 'train-a.jsonl'

def A(i, owner, text, seqs, status='active'):
    return dict(op='add', intent_id=f'i{i}', owner=owner, text=text, source_seqs=seqs, status=status)
def U(i, seqs, **fields):
    return dict(op='update', intent_id=f'i{i}', source_seqs=seqs, **fields)
def W(i, seqs):
    return dict(op='withdraw', intent_id=f'i{i}', source_seqs=seqs)
def R(i, seqs, status='active'):
    return dict(op='reopen', intent_id=f'i{i}', source_seqs=seqs, status=status)
def D(seq, ops, note, checks):
    return dict(through_seq=seq, operations=ops, evidence_note=note, critical_checks=checks)
families=[]
def F(n, lang, domain, scenario, tags, events, decisions):
    known=set()
    for d in decisions:
        touched={op['intent_id'] for op in d['operations']}
        d['preserve_ids']=sorted(known-touched, key=lambda s:int(s[1:]))
        known |= {op['intent_id'] for op in d['operations'] if op['op']=='add'}
    families.append(dict(family_id=f'train-a-{n:03}', split='train', language=lang,
        domain=domain, scenario=scenario, tags=tags,
        events=[dict(seq=i, speaker=s, role=r, text=t) for i,(s,r,t) in enumerate(events)],
        decisions=decisions))

F(1,'zh','neighborhood repair event','Volunteer repair cafe moves day while retaining access conditions',
  ['local_revision','retention','unaccepted_proposal','combined_change','withdrawal','delayed_change'],[
 ('林舒','user','帮我筹办社区维修角，原定这周六。活动放在室内，居民参加不收费。'),
 ('助手','assistant','可以加一个提前预约的环节，减少排队。'),
 ('林舒','user','我看到了，这只是一个备选，暂时没有决定采用。'),
 ('林舒','user','物业说周六要检修电路，活动挪到周日。'),
 ('林舒','user','日期变了，免费参加这一点照旧。'),
 ('助手','assistant','已经在整理桌椅、工具和海报的清单。'),
 ('林舒','user','另外留一块安静区，让不适应噪声的居民也能等候。'),
 ('林舒','user','活动介绍里不要写参与居民的姓名。'),
 ('助手','assistant','海报草稿正在排版，安静区目前标在东侧。'),
 ('林舒','user','东侧空间不够，安静区这次取消，维修活动继续办。')],[
 D(0,[A(1,'林舒','筹办社区维修角活动',[0]),A(2,'林舒','社区维修角在本周六举行',[0]),A(3,'林舒','社区维修角在室内举行',[0]),A(4,'林舒','社区维修角向居民免费开放',[0])],'The opening contains one event goal and three separately mutable constraints.',['Capture indoor and free access as independent constraints.']),
 D(2,[],'The assistant suggested booking; the user explicitly leaves it unaccepted.',['Do not add advance booking.','Keep all four original requirements.']),
 D(4,[U(2,[3],text='社区维修角在本周日举行')],'Only the day changes; the repeated free condition is already represented.',['Replace Saturday with Sunday under the same ID.','Indoor and free requirements stay unchanged.']),
 D(7,[A(5,'林舒','社区维修角设置安静等候区',[6]),A(6,'林舒','社区维修角活动介绍不出现参与居民姓名',[7])],'Two arrived user messages independently add access and privacy constraints.',['Capture both messages.','Assistant work progress does not complete the event.']),
 D(9,[W(5,[9])],'The user cancels only the quiet area and explicitly retains the repair event.',['Do not cancel the whole event.','Keep Sunday, indoor, free and privacy constraints.'])])

F(2,'zh','museum audio guide','A short local-history recording gains a confirmed accessibility requirement',
 ['uncertainty_resolution','new_information_request','acceptance','retention'],[
 ('韩蕾','user','帮我做旧码头展区的中文语音导览，整段控制在两分钟内。'),
 ('韩蕾','user','可能会有听不清声音的访客，要不要配文字我还拿不准。'),
 ('助手','assistant','可以把旁白同步展示成字幕。'),
 ('韩蕾','user','刚收到场馆要求，就采用你说的同步字幕，必须有。'),
 ('助手','assistant','我准备在开头加入一段老船汽笛声。'),
 ('韩蕾','user','那个声音建议我还没同意，先放着。'),
 ('韩蕾','user','另外说明一下，字幕文件和导览正文分别交付。'),
 ('韩蕾','user','SRT 和 VTT 两种字幕文件有什么区别？给我一个简短对比。')],[
 D(0,[A(1,'韩蕾','制作旧码头展区中文语音导览',[0]),A(2,'韩蕾','旧码头语音导览总时长不超过两分钟',[0])],'The project and duration limit are explicit.',['Keep the Chinese-language task context.']),
 D(1,[A(3,'韩蕾','旧码头语音导览可能需要配套文字内容',[1],status='uncertain')],'The user raises a concrete accessibility candidate but has not decided the form.',['Mark text support uncertain, not mandatory captions yet.']),
 D(3,[U(3,[2,3],text='旧码头语音导览必须配有同步字幕',status='active')],'The user accepts the assistant caption proposal; both proposal and acceptance establish its meaning.',['Promote the existing candidate to active.','Retain the two-minute limit.']),
 D(6,[A(4,'韩蕾','字幕文件与旧码头导览正文分别交付',[6])],'Separate delivery is requested; the earlier sound proposal remains unaccepted.',['Do not introduce a foghorn effect.','Capture separate files without replacing the caption requirement.']),
 D(7,[A(5,'韩蕾','简短比较 SRT 与 VTT 字幕文件的区别',[7])],'The comparison is a new information request, not a change of subtitle format.',['Do not silently select SRT or VTT.','Do not label this new question as no change.'])])

F(3,'zh','small business reporting','Two shop owners retain different exports and deadlines',
 ['multi_owner','local_revision','retention','combined_change','no_change'],[
 ('周砚','user','给我的花店做一份按周汇总的销售表，用 CSV 格式。'),
 ('许晴','user','我的咖啡店也要汇总，不过按天看，给我 XLSX。'),
 ('周砚','user','我这份要隐藏顾客联系方式。'),
 ('助手','assistant','两家店可以采用统一的文件格式。'),
 ('许晴','user','这只是你的建议，我还没有要改格式。'),
 ('周砚','user','花店这份改成按月汇总，文件格式别动。'),
 ('许晴','user','咖啡店那份请加上每日报损金额。'),
 ('助手','assistant','我已分别准备好两份表头。'),
 ('许晴','user','收到。')],[
 D(0,[A(1,'周砚','为周砚的花店制作销售汇总表',[0]),A(2,'周砚','花店销售表按周汇总',[0]),A(3,'周砚','花店销售表使用 CSV 格式',[0])],'All initial requirements belong to the flower-shop owner.',['Do not infer another shop.']),
 D(1,[A(4,'许晴','为许晴的咖啡店制作销售汇总表',[1]),A(5,'许晴','咖啡店销售表按天汇总',[1]),A(6,'许晴','咖啡店销售表使用 XLSX 格式',[1])],'The second speaker creates a separate report with different granularity and format.',['Keep owners and report identities separate.']),
 D(4,[A(7,'周砚','花店销售表隐藏顾客联系方式',[2])],'The privacy requirement applies only to the flower shop; no shared format is accepted.',['Retain both CSV and XLSX.','Do not apply flower-shop privacy scope to the other report without evidence.']),
 D(6,[U(2,[5],text='花店销售表按月汇总'),A(8,'许晴','咖啡店销售表包含每日报损金额',[6])],'Two owners independently revise their own report in the same observation window.',['Change only the flower-shop period.','Add daily waste cost only to the coffee-shop report.']),
 D(8,[],'Assistant preparation and acknowledgement do not withdraw any requested report.',['Keep all report requirements active.'])])

F(4,'zh','shared apartment grocery planning','Dinner ingredients change without losing a separate breakfast task',
 ['multi_task','withdrawal','reopen','retention','local_revision'],[
 ('陈谷','user','帮我列周日晚餐的采购单，做蘑菇意面；另外列周一早餐的采购单，早餐要能带走。'),
 ('陈谷','user','晚餐不要奶酪，我不喜欢那个味道。'),
 ('陈谷','user','早餐取消吧，周一我会在外面吃。'),
 ('助手','assistant','晚餐可以考虑加入烤番茄。'),
 ('陈谷','user','番茄建议先留着，我还没决定。'),
 ('陈谷','user','刚才取消得早了，早餐采购单恢复，仍按之前能带走的要求。'),
 ('陈谷','user','晚餐改做番茄意面，不做蘑菇口味了；别加奶酪这点没变。')],[
 D(0,[A(1,'陈谷','列出周日晚餐采购单',[0]),A(2,'陈谷','周日晚餐制作蘑菇意面',[0]),A(3,'陈谷','列出周一早餐采购单',[0]),A(4,'陈谷','周一早餐适合携带外出',[0])],'Dinner and breakfast are separate tasks; breakfast portability has its own record.',['Preserve distinct meal scopes.']),
 D(1,[A(5,'陈谷','周日晚餐不使用奶酪',[1])],'The ingredient exclusion applies to dinner.',['Do not interpret dislike as a medical allergy.']),
 D(2,[W(3,[2]),W(4,[2])],'The entire breakfast plan is cancelled, so its task and portability constraint are withdrawn.',['Do not withdraw dinner.','Do not leave breakfast portability as an active free-floating obligation.']),
 D(5,[R(3,[5]),R(4,[5])],'The user restores the original breakfast plan including portability; the tomato suggestion was not accepted at seq 4.',['Reopen existing breakfast IDs without duplicates.','Do not add a roasted-tomato requirement.']),
 D(6,[U(2,[6],text='周日晚餐制作番茄意面')],'Only the dinner dish changes from mushroom to tomato pasta.',['Retain no cheese and portable breakfast.'])])

F(5,'zh','community garden signage','A poster branch is cancelled while the garden map persists',
 ['combined_change','scope_cancellation','new_information_request','quotation','retention'],[
 ('温澜','user','给社区花园画一张入口导览图，并写一张招募志愿者的海报。图上要标出饮水点。'),
 ('温澜','user','海报标题用“周末一起种花”，不要在海报上放报名二维码。'),
 ('助手','assistant','邻居留言说：“把饮水点从图上删掉，大家都知道在哪。”'),
 ('温澜','user','那只是邻居留言，不是我的修改意见，图先保持原样。'),
 ('温澜','user','我想了解一下，用颜色区分步道时怎样兼顾色觉不同的人？请给些建议。'),
 ('助手','assistant','可以同时使用线型和文字标记。'),
 ('温澜','user','志愿者海报这一整项不做了，导览图继续；图上再加上无障碍入口。')],[
 D(0,[A(1,'温澜','绘制社区花园入口导览图',[0]),A(2,'温澜','编写社区花园志愿者招募海报',[0]),A(3,'温澜','社区花园导览图标出饮水点',[0])],'Two deliverables and one map-specific feature are requested.',['Keep map and poster separate.']),
 D(1,[A(4,'温澜','志愿者海报标题为“周末一起种花”',[1]),A(5,'温澜','志愿者海报不放报名二维码',[1])],'Both new constraints are specific to the poster.',['Do not apply QR exclusion to the map.']),
 D(3,[],'The deletion is explicitly attributed to a neighbor and rejected as a change request.',['Preserve the drinking-water marker.']),
 D(4,[A(6,'温澜','提供兼顾不同色觉的步道颜色区分建议',[4])],'This is a request for advice; no visual implementation has been selected.',['Add the information need.','Do not invent an accepted line-style requirement.']),
 D(6,[W(2,[6]),W(4,[6]),W(5,[6]),A(7,'温澜','社区花园导览图标出无障碍入口',[6])],'The whole poster branch is cancelled, while an accessibility marker is added to the retained map.',['Withdraw both dependent poster constraints.','Retain the map, drinking-water point and advice request.'])])

F(6,'zh','school science demonstration','Teacher narrows a classroom demo after a supplier substitution',
 ['local_revision','retention','unaccepted_proposal','delayed_change','combined_change'],[
 ('顾宁','user','帮我设计一堂四年级磁铁演示课，学生分组动手，不用电池。'),
 ('顾宁','user','每组实验材料装进一个透明袋。'),
 ('助手','assistant','供应商提出把条形磁铁换成电磁铁套装。'),
 ('顾宁','user','只是收到报价，我没有同意这个替换。'),
 ('助手','assistant','板书可以从“哪些材料会被吸引”开始。'),
 ('顾宁','user','这个开场就采用，写进教案。'),
 ('顾宁','user','给教案加一个材料回收步骤，下课时检查磁铁数量。'),
 ('助手','assistant','已整理出回收表的草稿。'),
 ('顾宁','user','班级临时合并了，改成老师台前演示，学生不再分组操作；透明袋分组包装也不用了。')],[
 D(0,[A(1,'顾宁','设计四年级磁铁演示课',[0]),A(2,'顾宁','磁铁课采用学生分组动手操作',[0]),A(3,'顾宁','磁铁课实验不用电池',[0])],'The teaching activity, participation mode and battery exclusion are independent.',['Keep the grade context.']),
 D(1,[A(4,'顾宁','磁铁课每组材料装入一个透明袋',[1])],'Packaging is tied to the group-based participation mode.',['Record transparent group bags without inventing group size.']),
 D(5,[A(5,'顾宁','磁铁课以“哪些材料会被吸引”作为开场',[4,5])],'Only the board-opening proposal is accepted; supplier electromagnets are not.',['Do not replace the no-battery constraint.','Use proposal and acceptance sources.']),
 D(6,[A(6,'顾宁','磁铁课教案包含下课回收材料并核对磁铁数量的步骤',[6])],'The teacher explicitly requests a recovery/counting step.',['Treat counting as part of the material-return step.']),
 D(8,[U(2,[8],text='磁铁课采用老师台前演示，学生不分组操作'),W(4,[8])],'Participation changes and group packaging is explicitly cancelled; other lesson constraints remain.',['Keep no batteries, opening question and return-count step.','Do not withdraw the entire lesson.'])])

F(7,'zh','oral history transcript','Researcher revises the treatment of place names after intervening dialogue',
 ['privacy','delayed_change','retention','new_information_request','local_revision'],[
 ('邵禾','user','整理这次口述史访谈的逐字稿，受访者姓名用代号替换，地名保留原文。'),
 ('邵禾','user','每隔一分钟加一个时间戳。'),
 ('助手','assistant','我在检查转录中的停顿和重复词。'),
 ('邵禾','user','口头重复也保留，不要整理成书面语。'),
 ('助手','assistant','有一句话中断后又重新开始。'),
 ('邵禾','user','这种中断在逐字稿里通常怎么标？请解释一下。'),
 ('助手','assistant','可以通过约定的符号标出未完成语句。'),
 ('邵禾','user','我暂时只是在了解标法，还没选定一种。'),
 ('邵禾','user','隐私审查更新了：村一级地名也改成代号，市名继续保留。姓名代号和一分钟时间戳照旧。')],[
 D(0,[A(1,'邵禾','整理口述史访谈逐字稿',[0]),A(2,'邵禾','逐字稿中受访者姓名替换为代号',[0]),A(3,'邵禾','逐字稿保留地名原文',[0])],'Name anonymization and place-name preservation have different scopes.',['Do not anonymize all locations initially.']),
 D(1,[A(4,'邵禾','口述史逐字稿每隔一分钟添加时间戳',[1])],'The interval is a separate formatting requirement.',['Keep the exact one-minute interval.']),
 D(3,[A(5,'邵禾','逐字稿保留口头重复，不改写为书面语',[3])],'The user adds fidelity to spoken repetition.',['Assistant progress does not establish completion.']),
 D(7,[A(6,'邵禾','解释逐字稿中通常怎样标记中断后重新开始的话语',[5])],'There is a new informational request but no selected notation style.',['Capture the explanation request.','Do not adopt the assistant unspecified symbol suggestion.']),
 D(8,[U(3,[8],text='逐字稿中村级地名替换为代号，市名保留原文')],'Location policy is selectively revised after intervening dialogue.',['Retain name anonymization, one-minute timestamps and spoken repetitions.','Do not anonymize city names.'])])

F(8,'zh','podcast production','Producer resolves who requested an opening disclaimer',
 ['unresolved_owner','uncertainty_resolution','quotation','new_information_request','retention'],[
 ('沈遥','user','把我们的访谈播客剪成一期节目，保留嘉宾说话的自然停顿。'),
 ('沈遥','user','手写交接条上只有“片头加一段免责声明”，没写谁提的，也不确定有没有通过，先作为待确认项记住。'),
 ('助手','assistant','录音里嘉宾说：“这段全部删掉吧。”'),
 ('沈遥','user','那是他在复述以前拍广告的经历，不是在指挥这次剪辑。'),
 ('陆绮','user','交接条是我的，那项我还没确认，请先保持待定。'),
 ('陆绮','user','现已确定：请在这期片头加免责声明。'),
 ('沈遥','user','顺便给我解释一下，降噪会不会影响自然停顿的听感？')],[
 D(0,[A(1,'沈遥','将访谈播客剪辑为一期节目',[0]),A(2,'沈遥','访谈播客保留嘉宾说话的自然停顿',[0])],'The producer asks for an episode and explicit pacing preservation.',['Do not infer noise reduction yet.']),
 D(1,[A(3,'__unresolved__','访谈播客片头可能需要免责声明',[1],status='uncertain')],'A concrete candidate is recorded with both acceptance and ownership unresolved.',['Do not assign the handoff note to the reporting speaker.','Use uncertain status.']),
 D(3,[],'The quoted deletion is part of a narrated past event, explicitly not an editing instruction.',['Do not delete or withdraw any current podcast requirement.']),
 D(5,[U(3,[4,5],owner='陆绮',text='访谈播客片头加入免责声明',status='active')],'The note author first identifies herself and then explicitly confirms the request.',['Resolve owner to 陆绮, not 沈遥.','Preserve the natural pauses requirement.']),
 D(6,[A(4,'沈遥','解释降噪对播客自然停顿听感的可能影响',[6])],'The question asks for an explanation, not permission to apply noise reduction.',['Record an information request.','Do not add mandatory noise reduction.'])])

F(9,'zh','pet adoption poster','Shelter poster changes contact channel while retaining animal identity',
 ['local_revision','multi_task','combined_change','retention','no_change'],[
 ('程艾','user','帮我做小猫“墨点”的领养海报，照片用今天拍的那张，联系邮箱写 shelter@example.test。'),
 ('助手','assistant','也许可以写“适合所有家庭”来吸引关注。'),
 ('程艾','user','这句话别采纳，我们没有这个依据。海报加上“需要先预约见面”。'),
 ('程艾','user','邮箱先别公开了，联系渠道换成收容站前台电话 555-0108。'),
 ('助手','assistant','联系方式已放在草稿底部。'),
 ('程艾','user','再给志愿者写一份接待预约的内部清单，清单不要放进海报。'),
 ('程艾','user','海报照片改用昨日侧脸那张，猫还是墨点；内部清单照常做。'),
 ('助手','assistant','我将按更新后的照片继续排版。'),
 ('程艾','user','好，谢谢。')],[
 D(0,[A(1,'程艾','制作小猫“墨点”的领养海报',[0]),A(2,'程艾','墨点领养海报使用今天拍摄的照片',[0]),A(3,'程艾','墨点领养海报联系渠道为 shelter@example.test 邮箱',[0])],'The identity, selected photo and contact channel are independently tracked.',['Do not invent pet traits.']),
 D(2,[A(4,'程艾','墨点领养海报注明需要先预约见面',[2]),A(5,'程艾','墨点领养海报不使用“适合所有家庭”的宣传语',[2])],'The user explicitly adds an appointment condition and prohibits a particular unsupported claim.',['Do not treat rejection of the slogan as adoption cancellation.']),
 D(3,[U(3,[3],text='墨点领养海报联系渠道为收容站前台电话 555-0108，不公开邮箱')],'The public contact channel is replaced in one record.',['Do not retain the email as an alternative public contact.']),
 D(6,[A(6,'程艾','为志愿者编写内部预约接待清单',[5]),A(7,'程艾','预约接待清单不放入墨点领养海报',[5]),U(2,[6],text='墨点领养海报使用昨日拍摄的侧脸照片')],'The separate internal deliverable is added, then the poster photo alone is replaced.',['Keep the cat identity and phone channel.','Do not merge the internal checklist into the public poster.']),
 D(8,[],'An acknowledgement following assistant progress does not change requirements.',['No task is inferred complete or withdrawn.'])])

F(10,'zh','family archive catalog','Archivist keeps uncertain dates instead of converting an estimate into fact',
 ['uncertainty_resolution','new_information_request','local_revision','retention'],[
 ('余岚','user','帮我编一份祖父照片目录，每张都保留原始文件名。第一批按拍摄地点分组。'),
 ('余岚','user','有些照片可能需要标注大概年代，但我还没确定要不要加这一列。'),
 ('助手','assistant','可以先加入“估计年代”列，并明确它不是确定日期。'),
 ('余岚','user','采用这个办法，加估计年代列，无法判断的留空。'),
 ('余岚','user','现在更适合按人物分组，替换掉地点分组；地点仍保留为一列。'),
 ('助手','assistant','我把示例年代写成了 1965 年。'),
 ('余岚','user','示例不等于证据，别把猜测写成确定年份。'),
 ('余岚','user','同一张照片里两个人都出现时，应该怎么归组？请给我两个可选办法，先别替我定。')],[
 D(0,[A(1,'余岚','编制祖父照片目录',[0]),A(2,'余岚','照片目录保留每张照片的原始文件名',[0]),A(3,'余岚','照片目录按拍摄地点分组',[0])],'Catalog, filename fidelity and grouping method are distinct needs.',['Do not derive dates from filenames.']),
 D(1,[A(4,'余岚','照片目录可能增加大概年代列',[1],status='uncertain')],'The user identifies a candidate column without accepting it.',['Preserve uncertainty about adding the column.']),
 D(3,[U(4,[2,3],text='照片目录增加明确标为估计的年代列，无法判断时留空',status='active')],'The user accepts an explicitly uncertain date column and specifies missing-value behavior.',['Do not turn estimated dates into verified dates.']),
 D(6,[U(3,[4],text='照片目录按人物分组'),A(5,'余岚','照片目录将拍摄地点保留为一列',[4])],'Grouping changes but place information remains; the anti-guess statement restates the already explicit estimated-date constraint.',['Keep filenames and estimated-date labeling.','Do not label 1965 as a new user requirement.']),
 D(7,[A(6,'余岚','提供两种多人同框照片的归组办法供选择，暂不代选',[7])],'This is a new options request with an explicit defer-selection boundary.',['Do not change grouping policy based on an unselected method.'])])

F(11,'zh','daily commuting route','Commuter separates the weekday route from a weekend errand',
 ['multi_task','local_revision','withdrawal','retention','indirect_requirement'],[
 ('罗祺','user','帮我规划工作日骑车去办公室的路线，尽量走有隔离车道的路。'),
 ('罗祺','user','单程别超过四十分钟。'),
 ('罗祺','user','另外安排周六去修车店取车的公交路线。'),
 ('助手','assistant','上班路线有一段隧道。'),
 ('罗祺','user','我不愿意骑进隧道，通勤路线避开它。'),
 ('罗祺','user','周六取车我改请朋友送，公交那项取消。上班骑车还是要规划。'),
 ('罗祺','user','办公室下周搬到河西园区，请把通勤终点换过去；四十分钟限制不变。')],[
 D(0,[A(1,'罗祺','规划工作日骑车到办公室的通勤路线',[0]),A(2,'罗祺','骑车通勤路线优先使用隔离车道',[0])],'The office commute and preferred infrastructure are explicit.',['Keep the preference strength as priority, not an absolute requirement for every segment.']),
 D(1,[A(3,'罗祺','骑车通勤单程时长不超过四十分钟',[1])],'The time cap applies to cycling commutes.',['Do not apply it to future unrelated travel.']),
 D(2,[A(4,'罗祺','规划周六去修车店取车的公交路线',[2])],'A separate weekend errand is introduced.',['Do not replace the weekday cycling task.']),
 D(5,[A(5,'罗祺','骑车通勤路线避开隧道',[4]),W(4,[5])],'The user rules out tunnels for cycling and cancels only the bus-planning errand.',['Do not create a task to book the friend.','Keep the cycling commute active.']),
 D(6,[U(1,[6],text='规划工作日骑车到河西园区办公室的通勤路线')],'The destination changes without removing route constraints.',['Retain forty minutes, tunnel avoidance and the isolated-lane preference.','The cancelled bus route stays withdrawn.'])])

F(12,'zh','library digital orientation','Librarian changes the delivery medium but retains accessibility',
 ['acceptance','combined_change','retention','delayed_change','new_information_request'],[
 ('莫瑾','user','帮图书馆做新读者入门材料，先做成纸质折页，字体至少十四号。'),
 ('莫瑾','user','借书、续借和预约这三件事都要讲到。'),
 ('助手','assistant','可以增加一个扫码进入在线目录的入口。'),
 ('莫瑾','user','可以，就加你说的扫码入口。'),
 ('助手','assistant','目前折页已经分成三个栏目。'),
 ('莫瑾','user','馆里刚改决定，材料改成网页，不印折页了。字号仍然要足够大，至少十四号。'),
 ('莫瑾','user','网页加一段如何联系值班馆员的说明。'),
 ('助手','assistant','我可以把二维码换成可点击链接。'),
 ('莫瑾','user','采用这个替换，直接链接在线目录，不再放二维码。'),
 ('莫瑾','user','屏幕阅读器怎样读取这种网页？请简单解释给我听。')],[
 D(0,[A(1,'莫瑾','制作图书馆新读者入门材料',[0]),A(2,'莫瑾','图书馆入门材料采用纸质折页形式',[0]),A(3,'莫瑾','图书馆入门材料字号至少十四号',[0])],'Medium and minimum typography are separately mutable.',['Keep the material task distinct from format.']),
 D(1,[A(4,'莫瑾','入门材料介绍借书流程',[1]),A(5,'莫瑾','入门材料介绍续借流程',[1]),A(6,'莫瑾','入门材料介绍预约流程',[1])],'Three independently checkable content requirements are stated together.',['Capture all three services, not only borrowing.']),
 D(3,[A(7,'莫瑾','入门材料提供扫码进入在线目录的入口',[2,3])],'The user accepts a specific assistant proposal.',['Use the proposal for the destination and acceptance for authority.']),
 D(8,[U(2,[5],text='图书馆入门材料采用网页形式，不印纸质折页'),A(8,'莫瑾','入门网页说明如何联系值班馆员',[6]),U(7,[7,8],text='入门网页提供进入在线目录的可点击链接，不放二维码')],'The medium changes, a contact section is added, and the user later accepts a link replacing the QR entry.',['Keep the minimum font size and all three services.','Do not keep QR as a second required entry method.']),
 D(9,[A(9,'莫瑾','简单解释屏幕阅读器怎样读取图书馆入门网页',[9])],'The user requests an explanation; a formal accessibility compliance target is not supplied.',['Record the question without inventing a particular standard.'])])

F(13,'zh','amateur theater rehearsal','Stage manager resolves a note while another actor owns a separate request',
 ['multi_owner','unresolved_owner','uncertainty_resolution','withdrawal','reopen','retention'],[
 ('江棠','user','整理周三排练的流程，先走第二幕，再走第一幕。'),
 ('江棠','user','群里有人提“排练前加十分钟热身”，转发记录没署名，也还没通过。作为待确认安排先留着。'),
 ('祝青','user','我另外需要一份只含我自己出场提示的清单。'),
 ('助手','assistant','如果加热身，需要调整开始时间。'),
 ('江棠','user','热身那条是我的建议，现在正式采用，排练前安排十分钟。'),
 ('祝青','user','我的出场清单先取消，我暂时能直接看台本。'),
 ('助手','assistant','当前流程仍按第二幕、第一幕排序。'),
 ('祝青','user','台本借出去了，还是恢复刚才那份只含我出场提示的清单。')],[
 D(0,[A(1,'江棠','整理周三排练流程',[0]),A(2,'江棠','周三排练先走第二幕再走第一幕',[0])],'The stage manager requests the run sheet and a particular scene order.',['Do not assume a start time.']),
 D(2,[A(3,'__unresolved__','周三排练前可能增加十分钟热身',[1],status='uncertain'),A(4,'祝青','为祝青提供仅包含其本人出场提示的清单',[2])],'The unattributed pending warm-up and the actor-specific checklist are different needs.',['Unresolved note ownership is not the forwarding speaker.','Checklist owner is 祝青.']),
 D(4,[U(3,[4],owner='江棠',text='周三排练前安排十分钟热身',status='active')],'The requester identifies herself and accepts the pending warm-up.',['Do not infer an exact earlier clock time.','Keep scene order and actor checklist.']),
 D(5,[W(4,[5])],'Only the actor checklist is cancelled.',['Do not cancel the rehearsal plan.']),
 D(7,[R(4,[7])],'The actor explicitly restores the same scoped checklist.',['Reopen i4 rather than create a duplicate.','Keep ten-minute warm-up and scene order unchanged.'])])

F(14,'en','astronomy club observing night','Cloud contingency is confirmed without displacing the dark-sky constraints',
 ['uncertainty_resolution','acceptance','combined_change','retention','no_change'],[
 ('Mara','user','Plan our astronomy club observing night at the hilltop field. Keep white lights off during the observing session.'),
 ('Mara','user','There might need to be an indoor backup if it is cloudy, but I have not decided whether to organize one.'),
 ('Assistant','assistant','An indoor star-map workshop could be a backup.'),
 ('Mara','user','Yes, use that workshop as the cloudy-weather backup.'),
 ('Mara','user','Make the workshop suitable for complete beginners.'),
 ('Assistant','assistant','I am assembling an equipment list for the field session.'),
 ('Mara','user','The field is closed. Move the observing location to the school courtyard; keep the indoor backup as agreed.'),
 ('Assistant','assistant','We could sell souvenir badges during the evening.'),
 ('Mara','user','I have seen that suggestion, but it is not part of the plan at this point.')],[
 D(0,[A(1,'Mara','Plan the astronomy club observing night',[0]),A(2,'Mara','Hold the observing session at the hilltop field',[0]),A(3,'Mara','Keep white lights off during the observing session',[0])],'The event goal, outdoor location and light restriction are separate.',['Do not infer a date or equipment purchase.']),
 D(2,[A(4,'Mara','Possibly arrange an indoor cloudy-weather backup for observing night',[1],status='uncertain')],'The user has not yet adopted the assistant workshop proposal.',['Do not prematurely activate the backup or select a workshop.']),
 D(4,[U(4,[2,3],text='Arrange an indoor star-map workshop as the cloudy-weather backup',status='active'),A(5,'Mara','Make the indoor star-map workshop suitable for complete beginners',[4])],'Acceptance resolves the pending backup and another message adds audience suitability.',['Use both suggestion and acceptance evidence.','Retain the outdoor light restriction.']),
 D(6,[U(2,[6],text='Hold the observing session in the school courtyard')],'Only the outdoor location changes.',['Do not replace or cancel the indoor workshop.','White-light restriction persists at the new location.']),
 D(8,[],'The badge idea is explicitly left outside the current plan.',['Do not create merchandise work.','Keep all existing event constraints.'])])

F(15,'en','command-line report tool','Developer replaces one output representation while retaining safety and deterministic order',
 ['local_revision','retention','new_information_request','unaccepted_proposal','combined_change'],[
 ('Eli','user','Build a command-line tool that exports the task list as JSON. It must never overwrite an existing destination file.'),
 ('Eli','user','Sort exported tasks by their stable task ID, not by the current screen order.'),
 ('Assistant','assistant','We could add a force flag to overwrite files when needed.'),
 ('Eli','user','That is only a possibility you raised; I have not requested the force flag.'),
 ('Eli','user','What would NDJSON let me do that a JSON array would not? Explain the tradeoff before changing anything.'),
 ('Assistant','assistant','NDJSON permits processing one record at a time.'),
 ('Eli','user','Then switch the export to NDJSON. Keep the stable-ID ordering and no-overwrite behavior.'),
 ('Eli','user','Also give the tool a dry-run mode that reports the intended destination without writing a file.')],[
 D(0,[A(1,'Eli','Build a command-line tool to export the task list',[0]),A(2,'Eli','Export the task list as JSON',[0]),A(3,'Eli','Never overwrite an existing export destination file',[0])],'Output representation and destination safety are distinct.',['No overwrite exception exists.']),
 D(3,[A(4,'Eli','Sort exported tasks by stable task ID rather than screen order',[1])],'The ordering requirement is added; the proposed force flag remains unaccepted.',['Do not add a force flag or weaken no-overwrite.']),
 D(4,[A(5,'Eli','Explain the tradeoff between NDJSON and a JSON array before changing the export',[4])],'The user asks for a comparison and postpones changing format.',['JSON remains the active format at this decision.']),
 D(6,[U(2,[6],text='Export the task list as NDJSON')],'The user explicitly selects NDJSON after the discussion.',['Retain no-overwrite and stable-ID order.','The assistant explanation does not itself withdraw the information request.']),
 D(7,[A(6,'Eli','Provide a dry-run mode reporting the intended export destination without writing a file',[7])],'Dry run is a separate tool behavior, not permission to create the target file.',['Keep no-overwrite in normal execution.'])])

F(16,'en','conference research slides','Presenter narrows a claim and requests a separate reference handout',
 ['local_revision','multi_task','quotation','retention','no_change'],[
 ('Noor','user','Prepare slides for my ten-minute research talk. Include the pilot result, and label it exploratory rather than confirmed.'),
 ('Noor','user','Every numerical claim on a slide needs a source note.'),
 ('Assistant','assistant','A colleague commented, "Say it proves the intervention works."'),
 ('Noor','user','That quote is feedback to discuss, not wording I approve. Keep the exploratory label.'),
 ('Noor','user','Actually leave the pilot result out of the slides. Discuss the study design instead; the talk is still ten minutes.'),
 ('Noor','user','Give me a separate one-page references handout, with the pilot paper included there.'),
 ('Assistant','assistant','I have drafted the title slide and source-note style.'),
 ('Noor','user','Thanks, I will look at the draft later.')],[
 D(0,[A(1,'Noor','Prepare slides for a research talk',[0]),A(2,'Noor','Keep the research talk within ten minutes',[0]),A(3,'Noor','Include the pilot result in the slides',[0]),A(4,'Noor','Label the pilot result in the slides as exploratory, not confirmed',[0])],'The pilot inclusion and its qualifier are tracked separately.',['Do not state that the pilot proves efficacy.']),
 D(3,[A(5,'Noor','Provide a source note for every numerical claim on a slide',[1])],'Only source notes are added; quoted feedback does not override the exploratory qualifier.',['Keep the quote out of approved claims.']),
 D(4,[W(3,[4]),W(4,[4]),A(6,'Noor','Discuss the study design in the research slides instead of presenting the pilot result',[4])],'Removing the pilot from slides withdraws its slide-only qualifier and adds the replacement content.',['Keep ten minutes and source notes.','Do not leave an active requirement to show the pilot result.']),
 D(5,[A(7,'Noor','Produce a separate one-page references handout',[5]),A(8,'Noor','Include the pilot paper in the references handout',[5])],'The pilot paper belongs to a different deliverable and does not reopen the result slide.',['Do not restore i3 or i4.','Keep the one-page and separate-handout scope.']),
 D(7,[],'The assistant drafting report and deferred review do not change requirements.',['Do not mark the talk or handout complete.'])])

F(17,'en','small kitchen furniture','Buyer resolves a tentative finish and swaps an object while preserving physical constraints',
 ['uncertainty_resolution','local_revision','retention','combined_change','new_information_request'],[
 ('Tessa','user','Help me choose a kitchen trolley. It has to fit a gap no wider than  sixty centimetres, and it needs locking wheels.'),
 ('Tessa','user','A wood top might suit the room, although I have not settled on that.'),
 ('Assistant','assistant','Stainless steel would be another option for the top.'),
 ('Tessa','user','I have decided against wood. Make the top stainless steel.'),
 ('Tessa','user','The trolley idea still works, but I measured again: the available width is fifty-four centimetres, not sixty.'),
 ('Tessa','user','What does a load rating usually include, the top shelf alone or all shelves? Explain how I should read it.'),
 ('Tessa','user','Also require at least two shelves; everything else we agreed still applies.')],[
 D(0,[A(1,'Tessa','Help choose a kitchen trolley',[0]),A(2,'Tessa','Kitchen trolley width must not exceed sixty centimetres',[0]),A(3,'Tessa','Kitchen trolley must have locking wheels',[0])],'The width cap and locking-wheel requirement are independent selection constraints.',['Treat sixty centimetres as a maximum, not an exact width.']),
 D(1,[A(4,'Tessa','Kitchen trolley may need a wood top',[1],status='uncertain')],'Wood is a concrete tentative preference.',['Do not make wood mandatory.']),
 D(4,[U(4,[3],text='Kitchen trolley must have a stainless-steel top',status='active'),U(2,[4],text='Kitchen trolley width must not exceed fifty-four centimetres')],'The user resolves the surface material and separately corrects the gap measurement.',['Update existing IDs without retaining wood as active.','Keep locking wheels.']),
 D(5,[A(5,'Tessa','Explain whether a trolley load rating applies to the top shelf or all shelves and how to interpret it',[5])],'An explanation is requested; there is no specified minimum load rating.',['Do not invent a weight-capacity threshold.']),
 D(6,[A(6,'Tessa','Kitchen trolley must have at least two shelves',[6])],'Shelf count is added while earlier selection constraints remain.',['Preserve fifty-four-centimetre cap, steel top and locking wheels.'])])

F(18,'en','chamber music rehearsal','Musician cancels and restores a recording with its original sharing boundary',
 ['withdrawal','reopen','multi_owner','retention','new_information_request'],[
 ('Jonas','user','Make a rehearsal agenda for our string quartet, starting with the slow movement. Record the rehearsal for our private review; do not publish the recording.'),
 ('Pia','user','I need a separate list of my cello entrances in that movement.'),
 ('Jonas','user','Drop the recording plan entirely for now. The rehearsal and Pia’s entrance list still stand.'),
 ('Assistant','assistant','There are several ways to mark entrances in a part.'),
 ('Pia','user','Please explain two of those marking methods before I choose one.'),
 ('Jonas','user','Everyone has agreed to the original recording plan after all. Restore it, with the same private-review-only boundary.')],[
 D(0,[A(1,'Jonas','Prepare the string quartet rehearsal agenda',[0]),A(2,'Jonas','Begin the quartet rehearsal with the slow movement',[0]),A(3,'Jonas','Record the quartet rehearsal for private review',[0]),A(4,'Jonas','Do not publish the quartet rehearsal recording',[0])],'The recording task and non-publication constraint are scoped together but individually retained.',['Do not infer consent from the opening request beyond its stated plan.']),
 D(1,[A(5,'Pia','Provide Pia a separate list of her cello entrances in the slow movement',[1])],'The second speaker owns the cello-specific request.',['Do not replace the quartet agenda with the cello list.']),
 D(2,[W(3,[2]),W(4,[2])],'The entire recording branch is cancelled, including its scoped sharing condition.',['Retain slow-movement order and Pia’s list.']),
 D(4,[A(6,'Pia','Explain two entrance-marking methods for Pia to choose between',[3,4])],'The assistant suggestion becomes an explicit request for two explanations.',['Do not choose a marking method on Pia’s behalf.']),
 D(5,[R(3,[5]),R(4,[5])],'The original recording plan and boundary are explicitly restored.',['Use the existing record IDs.','Do not allow public release.'])])

F(19,'en','collaborative product onboarding','Product manager and support lead retain separate deliverables during a target-audience change',
 ['multi_owner','multi_task','local_revision','acceptance','retention','no_change'],[
 ('Avery','user','Write an onboarding walkthrough for first-time administrators of our scheduling app. Keep it under five steps.'),
 ('Sam','user','For the support team, I need a separate troubleshooting sheet about invitation emails.'),
 ('Assistant','assistant','The walkthrough could begin with a sample calendar instead of an empty screen.'),
 ('Avery','user','Use the sample-calendar opening you proposed.'),
 ('Sam','user','On my troubleshooting sheet, include how to check whether an invite expired.'),
 ('Avery','user','Change my walkthrough audience to returning administrators who have never used the new scheduling view. Keep the step limit.'),
 ('Assistant','assistant','I can merge the troubleshooting sheet into the walkthrough.'),
 ('Sam','user','No decision on that suggestion yet.')],[
 D(0,[A(1,'Avery','Write an onboarding walkthrough for the scheduling app',[0]),A(2,'Avery','Target the walkthrough at first-time administrators',[0]),A(3,'Avery','Keep the walkthrough under five steps',[0])],'The walkthrough goal, audience and strict fewer-than-five-step limit are separate.',['Do not reinterpret under five as five or fewer.']),
 D(1,[A(4,'Sam','Write a separate support-team troubleshooting sheet about invitation emails',[1])],'The support lead requests a distinct artifact.',['Preserve Sam as owner.']),
 D(4,[A(5,'Avery','Open the scheduling walkthrough with a sample calendar',[2,3]),A(6,'Sam','Explain how to check invite expiration in the troubleshooting sheet',[4])],'An accepted proposal changes the walkthrough, while the other owner adds support content.',['Do not assign support content to Avery.']),
 D(5,[U(2,[5],text='Target the walkthrough at returning administrators unfamiliar with the new scheduling view')],'Only the audience changes; step limit and opening are retained.',['Keep fewer than five steps and the sample calendar.','Do not modify the troubleshooting audience.']),
 D(7,[],'Merging is suggested but no user accepts it.',['Keep the support sheet separate.'])])

F(20,'en','museum exhibit logistics','Registrar distinguishes an object label from a crate instruction',
 ['multi_task','local_revision','quotation','combined_change','retention'],[
 ('Leah','user','Prepare a packing checklist for the ceramic exhibit. Each object should keep its existing accession label, and each crate needs an orientation arrow.'),
 ('Leah','user','Add a photo of each object before packing to the checklist.'),
 ('Assistant','assistant','The old crate has a sticker saying "Remove all labels before reuse."'),
 ('Leah','user','That sticker is historical. It is not an instruction to remove the objects’ accession labels.'),
 ('Leah','user','For the new crates, replace orientation arrows with the printed words THIS SIDE UP. Keep the object photos.'),
 ('Leah','user','Also make an unpacking checklist for the receiving museum.'),
 ('Leah','user','Put a condition-check step at the start of the unpacking checklist, before any display setup.')],[
 D(0,[A(1,'Leah','Prepare a packing checklist for the ceramic exhibit',[0]),A(2,'Leah','Keep each ceramic object’s existing accession label',[0]),A(3,'Leah','Place an orientation arrow on each exhibit crate',[0])],'Object labels and crate orientation markings have distinct scopes.',['Do not conflate object and crate labels.']),
 D(1,[A(4,'Leah','Include taking a photo of each object before packing in the packing checklist',[1])],'The requested photos occur before packing, not after unpacking.',['Preserve the timing.']),
 D(3,[],'The quoted old sticker is explicitly not an active instruction for object labels.',['Do not withdraw accession-label preservation.']),
 D(5,[U(3,[4],text='Print THIS SIDE UP on each new exhibit crate instead of an orientation arrow'),A(5,'Leah','Prepare an unpacking checklist for the receiving museum',[5])],'A crate-marking replacement and a separate receiving deliverable both occur.',['Do not retain arrows as required.','Keep object photos and accession labels.']),
 D(6,[A(6,'Leah','Start the unpacking checklist with a condition check before display setup',[6])],'The inspection ordering applies to the receiving checklist.',['Do not move the before-packing photo step to the receiving workflow.'])])

F(21,'en','board game rule editing','Designer distinguishes quoted game commands from editing instructions',
 ['quotation','new_information_request','local_revision','retention','combined_change'],[
 ('Owen','user','Edit my cooperative board game rules for clarity. Keep the existing card names exactly as written.'),
 ('Owen','user','The card text "Discard your entire hand" is a game instruction quoted in the manuscript; do not treat it as an instruction to delete the document.'),
 ('Assistant','assistant','I could rename the card called Last Lantern to Final Light.'),
 ('Owen','user','I have not approved a card rename. Please show a brief example of how a turn could be explained more clearly.'),
 ('Owen','user','Keep the rules edit, but do not include a worked turn in the final rulebook. The example is just for our discussion.'),
 ('Owen','user','One name is now changing after all: rename Last Lantern to Night Watch. Every other card name must stay as written.'),
 ('Owen','user','Add a glossary for the terms used on the cards.')],[
 D(0,[A(1,'Owen','Edit the cooperative board game rules for clarity',[0]),A(2,'Owen','Keep all existing card names exactly as written',[0])],'The editing goal is constrained by card-name fidelity.',['Do not paraphrase names.']),
 D(1,[],'The user explains a quoted in-game command; the existing editing task does not change.',['Do not delete any artifact or turn the card command into a task.']),
 D(4,[A(3,'Owen','Show a brief clearer turn explanation as a discussion example',[3,4]),A(4,'Owen','Do not include a worked turn in the final rulebook',[4])],'The user requests an example but scopes it outside the final deliverable.',['Do not adopt Final Light.','Keep the discussion example and final-rulebook exclusion distinct.']),
 D(5,[U(2,[5],text='Keep all existing card names exactly as written except Last Lantern'),A(5,'Owen','Rename the card Last Lantern to Night Watch',[5])],'An explicit exception narrows the global preservation rule without releasing other names.',['Only Last Lantern changes.','Do not use the earlier unaccepted Final Light.']),
 D(6,[A(6,'Owen','Add a glossary of the terms used on the game cards',[6])],'The glossary is an additional content requirement.',['Keep the no-worked-turn boundary and card-name exception.'])])

F(22,'en','family trip itinerary','Traveler changes a day plan without losing a separate accessibility need',
 ['local_revision','withdrawal','reopen','retention','combined_change'],[
 ('Iris','user','Plan a two-day city visit for me and my father. Keep walking segments short, and include the botanical garden on day one.'),
 ('Iris','user','Add a boat ride on day two, provided we can stay seated for the whole ride.'),
 ('Iris','user','Forget the boat ride for now; do not plan it. Keep day two open.'),
 ('Assistant','assistant','The garden can be visited in the morning or afternoon.'),
 ('Iris','user','Move the botanical garden to day two. For day one, add the small railway museum instead.'),
 ('Iris','user','Restore the same boat ride option on day two, with the seated-throughout condition. Day two no longer needs to stay open.')],[
 D(0,[A(1,'Iris','Plan a two-day city visit for Iris and her father',[0]),A(2,'Iris','Keep walking segments short throughout the city visit',[0]),A(3,'Iris','Include the botanical garden on day one',[0])],'The walking preference applies across the itinerary.',['Do not invent a medical reason or exact distance limit.']),
 D(1,[A(4,'Iris','Include a boat ride on day two',[1]),A(5,'Iris','Choose a boat ride where participants can remain seated throughout',[1])],'Boat participation and its seated condition are separate linked requirements.',['Do not weaken seated throughout to seats available.']),
 D(2,[W(4,[2]),W(5,[2]),A(6,'Iris','Keep day two open in the city itinerary',[2])],'The boat branch is cancelled and an open-day constraint replaces it.',['Keep short walking segments and the day-one garden.']),
 D(4,[U(3,[4],text='Include the botanical garden on day two'),A(7,'Iris','Include the small railway museum on day one',[4]),W(6,[4])],'Moving the garden onto day two supersedes keeping that entire day open.',['Do not preserve an incompatible empty-day requirement.','Do not reopen the boat yet.']),
 D(5,[R(4,[5]),R(5,[5])],'The user explicitly restores the boat and seated condition; the open-day record is already withdrawn.',['Do not withdraw an already-withdrawn record again.','Keep the garden on day two and museum on day one.'])])

F(23,'en','public dataset cleanup','Analyst separates uncertain deduplication from an approved missing-value policy',
 ['uncertainty_resolution','retention','new_information_request','combined_change','local_revision'],[
 ('Ben','user','Prepare a cleaned copy of the public bicycle-count dataset. Never modify the source file, and preserve all original column names.'),
 ('Ben','user','Duplicate-looking rows may need removal, but I do not yet know whether repeated readings are legitimate. Keep deduplication pending.'),
 ('Assistant','assistant','We could treat matching station, timestamp and count as duplicates.'),
 ('Ben','user','Before deciding, explain why two readings might share all three fields.'),
 ('Ben','user','For missing counts, keep the cells empty rather than filling them with zero.'),
 ('Ben','user','I checked the collection guide. Identical station, timestamp and count rows are redundant exports; use that rule to remove duplicates.'),
 ('Ben','user','One column name does need changing: rename station_code to station_id in the cleaned copy. Leave every other column name alone.')],[
 D(0,[A(1,'Ben','Prepare a cleaned copy of the public bicycle-count dataset',[0]),A(2,'Ben','Do not modify the original bicycle-count source file',[0]),A(3,'Ben','Preserve all original column names in the cleaned dataset',[0])],'The output copy, source immutability and schema fidelity are distinct.',['Do not perform an in-place cleanup.']),
 D(1,[A(4,'Ben','Possibly remove duplicate-looking bicycle-count rows after determining whether repeated readings are legitimate',[1],status='uncertain')],'Deduplication is a concrete pending action.',['Do not delete repeated readings yet.']),
 D(4,[A(5,'Ben','Explain why two readings might share station, timestamp and count before deduplication is decided',[2,3]),A(6,'Ben','Keep missing bicycle counts empty instead of replacing them with zero',[4])],'A question and a definite missing-value policy arrive while deduplication remains pending.',['Do not treat the assistant duplicate rule as accepted at this point.']),
 D(5,[U(4,[5],text='Remove redundant rows with identical station, timestamp and count from the cleaned copy',status='active')],'The user confirms the rule after checking the guide.',['Activate the existing deduplication candidate.','Keep missing values empty and the source unchanged.']),
 D(6,[U(3,[6],text='Preserve original column names except station_code in the cleaned dataset'),A(7,'Ben','Rename station_code to station_id in the cleaned copy',[6])],'The explicit rename becomes an exception to otherwise preserved column names.',['Do not rename the source file schema.','Do not release all other column names for change.'])])

F(24,'en','makerspace workshop preparation','Coordinator changes materials and cancels only a supplementary session',
 ['scope_cancellation','combined_change','retention','unaccepted_proposal','local_revision'],[
 ('Ruth','user','Plan a beginner bookbinding workshop at the makerspace. Use hand tools only, and prepare a separate optional session on decorating covers.'),
 ('Ruth','user','For the main workshop, use pre-cut paper sheets so no one needs to trim them during class.'),
 ('Assistant','assistant','An electric cutter could speed up the session.'),
 ('Ruth','user','I am not adopting that idea. The hand-tools-only condition remains.'),
 ('Ruth','user','The decorating session should use paper collage rather than paint.'),
 ('Ruth','user','Actually drop that entire optional decorating session. Keep the bookbinding workshop.'),
 ('Ruth','user','For binding, use cotton thread. Also make the main workshop instructions available as a large-print handout.')],[
 D(0,[A(1,'Ruth','Plan a beginner bookbinding workshop at the makerspace',[0]),A(2,'Ruth','Use hand tools only for the bookbinding workshop',[0]),A(3,'Ruth','Prepare a separate optional cover-decorating session',[0])],'Main workshop and optional decorating session are separate scopes.',['Do not make the optional session mandatory.']),
 D(3,[A(4,'Ruth','Use pre-cut paper sheets in the main bookbinding workshop so participants do not trim them during class',[1])],'The paper preparation is added and the electric cutter suggestion is rejected.',['Keep hand tools only.','Do not require participants to trim paper.']),
 D(4,[A(5,'Ruth','Use paper collage rather than paint in the optional cover-decorating session',[4])],'The material choice is scoped to the optional session.',['Do not apply the collage requirement to binding pages.']),
 D(5,[W(3,[5]),W(5,[5])],'Cancellation of the entire optional session also withdraws its material constraint.',['Do not cancel the main workshop or its pre-cut paper requirement.']),
 D(6,[A(6,'Ruth','Use cotton thread for binding in the main workshop',[6]),A(7,'Ruth','Provide a large-print handout of the main workshop instructions',[6])],'Two independent additions apply to the remaining main workshop.',['Capture both thread and accessible instructions.','Keep the decorating session withdrawn.'])])

F(25,'en','volunteer website content','Editor resolves an unattributed offline request while preserving a public-information boundary',
 ['unresolved_owner','uncertainty_resolution','multi_owner','retention','new_information_request','no_change'],[
 ('Dana','user','Draft the volunteer hub website copy. Publish shift times, but do not publish volunteers’ personal phone numbers.'),
 ('Dana','user','A note from the planning meeting says an offline version might be needed. Nobody signed it, and we have not agreed to make one. Keep that possibility pending.'),
 ('Assistant','assistant','An offline PDF could carry the shift timetable.'),
 ('Miles','user','The note was mine, but I am still checking whether an offline version is necessary.'),
 ('Dana','user','The public copy also needs the venue accessibility information.'),
 ('Miles','user','Confirmed: I need the offline PDF you suggested, containing the shift timetable. Keep personal phone numbers out of that PDF as well.'),
 ('Assistant','assistant','The web draft and offline version can use the same headings.'),
 ('Dana','user','I have not decided on the headings. For now, explain how we could keep the website and PDF updated together.')],[
 D(0,[A(1,'Dana','Draft the volunteer hub website copy',[0]),A(2,'Dana','Publish volunteer shift times on the hub website',[0]),A(3,'Dana','Do not publish volunteers’ personal phone numbers on the hub website',[0])],'Public shift information and personal-contact exclusion are separately tracked.',['Do not infer permission to publish private contacts.']),
 D(1,[A(4,'__unresolved__','An offline version of volunteer information may be needed',[1],status='uncertain')],'The candidate is both unapproved and unattributed.',['Do not assign the note to Dana.','Do not select PDF based on a future suggestion.']),
 D(4,[U(4,[3],owner='Miles'),A(5,'Dana','Include venue accessibility information in the public website copy',[4])],'Miles resolves ownership without resolving necessity; Dana separately adds website content.',['Keep i4 uncertain.','Do not make accessibility information a Miles request.']),
 D(5,[U(4,[2,5],text='Provide an offline PDF containing the volunteer shift timetable',status='active'),A(6,'Miles','Exclude volunteers’ personal phone numbers from the offline PDF',[5])],'Miles accepts the PDF proposal and explicitly applies a privacy rule to that artifact.',['Keep owner Miles from the prior state.','Do not omit the separately scoped PDF privacy boundary.']),
 D(7,[A(7,'Dana','Explain how the volunteer website and offline PDF could be kept updated together',[7])],'The user asks for a maintenance explanation without selecting common headings.',['Do not adopt shared headings.','Record the new information request rather than an empty patch.'])])

def write_and_check():
    assert len(families)==25
    assert sum(f['language']=='zh' for f in families)==13
    assert sum(f['language']=='en' for f in families)==12
    assert sum(len(f['events'])>=8 for f in families)>=6
    sys.path.insert(0, str(ROOT/'experiments'/'deep_conversation'))
    from intention_state import IntentStore
    decisions=0
    for f in families:
        assert len(f['decisions'])==5, f['family_id']
        assert 5<=len(f['events'])<=14
        assert [e['seq'] for e in f['events']]==list(range(len(f['events'])))
        cursors=[d['through_seq'] for d in f['decisions']]
        assert cursors==sorted(set(cursors)) and cursors[-1]==len(f['events'])-1
        with IntentStore(':memory:') as st:
            last=-1
            for k,d in enumerate(f['decisions']):
                assert d['evidence_note'] and d['critical_checks']
                prev={r['intent_id']:r for r in st.snapshot()['intents']}
                st.observe([e for e in f['events'] if last<e['seq']<=d['through_seq']])
                out=st.commit_patch(f'decision-{k}',k,d['through_seq'],d['operations'])
                after={r['intent_id']:r for r in out['intents']}
                actual=sorted([i for i in prev if prev[i]==after[i]],key=lambda s:int(s[1:]))
                assert actual==d['preserve_ids'],(f['family_id'],k,actual,d['preserve_ids'])
                for op in d['operations']:
                    assert max(op['source_seqs'])<=d['through_seq']
                    if op.get('owner')=='__unresolved__':
                        assert op.get('status')=='uncertain'
                last=d['through_seq']; decisions+=1
    OUT.parent.mkdir(parents=True,exist_ok=True)
    OUT.write_text(''.join(json.dumps(f,ensure_ascii=False)+'\n' for f in families),encoding='utf-8')
    parsed=[json.loads(line) for line in OUT.read_text(encoding='utf-8').splitlines()]
    assert parsed==families
    print(json.dumps(dict(status='author_self_check_passed_not_independent_review',families=len(families),decisions=decisions,
        chinese_families=13,english_families=12,long_families=sum(len(f['events'])>=8 for f in families),
        events=sum(len(f['events']) for f in families),operations=sum(len(d['operations']) for f in families for d in f['decisions']),
        output=str(OUT)),ensure_ascii=False))

if __name__=='__main__':
    write_and_check()
