"""Independent re-review of author corrections and their propagated states."""
from pathlib import Path
import json, hashlib
import review_train_c as prior
P=prior.P
OVERRIDES={
 (3,2):'The revised i2 now preserves the entire original product-ID string including leading zeros, supported by seq 3. This repairs the formerly incorrect no-change label.',
 (4,0):'The initial duration is now explicitly at most forty-five minutes; task and Saturday-ten start remain separate.',
 (4,3):'Cancelling the registration form withdraws both i4 and its form-scoped address constraint i5; walk-in admission is added while event/time/duration survive.',
 (4,4):'Both the original form and its home-address exclusion reopen under their original IDs. Existing walk-in permission remains because the user has not revoked it.',
 (14,3):'Two pages, the separate explanation request and readable type are all captured. The new i6 records the explicit readability purpose without inventing a numeric font size.',
 (14,4):'Only the separate tie-rule explanation is withdrawn. Official rules, worked tie example, two-page scope and readable type all remain.',
 (16,0):'The main log, location field, date field and precise-nest-coordinate prohibition now have separate stable IDs.',
 (16,1):'The audio candidate is added as i5 after the atomic-field split and remains uncertain; all four original needs remain.',
 (16,2):'The photo suggestion is not adopted; all five records, including the uncertain audio candidate, remain unchanged.',
 (16,3):'i5 becomes active with an explicitly optional audio-note field. Optional input is not confused with uncertain adoption.',
 (16,4):'Withdrawing the separate location-field requirement is acceptable for Remove location altogether. It explicitly cancels that existing field while retaining the withdrawn record/history, date field, precise-coordinate prohibition and optional audio. An additional permanent prohibition on any future location feature is not required by this cancellation.',
 (19,1):'The target now preserves both branches: include a rain shell if rain is forecast, otherwise leave it off. The rule is active despite being conditional.',
 (24,0):'Form task, item description, approximate loss date and no home address are now independent records. Approximate does not become exact.',
 (24,1):'Optional contact email is added as i5 while the task and three separate field/privacy constraints remain.',
 (24,2):'The passport field remains an explicitly disclaimed quotation; all five current records are preserved.',
 (24,3):'The anonymous-code tradeoff question is a new i6 request; no form substitution is adopted.',
 (24,4):'Only the existing email field i5 becomes required. The description/date fields, no-address constraint and explanation request remain unchanged.',
}
def main():
 source=P/'data/source/train-c.jsonl'; raw=source.read_bytes()
 assert prior.sha(raw)=='1560115819a65c97ad319ff87ba7188564c11300e95bf02195430f2f7a507889'
 fs=[json.loads(l) for l in raw.decode('utf-8').splitlines()]
 old={f['family_id']:f for f in map(json.loads,(P/'review/train-c-source-reviewed.jsonl').read_text(encoding='utf-8').splitlines())}
 rows={(r['family_id'],r['decision_index']):r for r in map(json.loads,(P/'data/compiled/train.records.jsonl').read_text(encoding='utf-8').splitlines()) if r['family_id'].startswith('train-c-')}
 reports=[]; changed=[]
 for f in fs:
  fid=f['family_id']; n=int(fid[-3:]); assert f['events']==old[fid]['events']
  if f!=old[fid]: changed.append(fid)
  ds=[]
  with prior.IntentStore(':memory:') as st:
   last=-1
   for di,d in enumerate(f['decisions']):
    r=rows[(fid,di)]; st.observe(f['events'][last+1:d['through_seq']+1]); before=st.snapshot()
    assert before==r['input']['intention_state']; assert r['input']['conversation']==f['events'][:d['through_seq']+1]
    assert r['target']=={'operations':d['operations']}
    after=st.commit_patch(f'decision-{di}',di,d['through_seq'],d['operations'])
    assert after==r['expected_post_state']
    bi={x['intent_id']:x for x in before['intents']}; ai={x['intent_id']:x for x in after['intents']}
    assert sorted(i for i in bi if bi[i]==ai[i])==sorted(d['preserve_ids'])==sorted(r['preserve_ids'])
    ds.append(dict(decision_index=di,through_seq=d['through_seq'],verdict='accepted',semantic_review=OVERRIDES.get((n,di),prior.NOTES[n][di]),
      critical_checks=[{'check':x,'verdict':'supported'} for x in d['critical_checks']],preserve_ids=d['preserve_ids'],
      original_dialogue_checked=True,full_compiled_pre_and_post_states_match_runtime=True,preservation_checked=True,
      source_or_downstream_rechecked=f!=old[fid],record_sha256=prior.sha(prior.canon(r)),
      pre_state_sha256=prior.sha(prior.canon(before)),post_state_sha256=prior.sha(prior.canon(after)),
      post_state_projection=[{k:x[k] for k in ('intent_id','owner','text','status')} for x in after['intents']]))
    last=d['through_seq']
  reports.append(dict(family_id=fid,verdict='accepted',source_sha256=prior.sha(prior.canon(f)),canonical_family_sha256=prior.sha(prior.canon(f)),
    prior_source_sha256=prior.sha(prior.canon(old[fid])),raw_events_unchanged=True,decisions=ds))
 assert source.read_bytes()==raw
 out=dict(status='accepted',author='root',reviewer='/root/tracker_corpus_a',independent=True,human_review=False,date='2026-10-24',
  source_file_sha256=prior.sha(raw),source_path='data/source/train-c.jsonl',
  canonical_family_hash_rule="SHA256 UTF-8 JSON sort_keys=True ensure_ascii=False separators=(',',':')",
  prior_review='review/train-c-review.json',prior_review_sha256=prior.sha((P/'review/train-c-review.json').read_bytes()),
  resolved_issues=[dict(issue_id=i['issue_id'],status='resolved',reason='See the individually re-reviewed affected decisions and downstream post-states.') for i in prior.ISSUES],
  method='Reviewed every changed operation against the unchanged original dialogue; inspected propagated atomic-field IDs and constraints. Replayed all 125 decisions and compared exact compiled input, target, post-state and preserved records. Unchanged semantics retain the independent first-pass review.',
  summary=dict(families_accepted=25,decisions_accepted=125,corrected_families=changed,runtime_checks=125,unresolved_issues=0),
  families=reports,release_gate_passed_for_this_source=True,
  limits=['Independent model review only; not human annotations or evidence of downstream utility.','Whole-corpus leakage, training-mask and model evaluation gates are the responsibility of the root release process.'])
 (P/'review/train-c-rereview.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(out['summary']))
if __name__=='__main__':main()
