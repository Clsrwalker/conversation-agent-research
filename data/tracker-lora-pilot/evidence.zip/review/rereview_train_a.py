"""Re-review exact corrections and resulting downstream state; original review retained."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,sys,copy
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from review_train_a import ROOT,P,IntentStore,canonical,sha,NOTES

def main():
 source=P/'data/source/train-a.jsonl'; original=json.loads((HERE/'train-a-review.json').read_text(encoding='utf-8'))
 changes=json.loads((HERE/'train-a-revision-log.json').read_text(encoding='utf-8'))
 assert original['source_sha256']==changes['old_sha256']
 assert sha(source)==changes['new_sha256']=='c97ba2ac42c758d9a34bc182c6c9d9ac5cf2a86b8e94d090844a9bbd0d2e5754'
 families=[json.loads(s) for s in source.read_text(encoding='utf-8').splitlines() if s]
 oldfamilies=[json.loads(s) for s in (HERE/'revisions/train-a-v1/train-a.jsonl').read_text(encoding='utf-8').splitlines() if s]
 prior={f['family_id']:f for f in original['families']}; results=[]
 resolutions={
 (7,5):'Village-level exception now explicitly preserves all other place names, including cities.',
 (8,2):'Candidate text now states both adoption and ownership unresolved; later Lu update removes both uncertainty dimensions.',
 (9,2):'Forbidden slogan now cites proposal plus deictic rejection [1,2], while appointment need cites only [2].',
 (11,5):'Destination update explicitly begins next week; route constraints and cancelled bus task persist.',
 (13,2):'Unattributed warm-up now states both uncertain dimensions; later Jiang adoption resolves both.',
 (20,4):'Only new crates switch to THIS SIDE UP; other crates retain arrows. Object labels/photos and unpacking task remain distinct.',
 (25,2):'Offline candidate now explicitly has unresolved owner and adoption.',
 (25,3):'Miles resolves ownership while text and status retain undecided adoption; next decision makes PDF active with Miles owner.'}
 for n,(f,old) in enumerate(zip(families,oldfamilies),1):
  assert f['family_id']==old['family_id'] and f['events']==old['events']
  ds=[]
  with IntentStore(':memory:') as st:
   for k,(d,oldd,pd) in enumerate(zip(f['decisions'],old['decisions'],prior[f['family_id']]['decisions']),1):
    if pd['issue']:
     assert d['operations']==pd['issue']['proposed_complete_operations']
    else: assert d==oldd
    st.observe([e for e in f['events'] if e['seq']<=d['through_seq']]);b=st.snapshot()
    a=st.commit_patch(f'setup-{k}',b['version'],d['through_seq'],d['operations'])
    bb={i['intent_id']:i for i in b['intents']};aa={i['intent_id']:i for i in a['intents']}
    assert all(bb[i]==aa[i] for i in d['preserve_ids'])
    for i in a['intents']:
     if i['owner']=='__unresolved__' and i['status']!='withdrawn':
      assert i['status']=='uncertain' and ('归属' in i['text'] or 'ownership' in i['text'])
    ds.append({'decision_index':k,'through_seq':d['through_seq'],'verdict':'accepted','was_correction':bool(pd['issue']),'semantic_check':resolutions.get((n,k),NOTES[n][k-1]),'checks':{'author_raw_dialogue_unchanged':True,'correction_matches_independent_review':bool(pd['issue']),'unchanged_target_matches_prior_review':not bool(pd['issue']),'runtime_replay':'passed','untouched_records_preserved':True,'downstream_state_reviewed':True},'post_state_projection':[{key:i[key] for key in ('intent_id','owner','text','status')} for i in a['intents']]})
  results.append({'family_id':f['family_id'],'canonical_family_sha256':canonical(f),'verdict':'accepted','decisions':ds})
 out={'id':'train-a-independent-model-rereview','date':'2026-10-24','timezone':'America/Halifax','created_at_utc':datetime.now(timezone.utc).isoformat(),'reviewer':'tracker_annotation_v2; did not author or modify A','kind':'independent_model_semantic_review_not_human_review','status':'accepted_after_corrections','human_review_performed':False,'source_sha256':sha(source),'source_modified':False,'previous_review_path':'review/train-a-review.json','previous_review_sha256':sha(HERE/'train-a-review.json'),'revision_log_sha256':sha(HERE/'train-a-revision-log.json'),'annotation_guide_sha256':sha(P/'annotation/ANNOTATION_GUIDE.md'),'summary':{'families_reviewed':25,'decisions_reviewed':125,'accepted_decisions':125,'corrections_confirmed':8,'raw_dialogues_changed':0,'runtime_replays_passed':125},'families':results,'limitations':['Synthetic model-authored and model-reviewed data, not human adjudication.','This review covers normal source trajectories; future fault variants require separate review.','Structural replay does not establish training usefulness or deployment quality.']}
 (HERE/'train-a-rereview.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(out['summary']))
if __name__=='__main__':main()
