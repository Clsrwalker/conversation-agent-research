"""Bind all independently reviewed labels to the exact frozen pilot corpus."""
from pathlib import Path
import hashlib
import json
import sys
from datetime import datetime, timezone
STUDY=Path(__file__).resolve().parent.parent
ROOT=next(p for p in STUDY.parents if (p/'experiments/deep_conversation/intention_state.py').exists())
sys.path.insert(0,str(ROOT/'experiments/deep_conversation/tracker_lora'))
from build_dataset import encode, sha, write_json

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def canonical(value):
    return hashlib.sha256(encode(value).encode()).hexdigest()

AUTHORS={'train-a':'/root/tracker_corpus_a','train-b':'/root/tracker_annotation_v2',
         'train-c':'/root','train-d':'/root/tracker_annotation_v2',
         'dev':'/root/tracker_corpus_a','test':'/root/tracker_corpus_a'}
REVIEWS={'train-a':('train-a-rereview.json','/root/tracker_annotation_v2'),
         'train-b':('train-b-review.json','/root'),
         'train-c':('train-c-rereview.json','/root/tracker_corpus_a'),
         'train-d':('train-d-review.json','/root'),
         'dev':('dev-rereview.json','/root/tracker_annotation_v2'),
         'test':('test-rereview.json','/root/tracker_annotation_v2')}
FAULT_REVIEWS={k:(f'{k}-fault-review.json',v[1]) for k,v in REVIEWS.items()}
FAULT_REVIEWS['train-c']=('train-c-faults-rereview.json','/root/tracker_corpus_a')

def main():
    families={}
    records={}
    for shard,(filename,reviewer) in REVIEWS.items():
        source=STUDY/f'data/source/{shard}.jsonl'
        actual={f['family_id']:f for f in map(json.loads,source.read_text(encoding='utf-8').splitlines())}
        report_path=STUDY/'review'/filename
        report=read(report_path)
        assert report['status'] in {'accepted','accepted_after_corrections'}
        assert (report.get('source_sha256') or report.get('source_file_sha256'))==sha(source)
        reviewed=report['families']
        if isinstance(reviewed,list):
            reviewed={f['family_id']:f for f in reviewed}
        assert set(reviewed)==set(actual)
        assert AUTHORS[shard]!=reviewer
        for identifier,item in reviewed.items():
            expected=item.get('family_sha256') or item.get('canonical_family_sha256')
            assert expected==canonical(actual[identifier])
            assert item['verdict'] in {'accept','accepted'}
            assert len(item['decisions'])==5 and all(d['verdict'] in {'accept','accepted'} for d in item['decisions'])
            families[identifier]={'family_sha256':expected,'verdict':'accept','decisions_reviewed':5,
              'author':AUTHORS[shard],'reviewer':reviewer,'independent_of_author':True,
              'review_path':f'review/{filename}','review_sha256':sha(report_path)}
        records[f'review/{filename}']=sha(report_path)
    faults={}
    for shard,(filename,reviewer) in FAULT_REVIEWS.items():
        fault_path=STUDY/f'data/faults/{shard}.json'
        actual={f['example_id']:f for f in read(fault_path)}
        report_path=STUDY/'review'/filename
        report=read(report_path)
        assert report['status'] in {'accepted','accepted_after_corrections'}
        assert (report.get('fault_file_sha256') or report.get('source_file_sha256'))==sha(fault_path)
        reviewed=report['faults']
        if isinstance(reviewed,list):
            reviewed={f['example_id']:f for f in reviewed}
        assert set(actual)==set(reviewed) and AUTHORS[shard]!=reviewer
        for identifier,item in reviewed.items():
            expected=item.get('fault_sha256') or item.get('canonical_fault_sha256')
            assert canonical(actual[identifier])==expected
            assert item['verdict'] in {'accept','accepted'}
            fid=identifier.rsplit('-',1)[0]
            assert (item.get('family_sha256') or item.get('canonical_family_sha256'))==families[fid]['family_sha256']
            faults[identifier]={'fault_sha256':expected,'verdict':'accept','independent_of_author':True,
              'author':AUTHORS[shard],'reviewer':reviewer,'review_path':f'review/{filename}',
              'review_sha256':sha(report_path)}
        records[f'review/{filename}']=sha(report_path)
    assert len(families)==130 and len(faults)==65
    manifest=read(STUDY/'data/compiled/manifest.json')
    assert manifest['update_counts']=={'train':500,'dev':50,'test':100}
    for fid,record in families.items():
        assert record['family_sha256']==manifest['family_sources'][fid]['family_sha256']
    for relative,expected in manifest['source_files'].items():
        assert sha(STUDY/relative)==expected
    training_sft_sha256=sha(STUDY/'data/compiled/train.sft.jsonl')
    assert training_sft_sha256==manifest['training_sft_sha256']
    admission={'status':'approved_for_pilot','created_at_utc':datetime.now(timezone.utc).isoformat(),
      'date':'2026-10-24','timezone':'America/Halifax',
      'kind':'bounded synthetic pilot release, independently model-reviewed labels',
      'human_validated':False,'families':families,'fault_examples':faults,'review_files':records,
      'training_sft_sha256':training_sft_sha256,
      'limitations':['500 updates belong to 100 fictional scenario families, not 500 independent conversations.',
        'Separate model review is not human gold or real-user distribution validation.',
        'Injected prior-state errors are text corruption only, not missing-record/owner/status failures.',
        'Short held-out conversations and shared task domains limit long-history and out-of-domain conclusions.',
        'This admission demonstrates label review and executable examples, not reduced model omissions.']}
    write_json(STUDY/'review/admission.json',admission)
    print(json.dumps({'status':admission['status'],'families':len(families),'fault_examples':len(faults),
      'training_sft_sha256':training_sft_sha256}))

if __name__=='__main__':
    main()
