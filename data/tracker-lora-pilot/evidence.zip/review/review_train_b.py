"""Record root's independent full semantic reading and verified corrections."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

HERE = Path(__file__).resolve().parent
STUDY = HERE.parent
ROOT = next(p for p in STUDY.parents if (p / 'experiments/deep_conversation/intention_state.py').exists())
sys.path.insert(0, str(ROOT / 'experiments/deep_conversation/tracker_lora'))
from build_dataset import materialize, encode

# Each entry was written after reading the actual raw events and operations;
# automatic replay below separately establishes structural consistency only.
NOTES = {
1:['Report, fixed seed and reported metric all captured.','Declines the particular extra experiment, no adoption.','Macro F1 replaces accuracy; seed remains.','Appendix runtime belongs to Meng, not Ji.','Dataset acquisition paragraph is requested despite pending log read.'],
2:['School activity and free participation separate.','Playground is a concrete undecided candidate.','Explicitly rejects playground candidate and adopts library; preserve fee rule.','User explicitly requests comparison despite quoting parent question.','Fee repetition is true no-change.'],
3:['Task, Thursday, word ceiling and acknowledgement block independent.','Disclaimed old-publication quote does not increase word limit.','Friday replaces Thursday, not word ceiling.','Acknowledgement block temporarily withdrawn.','Exact block restored with stable ID.'],
4:['Paper, A4 and APA recorded.','Font-licensing explanation is a new information request.','Line numbers apply to body, exclude references.','Numbered citation style replaces APA only.','Thanks and keep-as-is are no-change.'],
5:['Spoken practice is supported by waiting until speaker finishes paragraph.','Unaccepted essay suggestion creates no essay task.','Listening/speaking-only adoption cites proposal and acceptance.','Correction timing changes paragraph to sentence.','Withdraw only-listening/speaking restriction; permission for reading is not a mandatory reading task.'],
6:['Route, tactile replicas and no flashing lights separate.','Possible captions have explicitly unresolved owner and adoption.','Xia confirms owner, every-video scope and active status on same ID.','Audio interpretation belongs to A Luo.','Withdraw replicas only; captions, lights and other owner persist.'],
7:['Refund window and manual approval separate.','Opened-product escalation is settled conditional active rule.','Assistant completion cannot clear demands.','Training-material quote not accepted.','14 days replaces 30, other process constraints persist.'],
8:['Chinese captions and no-guessing policy captured.','Timestamp cadence independent.','CORRECTED: no background music and captions-only is a lasting new scope limit, not only rejecting a proposal.','Speaker-start timing changes; pure-filler removal permission recorded separately.','Explicit verbatim retention replaces filler-removal rule; new timestamp cadence remains.'],
9:['Fictional exercise, timed technical stage and anonymous score sheet.','Question stage with its duration added.','Both durations revised; anonymity retained.','Comparison of scoring methods is a new unanswered question.','Question stage withdrawn, technical stage stays 15 minutes.'],
10:['Offline app test plan plus export integrity.','Settled if-Web Firefox rule active, not uncertain.','All-browser proposal declined.','Suspend integrity in this plan; startup result does not reverse cancellation.','Restore same integrity check with original ID.'],
11:['Plan, approval and rollback threshold separate.','Configuration-diff checklist belongs to Yuan.','Automated switching rejected; approval retained.','Threshold and explicit document-only/no-execution limit both captured.','Owner restatement requires no patch.'],
12:['Synthetic-source disclosure captured with data-card task.','Bilingual candidate uncertain.','Reject bilingual candidate, adopt Chinese-only; no fake field collection.','Separate licences explanation requested.','New methodological-use scope is add despite word revise; synthetic origin retained.'],
13:['Preregistration, primary endpoint and blinding separate.','Error-count candidate uncertain.','Randomization diagram belongs to Eli.','Candidate accepted as secondary under same ID.','Primary endpoint changes without deleting secondary or blinding.'],
14:['Open participation, no auditions and short final performance.','Audition suggestion not adopted.','CORRECTED: short duration qualifier retained when format changes to audio drama; sound session added.','Two non-speaking contribution options and tradeoffs requested.','No-audition restatement true no-change.'],
15:['Checklist, quotation fidelity and glossary separate.','Nested quote explicitly disclaimed.','Glossary withdrawn, quotation fidelity persists.','Photo caption check added.','Original glossary restored unchanged.'],
16:['PDF deliverable, columns and reading order independent.','Accepted single-column proposal cites both turns.','Map contrast constraint avoids color alone.','Editable source supplements rather than replaces PDF.','Explicit repetition no update.'],
17:['Short practice, workplace context and avoidance of numeric accent ratings captured.','Poem suggestion rejected.','Recording candidate remains uncertain despite assistant support.','Candidate rejected explicitly.','Stress comparison question survives later acknowledgement; workplace and ratings preserved.'],
18:['Route opening and step-free constraint independent.','Reading level belongs to Sana.','Upstairs suggestion not adopted.','Start object changes and hands-on stop is added.','Sana reaffirms existing reading level.'],
19:['Initial response deadline is not guaranteed resolution.','Weekend channel candidate uncertain.','Delivered-but-missing escalation is settled conditional rule.','Adoption limits weekend staffing to Saturday mornings.','One-working-day response change retains distinction from resolution.'],
20:['Captions, speaker scheme and no-guessing policy separate.','Disclaimed producer quotation not followed.','Speaker labels replace scheme only.','Important sound descriptions added with examples, not all sounds.','Subtitles/captions question is new despite thanks.'],
21:['Mock exercise and fictional-only profile boundary recorded.','Separate pair exercise added.','Narrated walkthrough replaces written review, not fictional constraint.','Cancel only pair exercise.','Assistant invented completion cannot clear user intents.'],
22:['Tests, backward compatibility and secret-free fixtures.','Simplification proposal rejected.','Nested-list round-trip test added.','Round-trip scope broadened; empty-file test separately added.','Comparison-method question added; secret-free requirement unchanged.'],
23:['Staging-only plan and manual approval preserved.','Screenshot candidate uncertain.','Per-stage screenshots confirmed on same record.','Assistant completion does not cancel scope.','Withdraw screenshots only.'],
24:['Workshop task and Jun code checklist distinct.','Bea owns failed-experiment examples.','Quiet-room candidate has unknown owner and need.','Bea confirms both owner and adoption.','Only Jun material broadens to environment details.'],
25:['Production plan, quantity and binding separate.','Settled page-count conditional insert rule.','Thread stitching acceptance cites proposal and user, not assistant acknowledgement.','45 replaces 60 copies, conditional insert retained.','Different-zine quote explicitly disclaimed; no change.']}

source = STUDY / 'data/source/train-b.jsonl'
prompt = (STUDY / 'annotation/system_prompt.txt').read_text(encoding='utf-8').strip()
families = [json.loads(line) for line in source.read_text(encoding='utf-8').splitlines()]
reviewed = {}
for family in families:
    number = int(family['family_id'].rsplit('-', 1)[1])
    rows = materialize(family, prompt)
    decisions = []
    for i, row in enumerate(rows):
        assert len(NOTES[number]) == 5
        source_seqs = sorted({s for op in row['target']['operations'] for s in op['source_seqs']})
        decisions.append({'decision_index': i, 'example_id': row['example_id'], 'verdict': 'accept',
                          'semantic_review_note': NOTES[number][i],
                          'checks': ['all new requests accounted for', 'scope/strength/owner supported',
                                     'no unsupported changes', 'unchanged constraints retained',
                                     'status and stable-ID transitions appropriate', 'arrived evidence only'],
                          'supporting_events': [e for e in row['input']['conversation'] if e['seq'] in source_seqs],
                          'runtime_replay': 'passed', 'preserved_ids_checked': row['preserve_ids'],
                          'expected_semantic_state': row['expected_semantic_state']})
    reviewed[family['family_id']] = {'family_sha256': hashlib.sha256(encode(family).encode()).hexdigest(),
                                   'author': '/root/tracker_annotation_v2', 'reviewer': '/root',
                                   'independent_of_author': True, 'verdict': 'accept',
                                   'decisions_reviewed': 5, 'decisions': decisions}
report = {'status': 'accepted_after_corrections', 'date': '2026-10-24',
          'kind': 'independent model semantic review, not human review or model-output evaluation',
          'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
          'system_prompt_sha256': hashlib.sha256((STUDY/'annotation/system_prompt.txt').read_bytes()).hexdigest(),
          'reviewer': '/root', 'families': reviewed, 'total_decisions': 125,
          'initial_findings': [{'family': 'train-b-008', 'decision_index': 2, 'error': 'missed durable negative scope', 'resolved': True},
                               {'family': 'train-b-014', 'decision_index': 2, 'error': 'lost short qualifier during format revision', 'resolved': True}],
          'prior_source_and_changes': 'data/authoring/train-b-revisions.json',
          'limitation': 'Synthetic evidence-based annotation under the frozen convention; external human validation absent.'}
(HERE / 'train-b-review.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'status': report['status'], 'families': len(reviewed), 'decisions': 125, 'source_sha256': report['source_sha256']}))
