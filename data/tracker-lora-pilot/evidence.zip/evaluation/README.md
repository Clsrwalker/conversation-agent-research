# Tracker LoRA evaluation protocol

2026-10-24（America/Halifax）。当前文件已由 root 审阅，是否冻结及确切版本以 `protocol-lock.json` 为准。冻结不代表正式评测已经运行，也不代表 LoRA 有收益。

同一个 Qwen2.5-14B-Instruct NF4 对象做 adapter off/on 对照，每组 100 次单步更新。共享 tracker system prompt、2048 输入上限、512 输出上限、greedy 解码和 dynamic cache。100 个更新来自 20 个独立保留场景，其中 90 个普通前态、10 个错误文本前态。训练固定 1 epoch；测试不用于选 checkpoint。

评估分两层。`IntentStore` 真实回放检查补丁是否合法；匿名复核依据原对话检查意思是否正确。错误 JSON 或非法补丁保持前态，仍纳入分母。合法但遗漏新增要求的补丁也会被语义复核记错。等价改写和新 ID 的不同命名不能因字符串不同而算错；已有 ID 的错误替换另计身份保持问题。

本试验把已独立复核的 intention record 作为原子评分单位。某个要求完全缺席记 omission；同一要求的条件、值、范围、否定或强度遗漏记 wrong_value。必须同时报告完整正确覆盖率、错误值/owner/status、旧约束丢失、误撤销、误加、不确定变 active、无变化误改和原文证据错误，不能只挑遗漏率一个数字。

## Commands

These commands are offline except for the separate collector. They do not load or call a model. Run from the repository root; use a new output directory for each blind preparation. Do not invoke Python with `-O` or `-OO`.

```powershell
& 'experiments/deep_conversation/.venv/Scripts/python.exe' -B 'experiments/deep_conversation/tracker_lora/evaluate_tracker.py' fixtures --output 'output/research/2026-10-24/tracker-lora-pilot/evaluation/fixtures-final.json'
& 'experiments/deep_conversation/.venv/Scripts/python.exe' -B 'experiments/deep_conversation/tracker_lora/evaluate_tracker.py' check-inputs --records 'output/research/2026-10-24/tracker-lora-pilot/data/compiled/test.records.jsonl' --output 'output/research/2026-10-24/tracker-lora-pilot/evaluation/input-reconstruction.json'
```

After root review, before test collection:

```powershell
& 'experiments/deep_conversation/.venv/Scripts/python.exe' -B 'experiments/deep_conversation/tracker_lora/evaluate_tracker.py' freeze --protocol 'output/research/2026-10-24/tracker-lora-pilot/evaluation/protocol.json' --records 'output/research/2026-10-24/tracker-lora-pilot/data/compiled/test.records.jsonl' --manifest 'output/research/2026-10-24/tracker-lora-pilot/data/compiled/manifest.json' --system-prompt 'output/research/2026-10-24/tracker-lora-pilot/annotation/system_prompt.txt' --output '<new protocol-lock.json>'
```

After all 200 assigned collection records exist, including failed records:

```powershell
& 'experiments/deep_conversation/.venv/Scripts/python.exe' -B 'experiments/deep_conversation/tracker_lora/evaluate_tracker.py' prepare --lock '<protocol-lock.json>' --outputs '<collection/outputs.jsonl>' --collection-config '<collection/collection-config.json>' --output '<new blind-review directory>'
```

Give reviewers only `review-packets.json` and a copy of `review-template.json`. Keep `PRIVATE-mapping.json` and `PRIVATE-runtime-results.json` private until all judgments are adjudicated. Preserve the untouched original template; put completed reviews in a different file. The template names every required reference unit and asks for semantic matches, owner/status judgments, a rationale, false extras, identity errors and `source_error_operation_indices`. Initial uncertain judgments must remain `needs_adjudication`; the scorer accepts only adjudicated final judgments. Model review is not described as human annotation.

```powershell
& 'experiments/deep_conversation/.venv/Scripts/python.exe' -B 'experiments/deep_conversation/tracker_lora/evaluate_tracker.py' score --prepared '<blind-review directory>' --judgments '<final-adjudicated-judgments.json>' --output '<new results.json>'
```

Quality denominators include invalid and failed outputs. Cost summaries include completed generations and separately count failures. The primary confidence interval resamples the 20 paired families, not 100 supposedly independent updates. Ordinary/fault and Chinese/English results are descriptive subgroups with small sample counts.

## Limits

One-step evaluation supplies a compiled prior state at every decision, so model errors do not accumulate across turns. The protocol separately plans own-state rollout, using each arm's own prior state without replacing it with gold. That phase, chat/work integration, long real conversations and final answer benefits have not been measured here. Passing the offline acceptance fixtures establishes evaluator behavior, not tracking quality.
