"""Run the predeclared local-model web integration diagnostics sequentially."""
import argparse
import json
from pathlib import Path
import time
from urllib.request import Request, urlopen
import uuid

ROOT = Path(__file__).resolve().parents[3]
RECORDS = ROOT / 'output/research/records/question-diagnostics'
parser = argparse.ArgumentParser()
parser.add_argument('--revision', default='v1')
revision = parser.parse_args().revision
if not revision.isalnum():
    raise ValueError('Use an alphanumeric diagnostic revision.')
plan = json.loads((RECORDS / 'web-knowledge-plan.json').read_text())
out = RECORDS / f'web-knowledge-runs-{revision}.json'
if out.exists():
    raise FileExistsError(f'Retain the existing diagnostic: {out}')
BASE = 'http://127.0.0.1:8769'

def request(path, value=None, token=None):
    headers = {} if value is None else {'Content-Type': 'application/json', 'Origin': BASE, 'X-Lab-Token': token}
    with urlopen(Request(BASE + path, data=None if value is None else json.dumps(value).encode(), headers=headers), timeout=20) as response:
        return json.load(response)

config = request('/api/lab/config')
assert config['capabilities']['web_retrieval']
assert config['preflight']['model']['digest'] == plan['model_digest']
result = {'plan': plan, 'revision': revision, 'runs': []}
out.write_text(json.dumps(result, indent=2) + '\n')
for case in plan['cases']:
    payload = {key: case[key] for key in ('harness', 'question', 'documents')}
    payload['request_id'] = 'web-knowledge-' + uuid.uuid4().hex
    job = request('/api/lab/runs', payload, config['csrf_token'])
    start = time.monotonic()
    while True:
        detail = request('/api/lab/runs/' + job['id'])
        if detail['job']['status'] not in {'starting', 'running'}:
            break
        if time.monotonic() - start > 600:
            raise TimeoutError(job['id'])
        time.sleep(2)
    entry = {'case': case, 'job_id': job['id'], 'status': detail['job']['status'], 'response': detail.get('direct_response')}
    result['runs'].append(entry)
    out.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps(entry, ensure_ascii=False), flush=True)
    if entry['status'] != 'completed':
        raise RuntimeError(f"Worker failed: {job['id']}; stop batch and retain output.")
