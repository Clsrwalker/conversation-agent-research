"""Export exposed web diagnostics with verified totals; retain earlier failures."""
import hashlib
import html
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[2]
EXP = ROOT / 'experiments/deep_conversation'
SITE = ROOT / 'sites/conversation-agent-research'
DEST = SITE / 'dist/data'
RECORDS = ROOT / 'output/research/records/question-diagnostics'


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def public_receipt(receipt):
    result = dict(receipt['result'])
    # Keep full fetched text in the original local run. The website exports
    # identifiers, hashes and statuses, not full copies of third-party pages.
    result.pop('text', None)
    result.pop('excerpt', None)
    if 'sources' in result:
        result['sources'] = [{k: v for k, v in source.items() if k not in {'text', 'snippet', 'excerpt'}}
                             for source in result['sources']]
    return {k: receipt[k] for k in ('call_id', 'name', 'args')} | {'result': result}


all_runs = []
reviews = []
for revision in ('v1', 'v2', 'v3', 'v4'):
    batch = read(RECORDS / f'web-knowledge-runs-{revision}.json')
    review = read(RECORDS / f'web-knowledge-review-{revision}.json')
    assert len(batch['runs']) == 6
    reviews.append(review)
    for row in batch['runs']:
        folder = EXP / 'runs' / ('lab-' + row['job_id'])
        summary = read(folder / 'summary.json')
        calls = read(folder / 'model_calls.json')
        receipts = read(folder / 'tool_calls.json')
        model_tool_errors = {}
        for call in calls:
            for messages in call['request']:
                for message in messages:
                    if message.get('type') != 'tool':
                        continue
                    try:
                        payload = json.loads(message.get('content', ''))
                    except (ValueError, TypeError):
                        payload = {}
                    if message.get('status') == 'error' or (isinstance(payload, dict) and payload.get('status') == 'error'):
                        model_tool_errors[message['tool_call_id']] = {
                            'name': message.get('name'), 'content': message.get('content'),
                            'receipt_present': any(r['call_id'] == message['tool_call_id'] for r in receipts)}
        provenance = read(folder / 'lab_provenance.json')
        response = read(folder / 'direct_response.json')
        assert row['response'] == response
        assert provenance['actual_local_model']['digest'] == batch['plan']['model_digest']
        assert provenance['task_adapter']['id'] == f'direct-question-web-{revision}'
        assert len(calls) == summary['model_calls']
        assert sum(c['total_tokens'] for c in calls) == summary['token_usage']['total_tokens']
        assert abs(sum(c['wall_ms'] for c in calls) - summary['api_wall_ms']) < .02
        web = [receipt for receipt in receipts if receipt['name'] in {'web_search', 'read_web_page'}]
        all_runs.append({
            'revision': revision, 'case': row['case'], 'job_id': row['job_id'],
            'model_calls': summary['model_calls'], 'total_tokens': summary['token_usage']['total_tokens'],
            'model_wall_ms': summary['api_wall_ms'],
            'web_tool_wall_ms': round(sum(r['result'].get('wall_ms', 0) for r in web), 3),
            'searches': sum(r['name'] == 'web_search' for r in web),
            'page_reads': sum(r['name'] == 'read_web_page' for r in web),
            'successful_page_reads': sum(r['name'] == 'read_web_page' and r['result'].get('status') == 'read' for r in web),
            'web_errors': sum(r['result'].get('status') == 'error' for r in web),
            'response': response, 'review': review['cases'][row['case']['id']],
            'tools': [public_receipt(receipt) for receipt in receipts],
            'model_visible_tool_errors': model_tool_errors,
            'provenance': {k: provenance[k] for k in ['input_mode', 'harness', 'source', 'task_adapter', 'actual_local_model', 'source_fingerprint']},
            'record_hashes': {name: sha(folder / name) for name in ['summary.json', 'model_calls.json', 'tool_calls.json', 'direct_response.json', 'lab_provenance.json']}
        })

validation = {
    'id': 'shared-web-knowledge-tools', 'date': '2026-10-10', 'timezone': 'America/Halifax',
    'type': 'engineering_validation_and_exposed_diagnostics',
    'status': 'implemented_with_narrow_model_diagnostics',
    'problem': 'The local model guessed unfamiliar terminology or asked for context, with no real web tool available in direct-question tests.',
    'change': 'Shared DDGS search and public HTML/text reading in all four question harnesses, with source receipts, persisted operation limits, a shorter knowledge-investigation prompt and a question-only profile that hides unrelated virtual file tools. No semantic delivery gate or fixed response schema.',
    'conditions': read(RECORDS / 'web-knowledge-plan.json'),
    'offline_checks': {'web_tools': 21, 'direct_request': 27, 'lab_api': 31, 'lab_worker': 9, 'graph_mapping': 48,
                       'result': 'passed', 'interpretation': 'Software behavior checks, not answer quality.'},
    'diagnostic_runs': len(all_runs), 'paid_model_api_calls': 0,
    'provider_smoke': {'query': 'agent harness LLM', 'bing_results': 5,
                       'duckduckgo': 'DDGSException: No results found.',
                       'original_sha256': sha(RECORDS / 'web-provider-smoke.json')},
    'reader_smoke': {'successful_pages': ['https://www.langchain.com/blog/the-anatomy-of-an-agent-harness',
                                        'https://handbook.modular.com/model-interaction/agent-harnesses/'],
                     'original_sha256': sha(RECORDS / 'web-page-smoke.json')},
    'browser_checks': {'date': '2026-10-10', 'status': 'pass',
                       'run_id': 'e91fa27548e5432a99932762a537bf92',
                       'checks': ['Final response matches the saved response', 'Web branch is observed for the actual search',
                                  'Model calls 2, tokens 2839 and model time 7.24 s match the ledger',
                                  'New profile shows private notes; recorded historical profiles remain distinct',
                                  'Research page shows latest six runs and keeps earlier 18 in a disclosure']},
    'outcomes_by_revision': {version: {outcome: sum(r['revision'] == version and r['review']['outcome'] == outcome for r in all_runs)
                                     for outcome in ['met target', 'partial', 'failed']} for version in ['v1', 'v2', 'v3', 'v4']},
    'evidence': 'web-knowledge-diagnostics.json', 'source_download': 'web-knowledge-source.zip',
    'limitations': [
        'Exposed development questions, one run per configuration/case/revision, unblinded assistant review. No accuracy estimate or stable reliability claim.',
        'The shared task prompt and tool availability change together against the earlier no-web implementation. Live results vary; this is not an isolated orchestration comparison.',
        'Eight persisted web-tool attempts are not eight HTTP requests; redirects and fallback searches may make more requests.',
        'Bing succeeded in the provider smoke check; DuckDuckGo returned no usable results. Provider availability is not guaranteed.',
        'Public HTML/text only. No PDF parsing, authenticated pages or browser JavaScript rendering. Pages can be truncated at 10,000 characters.',
        'OS DNS resolution is not hard-interrupt bounded; seven-second network deadlines are per hop, not a total run SLA.',
        'Source retrieval and citations do not establish that every claim is supported. Web errors remain visible; the agent decides what to do next.',
        'The progress projection still summarizes the original local-source jobs; web receipts and activity are visible separately, but no progress-feedback benefit is established.',
        'No real ASR, live conversation, user study or speed benefit is tested. Historical baseline scores remain unchanged.'
    ]
}

files = [EXP / name for name in [
    'direct_request.py', 'web_tools.py', 'lab_worker.py', 'lab.py', 'requirements.txt', 'requirements.lock.txt',
    'test_direct_request.py', 'test_web_tools.py', 'test_lab_worker.py', 'test_lab.py',
    'build_lab_ui.py', 'lab_ui/harness-graph.js', 'lab_ui/lab-app.js', 'lab_ui/lab.js',
    'lab_ui/index.html', 'lab_ui/lab.css', 'tests/test_harness_graph.cjs']]
files += [ROOT / 'scripts/research/diagnostics/run_web_knowledge_checks.py', Path(__file__)]
files += [RECORDS / name for name in ['web-tools-unit-tests.txt', 'web-tools-v2-unit-tests.txt',
                                    'web-tools-v3-unit-tests.txt', 'web-tools-v4-direct-tests.txt',
                                    'web-lab-unit-tests.txt', 'web-graph-unit-tests.txt']]
validation['source_sha256'] = {p.relative_to(ROOT).as_posix(): sha(p) for p in files}
with zipfile.ZipFile(DEST / 'web-knowledge-source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in files:
        archive.write(path, path.relative_to(ROOT).as_posix())
    archive.writestr('checksums.json', json.dumps(validation['source_sha256'], indent=2))
write(DEST / 'web-knowledge-diagnostics.json', {'date': validation['date'], 'plan': validation['conditions'], 'reviews': reviews,
                                             'runs': all_runs, 'export_note': 'Full third-party page text and private model request logs are excluded; original local run hashes are preserved.'})
write(DEST / 'web-knowledge-validation.json', validation)
feature_path = DEST / 'harness-run-lab-validation.json'
feature = read(feature_path)
feature['web_knowledge_followup'] = {'date': validation['date'], 'record': 'web-knowledge-validation.json',
                                   'diagnostics': 'web-knowledge-diagnostics.json'}
write(feature_path, feature)

def result_table(selected, caption):
    rows = '\n'.join('<tr>' + ''.join(f'<td>{html.escape(str(value))}</td>' for value in [
        r['revision'], r['case']['id'], r['model_calls'], r['total_tokens'],
        f"{r['model_wall_ms']/1000:.2f} s", f"{r['searches']} / {r['successful_page_reads']}", r['review']['outcome']]) + '</tr>' for r in selected)
    return '<div class="table-scroll"><table><caption>' + caption + '</caption><thead><tr><th>Revision</th><th>Check</th><th>Calls</th><th>Tokens</th><th>Model time</th><th>Search / read</th><th>Review</th></tr></thead><tbody>' + rows + '</tbody></table></div>'
fragment = '''<!-- web-knowledge:start -->
      <section class="home-test-records" id="web-knowledge"><h2>Knowledge questions can now use the web</h2>
      <p>10 Oct 2026 · Engineering integration and exposed development checks.</p>
      <p>The local model previously guessed what “agent harness” meant or asked for context. All four question configurations now have real web search and page reading. The model chooses queries and sources; the runtime records results, failures and source URLs. Supplied-document questions keep their separate local tools.</p>
      <p>The first six checks exposed a remaining decision problem: two harness explanations used only search snippets, two still asked for context without searching, and the MCP answer omitted citations. The supplied-only calculation succeeded. Shortening the shared prompt in v2 did not resolve the reported concept. In v3, we hid seven unrelated virtual file tools; the concept checks still failed. In v4, a shorter research-first prompt replaced repeated clarification language. The original replay runner and frozen source were unchanged. All four revisions are retained below.</p>
      <p><strong>Latest result:</strong> all four configurations searched for the reported concept and explained the intended LLM, tool and state-management meaning. None opened a page in those four runs, so all remain <em>partial</em> under the original checks. Some answers also overstated safety guarantees. MCP met its narrower check, and the supplied-only calculation returned 270 without web access. Each calculation case still encountered a tool-input error; the correct final value does not establish a reliable calculation interface.</p>
      ''' + result_table([r for r in all_runs if r['revision'] == 'v4'], 'Latest diagnostic: v4') + '''
      <details class="disclosure"><summary>Earlier revisions: all 18 development runs</summary>''' + result_table([r for r in all_runs if r['revision'] != 'v4'], 'Previous failures remain part of the record') + '''</details>
      <p>“Read” counts successful page reads; model time excludes web-tool time and is not end-to-end latency. The download includes separate web timings and errors. “Met target” uses the predeclared case checks, not a research quality score. These repeated development questions do not establish general reliability or a harness ranking.</p>
      <p><strong>Engineering checks:</strong> 21 web-tool, 27 question-runtime, 31 Lab API, 9 worker and 48 graph-mapping checks passed. The local monitor shows actual search and page-read events in a separate branch. This validates plumbing and observation, not the truth of generated answers.</p>
      <p><strong>Limits:</strong> searches depend on public providers; the DuckDuckGo smoke check returned no usable result. Only public HTML/text is supported. Eight web-tool attempts are allowed per run; redirects and fallback engines can make more HTTP requests. No ASR, real-user benefit or speed improvement is claimed.</p>
      <div class="evidence-downloads"><a href="data/web-knowledge-diagnostics.json" download>All revisions, responses and tool records ↓</a><a href="data/web-knowledge-validation.json" download>Checks and limitations ↓</a><a href="data/web-knowledge-source.zip" download>Web tools and adapter source ↓</a></div></section>
      <!-- web-knowledge:end -->'''
path = SITE / 'methods-section.html'
content = path.read_text(encoding='utf-8')
if '<!-- web-knowledge:start -->' in content:
    start = content.index('<!-- web-knowledge:start -->')
    end = content.index('<!-- web-knowledge:end -->') + len('<!-- web-knowledge:end -->')
    content = content[:start] + fragment + content[end:]
else:
    content = content.replace('<!-- question-task-v3:start -->', fragment + '\n      <!-- question-task-v3:start -->', 1)
content = content.replace('Every harness now tests direct questions', 'Earlier repair: a shared question contract')
content = content.replace('Engineering validation · Answer quality remains unresolved.', 'Engineering validation before web integration · Original failures retained.')
content = content.replace('The concept answer is still incorrect.', 'Before web integration, the concept answer was still incorrect.')
content = content.replace('There is still no live web retrieval to fill the knowledge gap.', 'Those runs did not yet have live web retrieval to fill the knowledge gap.')
path.write_text(content, encoding='utf-8')
overview = SITE / 'overview-section.html'
text = overview.read_text(encoding='utf-8')
text = text.replace('All four test configurations accept direct questions.', 'All four test configurations accept direct questions and can search and read public web sources.')
text = text.replace('No live web retrieval or deployed user-assistance interface.', 'Web retrieval is available in question tests; no deployed live-assistance interface.')
overview.write_text(text, encoding='utf-8')
print(json.dumps({'runs': len(all_runs), 'outcomes': validation['outcomes_by_revision'], 'website': str(SITE)}))
