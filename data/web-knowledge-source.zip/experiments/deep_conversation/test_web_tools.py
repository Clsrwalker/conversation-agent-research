"""Offline web adapter tests; no search provider, public page, or LLM is called."""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import socket
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from langgraph.checkpoint.sqlite import SqliteSaver

from agent import RunContext
from config import Settings
from direct_request import build_direct_request_graph
from test_agent import fixture_case
from test_direct_request import DirectModel
import web_tools as web
from world import WorldStore


PUBLIC_IP = '93.184.216.34'


class FakeSocket:
    def __init__(self):
        self.timeouts = []

    def settimeout(self, timeout):
        self.timeouts.append(timeout)


class FakeResponse:
    def __init__(self, status=200, headers=None, body=b'Public readable text. ' * 4,
                 clock=None, step=0, chunk_size=None):
        self.status = status
        self.headers = headers or {'Content-Type': 'text/plain'}
        self.body = body
        self.reads = 0
        self.clock, self.step, self.chunk_size = clock, step, chunk_size

    def getheader(self, name, default=None):
        return self.headers.get(name, default)

    def read1(self, count):
        self.reads += 1
        if self.clock is not None:
            self.clock[0] += self.step
        if self.chunk_size:
            count = min(count, self.chunk_size)
        block, self.body = self.body[:count], self.body[count:]
        return block

    def read(self, count):
        raise AssertionError('Large blocking read must not bypass the deadline.')


class FakeConnection:
    def __init__(self, host, port, timeout, response):
        self.host, self.port, self.timeout = host, port, timeout
        self.response, self.sock = response, None
        self.closed = False

    def request(self, method, path, headers):
        self.requested = method, path, headers
        self.sock = self._create_connection((self.host, self.port), self.timeout)

    def getresponse(self):
        return self.response

    def close(self):
        self.closed = True


class WebToolsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.case = fixture_case(close=10000, events=[
            {'at_ms': 0, 'kind': 'utterance', 'speaker': 'User', 'text': 'Explain a technical concept.'}])
        self.case.update(corpus_ids=[], input_mode='direct_request')
        self.world = WorldStore(self.root / 'world.sqlite', self.case, [])
        self.network = patch.object(socket.socket, 'connect', side_effect=AssertionError('Unexpected real network'))
        self.network.start()

    def tearDown(self):
        self.world.close()
        self.network.stop()
        self.temp.cleanup()

    def fetch(self, responses, url='https://example.org/page', addresses=None, clock=None):
        connections = []

        def connection(host, port, timeout):
            item = FakeConnection(host, port, timeout, responses[len(connections)])
            connections.append(item)
            return item

        dns = addresses if addresses is not None else lambda host, port: [PUBLIC_IP]
        with patch.object(web, '_public_addresses', side_effect=dns), \
                patch.object(web.http.client, 'HTTPSConnection', side_effect=connection), \
                patch.object(web.http.client, 'HTTPConnection', side_effect=connection), \
                patch.object(web.socket, 'create_connection', return_value=FakeSocket()) as connect:
            if clock is None:
                result = web._get_page(url)
            else:
                with patch.object(web.time, 'monotonic', side_effect=lambda: clock[0]):
                    result = web._get_page(url)
        return result, connections, connect

    @staticmethod
    def search_result(url='https://example.org/reference'):
        return {'status': 'results', 'provider': 'scripted', 'sources': [
            {'source_id': 'web-test', 'url': url, 'title': 'Reference', 'snippet': 'A locator snippet.'}]}

    @staticmethod
    def page_result(url='https://example.org/reference'):
        return {'status': 'read', 'source_id': 'web-test', 'url': url, 'title': 'Reference',
                'text': 'Retrieved source body for offline protocol tests.', 'content_sha256': 'test-digest'}

    def test_url_normalizes_public_addresses_and_rejects_private_or_credential_urls(self):
        self.assertEqual(web._url('https://EXAMPLE.org:443/a b?x=y z#frag'), 'https://example.org/a%20b?x=y%20z')
        self.assertEqual(web._url('https://[2001:4860:4860::8888]/'), 'https://[2001:4860:4860::8888]/')
        for value in ['file:///secret', 'http://localhost/x', 'http://127.0.0.1/',
                      'http://10.0.0.1/', 'http://169.254.169.254/', 'https://[::1]/',
                      'https://user:pass@example.org/', 'http://example.org:8080/',
                      'http://intranet/', 'http://host.internal/', 'https://example.org/\nheader',
                      'http://example.org\\@127.0.0.1/']:
            with self.subTest(url=value), self.assertRaises((ValueError, UnicodeError)):
                web._url(value)

    def test_dns_rejects_mixed_public_and_private_results(self):
        public = (socket.AF_INET, socket.SOCK_STREAM, 6, '', (PUBLIC_IP, 443))
        private = (socket.AF_INET, socket.SOCK_STREAM, 6, '', ('127.0.0.1', 443))
        with patch.object(web.socket, 'getaddrinfo', return_value=[public, private]):
            with self.assertRaisesRegex(ValueError, 'private or reserved'):
                web._public_addresses('example.org', 443)
        with patch.object(web.socket, 'getaddrinfo', return_value=[public, public]):
            self.assertEqual(web._public_addresses('example.org', 443), [PUBLIC_IP])

    def test_checked_ip_is_pinned_while_connection_keeps_tls_hostname(self):
        result, connections, connect = self.fetch([FakeResponse()])
        self.assertEqual(result[0], 'https://example.org/page')
        self.assertEqual(connections[0].host, 'example.org')
        self.assertEqual(connect.call_args.args[0], (PUBLIC_IP, 443))
        self.assertTrue(connections[0].closed)
        self.assertEqual(connections[0].requested[0], 'GET')

    def test_public_redirect_revalidates_the_new_host(self):
        dns = Mock(side_effect=[[PUBLIC_IP], ['8.8.8.8']])
        result, connections, connect = self.fetch([
            FakeResponse(302, {'Location': 'https://other.example/new'}), FakeResponse()], addresses=dns)
        self.assertEqual(result[0], 'https://other.example/new')
        self.assertEqual([call.args[0] for call in dns.call_args_list], ['example.org', 'other.example'])
        self.assertEqual([call.args[0] for call in connect.call_args_list], [(PUBLIC_IP, 443), ('8.8.8.8', 443)])
        self.assertTrue(all(connection.closed for connection in connections))

    def test_redirect_to_literal_private_address_is_rejected_before_connect(self):
        with self.assertRaisesRegex(ValueError, 'private or reserved'):
            self.fetch([FakeResponse(302, {'Location': 'http://127.0.0.1/secret'})])

    def test_redirect_to_hostname_with_private_dns_is_rejected(self):
        def addresses(host, port):
            if host == 'other.example':
                raise ValueError('The URL resolves to a private or reserved address.')
            return [PUBLIC_IP]
        with self.assertRaisesRegex(ValueError, 'private or reserved'):
            self.fetch([FakeResponse(302, {'Location': 'https://other.example/secret'})], addresses=addresses)

    def test_redirect_limit_is_finite(self):
        with self.assertRaisesRegex(ValueError, 'redirect limit'):
            self.fetch([FakeResponse(302, {'Location': '/again'}) for _ in range(4)])

    def test_page_rejects_oversize_nontext_encoding_and_http_errors(self):
        for response, message in [
            (FakeResponse(body=b'x' * 17), 'download limit'),
            (FakeResponse(headers={'Content-Type': 'application/pdf'}), 'not PDFs'),
            (FakeResponse(headers={'Content-Type': 'text/plain', 'Content-Encoding': 'gzip'}), 'encoding'),
            (FakeResponse(status=404), 'HTTP 404')]:
            with self.subTest(message=message), patch.object(web, 'MAX_BYTES', 16), self.assertRaisesRegex(ValueError, message):
                self.fetch([response])

    def test_small_trickles_are_interrupted_by_read_deadline(self):
        clock = [0]
        response = FakeResponse(body=b'x' * 30, clock=clock, step=4, chunk_size=1)
        with self.assertRaisesRegex(TimeoutError, 'deadline'):
            self.fetch([response], clock=clock)
        self.assertEqual(response.reads, 2)

    def test_html_extraction_removes_chrome_and_separates_minified_blocks(self):
        title, text = web._extract(
            b'<html><head><title>Reference</title><style>HIDDEN_STYLE</style></head><body>'
            b'<nav>HIDDEN_NAV</nav><p>First paragraph.</p><p>Second paragraph.</p>'
            b'<script>HIDDEN_SCRIPT</script><footer>HIDDEN_FOOTER</footer></body></html>', 'text/html')
        self.assertEqual(title, 'Reference')
        self.assertIn('First paragraph.\nSecond paragraph.', text)
        self.assertNotIn('HIDDEN_', text)

    def test_page_receipt_bounds_text_and_hashes_received_content(self):
        body = b'An explanatory source body. ' * 10
        with patch.object(web, '_get_page', return_value=('https://example.org/final', 'text/plain', body)), \
                patch.object(web, 'MAX_TEXT', 25):
            result = web._page('https://example.org/start')
        self.assertEqual(len(result['text']), 25)
        self.assertTrue(result['truncated'])
        self.assertEqual(result['content_sha256'], hashlib.sha256(body).hexdigest())
        self.assertEqual(result['bytes_received'], len(body))
        self.assertEqual(result['requested_url'], 'https://example.org/start')

    def test_search_records_fallback_and_skips_bad_duplicate_and_excess_hits(self):
        engines, backends = [], []

        class Engine:
            def __init__(self, timeout, verify):
                self._proxy = 'environment-proxy'
                self.timeout, self.verify = timeout, verify
                engines.append(self)

            def text(self, query, max_results, backend):
                backends.append(backend)
                if backend == 'bing':
                    raise TimeoutError('fixture failure')
                return [None, {'href': 'http://127.0.0.1/'},
                        {'href': 'https://example.org/0'}, {'href': 'https://example.org/0#duplicate'},
                        *({'href': f'https://example.org/{index}', 'title': 'Reference', 'body': 'Snippet'}
                          for index in range(1, 15))]

        with patch.dict(sys.modules, {'ddgs': SimpleNamespace(DDGS=Engine)}):
            result = web._search('a public concept')
        self.assertEqual(backends, ['bing', 'duckduckgo'])
        self.assertTrue(all(engine._proxy is None and engine.verify for engine in engines))
        self.assertEqual(result['provider'], 'duckduckgo')
        self.assertEqual([row['status'] for row in result['provider_attempts']], ['error', 'results'])
        self.assertEqual(len(result['sources']), web.MAX_RESULTS)
        self.assertEqual(len({row['url'] for row in result['sources']}), web.MAX_RESULTS)

    def test_search_empty_results_are_explicit_without_invented_sources(self):
        factory = Mock(return_value=SimpleNamespace(text=Mock(return_value=[])))
        with patch.dict(sys.modules, {'ddgs': SimpleNamespace(DDGS=factory)}):
            result = web._search('unknown')
        self.assertEqual(result['status'], 'error')
        self.assertNotIn('sources', result)
        self.assertEqual([row['status'] for row in result['provider_attempts']], ['empty', 'empty'])

    def test_completed_receipt_is_reused_after_world_reopen_without_request(self):
        operation = Mock(side_effect=lambda: self.search_result())
        first = web._execute(self.world, 'one', 'web_search', {'query': 'topic'}, operation)
        self.world.close()
        self.world = WorldStore(self.root / 'world.sqlite')
        second = web._execute(self.world, 'one', 'web_search', {'query': 'topic'}, operation)
        self.assertEqual(first, second)
        operation.assert_called_once()
        self.assertEqual(sum(row['kind'] == 'web_request_reserved' for row in self.world.export()['environment_log']), 1)

    def test_eight_attempt_budget_survives_reopen_and_blocked_receipt_is_cached(self):
        operation = Mock(side_effect=lambda: self.search_result())
        for index in range(web.MAX_REQUESTS):
            web._execute(self.world, str(index), 'web_search', {'query': f'topic-{index}'}, operation)
        self.world.close()
        self.world = WorldStore(self.root / 'world.sqlite')
        result = web._execute(self.world, 'blocked', 'web_search', {'query': 'last'}, operation)
        again = web._execute(self.world, 'blocked', 'web_search', {'query': 'last'}, operation)
        self.assertEqual(result, again)
        self.assertEqual(operation.call_count, 8)
        self.assertEqual(result['status'], 'error')
        self.assertEqual(result['request_budget_unit'], 'web_tool_attempts')
        self.assertEqual(sum(row['kind'] == 'web_request_reserved' for row in self.world.export()['environment_log']), 8)

    def test_crash_before_receipt_retains_reservation_and_retry_consumes_attempt(self):
        with self.assertRaises(KeyboardInterrupt):
            web._execute(self.world, 'crashed', 'web_search', {'query': 'topic'}, Mock(side_effect=KeyboardInterrupt()))
        self.assertFalse(self.world.export()['tool_calls'])
        self.world.close()
        self.world = WorldStore(self.root / 'world.sqlite')
        web._execute(self.world, 'crashed', 'web_search', {'query': 'topic'}, lambda: self.search_result())
        self.assertEqual(sum(row['kind'] == 'web_request_reserved' for row in self.world.export()['environment_log']), 2)

    def test_errors_are_persisted_without_untrusted_exception_body(self):
        result = web._execute(self.world, 'error', 'read_web_page', {'url': 'https://example.org/'},
                              Mock(side_effect=OSError('PRIVATE_EXCEPTION_BODY')))
        self.assertEqual(result['status'], 'error')
        self.assertIn('OSError', result['error'])
        self.assertNotIn('PRIVATE_EXCEPTION_BODY', json.dumps(result))
        self.assertTrue(result['untrusted_data'])
        self.assertEqual(web.available_web_sources(self.world), [])

    def test_source_metadata_upgrades_to_page_and_excludes_body(self):
        web._execute(self.world, 'search', 'web_search', {'query': 'topic'}, lambda: self.search_result())
        web._execute(self.world, 'page', 'read_web_page', {'url': 'https://example.org/reference'}, lambda: self.page_result())
        web._execute(self.world, 'search-again', 'web_search', {'query': 'topic'}, lambda: self.search_result())
        sources = web.available_web_sources(self.world)
        self.assertEqual(len(sources), 1)
        self.assertEqual(sources[0]['level'], 'page')
        self.assertEqual(sources[0]['content_sha256'], 'test-digest')
        self.assertNotIn('text', sources[0])
        self.assertNotIn('snippet', sources[0])

    def test_tool_factory_is_network_free_and_runtime_is_not_a_model_parameter(self):
        with patch.object(web, '_search', side_effect=AssertionError('Unexpected search')), \
                patch.object(web, '_get_page', side_effect=AssertionError('Unexpected page')):
            tools = {item.name: item for item in web.make_web_tools(self.world, Settings())}
            self.assertEqual(set(tools), {'web_search', 'read_web_page'})
            self.assertEqual(tools['web_search'].tool_call_schema.model_json_schema()['required'], ['query'])
            self.assertEqual(tools['read_web_page'].tool_call_schema.model_json_schema()['required'], ['url'])
            response = json.loads(tools['web_search'].func(query=' ', runtime=SimpleNamespace(tool_call_id='blank')))
        self.assertEqual(response['status'], 'error')
        self.assertIn('1–300', response['error'])

    def test_real_tool_runtime_with_scripted_model_returns_sources_without_wait(self):
        model = DirectModel(scenario='web_retrieve')
        with patch.object(web, '_search', side_effect=lambda query: self.search_result()), \
                patch.object(web, '_page', side_effect=lambda url: self.page_result(url)), \
                SqliteSaver.from_conn_string(':memory:') as saver:
            graph, _, accounting = build_direct_request_graph(self.world, Settings(preset='agent-led'), saver, model=model)
            result = graph.invoke({'messages': [], 'event_cursor': -1},
                config={'configurable': {'thread_id': 'web'}, 'callbacks': [accounting]},
                context=RunContext(), durability='sync')
        self.assertEqual([row['name'] for row in self.world.export()['tool_calls']], ['web_search', 'read_web_page'])
        self.assertEqual(result['direct_response']['available_web_sources'][0]['level'], 'page')
        self.assertFalse(result['direct_response']['quality_evaluated'])

    def test_verified_frozen_world_supports_receipt_and_budget_interface(self):
        source = Path(__file__).parent / 'baselines/2026-10-07-agent-led-recovery-v1/source/experiments/deep_conversation/world.py'
        spec = importlib.util.spec_from_file_location('frozen_web_tools_test_world', source)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        world = module.WorldStore(self.root / 'frozen.sqlite', self.case, [])
        try:
            result = web._execute(world, 'frozen', 'web_search', {'query': 'topic'}, lambda: self.search_result())
            self.assertEqual(result['status'], 'results')
            self.assertEqual(web.available_web_sources(world)[0]['level'], 'snippet')
            self.assertEqual(sum(row['kind'] == 'web_request_reserved' for row in world.export()['environment_log']), 1)
        finally:
            world.close()


if __name__ == '__main__':
    unittest.main()
