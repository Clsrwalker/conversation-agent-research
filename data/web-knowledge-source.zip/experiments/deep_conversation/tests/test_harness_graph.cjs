'use strict';

// Offline presentation checks using metadata shaped like RuntimeMonitor callbacks.
// No model, browser, service, or production run is started by this test file.
const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Graph = require('../lab_ui/harness-graph.js');

const harnesses = ['native', 'agent-led', 'frozen-baseline', 'progress'];
const direct = harness => Graph.resolveTemplate({harness, input_mode:'direct_request', task_contract_version:3});
const legacy = harness => Graph.resolveTemplate({harness, input_mode:'human_human_transcript', task_contract_version:1});
const template = direct('agent-led');
const idList = value => Array.isArray(value) ? value.map(item => item.id) : Object.keys(value);
const topology = value => JSON.stringify({nodes:value.nodes, edges:value.edges});

function callback(seq, event, node, extra={}) {
  const nested = !['observe', 'investigate', 'consider_recovery', 'deliver_response'].includes(node);
  return {
    schema_version:1, seq, session_id:'session-a',
    timestamp:`2026-10-10T12:00:${String(seq).padStart(2,'0')}.000Z`,
    event, name:node, node, run_id:`${node}-call`,
    parent_run_id:nested?'investigator-run':'outer-run',
    graph_namespace:nested?`investigate:one|${node}:one`:`${node}:one`,
    graph_step:({observe:1,investigate:2,DirectEventBoundary_before_model:2,
      EventBoundary_before_model:2,model:3,tools:4,consider_recovery:3,deliver_response:4})[node.replaceAll('.','_')]||1,
    data:{}, ...extra,
  };
}

function packet(events=[], status={}) {
  return {
    run_id:'record-a',
    runtime:{events, next_seq:Math.max(0,...events.map(row=>row.seq||0)),
      status:{status:'running',session_id:'session-a',active_nodes:[],active_models:[],active_tools:[],...status}},
    world:{events:[],tool_receipts:[],pending_jobs:[]},
    graph:{status:'missing'},
  };
}

function project(events=[], options={}) {
  return Graph.project(options.template||template, {
    job:{id:'job-a',status:'running',harness:'agent-led',input_mode:'direct_request',...options.job},
    packet:options.packet||packet(events,options.status),
    live:options.live ?? true,
  }, options.previous||null);
}

function inactive(value) {
  assert.equal(value.activeCount,0);
  for (const node of Object.values(value.nodes)) assert.equal(node.active,false);
  assert.deepEqual(value.pulses,[]);
}

const observeStart=callback(1,'node_start','observe');
const observeEnd=callback(2,'node_end','observe');
const investigateStart=callback(3,'node_start','investigate');
const boundaryStart=callback(4,'node_start','DirectEventBoundary.before_model');
const boundaryEnd=callback(5,'node_end','DirectEventBoundary.before_model');
const modelStart=callback(6,'node_start','model');
const modelEnd=callback(9,'node_end','model');
const toolNodeStart=callback(10,'node_start','tools');
const searchStart=callback(11,'tool_start','tools',{name:'search',run_id:'search-call',parent_run_id:'tools-call'});
const searchEnd=callback(12,'tool_end','tools',{name:'search',run_id:'search-call',parent_run_id:'tools-call'});

test('four pre-run architectures are present and source mechanisms differ',()=>{
  const templates=harnesses.map(direct);
  assert.equal(new Set(templates.map(x=>x.id)).size,4);
  assert.equal(new Set(templates.map(topology)).size,4);
  for(const value of templates) {
    assert.equal(value.supported,true);
    assert.ok(idList(value.nodes).includes('model'));
    assert.ok(idList(value.nodes).includes('response'));
    assert.ok(value.edges.length>0);
  }
  assert.ok(!idList(direct('native').nodes).includes('calculate'));
  assert.ok(idList(direct('agent-led').nodes).includes('calculate'));
  assert.ok(!idList(direct('agent-led').nodes).includes('recovery'));
  assert.ok(idList(direct('frozen-baseline').nodes).includes('recovery'));
  assert.ok(!idList(direct('frozen-baseline').nodes).includes('progress'));
  assert.ok(idList(direct('progress').nodes).includes('progress'));
});

test('legacy replay and direct question delivery remain distinct',()=>{
  for(const harness of harnesses) {
    const current=direct(harness), archived=legacy(harness);
    assert.notEqual(current.id,archived.id);
    assert.ok(idList(archived.nodes).includes('publication'));
    assert.ok(!idList(archived.nodes).includes('response'));
    assert.ok(!idList(archived.nodes).includes('request-response'));
    assert.ok(!idList(current.nodes).includes('publication'));
  }
});

test('web architecture requires declared capability and is available to all four question harnesses',()=>{
  for(const harness of harnesses) {
    const current=Graph.resolveTemplate({harness,input_mode:'direct_request',task_contract_version:3,
      capabilities:{web_retrieval:true}});
    assert.equal(current.features.webRetrieval,true);
    assert.ok(idList(current.nodes).includes('web'));
    assert.ok(current.edges.some(edge=>edge.id==='tools--web'));
    assert.ok(!current.edges.some(edge=>edge.id==='web--observe'));
    assert.equal(direct(harness).features.webRetrieval,false);
    assert.ok(!idList(direct(harness).nodes).includes('web'));
    const replay=Graph.resolveTemplate({harness,input_mode:'human_human_transcript',
      capabilities:{web_retrieval:true}});
    assert.equal(replay.features.webRetrieval,false);
  }
});

test('saved web source fingerprints select web architecture without rewriting old direct records',()=>{
  const saved=Graph.resolveTemplate({harness:'agent-led',input_mode:'direct_request',
    source_fingerprint:{source_sha256:{'experiments/deep_conversation/web_tools.py':'recorded-source-hash'}}});
  assert.equal(saved.features.webRetrieval,true);
  const old=Graph.resolveTemplate({harness:'agent-led',input_mode:'direct_request',
    source_fingerprint:{source_sha256:{'experiments/deep_conversation/direct_request.py':'old-source-hash'}}});
  assert.equal(old.features.webRetrieval,false);
  assert.notEqual(saved.id,old.id);
});

test('older job metadata resolves conservatively, including the historical direct-help alias',()=>{
  assert.equal(Graph.resolveTemplate({harness:'agent-led'}).id,legacy('agent-led').id);
  assert.equal(Graph.resolveTemplate({harness:'direct-help'}).id,direct('agent-led').id);
  assert.equal(Graph.resolveTemplate({harness:'agent-led',input_mode:'unrecognized'}).supported,false);
});

test('unrecognized harnesses and future contracts do not borrow an incorrect graph',()=>{
  for(const request of [
    {harness:'unknown',input_mode:'direct_request',task_contract_version:3},
    {harness:'progress',input_mode:'direct_request',task_contract_version:99},
  ]) {
    const unsupported=Graph.resolveTemplate(request);
    assert.equal(unsupported.supported,false);
    assert.equal(unsupported.nodes.length,0);
    const value=project([modelStart],{template:unsupported});
    assert.deepEqual(Object.keys(value.nodes),[]);
    assert.deepEqual(Object.keys(value.edges),[]);
    assert.deepEqual(value.pulses,[]);
  }
});

test('running records and exported graph contents cannot grow or rewrite the architecture',()=>{
  const before=topology(template);
  const malicious=packet([observeStart,observeEnd,investigateStart,modelStart]);
  malicious.graph={record:{outer:{nodes:[{id:'invented-stage'}],edges:[]},investigator:{nodes:[],edges:[]}}};
  const previous=project([]), saved=JSON.stringify(previous);
  project([],{packet:malicious,previous});
  assert.equal(topology(template),before);
  assert.equal(JSON.stringify(previous),saved);
  assert.equal(topology(direct('agent-led')),before);
});

test('initial snapshots show history without replaying it as live animation',()=>{
  const value=project([observeStart,observeEnd,investigateStart]);
  assert.equal(value.nodes.observe.visits,1);
  assert.equal(value.nodes.investigate.visits,1);
  assert.deepEqual(value.pulses,[]);
});

test('only a new observed transition pulses and identical polling never repeats it',()=>{
  const previous=project([observeStart,observeEnd]);
  const events=[observeStart,observeEnd,investigateStart];
  const next=project(events,{previous});
  assert.ok(next.pulses.some(pulse=>pulse.edgeId==='observe--investigate'));
  assert.ok(next.edges['observe--investigate'].observed);
  const repeated=project(events,{previous:next});
  assert.deepEqual(repeated.pulses,[]);
  assert.equal(repeated.nodes.observe.visits,1);
  assert.equal(repeated.nodes.investigate.visits,1);
  assert.equal(repeated.cursor.maxSeq,next.cursor.maxSeq);
});

test('out-of-order and duplicate callbacks do not alter counts or observed routes',()=>{
  const events=[observeStart,observeEnd,investigateStart,boundaryStart,boundaryEnd,modelStart];
  const expected=project(events);
  const actual=project([modelStart,observeStart,boundaryEnd,investigateStart,observeEnd,boundaryStart,modelStart,observeStart]);
  assert.deepEqual(actual.nodes,expected.nodes);
  assert.deepEqual(actual.edges,expected.edges);
  assert.deepEqual(actual.cursor,expected.cursor);
});

test('older poll contents cannot lower the animation cursor',()=>{
  const previous=project([observeStart,observeEnd,investigateStart]);
  const value=project([observeStart],{previous});
  assert.ok(value.cursor.maxSeq>=previous.cursor.maxSeq);
  assert.deepEqual(value.pulses,[]);
});

test('partial polling windows retain earlier observed history without double-counting it',()=>{
  const previous=project([observeStart,observeEnd,investigateStart]);
  const next=project([boundaryStart,boundaryEnd,modelStart],{previous});
  assert.equal(next.nodes.observe.visits,1);
  assert.equal(next.nodes.investigate.visits,1);
  assert.equal(next.nodes.boundary.visits,1);
  assert.equal(next.nodes.model.visits,1);
  assert.equal(next.edges['observe--investigate'].observed,1);
  assert.ok(next.pulses.some(pulse=>pulse.edgeId==='boundary--model'));
  const repeated=project([observeStart,boundaryStart,modelStart],{previous:next});
  assert.equal(repeated.nodes.observe.visits,1);
  assert.equal(repeated.nodes.boundary.visits,1);
  assert.equal(repeated.nodes.model.visits,1);
  assert.equal(repeated.edges['observe--investigate'].observed,1);
  assert.deepEqual(repeated.pulses,[]);
});

test('cached partial history is not carried into another job or telemetry session',()=>{
  const previous=project([observeStart,observeEnd,investigateStart]);
  const anotherRun=project([modelStart],{previous,job:{id:'job-b'}});
  assert.equal(anotherRun.nodes.observe.visits,0);
  const anotherSession=project([{...modelStart,session_id:'session-b'}],{previous,status:{session_id:'session-b'}});
  assert.equal(anotherSession.nodes.observe.visits,0);
});

test('run switch and telemetry session switch never animate the old session',()=>{
  const previous=project([observeStart,observeEnd]);
  const newRun=project([observeStart,observeEnd,investigateStart],{previous,job:{id:'job-b'}});
  assert.deepEqual(newRun.pulses,[]);
  const newSession=project([observeStart,observeEnd,investigateStart].map(row=>({...row,session_id:'session-b'})),
    {previous,status:{session_id:'session-b'}});
  assert.deepEqual(newSession.pulses,[]);
});

test('unrelated graph contexts do not establish a sequential route',()=>{
  const start=callback(4,'node_start','DirectEventBoundary.before_model',{parent_run_id:'investigator-one'});
  const end=callback(5,'node_end','DirectEventBoundary.before_model',{parent_run_id:'investigator-one'});
  const unrelated=callback(6,'node_start','model',{parent_run_id:'investigator-two',graph_namespace:'investigate:two|model:one'});
  const value=project([start,end,unrelated],{previous:project([])});
  assert.ok(!value.edges['boundary--model']?.observed);
  assert.ok(!value.pulses.some(pulse=>pulse.edgeId==='boundary--model'));
});

test('missing intermediate callbacks do not animate an invented route',()=>{
  const value=project([observeStart,observeEnd,modelStart],{previous:project([])});
  assert.ok(value.nodes.model.visits);
  assert.ok(!value.edges['observe--investigate'].observed);
  assert.ok(!value.edges['boundary--model']?.observed);
  for(const pulse of value.pulses) assert.ok(value.edges[pulse.edgeId]?.observed);
});

test('an intervening unmapped graph node makes a direct sibling route unproven',()=>{
  const unknown=callback(3,'node_start','unknown_outer_stage',{
    parent_run_id:'outer-run',graph_namespace:'unknown_outer_stage:one',graph_step:2,
  });
  const next={...investigateStart,seq:5,graph_step:3};
  const value=project([observeStart,observeEnd,unknown,next],{previous:project([])});
  assert.ok(value.unsupported>0);
  assert.equal(value.edges['observe--investigate'].observed,0);
  assert.ok(!value.pulses.some(pulse=>pulse.edgeId==='observe--investigate'));
});

test('a tool callback after its recorded dispatch node ended does not establish dispatch',()=>{
  const ended={...toolNodeStart,seq:11,event:'node_end'};
  const late={...searchStart,seq:12};
  const value=project([toolNodeStart,ended,late],{previous:project([])});
  assert.equal(value.nodes.sources.visits,1);
  assert.equal(value.edges['tools--sources'].observed,0);
  assert.ok(!value.pulses.some(pulse=>pulse.edgeId==='tools--sources'));
});

test('direct and legacy boundary callbacks map to the boundary component',()=>{
  assert.equal(project([boundaryStart]).nodes.boundary.visits,1);
  const old=callback(4,'node_start','EventBoundary.before_model');
  assert.equal(project([old],{template:legacy('agent-led')}).nodes.boundary.visits,1);
});

test('a model provider callback does not double-count its enclosing graph node',()=>{
  const provider=callback(7,'model_start','model',{name:'ChatOllama',run_id:'provider-call',parent_run_id:'model-call'});
  const value=project([modelStart,provider],{status:{active_nodes:[modelStart],active_models:[provider]}});
  assert.equal(value.nodes.model.visits,1);
  assert.equal(value.nodes.model.active,true);
});

test('fresh runtime active tables identify active components and child tools',()=>{
  const value=project([investigateStart,toolNodeStart,searchStart],
    {status:{active_nodes:[investigateStart,toolNodeStart],active_tools:[searchStart]}});
  assert.equal(value.nodes.investigate.active,true);
  assert.equal(value.nodes.tools.active,true);
  assert.equal(value.nodes.sources.active,true);
  assert.ok(value.activeCount>0);
});

test('finished callbacks remain visited and no longer active',()=>{
  const value=project([searchStart,searchEnd]);
  assert.equal(value.nodes.sources.visits,1);
  assert.equal(value.nodes.sources.active,false);
});

test('actual tool names map to their source, event, working-state, and calculation components',()=>{
  const mappings={search:'sources',read_document:'sources',wait_for_event:'event-control',
    cancel_job:'event-control',save_notes:'working-state',read_file:'working-state',
    write_file:'working-state',calculate:'calculate'};
  for(const [name,id] of Object.entries(mappings)) {
    const start=callback(11,'tool_start','tools',{name,run_id:`${name}-call`,parent_run_id:'tools-call'});
    const value=project([start],{status:{active_tools:[start]}});
    assert.equal(value.nodes[id].visits,1,name);
    assert.equal(value.nodes[id].active,true,name);
  }
});

test('web callbacks use their own branch without becoming pending source jobs or waits',()=>{
  const selected=Graph.resolveTemplate({harness:'agent-led',input_mode:'direct_request',
    capabilities:{web_retrieval:true}});
  for(const name of ['web_search','read_web_page']) {
    const start=callback(11,'tool_start','tools',{name,run_id:`${name}-call`,parent_run_id:'tools-call'});
    const input=packet([toolNodeStart,start],{active_tools:[start]});
    input.world.pending_jobs=[{job_id:'local-document-job',status:'pending'}];
    const value=project([],{template:selected,packet:input});
    assert.equal(value.nodes.web.active,true,name);
    assert.equal(value.nodes.web.visits,1,name);
    assert.equal(value.nodes.web.pending,0,name);
    assert.equal(value.nodes.sources.pending,1,name);
    assert.equal(value.nodes.sources.visits,0,name);
    assert.equal(value.nodes['event-control'].visits,0,name);
    assert.equal(value.nodes['event-control'].active,false,name);
    assert.equal(value.edges['tools--web'].observed,1,name);
  }
});

test('synchronous web completion and failure clear activity without inventing observation routes',()=>{
  const selected=Graph.resolveTemplate({harness:'progress',input_mode:'direct_request',
    capabilities:{web_retrieval:true}});
  const start=callback(11,'tool_start','tools',{name:'read_web_page',run_id:'web-call',parent_run_id:'tools-call'});
  const end={...start,seq:12,event:'tool_end',data:{status:'read'}};
  const value=project([toolNodeStart,start,end],{template:selected});
  assert.equal(value.nodes.web.visits,1);
  assert.equal(value.nodes.web.active,false);
  assert.equal(value.nodes.web.pending,0);
  assert.equal(value.nodes.web.errors,0);
  assert.equal(value.nodes.observe.visits,0);
  assert.equal(value.edges['web--tools'].observed,0);
  const failed=project([toolNodeStart,start,{...end,data:{status:'error'}}],{template:selected});
  assert.equal(failed.nodes.web.errors,1);
  assert.equal(failed.nodes.recovery.visits,0);
});

test('web callbacks cannot retrofit capabilities into historical architectures',()=>{
  const start=callback(11,'tool_start','tools',{name:'web_search',run_id:'web-call',parent_run_id:'tools-call'});
  for(const selected of [direct('agent-led'),legacy('agent-led')]) {
    const value=project([toolNodeStart,start],{template:selected,status:{active_tools:[start]}});
    assert.ok(value.unsupported>0);
    assert.ok(!Object.hasOwn(value.nodes,'web'));
    assert.equal(value.nodes.sources.visits,0);
    assert.equal(value.nodes['event-control'].visits,0);
  }
});

test('direct question mode does not claim excluded card or review tools ran',()=>{
  for(const name of ['publish_card','withdraw_card','evidence_check']) {
    const start=callback(11,'tool_start','tools',{name,run_id:`${name}-call`,parent_run_id:'tools-call'});
    const value=project([start],{previous:project([]),status:{active_tools:[start]}});
    assert.ok(value.unsupported>0,name);
    assert.equal(value.nodes.calculate.visits,0,name);
    assert.equal(value.nodes.response.visits,0,name);
    assert.deepEqual(value.pulses,[]);
  }
});

test('tool exceptions mark the affected component without inventing recovery execution',()=>{
  const failure={...searchEnd,event:'tool_error',data:{error_type:'TimeoutError'}};
  const value=project([searchStart,failure],{template:direct('progress')});
  assert.ok(value.nodes.sources.errors>0);
  assert.equal(value.nodes.recovery.visits,0);
  assert.equal(value.nodes.recovery.active,false);
});

test('provider failures remain visible after the active model callback ends',()=>{
  const start=callback(7,'model_start','model',{name:'ChatOllama',run_id:'provider-call',parent_run_id:'model-call'});
  const error={...start,seq:8,event:'model_error',data:{error_type:'ConnectionError'}};
  const value=project([modelStart,start,error,modelEnd]);
  assert.ok(value.nodes.model.errors>0);
  assert.equal(value.nodes.model.active,false);
});

test('normally returned tool failures are distinguished from successful pending acknowledgments',()=>{
  const failed=project([searchStart,{...searchEnd,data:{status:'error',error_code:'unknown_source',retryable:true}}]);
  assert.ok(failed.nodes.sources.errors>0);
  const pending=project([searchStart,{...searchEnd,data:{status:'pending',job_started:'job-search'}}]);
  assert.equal(pending.nodes.sources.errors,0);
});

test('pending source jobs remain separate from currently executing tool callbacks',()=>{
  const input=packet([]);
  input.world.pending_jobs=[{job_id:'job-search',status:'pending'},{job_id:'job-read'}];
  const value=project([],{packet:input});
  assert.equal(value.nodes.sources.pending,2);
  assert.equal(value.nodes.sources.visits,0);
  assert.equal(value.nodes.sources.active,false);
  assert.deepEqual(value.pulses,[]);
});

test('direct recovery and delivery nodes require their own observed callbacks',()=>{
  const recovery=callback(14,'node_start','consider_recovery');
  const response=callback(16,'node_start','deliver_response');
  const value=project([recovery,response],{template:direct('progress'),status:{active_nodes:[response]}});
  assert.equal(value.nodes.recovery.visits,1);
  assert.equal(value.nodes.response.visits,1);
  assert.equal(value.nodes.response.active,true);
});

test('legacy card publication uses the publication tool evidence',()=>{
  const publish=callback(20,'tool_start','tools',{name:'publish_card',run_id:'publish-call',parent_run_id:'tools-call'});
  const value=project([publish],{template:legacy('agent-led'),status:{active_tools:[publish]}});
  assert.equal(value.nodes.publication.visits,1);
  assert.equal(value.nodes.publication.active,true);
  assert.ok(!Object.hasOwn(value.nodes,'response'));
});

test('legacy evidence review cannot masquerade as publication',()=>{
  const review=callback(11,'tool_start','tools',{name:'evidence_check',run_id:'review-call',parent_run_id:'tools-call'});
  const value=project([toolNodeStart,review],{
    template:legacy('agent-led'),status:{active_nodes:[toolNodeStart],active_tools:[review]},
  });
  assert.equal(value.nodes.publication.visits,0);
  assert.equal(value.nodes.publication.active,false);
  assert.equal(value.edges['tools--publication'].observed,0);
  assert.equal(value.nodes['evidence-advice'].visits,1);
  assert.equal(value.nodes['evidence-advice'].active,true);
  assert.equal(value.edges['tools--evidence-advice'].observed,1);
});

test('progress middleware and persistence never pretend to have independent live callbacks',()=>{
  const value=project([boundaryStart,boundaryEnd,modelStart],
    {template:direct('progress'),status:{active_nodes:[modelStart]}});
  for(const id of ['progress','persistence']) {
    assert.equal(value.nodes[id].visits,0);
    assert.equal(value.nodes[id].active,false);
    assert.ok(!value.pulses.some(pulse=>pulse.edgeId.startsWith(`${id}--`)||pulse.edgeId.endsWith(`--${id}`)));
  }
});

test('unrecognized callbacks cannot add components, visits, or animated routes',()=>{
  const unknown=callback(15,'node_start','unrecognized_stage');
  const value=project([unknown],{previous:project([]),status:{active_nodes:[unknown]}});
  assert.ok(value.unsupported>0);
  assert.ok(!Object.hasOwn(value.nodes,'unrecognized_stage'));
  inactive(value);
});

for(const terminal of ['completed','cancelled','error','paused']) {
  test(`${terminal} jobs suppress stale active tables and route animation`,()=>{
    const value=project([observeStart,observeEnd,investigateStart],{
      previous:project([observeStart,observeEnd]),job:{status:terminal},
      status:{active_nodes:[investigateStart],active_models:[modelStart]},
    });
    inactive(value);
    assert.equal(value.nodes.investigate.visits,1);
  });
}

test('loss of live confirmation clears activity but preserves recorded visits',()=>{
  const value=project([modelStart],{live:false,status:{active_nodes:[modelStart]}});
  inactive(value);
  assert.equal(value.nodes.model.visits,1);
});

test('a terminal telemetry status overrides stale running job metadata',()=>{
  const value=project([modelStart],{status:{status:'completed',active_nodes:[modelStart]}});
  inactive(value);
});

test('missing telemetry produces an intact, inactive architecture',()=>{
  const value=project([],{packet:{},live:false});
  assert.deepEqual(Object.keys(value.nodes).sort(),idList(template.nodes).sort());
  inactive(value);
});

test('a truncated event window never invents unobserved earlier visits',()=>{
  const value=project([searchStart,searchEnd]);
  assert.equal(value.nodes.sources.visits,1);
  assert.equal(value.nodes.observe.visits,0);
  assert.equal(value.nodes.model.visits,0);
  assert.deepEqual(value.pulses,[]);
});

// These saved histories are optional; synthetic contracts above stay portable.
test('knowledge question profile shows notes without fictional file-tool activity',()=>{
  for(const harness of ['native','agent-led','frozen-baseline','progress']) {
    const selected=Graph.resolveTemplate({harness,input_mode:'direct_request',capabilities:{web_retrieval:true,question_tool_profile:'knowledge'}});
    assert.equal(selected.features.knowledgeTools,true);
    assert.equal(selected.nodes.find(node=>node.id==='working-state').label,'Private notes');
    assert.equal(Graph.mapEvent(selected,{event:'tool_start',name:'read_file'}),null);
    assert.equal(Graph.mapEvent(selected,{event:'tool_start',name:'save_notes'}),'working-state');
  }
});

test('saved profile metadata distinguishes historical web and knowledge tool runs',()=>{
  const source_sha256={'experiments/deep_conversation/web_tools.py':'recorded-hash'};
  const older=Graph.resolveTemplate({harness:'agent-led',input_mode:'direct_request',source_fingerprint:{source_sha256}});
  const newer=Graph.resolveTemplate({harness:'agent-led',input_mode:'direct_request',source_fingerprint:{source_sha256,question_tool_profile:'knowledge'}});
  assert.equal(older.features.knowledgeTools,false);
  assert.equal(newer.features.knowledgeTools,true);
  assert.equal(older.nodes.find(node=>node.id==='working-state').label,'Private workspace');
});

// These saved histories are optional; synthetic contracts above stay portable.
// Only callback metadata is read. No private question or answer is printed.
const histories=[
  ['legacy frozen baseline','lab-7d94bdfbe864406da0cac481d14a7e32',legacy('frozen-baseline')],
  ['current direct request','lab-acc57ad02ca7463a9b955fe0039b3e9a',direct('agent-led')],
];
for(const [label,folder,selected] of histories) {
  const filename=path.join(__dirname,'..','runs',folder,'monitor_events.jsonl');
  test(`saved ${label} callbacks preserve topology and remain historical`,{skip:!fs.existsSync(filename)},()=>{
    const events=fs.readFileSync(filename,'utf8').trim().split(/\r?\n/).filter(Boolean).map(JSON.parse);
    const before=topology(selected);
    const value=project(events,{template:selected,live:false,job:{status:'completed'}});
    assert.equal(value.nodes.model.visits,events.filter(row=>row.event==='node_start'&&row.node==='model').length);
    assert.equal(value.nodes.observe.visits,events.filter(row=>row.event==='node_start'&&row.node==='observe').length);
    assert.equal(topology(selected),before);
    inactive(value);
  });
}
