'use strict';
(() => {
  const $ = id => document.getElementById(id), SVG = 'http://www.w3.org/2000/svg';
  const state = {config:null, jobs:[], selected:'', job:null, packet:null, directResponse:null, responseLoaded:false, healthy:false, submitting:false, cancelling:false, tokenMode:'cumulative', selectedNode:null, graphView:'configuration', graphZoom:null, lastCatalog:0, polling:false};
  const outputCache = new Map(), signatures = new Map();
  let pendingSubmission = null;
  const list = value => Array.isArray(value) ? value : Object.values(value || {});
  const finite = value => typeof value === 'number' && Number.isFinite(value) && value >= 0;
  const format = value => finite(value) ? value.toLocaleString(undefined,{maximumFractionDigits:0}) : '—';
  const short = (value, length=220) => String(value ?? '').length > length ? String(value).slice(0,length)+'…' : String(value ?? '');
  const friendly = value => String(value || 'Unknown').replaceAll('_',' ');
  const time = value => value ? new Date(value).toLocaleTimeString([], {timeZone:'America/Halifax',hour12:false}) : '—';
  const dateTime = value => value ? new Date(value).toLocaleString([], {timeZone:'America/Halifax',month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}) : '';
  const replay = value => finite(value) ? `${(value/1000).toFixed(2)} s replay` : 'Replay time unavailable';
  const problem = value => Boolean(value && (value.error || value.error_code || ['error','failed','not_published'].includes(value.status)));
  function element(tag, cls='', text) {const node=document.createElement(tag);if(cls)node.className=cls;if(text!==undefined)node.textContent=String(text);return node;}
  function svgElement(tag, attrs={}, text) {const node=document.createElementNS(SVG,tag);for(const [key,value] of Object.entries(attrs))node.setAttribute(key,String(value));if(text!==undefined)node.textContent=String(text);return node;}
  function empty(text) {return element('p','empty',text);}
  function notice(text) {$('notice').textContent=text||'';$('notice').hidden=!text;}
  function changed(key,value) {const signature=JSON.stringify(value);if(signatures.get(key)===signature)return false;signatures.set(key,signature);return true;}
  function replaceContent(id,nodes) {const host=$(id),top=host.scrollTop,open=new Set([...host.querySelectorAll('details[open]')].map(x=>x.dataset.key));host.replaceChildren(...nodes);host.querySelectorAll('details').forEach(x=>{x.open=open.has(x.dataset.key);});host.scrollTop=top;}
  function detail(key,title,value) {const node=element('details','tool-detail');node.dataset.key=key;node.append(element('summary','',title),valueView(value));return node;}
  function valueView(value,depth=0) {
    if(value===null||value===undefined)return element('span','muted','Not recorded');
    if(typeof value!=='object')return element('span','',typeof value==='boolean'?(value?'Yes':'No'):String(value));
    if(depth>=4)return element('p','',JSON.stringify(value));
    if(Array.isArray(value)){const ul=element('ul');value.forEach(item=>{const li=element('li');li.append(valueView(item,depth+1));ul.append(li);});if(!value.length)ul.append(element('li','muted','None'));return ul;}
    const dl=element('dl','data-fields');Object.entries(value).forEach(([key,item])=>{dl.append(element('dt','',friendly(key)));const dd=element('dd');dd.append(valueView(item,depth+1));dl.append(dd);});return dl;
  }
  async function api(path,{method='GET',body}={}) {
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);
    try {const response=await fetch(path,{method,cache:'no-store',credentials:'same-origin',signal:controller.signal,headers:method==='GET'?{}:{'Content-Type':'application/json','X-Lab-Token':state.config?.csrf_token||''},body:body===undefined?undefined:JSON.stringify(body)});const result=await response.json().catch(()=>({}));if(!response.ok)throw new Error(result.message||result.error?.message||result.error||`Request failed (${response.status})`);return result;}
    finally {clearTimeout(timer);}
  }
  function harnessLabel(id) {return state.config?.harnesses?.find(item=>item.id===id)?.label||friendly(id);}
  function supportsQuestionTests(config) {return Number.isInteger(config?.task_contract_version)&&config.task_contract_version>=3&&Array.isArray(config.harnesses)&&config.harnesses.length>0&&config.harnesses.every(item=>typeof item.id==='string'&&item.id.length>0&&item.input_mode==='direct_request')&&config.harnesses.some(item=>item.id===config.default_harness);}
  function inputMode(job) {return job?.input_mode||(job?.harness==='direct-help'?'direct_request':['frozen-baseline','agent-led','progress','native'].includes(job?.harness)?'human_human_transcript':'unknown');}
  function runLabel(job) {
    if(inputMode(job)==='human_human_transcript'){
      const names={'frozen-baseline':'Frozen research baseline','agent-led':'Agent-led','progress':'Investigation progress','native':'Native reference'};
      return `${names[job?.harness]||friendly(job?.harness)} · conversation replay`;
    }
    if(job?.harness==='direct-help')return 'Question test · previous adapter';
    return harnessLabel(job?.harness);
  }
  function taskTypeLabel(job) {
    if(job?.input_mode==='direct_request')return 'Task type: direct question (recorded)';
    if(job?.input_mode==='human_human_transcript')return 'Task type: conversation replay (recorded)';
    if(job?.input_mode)return `Task type: ${friendly(job.input_mode)} (recorded)`;
    if(['frozen-baseline','agent-led','progress','native'].includes(job?.harness))return 'Task type: conversation replay (inferred from legacy preset; not recorded)';
    if(job?.harness==='direct-help')return 'Task type: direct question (inferred from preset; not recorded)';
    return 'Task type: unknown (not recorded)';
  }
  function isDirect(job=state.job) {return inputMode(job)==='direct_request';}
  function retrievalNote(config) {
    if(config?.capabilities?.web_retrieval!==true)return 'Retrieval searches only the supplied documents. This service does not declare public web access.';
    const provider=config.capabilities.web_search_provider||'public search providers';
    const notes=[`The agent can search supplied documents and the public web via ${provider}.`];
    if(config.capabilities.web_query_sent_to_public_provider===true)notes.push('Web-search queries are sent to public providers.');
    if(config.capabilities.supplied_documents_automatically_sent===false)notes.push('Supplied documents are not automatically uploaded.');
    return notes.join(' ');
  }
  function live() {return state.healthy&&['starting','running'].includes(state.job?.status)&&Boolean(state.packet?.run?.heartbeat_fresh);}
  function runtimeEvents() {return state.packet?.runtime?.events||[];}
  function updateButtons() {
    const busy=state.jobs.some(job=>job.can_cancel||job.blocks_new_runs||['starting','running'].includes(job.status))||state.job?.can_cancel||state.job?.blocks_new_runs||['starting','running'].includes(state.job?.status),available=state.config?.preflight?.status==='available',compatible=supportsQuestionTests(state.config),disabled=!compatible||!available||!state.config?.csrf_token||state.submitting||Boolean(busy);
    $('run-button').disabled=disabled;$('run-button').textContent=state.config&&!compatible?'Service update required':state.submitting?'Starting…':'Run test';$('run-button').title=!compatible?'Open the updated test bench on port 8769 to start a new test.':busy?'Wait for the active worker to finish before starting another run.':'';
    $('stop-button').disabled=!state.job?.can_cancel||state.cancelling;$('stop-button').textContent=state.cancelling?'Stopping…':'Stop run';$('compare-button').disabled=!state.job?.question;
  }

  let documentNumber=0;
  function addDocument(title='',text='') {
    if($('documents').children.length>=8){notice('This form supports up to eight source documents per run.');return;}
    const number=++documentNumber,item=element('div','document-item');item.dataset.document=String(number);
    const top=element('div','document-top'),label=element('label','',`Document ${number}`);label.htmlFor=`document-title-${number}`;
    const remove=element('button','document-remove','Remove');remove.type='button';remove.setAttribute('aria-label',`Remove document ${number}`);remove.addEventListener('click',()=>item.remove());top.append(label,remove);
    const titleInput=element('input');titleInput.type='text';titleInput.id=`document-title-${number}`;titleInput.placeholder='Document title';titleInput.value=title;titleInput.maxLength=200;titleInput.dataset.field='title';
    const body=element('textarea');body.rows=4;body.value=text;body.placeholder='Paste the source text the agent can retrieve';body.maxLength=20000;body.dataset.field='text';body.setAttribute('aria-label',`Document ${number} source text`);item.append(top,titleInput,body);$('documents').append(item);
  }
  function renderHarnessDescription() {
    if(state.config&&!supportsQuestionTests(state.config)){$('input-title').textContent='New tests unavailable';$('question-label').textContent='Question or task (unavailable on this service)';$('question').placeholder='Open the updated test bench to start a test';$('input-description').textContent='This service cannot apply the same question-test setup to every harness. New submissions are disabled; saved runs remain available.';$('harness-description').textContent='The offered configurations belong to an older test service.';updateButtons();return;}
    const item=state.config?.harnesses?.find(x=>x.id===$('harness-select').value);
    $('harness-description').textContent=item?.description||'Tests a direct question using the selected orchestration.';$('input-title').textContent='Question or task';$('question-label').textContent='Question or task';$('question').placeholder='Enter a question or task to test';$('input-description').textContent='All harnesses receive the same question-test setup. Each run starts independently from the question and optional documents supplied here.';updateButtons();
  }
  async function loadConfig() {
    const config=await api('/api/lab/config');state.config=config;
    $('retrieval-note').textContent=retrievalNote(config);
    const compatible=supportsQuestionTests(config);
    $('harness-select').replaceChildren(...(config.harnesses||[]).map(item=>{const option=element('option','',compatible?item.label:`Legacy configuration · ${item.label}`);option.value=item.id;return option;}));$('harness-select').disabled=!compatible;$('question').disabled=!compatible;$('add-document').disabled=!compatible;
    if(compatible)$('harness-select').value=config.default_harness;else $('harness-select').selectedIndex=-1;
    $('service-warning').hidden=compatible;$('page-title').textContent=compatible?'Harness Test Bench':'Saved Run Viewer';$('lab-intro').textContent=compatible?'Test a question and inspect the response, tool calls and execution records.':'This older service can display saved runs. Use the updated test bench to start new tests.';
    const profile=config.profile||{};$('model-name').textContent=profile.model||'Fixed local model';
    const budgets=profile.budgets||profile;$('model-profile').textContent=[profile.provider,finite(budgets.max_calls)?`${format(budgets.max_calls)} model calls`:null,finite(budgets.max_tokens)?`${format(budgets.max_tokens)} soft tokens`:null,finite(profile.context_window)?`${format(profile.context_window)} context`:null].filter(Boolean).join(' · ');
    $('preflight').textContent=config.preflight?.status==='available'?'Local model is available.':config.preflight?.message||config.preflight?.detail||'The fixed local model is unavailable. Start the configured local service, then reload this page.';$('preflight').className=`preflight${config.preflight?.status==='available'?' available':''}`;renderHarnessDescription();renderGraph();updateButtons();
  }
  async function catalog() {
    const result=await api('/api/lab/runs');state.jobs=result.runs||[];state.lastCatalog=Date.now();
    if(changed('history',state.jobs.map(job=>[job.id,job.status,job.updated_at,job.input_mode]))){const options=state.jobs.map(job=>{const option=element('option','',`${runLabel(job)} · ${friendly(job.status)} · ${dateTime(job.created_at)}`);option.value=job.id;return option;});if(!options.length){const option=element('option','','No saved runs yet');option.value='';options.push(option);}$('history-select').replaceChildren(...options);}
    if(!state.selected&&state.jobs.length)selectRun(state.jobs.find(job=>job.can_cancel)?.id||state.jobs[0].id,false,false);
    $('history-select').value=state.selected;updateButtons();
  }
  function clearResults() {state.packet=null;state.directResponse=null;state.responseLoaded=false;state.selectedNode=null;signatures.clear();graphProjection=null;renderGraph();$('tools').replaceChildren(empty('No tool receipts received.'));$('cards').replaceChildren(empty('No card has been published.'));$('events').replaceChildren(empty('No events received.'));$('token-chart').replaceChildren(empty('Waiting for measured calls.'));$('duration-chart').replaceChildren(empty('Waiting for measured calls.'));$('model-output').replaceChildren(empty('Waiting for provider-exposed text.'));$('tool-count').textContent='0';$('card-count').textContent='0';renderMetrics(null);renderDirectResponse();$('comparison-panel').hidden=true;}
  function selectRun(id,fetchNow=true,followGraph=true) {if(followGraph)state.graphView='run';state.selected=id;state.job=state.jobs.find(job=>job.id===id)||{id,status:'starting'};clearResults();$('history-select').value=id;renderJob();renderOutput();if(fetchNow)pollSelected().catch(handleConnectionError);}
  function renderJob() {
    const job=state.job;if(!job)return;
    $('selected-title').textContent=runLabel(job)||'Selected run';$('selected-subtitle').textContent=job.question||'Starting the local run…';$('job-status').textContent=friendly(job.status);$('job-status').className=`badge${['starting','running'].includes(job.status)?' live':['error','interrupted'].includes(job.status)?' error':''}`;
    $('selected-task-type').textContent=taskTypeLabel(job);$('selected-task-type').hidden=false;
    const runtime=state.packet?.runtime?.status||{},activeTools=live()?list(runtime.active_tools):[],activeModels=live()?list(runtime.active_models):[],activeNodes=live()?list(runtime.active_nodes):[];
    $('active-location').textContent=activeTools.length?`Tool: ${activeTools.map(x=>x.name||'tool').join(', ')}`:activeModels.length?`Model: ${activeModels.map(x=>x.node||x.name||'investigator').join(', ')}`:activeNodes.length?`Node: ${activeNodes.map(x=>x.node||x.name).join(' → ')}`:['starting','running'].includes(job.status)?'Waiting for a fresh execution callback':state.packet?.run?.stop_reason?`Stopped: ${friendly(state.packet.run.stop_reason)}`:`Run ${friendly(job.status).toLowerCase()}`;
    const world=state.packet?.world;$('replay-position').textContent=isDirect()?'Question test · independent run':world?`${replay(world.simulated_at_ms)} · ${list(world.pending_jobs).length} pending source jobs`:'';
    if(job.error)notice(typeof job.error==='string'?job.error:JSON.stringify(job.error));renderDirectResponse();updateButtons();
  }
  function renderDirectResponse() {
    const direct=isDirect(),response=state.directResponse,hasResponse=response?.status==='response'&&Boolean(response.text?.trim()),running=['starting','running'].includes(state.job?.status),loading=!state.responseLoaded;
    $('direct-response-panel').hidden=!direct;
    $('stream-boundary').textContent=direct?'Debug output can include intermediate text and tool requests. The delivered reply appears in Final response. This is not hidden reasoning.':'Debug output is not published assistance. Only explicit card actions display help in conversation replay.';
    if(!direct)return;
    $('direct-response-status').textContent=loading?'Loading':hasResponse?'Response available':running?'In progress':'No response';$('direct-response-status').className=`badge${!loading&&running&&!hasResponse?' live':''}`;
    $('direct-response-note').textContent=loading?'Retrieving the selected run’s response record.':hasResponse?'Delivered by this run. Correctness has not been evaluated.':running?'Waiting for the agent to finish its response.':'The run has no delivered response. Execution ending does not mean the question was answered.';
    if(changed('direct-response',[state.selected,response,running,loading]))$('direct-response').replaceChildren(loading?empty('Loading response…'):hasResponse?element('p','',response.text):empty(running?'The response will appear here when it is available.':'No response was delivered. Inspect the execution records below.'));
  }
  function measured(packet) {const calls=packet?.model_calls||[],finished=calls.filter(call=>finite(call.finished_at_ms)),tokenCalls=finished.filter(call=>finite(call.total_tokens)),durationCalls=finished.filter(call=>finite(call.wall_ms));return {calls,finished,tokens:tokenCalls.length?tokenCalls.reduce((sum,x)=>sum+x.total_tokens,0):null,duration:durationCalls.length?durationCalls.reduce((sum,x)=>sum+x.wall_ms,0):null,cards:packet?.world?Object.keys(packet.world.cards||{}).length:null};}
  function renderMetrics(packet) {const m=measured(packet);const rows=[['Model calls',packet?format(m.calls.length):'—',packet?`${m.finished.length} finished · ${m.calls.length-m.finished.length} unfinished`:'Waiting for records'],['Recorded tokens',format(m.tokens),'Finished calls · not billing totals'],['Model duration',finite(m.duration)?`${(m.duration/1000).toFixed(2)} s`:'—','Sum of measured call wall time'],['Active cards',format(m.cards),'Presence is not a quality score']];if(!changed('metrics',rows))return;$('metrics').replaceChildren(...rows.map(([label,value,note])=>{const item=element('article');item.append(element('span','',label),element('strong','',value),element('small','',note));return item;}));}
  function drawChart(calls,kind) {
    let sum=0;const all=calls.map((call,index)=>{const number=finite(call.finished_at_ms)&&finite(kind==='tokens'?call.total_tokens:call.wall_ms)?(kind==='tokens'?call.total_tokens:call.wall_ms):null;if(number!==null)sum+=number;return {ordinal:call.ordinal??index+1,value:number===null?null:kind==='tokens'&&state.tokenMode==='cumulative'?sum:number};}),rows=all.slice(-80);
    if(!rows.some(row=>row.value!==null))return [empty('No finished measurements yet.')];
    const W=470,H=190,L=48,R=15,T=16,B=30,pw=W-L-R,ph=H-T-B,maximum=Math.max(1,...rows.map(row=>row.value||0))*1.08,x=i=>L+(i+.5)*pw/rows.length,y=value=>T+ph*(1-value/maximum),unit=kind==='tokens'?'tokens':'ms';
    const svg=svgElement('svg',{viewBox:`0 0 ${W} ${H}`,role:'group','aria-label':kind==='tokens'?'Recorded token use by model call':'Measured call duration in milliseconds'});
    [0,.5,1].forEach(f=>{svg.append(svgElement('line',{x1:L,y1:y(maximum*f),x2:W-R,y2:y(maximum*f),class:'chart-gridline'}),svgElement('text',{x:L-8,y:y(maximum*f)+4,'text-anchor':'end'},maximum*f>=1000?`${+(maximum*f/1000).toFixed(1)}k`:Math.round(maximum*f)));});
    if(kind==='tokens'){let path='',previous=false;rows.forEach((row,i)=>{if(row.value===null){previous=false;return;}path+=`${previous?'L':'M'}${x(i)},${y(row.value)} `;previous=true;});svg.append(svgElement('path',{d:path,class:'chart-line'}));}
    rows.forEach((row,i)=>{if(row.value===null)return;const label=`Call ${row.ordinal}: ${format(row.value)} ${unit}`,point=svgElement('g',{tabindex:'0',role:'img','aria-label':label,class:'chart-point'});point.append(svgElement('title',{},label));if(kind==='tokens')point.append(svgElement('circle',{cx:x(i),cy:y(row.value),r:3.5,class:'chart-mark'}));else point.append(svgElement('rect',{x:x(i)-Math.min(25,pw/rows.length*.6)/2,y:y(row.value),width:Math.min(25,pw/rows.length*.6),height:Math.max(1,T+ph-y(row.value)),rx:3,class:'duration-mark'}));svg.append(point);if(i===0||i===rows.length-1||i===Math.floor(rows.length/2))svg.append(svgElement('text',{x:x(i),y:H-10,'text-anchor':'middle'},`#${row.ordinal}`));});
    return [svg,element('p','chart-note',`${rows.length<all.length?'Latest 80 of '+all.length:'All '+all.length} recorded calls · ${unit}`)];
  }
  function renderCharts(packet) {const calls=packet?.model_calls||[];if(!changed('charts',[calls,state.tokenMode]))return;$('token-chart').replaceChildren(...drawChart(calls,'tokens'));$('duration-chart').replaceChildren(...drawChart(calls,'duration'));$('token-cumulative').setAttribute('aria-pressed',String(state.tokenMode==='cumulative'));$('token-per-call').setAttribute('aria-pressed',String(state.tokenMode==='per-call'));}
  let graphProjection=null, graphTemplate=null, graphExpanded=false, previousBodyOverflow='';
  const graphController=HarnessGraph.mount($('graph'),{onSelect(node){state.selectedNode=state.selectedNode===node.id?null:node.id;renderGraph();}});
  function graphFit() {
    return Math.max(.2,Math.min(1,($('graph-viewport').clientWidth-24)/(graphTemplate?.width||1240),graphExpanded?($('graph-viewport').clientHeight-24)/((graphTemplate?.height||650)+22):1));
  }
  function graphSizing() {
    if(!graphTemplate)return;
    const zoom=state.graphZoom??graphFit();
    $('graph').style.width=`${graphTemplate.width*zoom}px`;
    $('graph').style.maxWidth='none';
    $('graph-zoom-level').textContent=`${Math.round(zoom*100)}%`;
  }
  function graphDetails() {
    const node=graphTemplate?.nodes.find(item=>item.id===state.selectedNode);
    $('node-detail').hidden=!node;
    if(!node)return;
    const status=graphProjection.nodes[node.id]||{},parts=[];
    if(status.active)parts.push('Active now');
    if(status.pending)parts.push(`${status.pending} pending source job${status.pending===1?'':'s'}`);
    if(status.visits)parts.push(`${status.visits} observed starts`);
    if(status.errors)parts.push(`${status.errors} recorded errors`);
    if(!node.observable)parts.push('Structural component · no separate runtime callback');
    else if(state.graphView==='configuration')parts.push('Configuration preview');
    else if(!parts.length)parts.push('No matching execution event');
    const source=element('p','graph-sources');source.append(element('span','','Source: '));
    source.append(document.createTextNode((node.sources||[]).join(' · ')));
    $('node-detail').replaceChildren(element('strong','',node.label),element('p','graph-node-state',parts.join(' · ')),element('p','',node.description),source);
  }
  function renderGraph() {
    const preview=state.graphView==='configuration'||!state.job;
    const selectedHarness=$('harness-select').value||state.config?.default_harness||'agent-led';
    const descriptor=preview?{harness:selectedHarness,input_mode:'direct_request',task_contract_version:state.config?.task_contract_version,capabilities:state.config?.capabilities}:
      {...state.job,input_mode:inputMode(state.job),source_fingerprint:state.packet?.graph?.record?.source_fingerprint};
    const template=HarnessGraph.resolveTemplate(descriptor);
    if(graphTemplate?.id!==template.id){state.selectedNode=null;state.graphZoom=null;graphProjection=null;}
    graphTemplate=template;
    graphProjection=HarnessGraph.project(template,{job:preview?{...descriptor,id:`preview-${selectedHarness}`,status:'preview'}:state.job,packet:preview?null:state.packet,live:!preview&&live()},graphProjection);
    graphController.update(template,graphProjection,{selectedNode:state.selectedNode});
    $('graph-origin').textContent=`${template.label} · ${template.subtitle}`;
    const isLive=!preview&&live(),waiting=!preview&&['starting','running'].includes(state.job?.status);
    $('graph-state').textContent=preview?'Configuration':isLive?'Live':waiting?'Awaiting fresh events':'Recorded';
    $('graph-state').className=`badge${isLive?' live':''}`;
    $('graph-configuration').setAttribute('aria-pressed',String(preview));
    $('graph-selected-run').setAttribute('aria-pressed',String(!preview));
    $('graph-selected-run').disabled=!state.job;
    $('graph-unmapped').hidden=template.supported&&!graphProjection.unsupported;
    $('graph-unmapped').textContent=template.supported?`${graphProjection.unsupported} recorded execution events have no matching component in this architecture.`:'This saved configuration has no verified architecture mapping.';
    graphDetails();graphSizing();
  }
  function resultSummary(value) {if(typeof value==='string')return short(value,350);if(!value)return 'No result body recorded.';for(const key of ['error','reason','text','answer','message'])if(typeof value[key]==='string'&&value[key])return short(value[key],350);if(value.status==='pending'||value.job_started)return 'A pending job was acknowledged. Its evidence arrives later.';if(value.status)return friendly(value.status);if(Array.isArray(value.sources))return `${value.sources.length} source records returned.`;return 'Result recorded.';}
  function renderTools() {const tools=state.packet?.world?.tool_receipts||[];if(!changed('tools',tools))return;$('tool-count').textContent=format(tools.length);replaceContent('tools',tools.length?[...tools].reverse().slice(0,80).map((tool,index)=>{const item=element('article',`item${problem(tool.result)?' has-error':''}`),head=element('div','item-heading');head.append(element('strong','',friendly(tool.name)),element('span','item-time',replay(tool.at_ms)));item.append(head,element('p','',resultSummary(tool.result)),detail(`tool-${tool.call_id||index}`,'Arguments and return',{arguments:tool.args||{},returned:tool.result}));return item;}):[empty('No tool receipts yet.')]);}
  function renderCards() {const cards=state.packet?.world?.cards||{};if(!changed('cards',cards))return;const rows=Object.entries(cards);$('card-count').textContent=format(rows.length);replaceContent('cards',rows.length?rows.map(([id,card])=>{const item=element('article','item'),head=element('div','item-heading');head.append(element('strong','',id),element('span','item-time',replay(card.updated_ms)));item.append(head,element('p','',card.text||'No text in the saved card.'));if(card.source_ids?.length)item.append(element('p','muted',`Sources: ${card.source_ids.join(', ')}`));return item;}):[empty('No help card is currently active.')]);}
  function renderEvents() {const mode=$('event-filter').value,rows=mode==='runtime'?runtimeEvents():state.packet?.world?.events||[];if(!changed('events',[mode,rows]))return;const selected=[...rows].reverse().slice(0,120);replaceContent('events',selected.length?selected.map(event=>{const row=element('article','event-row'),kind=mode==='runtime'?event.event:event.event?.kind||event.kind;const body=event.event&&typeof event.event==='object'?event.event:event.result||event.data||{};let description=body.text||body.error||body.error_type||body.reason||event.node||event.name||'';if(!description&&event.kind==='job_started')description=`${event.job?.operation||'Source'} job scheduled`;if(!description&&event.kind==='model_call_finished')description=`${friendly(event.outcome)} · ${finite(event.wall_ms)?format(event.wall_ms)+' ms':'duration unavailable'}`;row.append(element('time','',mode==='runtime'?time(event.timestamp):replay(event.at_ms)),element('strong','',friendly(kind)),element('p','',short(description,400)));return row;}):[empty('No matching events have been recorded.')]);}
  function outputState(id=state.selected) {if(!outputCache.has(id))outputCache.set(id,{cursor:0,calls:new Map(),events:0,truncated:false,nextOrdinal:1});return outputCache.get(id);}
  function consumeOutput(batch) {if(!batch)return;const cache=outputState();for(const event of batch.events||[]){if(finite(event.seq)&&event.seq<=cache.cursor)continue;if(finite(event.seq))cache.cursor=event.seq;cache.events++;if(event.event==='output_log_truncated'){cache.truncated=true;continue;}const id=String(event.call_id||'unidentified-call');if(!cache.calls.has(id))cache.calls.set(id,{id,ordinal:cache.nextOrdinal++,node:event.node||'',text:'',status:'streaming',timestamp:event.timestamp,tools:[]});const call=cache.calls.get(id);if(event.node)call.node=event.node;if(event.event==='model_output_delta'){const remaining=90000-call.text.length;if(remaining>0)call.text+=String(event.text||'').slice(0,remaining);if(remaining<String(event.text||'').length)cache.truncated=true;}else if(event.event==='model_output_end'){call.status='finished';call.truncated=Boolean(event.truncated);cache.truncated||=call.truncated;}else if(event.event==='model_output_error'){call.status='error';call.error=event.error_type||'Provider output error';}else if(event.event==='model_tool_request'){call.tools.push({name:event.name,args:event.args,tool_call_id:event.tool_call_id});}while(cache.calls.size>20){cache.calls.delete(cache.calls.keys().next().value);cache.truncated=true;}}
    if(finite(batch.next_seq))cache.cursor=Math.max(cache.cursor,batch.next_seq);cache.truncated||=Boolean(batch.truncated);renderOutput();
  }
  function renderOutput() {if(!state.selected)return;const cache=outputState(),rows=[...cache.calls.values()];if(!changed('output',[state.selected,rows,cache.truncated,state.job?.status]))return;const host=$('model-output'),scrollTop=host.scrollTop,follow=$('follow-output').checked;
    host.replaceChildren(...(rows.length?rows.map(call=>{const item=element('article','stream-call'),head=element('div','item-heading'),streaming=call.status==='streaming'&&['starting','running'].includes(state.job?.status),status=call.status==='streaming'&&!streaming?'No end record':friendly(call.status);head.append(element('strong','',`Model call ${call.ordinal}${call.node?' · '+call.node:''}`),element('span',`badge${call.status==='error'?' error':streaming?' live':''}`,status));item.append(head);if(call.text)item.append(element('p','stream-text',call.text));else item.append(element('p','empty',streaming?'Waiting for exposed text or tool requests…':'No provider-exposed text was recorded.'));call.tools.forEach((tool,i)=>{const block=detail(`output-tool-${call.id}-${i}`,`Tool request: ${tool.name||'unnamed tool'}`,tool.args||{});block.classList.add('stream-tool');item.append(block);});if(call.error)item.append(element('p','stream-text',call.error));return item;}):[empty('Some calls contain only tool requests.')]));
    host.scrollTop=follow?host.scrollHeight:scrollTop;$('output-note').textContent=`${cache.events} output events received. ${cache.truncated?'Older or oversized output has been bounded; this view is incomplete.':''}`;
  }
  function renderSnapshot(packet) {state.packet=packet;renderJob();renderMetrics(packet);renderCharts(packet);renderGraph();renderTools();renderCards();renderEvents();$('updated').textContent=`Snapshot ${time(packet.observed_at)}${isDirect()?' · measured execution records':' · measured wall time differs from replay time'}`;}
  async function pollSelected() {if(!state.selected)return;const requested=state.selected,cursor=outputState(requested).cursor,result=await api(`/api/lab/runs/${encodeURIComponent(requested)}?after_output_seq=${cursor}`);if(requested!==state.selected)return;state.healthy=true;state.job=result.job||state.job;state.directResponse=result.direct_response||null;state.responseLoaded=true;const index=state.jobs.findIndex(job=>job.id===requested);if(index>=0)state.jobs[index]=state.job;else state.jobs.unshift(state.job);if(result.snapshot)renderSnapshot(result.snapshot);else {renderJob();renderGraph();}consumeOutput(result.output_events);$('connection-text').textContent='Connected to this computer';$('connection-dot').className='healthy';}
  function handleConnectionError(error) {state.healthy=false;$('connection-text').textContent='Connection lost · retrying';$('connection-dot').className='';$('active-location').textContent='Saved state · live execution is not confirmed';if(state.packet)renderGraph();if(!state.config)notice(`Could not read the local lab configuration: ${error.message}`);}
  async function tick() {if(state.polling)return;state.polling=true;try{if(!state.config)await loadConfig();if(Date.now()-state.lastCatalog>4000)await catalog();await pollSelected();if(!state.selected){state.healthy=true;$('connection-text').textContent='Connected to this computer';$('connection-dot').className='healthy';}}catch(error){handleConnectionError(error);}finally{state.polling=false;setTimeout(tick,750);}}
  async function compare() {if(!state.job?.question)return;const question=state.job.question.trim(),fingerprint=state.job.input_sha256,modelFingerprint=state.job.model_profile_sha256,mode=inputMode(state.job),jobs=state.jobs.filter(job=>inputMode(job)===mode&&(fingerprint?job.input_sha256===fingerprint:(job.question||'').trim()===question)&&(!modelFingerprint||job.model_profile_sha256===modelFingerprint)).slice(0,8);$('comparison-panel').hidden=false;$('comparison').replaceChildren(empty('Loading comparable run measurements…'));$('comparison-note').textContent=fingerprint&&modelFingerprint?'Matched task mode, question, source documents and exact model-profile fingerprint. Task adapter revisions can differ; response presence is not a quality score.':fingerprint?'Matched task mode, question and source-document fingerprint. Model identity is not verified for all archived records; interpret the comparison cautiously.':'Same task mode and exact question text only. Source documents and model identity may differ across sessions; inspect the inputs before interpreting a comparison.';
    const results=await Promise.allSettled(jobs.map(job=>api(`/api/lab/runs/${encodeURIComponent(job.id)}?after_output_seq=999999999999`)));const table=element('table'),caption=element('caption','',`Up to eight saved runs with matching inputs.`),thead=element('thead'),head=element('tr');['Harness / run','Task adapter','Status','Calls','Tokens','Model time','Final response','Cards'].forEach(text=>head.append(element('th','',text)));thead.append(head);const tbody=element('tbody');jobs.forEach((job,index)=>{const result=results[index],packet=result.status==='fulfilled'?result.value.snapshot:null,m=measured(packet),row=element('tr'),first=element('td'),button=element('button','table-link',`${runLabel(job)} · ${dateTime(job.created_at)}`);button.type='button';button.addEventListener('click',()=>selectRun(job.id));first.append(button);row.append(first);const taskHash=packet?.graph?.record?.source_fingerprint?.source_sha256?.['experiments/deep_conversation/direct_request.py'];row.append(element('td','',isDirect(job)?taskHash?.slice(0,8)||'Unavailable':'Original replay'));const response=result.status==='fulfilled'?result.value.direct_response:null,responsePresence=!isDirect(job)?'Not applicable':result.status!=='fulfilled'?'Unavailable':response?.status==='response'&&response.text?.trim()?'Present (ungraded)':'None';[result.status==='fulfilled'?friendly(result.value.job?.status||job.status):'Unavailable',packet?format(m.calls.length):'—',format(m.tokens),finite(m.duration)?`${(m.duration/1000).toFixed(2)} s`:'—',responsePresence,format(m.cards)].forEach(value=>row.append(element('td','',value)));tbody.append(row);});table.append(caption,thead,tbody);$('comparison').replaceChildren(table);$('comparison-panel').scrollIntoView({behavior:'smooth',block:'nearest'});
  }
  $('run-form').addEventListener('submit',async event=>{
    event.preventDefault();if(!supportsQuestionTests(state.config)||$('run-button').disabled)return;
    const question=$('question').value.trim();if(!question){notice('Enter a question, task or conversation excerpt first.');$('question').focus();return;}
    const documents=[...$('documents').children].map(item=>({title:item.querySelector('[data-field="title"]').value.trim(),text:item.querySelector('[data-field="text"]').value.trim()})).filter(doc=>doc.title||doc.text);
    if(documents.some(doc=>!doc.title||!doc.text)){notice('Each source document needs both a title and source text, or remove the empty document.');return;}
    if(documents.reduce((total,doc)=>total+doc.text.length,0)>60000){notice('Combined source text must be at most 60,000 characters.');return;}
    const payload={question,documents,harness:$('harness-select').value},signature=JSON.stringify(payload);
    if(!pendingSubmission||pendingSubmission.signature!==signature)pendingSubmission={signature,request_id:crypto.randomUUID()};
    const request={...payload,request_id:pendingSubmission.request_id};
    if(new TextEncoder().encode(JSON.stringify(request)).length>128*1024){notice('This request exceeds the 128 KiB limit. Shorten the question or source documents.');return;}
    state.submitting=true;notice('');updateButtons();
    try{const result=await api('/api/lab/runs',{method:'POST',body:request});pendingSubmission=null;const job=result.job||{id:result.id,status:result.status||'starting',question,harness:payload.harness,input_mode:'direct_request',can_cancel:true};state.jobs=state.jobs.filter(item=>item.id!==job.id);state.jobs.unshift(job);selectRun(result.id||job.id,false);state.lastCatalog=0;await pollSelected();}
    catch(error){notice(error.message);}
    finally{state.submitting=false;updateButtons();}
  });
  $('stop-button').addEventListener('click',async()=>{if(!state.job?.can_cancel)return;state.cancelling=true;updateButtons();try{const result=await api(`/api/lab/runs/${encodeURIComponent(state.selected)}/cancel`,{method:'POST',body:{}});state.job=result.job||result;state.lastCatalog=0;renderJob();renderGraph();renderOutput();}catch(error){notice(error.message);}finally{state.cancelling=false;updateButtons();}});
  $('add-document').addEventListener('click',()=>addDocument());$('harness-select').addEventListener('change',()=>{renderHarnessDescription();state.graphView='configuration';state.selectedNode=null;renderGraph();});$('history-select').addEventListener('change',event=>{notice('');selectRun(event.target.value);});$('event-filter').addEventListener('change',renderEvents);$('token-cumulative').addEventListener('click',()=>{state.tokenMode='cumulative';renderCharts(state.packet);});$('token-per-call').addEventListener('click',()=>{state.tokenMode='per-call';renderCharts(state.packet);});$('compare-button').addEventListener('click',()=>compare().catch(error=>notice(error.message)));$('close-comparison').addEventListener('click',()=>{$('comparison-panel').hidden=true;});
  let resizeTimer;window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{graphSizing();},150);});
  const initial=new URL(location.href).searchParams.get('run');if(initial){state.selected=initial;state.graphView='run';}
  $('graph-configuration').addEventListener('click',()=>{state.graphView='configuration';state.selectedNode=null;graphProjection=null;renderGraph();});
  $('graph-selected-run').addEventListener('click',()=>{state.graphView='run';state.selectedNode=null;graphProjection=null;renderGraph();});
  $('graph-fit').addEventListener('click',()=>{state.graphZoom=null;graphSizing();});
  function expandGraph(expanded) {
    graphExpanded=expanded;const panel=$('harness-architecture-panel');panel.classList.toggle('is-expanded',expanded);
    if(expanded){previousBodyOverflow=document.body.style.overflow;document.body.style.overflow='hidden';panel.setAttribute('role','dialog');panel.setAttribute('aria-modal','true');}
    else{document.body.style.overflow=previousBodyOverflow;panel.removeAttribute('role');panel.removeAttribute('aria-modal');}
    $('graph-expand').textContent=expanded?'Close':'Expand';$('graph-expand').setAttribute('aria-expanded',String(expanded));state.graphZoom=null;graphSizing();$('graph-expand').focus();
  }
  $('graph-expand').addEventListener('click',()=>expandGraph(!graphExpanded));
  $('harness-architecture-panel').addEventListener('keydown',event=>{
    if(!graphExpanded)return;
    if(event.key==='Escape'){event.preventDefault();expandGraph(false);}
    if(event.key==='Tab'){const stops=[...$('harness-architecture-panel').querySelectorAll('button:not(:disabled),[tabindex="0"],summary')].filter(item=>item.getClientRects().length);const first=stops[0],last=stops.at(-1);if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}}
  });
  $('graph-zoom-level').addEventListener('click',()=>{state.graphZoom=1;graphSizing();});
  for(const [id,delta] of [['graph-zoom-in',.15],['graph-zoom-out',-.15]])$(id).addEventListener('click',()=>{const current=state.graphZoom??graphFit();state.graphZoom=Math.min(1.75,Math.max(.25,current+delta));graphSizing();});
  renderGraph();tick();
})();
