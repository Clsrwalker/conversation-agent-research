/* Fixed, source-described architectures. Runtime records only decorate them. */
(function (root, factory) {
  'use strict';
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.HarnessGraph = api;
})(typeof globalThis === 'object' ? globalThis : this, function () {
  'use strict';
  const SVG = 'http://www.w3.org/2000/svg';
  const array = value => Array.isArray(value) ? value : Object.values(value || {});
  const terminal = new Set(['completed', 'cancelled', 'canceled', 'error', 'failed', 'interrupted', 'paused']);
  const path = 'experiments/deep_conversation/';
  const frozen = path + 'baselines/2026-10-07-agent-led-recovery-v1/source/' + path;
  const freeze = value => {
    if (value && typeof value === 'object' && !Object.isFrozen(value)) {
      Object.values(value).forEach(freeze); Object.freeze(value);
    }
    return value;
  };
  const names = {'native':'Native reference', 'agent-led':'Agent-led', 'frozen-baseline':'Recovery baseline', 'progress':'Investigation progress'};

  function buildTemplate(harness, mode, webRetrieval = false, knowledgeTools = false) {
    const direct = mode === 'direct_request', led = harness !== 'native';
    const web = direct && webRetrieval;
    const recovery = ['frozen-baseline', 'progress'].includes(harness), progress = harness === 'progress';
    const source = harness === 'frozen-baseline' ? frozen : path;
    const nodes = [], edges = [];
    const add = (id, label, subtitle, kind, x, y, description, refs, observable = true) => {
      nodes.push({id,label,subtitle,kind,x,y,width:184,height:66,description,sources:refs,observable});
    };
    const edge = (from, to, label, kind = 'control', route = null) => {
      edges.push({id:from+'--'+to,from,to,label,kind,...(route ? {path:route} : {})});
    };
    add('input', direct?'Question + documents':'Conversation replay', direct?'Direct request':'Timed input events', 'input',30,40,
      direct?'The shared adapter accepts the user question and a catalog of supplied document IDs and titles. Document bodies are retrieved through tools. This input contract is separate from the frozen conversation study.':'The replay supplies conversation and source events on a simulated timeline. A replay utterance is not a direct instruction to answer.',
      [path+'lab_worker.py:90',path+'direct_request.py:116',source+'world.py'],false);
    add('observe','Observe events',direct?'Roles + arrived results':'Replay + arrived results','control',265,40,
      direct?'Read new world events, preserve user and assistant roles, and attach runtime source observations. Advance the simulated clock when no event has arrived. Stop when the window or model budget is exhausted.':'Read new conversation and source events from the world ledger. Advance the simulated clock when the observation is empty; route to the investigator while the run remains in budget.'+(recovery?' The selected recovery mechanism is checked inside this observation step.':''),
      [direct?path+'direct_request.py:233':source+(led?'agent_led.py:81':'agent.py:354')]);
    add('investigate','Investigator',direct?'Shared question adapter':'Selected research agent','control',500,40,
      'The outer graph invokes the nested agent. Its model and tool loop are expanded below. The outer invocation can remain active while several nested callbacks run.',
      [direct?path+'direct_request.py:217':source+(led?'agent_led.py:57':'agent.py:314')]);
    add('boundary',led?'Event boundary':'Budget boundary',led?'New input + budget guard':'Budget guard only','guard',280,210,
      'Before each model call, check the run window, call budget, token budget and message/tool pairing. '+(led?'Inject newly arrived events before the model continues.':'Native mode does not inject new events at this boundary; the outer observation step supplies them.'),
      [direct?path+'direct_request.py:160':source+'agent.py:180']);
    add('model','Qwen2.5 14B','Choose next action','model',500,210,
      'The model can request the available tools or return prose. Runtime model callbacks report actual model activity; they do not expose hidden reasoning. A finished call is not a correctness judgment.',
      [direct?path+'direct_request.py:217':source+(led?'agent_led.py:68':'agent.py:345'),path+'monitor_runtime.py:248']);
    add('tools',led?'Optional tools':'Native tools','Dispatch requested calls','tool',500,370,
      'The nested tools node dispatches model-requested tools. Multiple tool callbacks may overlap. Starting or finishing this node does not mean every available tool was used.',
      [direct?path+'direct_request.py:201':source+(led?'agent_led_tools.py:131':'agent.py:210')]);
    add('sources','Source jobs','Search · read document','source',260,530,
      'Search and read_document start asynchronous jobs over the supplied corpus. A pending acknowledgment is not source content. Arrived results return through observations. Active tool callbacks and pending source jobs are displayed separately.',
      [source+'agent.py:214',source+'world.py']);
    if (web) add('web','Web search / read','Immediate tool results','source',30,530,
      'Optional web_search queries the public web through DDGS, using Bing with DuckDuckGo fallback. read_web_page reads a public page. Both return synchronous tool results and save receipts; they do not create pending source jobs or require wait_for_event. Search queries are sent to the provider. Retrieved content is untrusted evidence, not instructions or a guarantee of correctness.',
      [path+'web_tools.py:232',path+'web_tools.py:246']);
    add('event-control','Wait / cancel','Pending job control','tool',30,370,
      'wait_for_event yields control so the outer loop can observe arrived events. cancel_job cancels a selected pending source job. A pending job alone does not establish that either control tool is currently executing.',
      [source+'agent.py:228',source+'agent.py:240']);
    add('working-state',knowledgeTools?'Private notes':'Private workspace',knowledgeTools?'save_notes':'Files + saved notes','state',500,530,
      knowledgeTools?'save_notes keeps private working material. This question profile excludes virtual file tools from the model. Supplied documents remain available through read_document. Notes are not a delivered response.':'Private file tools and save_notes keep working material. read_file reads virtual working files; read_document retrieves supplied source content. Workspace writes are not a delivered response or a published help card.',
      [source+'agent.py:245',direct?path+'direct_request.py:217':source+(led?'agent_led.py:68':'agent.py:345')]);
    add('persistence','Saved state','Checkpoints + world ledger','state',990,530,
      'The outer graph checkpointer and world ledger preserve graph state, tool receipts and simulated events. The current telemetry does not provide a separate persistence callback, so this component remains structural.',
      [direct?path+'direct_request.py:316':source+(led?'agent_led.py:124':'agent.py:382'),source+'world.py'],false);
    if (led) add('calculate','Calculate','Agent-led tool','tool',750,530,
      'A model-selected arithmetic tool in the agent-led family. Calculation uses explicitly supplied operands and records its result; the tool is not present in the native reference configuration.',
      [source+'agent_led_tools.py:136']);
    if (direct) {
      add('response','Deliver response','Final prose or no response','output',990,40,
        'Deliver the final non-tool AI message to direct_response.json. Empty output, a closed window or an exhausted budget may produce a no_response record. Delivery is a transport result, not an answer-quality gate.',
        [path+'direct_request.py:292']);
      add('request-response','Empty-output retry','At most one continuation','control',990,210,
        'After an empty final model message, request one bounded continuation. This shared task-adapter behavior is distinct from the selected harness’s failed-tool recovery.',
        [path+'direct_request.py:268']);
    } else {
      add('publication','Publish / withdraw','Explicit help-card action','output',990,370,
        'Only explicit publish_card or withdraw_card calls alter displayed help cards. Ordinary final prose stays private in conversation replay. '+(led?'Private evidence advice is a separate optional tool.':'The native publication tool uses its selected validation contract.'),
        [source+(led?'agent_led_tools.py:175':'agent.py:263')]);
      if (led) add('evidence-advice','Evidence advice','Optional private review','feedback',990,210,
        'evidence_check can request sources-only feedback on a draft using the shared model budget. The result is private advice. It neither publishes a card nor approves publication.',
        [source+'agent_led_tools.py:175']);
    }
    if (recovery) add('recovery','Failure recovery',direct?'Check eligible tool exit':'Inside observe','guard',750,40,
      direct?'The consider_recovery node checks whether an eligible failed tool exit warrants bounded recovery feedback. Entering the node does not prove recovery was requested; a subsequent investigator transition records continuation.':'The observer checks failed-tool feedback and may give the model a bounded opportunity to continue. This is a branch inside observe, not a separately instrumented graph node.',
      [direct?path+'direct_request.py:274':source+'agent_led.py:81'],direct);
    if (progress) add('progress','Investigation progress','Feedback before the model','feedback',750,210,
      'Project bounded progress facts from existing messages and append them to each model request. This wrapper has no independent runtime callback. Its configured presence is shown here without claiming an observed active step.',
      [direct?path+'direct_request.py:93':source+'investigation_progress.py:178'],false);
    edge('input','observe','Input events','data');
    edge('observe','investigate','Run while in budget');
    edge('investigate','boundary','Nested agent invocation','control','M592 106 V146 H372 V210');
    edge('boundary','model','Prepared model input');
    edge('model','tools','Tool requests');
    edge('tools','boundary','Continue after tool results','control','M500 403 H440 V300 H372 V276');
    edge('tools','sources','Search / read_document','data','M541 436 V476 H352 V530');
    if (web) {
      edge('tools','web','Optional web_search / read_web_page','data','M520 436 V492 H122 V530');
      edge('web','tools','Immediate tool result','data','M122 530 V510 H476 V422 H500');
    }
    edge('tools','event-control','Wait / cancel','control');
    edge('tools','working-state',knowledgeTools?'save_notes':'Private files / save_notes','data');
    edge('working-state','persistence','Persisted working state','data','M592 596 V622 H1082 V596');
    edge('sources','observe','Arrived source events','data','M260 563 H240 V73 H265');
    edge('event-control','observe','Return to observation','control','M122 370 V144 H357 V106');
    if (led) edge('tools','calculate','Arithmetic','data','M643 436 V476 H842 V530');
    if (direct) {
      const after = recovery?'recovery':'investigate';
      if (recovery) {
        edge('investigate','recovery','Check eligible failure');
        edge('recovery','investigate','Recovery continuation','control','M842 40 V22 H592 V40');
      }
      edge(after,'response','Final response / stop');
      edge(after,'request-response','Empty final output','control',recovery?'M842 106 V160 H1082 V210':'M684 88 H965 V170 H1082 V210');
      edge(after,'observe','Wait for observations','control',recovery?'M795 40 V10 H357 V40':'M547 40 V10 H357 V40');
      edge('request-response','investigate','One continuation','control','M990 243 H957 V132 H638 V106');
      edge('observe','response','Window or budget stop','control','M407 40 V0 H1082 V40');
    } else {
      edge('investigate','observe','Next observation','control','M547 40 V10 H357 V40');
      edge('tools','publication','Explicit card tools','control');
      if (led) edge('tools','evidence-advice','Private draft advice','control','M684 391 H966 V243 H990');
      if (recovery) edge('recovery','observe','Recovery feedback inside observer','data','M842 40 V0 H402 V40');
    }
    if (progress) edge('progress','model','Request projection','data');
    return freeze({id:harness+':'+mode+(web?':web':'')+(knowledgeTools?':knowledge':''),harness,mode,supported:true,width:1240,height:650,
      label:names[harness],subtitle:direct?(harness==='frozen-baseline'?'Frozen recovery code + shared question adapter':'Direct question · '+(progress?'recovery + progress feedback':led?'agent-led tools':'native tool set')):'Historical conversation replay',
      features:{agentLed:led,recovery,progress,direct,webRetrieval:web,knowledgeTools},nodes,edges});
  }

  const templates = {};
  for (const harness of Object.keys(names)) for (const mode of ['direct_request','human_human_transcript']) templates[harness+':'+mode] = buildTemplate(harness,mode);
  for (const harness of Object.keys(names)) templates[harness+':direct_request:web'] = buildTemplate(harness,'direct_request',true);
  for (const harness of Object.keys(names)) templates[harness+':direct_request:web:knowledge'] = buildTemplate(harness,'direct_request',true,true);
  const unknown = freeze({id:'unknown',label:'Unmapped configuration',subtitle:'No source template matches this task contract',mode:'unknown',supported:false,width:1240,height:260,nodes:[],edges:[],features:{}});
  freeze(templates);
  function resolveTemplate(value = {}) {
    const harness = value.harness==='direct-help'?'agent-led':value.harness;
    const version = value.task_contract_version;
    if (version != null && (!Number.isInteger(version) || version < 1 || version > 3)) return unknown;
    let mode=value.input_mode;
    if (!mode) mode=value.harness==='direct-help'?'direct_request':'human_human_transcript';
    const web = mode==='direct_request' && (value.capabilities?.web_retrieval===true ||
      typeof value.source_fingerprint?.source_sha256?.[path+'web_tools.py']==='string');
    const knowledge=web && (value.capabilities?.question_tool_profile==='knowledge' ||
      value.source_fingerprint?.question_tool_profile==='knowledge');
    return templates[harness+':'+mode+(web?':web':'')+(knowledge?':knowledge':'')] || unknown;
  }

  function mapEvent(template, event) {
    if (!template.supported || !event || typeof event.event !== 'string') return null;
    const kind=event.event.split('_')[0], name=String(event.name||''), node=String(event.node||'');
    if (kind==='model') {
      const role=event.data?.harness_role;
      if (!template.features.direct && template.features.agentLed && (role==='evidence_advice' || node==='tools')) return 'evidence-advice';
      if (role && role!=='investigator') return null;
      return node==='tools'?null:'model';
    }
    if (kind==='tool') {
      if (['search','read_document'].includes(name)) return 'sources';
      if (['web_search','read_web_page'].includes(name) && template.features.webRetrieval) return 'web';
      if (['wait_for_event','cancel_job'].includes(name)) return 'event-control';
      if (name==='save_notes' || (!template.features.knowledgeTools && ['ls','read_file','write_file','edit_file','delete','glob','grep'].includes(name))) return 'working-state';
      if (name==='calculate' && template.features.agentLed) return 'calculate';
      if (['publish_card','withdraw_card'].includes(name) && !template.features.direct) return 'publication';
      if (name==='evidence_check' && !template.features.direct && template.features.agentLed) return 'evidence-advice';
      return null;
    }
    if (kind!=='node') return null;
    const nested=String(event.graph_namespace||'').includes('|');
    if (['observe','investigate'].includes(node) && !nested) return node;
    if (node==='consider_recovery' && !nested && template.features.direct && template.features.recovery) return 'recovery';
    if (node==='deliver_response' && !nested && template.features.direct) return 'response';
    if (node==='request_response' && !nested && template.features.direct) return 'request-response';
    if (['DirectEventBoundary.before_model','EventBoundary.before_model'].includes(node)) {
      // A mismatched task boundary is evidence of an older/different adapter.
      if (template.features.direct && node!=='DirectEventBoundary.before_model') return null;
      if (!template.features.direct && node!=='EventBoundary.before_model') return null;
      return 'boundary';
    }
    if (node==='model') return 'model';
    if (node==='tools') return 'tools';
    return null;
  }
  const isError = event => /_error$/.test(event.event||'') || Boolean(event.data?.error_code) || ['error','failed','not_published'].includes(event.data?.status);
  const isStart = event => /^(node|model|tool)_start$/.test(event.event||'');
  const seq = event => Number.isInteger(event.seq) && event.seq >= 0 ? event.seq : -1;
  const scope = event => event.session_id && event.parent_run_id ? event.session_id+'|'+event.parent_run_id : null;
  const keyFor = event => String(event.session_id||'')+'|'+seq(event)+'|'+String(event.event||'')+'|'+String(event.run_id||'');

  function project(template, input = {}, previous = null) {
    template=template?.supported===undefined?unknown:template;
    const packet=input.packet||{}, job=input.job||{}, runtime=packet.runtime||{}, status=runtime.status||{};
    const suppliedEvents=array(runtime.events).filter(event=>event && typeof event==='object');
    const runId=String(job.id||packet.run?.id||packet.run_id||'');
    const newestSupplied=[...suppliedEvents].sort((a,b)=>seq(a)-seq(b)).at(-1);
    const sessionId=String(status.session_id||newestSupplied?.session_id||'');
    const same=Boolean(previous && previous.templateId===template.id && previous.cursor?.runId===runId && previous.cursor?.sessionId===sessionId);
    const events=[], seen=new Set();
    for (const event of [...(same?previous._events||[]:[]),...suppliedEvents]) {
      if (!event || typeof event!=='object') continue;
      const key=keyFor(event); if (seen.has(key)) continue; seen.add(key); events.push(event);
    }
    events.sort((a,b)=>seq(a)-seq(b));
    const currentEvents=events.filter(e=>!sessionId||e.session_id===sessionId);
    const maxSeq=Math.max(same?previous.cursor.maxSeq:-1,...currentEvents.map(seq));
    const live=Boolean(input.live && !terminal.has(job.status) && !terminal.has(status.status) && packet.run?.heartbeat_fresh!==false);
    const nodes=Object.fromEntries(template.nodes.map(node=>[node.id,{visits:0,active:false,activeCount:0,errors:0,pending:0,lastEvent:null}]));
    const edges=Object.fromEntries(template.edges.map(edge=>[edge.id,{observed:0,lastEvent:null}]));
    const result={templateId:template.id,nodes,edges,pulses:[],cursor:{runId,sessionId,maxSeq},live,activeCount:0,lastEvent:null,unsupported:0,_events:events};
    const completed=new Map(), open=new Map(), nodeByRun=new Map();
    const edgeSeen=new Set();
    const observed=(edgeId,event) => {
      if (!edges[edgeId]) return;
      const eventKey=edgeId+'|'+keyFor(event); if(edgeSeen.has(eventKey))return; edgeSeen.add(eventKey);
      edges[edgeId].observed++; edges[edgeId].lastEvent=event;
      if (live && same && seq(event)>previous.cursor.maxSeq && event.session_id===sessionId) result.pulses.push({edgeId,seq:seq(event)});
    };
    for (const event of events) {
      const group=scope(event), prior=group?completed.get(group):null;
      // Any intervening sibling start consumes the previous completed node,
      // including unknown nodes. Missing/error callbacks cannot bridge a gap.
      if (group && /^node_(start|error)$/.test(event.event||'')) completed.delete(group);
      const id=mapEvent(template,event);
      if (!id || !nodes[id]) {
        if (/^(node|model|tool)_(start|end|error)$/.test(event.event||'') && !String(event.node||'').startsWith('PatchToolCallsMiddleware.')) result.unsupported++;
        continue;
      }
      const node=nodes[id]; node.lastEvent=event; result.lastEvent=event;
      if (isError(event)) node.errors++;
      if (event.event==='node_start' || event.event==='tool_start') node.visits++;
      if (event.event==='node_start') {
        nodeByRun.set(String(event.run_id),{id,event});
      }
      // A sibling node transition requires an actual end, start, same graph
      // parent, increasing graph step and a source-declared direct edge.
      if (event.event==='node_start') {
        if(prior && prior.id!==id && prior.event.session_id===event.session_id &&
          seq(prior.event)>=0 && seq(event)>seq(prior.event) &&
          Number.isInteger(prior.event.graph_step) && Number.isInteger(event.graph_step) &&
          event.graph_step===prior.event.graph_step+1) observed(prior.id+'--'+id,event);
      }
      if (event.event==='node_end' && !isError(event)) {
        const start=nodeByRun.get(String(event.run_id)), group=scope(event);
        if(start && group && start.id===id && start.event.session_id===event.session_id && seq(event)>seq(start.event)) completed.set(group,{id,event});
      }
      // A named tool is dispatched by a recorded tools node; never connect
      // parallel tools to each other by their incidental log order.
      if (event.event==='tool_start') {
        const parent=event.parent_run_id?open.get(String(event.parent_run_id)):null;
        if (parent?.id==='tools' && parent.event.event==='node_start' && parent.event.session_id===event.session_id) observed('tools--'+id,event);
      }
      if (isStart(event)) open.set(String(event.run_id),{id,event});
      if (/_end$|_error$/.test(event.event||'')) open.delete(String(event.run_id));
    }
    // Live state comes from current callback tables, not the last historical
    // event, graph topology, pending checkpoint branches or model output text.
    if (live && template.supported) {
      for (const [table,type] of [['active_nodes','node'],['active_models','model'],['active_tools','tool']]) {
        const activeSeen=new Set();
        for (const entry of array(status[table])) {
          if (entry?.session_id && entry.session_id!==sessionId)continue;
          const id=mapEvent(template,{...entry,event:type+'_start'});
          if (!id || !nodes[id] || !template.nodes.find(node=>node.id===id)?.observable)continue;
          const key=id+'|'+String(entry.run_id||entry.name||entry.node);
          if(activeSeen.has(key))continue; activeSeen.add(key);
          nodes[id].active=true; nodes[id].activeCount++;
        }
      }
    }
    if(nodes.sources)nodes.sources.pending=array(packet.world?.pending_jobs).filter(job=>!job.status||job.status==='pending').length;
    result.activeCount=Object.values(nodes).filter(node=>node.active).length;
    return result;
  }

  function svg(tag, attrs = {}, text) {
    const node=document.createElementNS(SVG,tag);
    for (const [key,value] of Object.entries(attrs)) node.setAttribute(key,String(value));
    if(text!==undefined)node.textContent=String(text); return node;
  }
  function edgePath(edge, nodes) {
    if(edge.path)return edge.path;
    const a=nodes.get(edge.from), b=nodes.get(edge.to), ax=a.x+a.width/2, ay=a.y+a.height/2, bx=b.x+b.width/2, by=b.y+b.height/2;
    if(a.y===b.y)return b.x>a.x?`M${a.x+a.width} ${ay} H${b.x}`:`M${a.x} ${ay} H${b.x+b.width}`;
    if(a.x===b.x)return b.y>a.y?`M${ax} ${a.y+a.height} V${b.y}`:`M${ax} ${a.y} V${b.y+b.height}`;
    const startY=b.y>a.y?a.y+a.height:a.y, endY=b.y>a.y?b.y:b.y+b.height, mid=(startY+endY)/2;
    return `M${ax} ${startY} V${mid} H${bx} V${endY}`;
  }
  let rendererNumber=0;
  function mount(host, options = {}) {
    if (!host || typeof host.replaceChildren!=='function') throw new TypeError('A graph container is required.');
    let templateId=null, currentTemplate=null, currentProjection=null, selectedNode=null, rootSvg=null;
    const nodeEls=new Map(), edgeEls=new Map(), timers=new Map(), played=new Set();
    const instance='hg-'+(++rendererNumber);
    const clearTimers=()=>{for(const timer of timers.values())clearTimeout(timer);timers.clear();};
    const select=id=>{
      selectedNode=id;
      for(const [key,parts]of nodeEls){parts.group.classList.toggle('hg-selected',key===id);parts.group.setAttribute('aria-pressed',String(key===id));}
      const node=currentTemplate?.nodes.find(item=>item.id===id);
      if(node && options.onSelect)options.onSelect(node,currentProjection?.nodes?.[id]||{});
    };
    function build(template) {
      clearTimers();played.clear();nodeEls.clear();edgeEls.clear();currentTemplate=template;templateId=template.id;
      rootSvg=svg('svg',{viewBox:`-12 -22 ${template.width+24} ${template.height+22}`,class:'hg-svg',role:'group','aria-label':`${template.label}: ${template.subtitle}`});
      if(!template.supported){const message=document.createElement('p');message.className='empty';message.textContent='This saved configuration has no matching architecture template.';host.replaceChildren(message);return;}
      const defs=svg('defs');
      for(const [kind,color]of [['normal','#8ea7bd'],['observed','#639689'],['flow','#58e5bc']]){
        const marker=svg('marker',{id:instance+'-'+kind,markerWidth:7,markerHeight:7,refX:6,refY:3,orient:'auto',markerUnits:'userSpaceOnUse'});
        marker.append(svg('path',{d:'M0 0 L6 3 L0 6',fill:color}));defs.append(marker);
      }
      rootSvg.append(defs);
      const group=svg('g',{class:'hg-zones','aria-hidden':'true'});
      group.append(svg('rect',{x:253,y:170,width:691,height:312,rx:18,class:'hg-zone'}),svg('text',{x:275,y:191,class:'hg-zone-label'},'MODEL AND TOOL LOOP'));
      rootSvg.append(group);
      const positions=new Map(template.nodes.map(node=>[node.id,node]));
      const edgeLayer=svg('g',{class:'hg-edges'});
      for(const edge of template.edges){
        const d=edgePath(edge,positions), base=svg('path',{d,class:'hg-edge'+(edge.kind==='data'?' hg-data':''),'data-edge':edge.id,'marker-end':`url(#${instance}-normal)`});
        base.append(svg('title',{},edge.label));
        const flow=svg('path',{d,class:'hg-flow','data-flow':edge.id,'aria-hidden':'true','marker-end':`url(#${instance}-flow)`});
        edgeLayer.append(base,flow);edgeEls.set(edge.id,{base,flow});
      }
      rootSvg.append(edgeLayer);
      for(const node of template.nodes){
        const group=svg('g',{class:'hg-node hg-'+node.kind,role:'button',tabindex:0,'data-node':node.id,'aria-pressed':'false'});
        group.append(svg('title',{},node.description),svg('rect',{x:node.x,y:node.y,width:node.width,height:node.height,rx:11}),svg('circle',{cx:node.x+15,cy:node.y+20,r:3.5,class:'hg-status-dot'}),svg('text',{x:node.x+28,y:node.y+25,class:'hg-node-label'},node.label),svg('text',{x:node.x+15,y:node.y+46,class:'hg-node-subtitle'},node.subtitle));
        const status=svg('text',{x:node.x+node.width-9,y:node.y+61,'text-anchor':'end',class:'hg-node-status'});group.append(status);
        group.addEventListener('click',()=>select(node.id));group.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();select(node.id);}});
        rootSvg.append(group);nodeEls.set(node.id,{group,status});
      }
      host.replaceChildren(rootSvg);
    }
    return {
      update(template, projection, settings = {}) {
        if(!template || !projection)throw new TypeError('Template and projected state are required.');
        const changedRun=currentProjection && (projection.cursor.runId!==currentProjection.cursor.runId||projection.cursor.sessionId!==currentProjection.cursor.sessionId);
        if(templateId!==template.id)build(template);
        if(changedRun){clearTimers();played.clear();for(const value of edgeEls.values())value.flow.classList.remove('hg-flowing');}
        currentTemplate=template;currentProjection=projection;
        selectedNode=settings.selectedNode?.id||settings.selectedNode||null;
        for(const node of template.nodes){
          const value=projection.nodes[node.id]||{}, parts=nodeEls.get(node.id);if(!parts)continue;
          const recorded=Boolean(value.lastEvent);
          const labels=[node.label,value.active?'active':recorded?'observed':'not observed',value.errors?`${value.errors} error callbacks`:null,value.pending?`${value.pending} pending source jobs`:null].filter(Boolean);
          parts.group.setAttribute('class',['hg-node','hg-'+node.kind,value.active?'hg-active':'',recorded?'hg-visited':'',value.errors?'hg-error':'',value.pending?'hg-pending':'',selectedNode===node.id?'hg-selected':'',!node.observable?'hg-structural':''].filter(Boolean).join(' '));
          parts.group.setAttribute('aria-label',labels.join(', '));parts.group.setAttribute('aria-pressed',String(selectedNode===node.id));
          parts.status.textContent=value.active?'ACTIVE':value.pending?`${value.pending} pending`:value.errors?'ERROR':recorded?'OBSERVED':!node.observable?'STRUCTURAL':'';
        }
        for(const edge of template.edges){const value=projection.edges[edge.id]||{}, parts=edgeEls.get(edge.id);if(!parts)continue;parts.base.classList.toggle('hg-observed',Boolean(value.observed));parts.base.setAttribute('marker-end',`url(#${instance}-${value.observed?'observed':'normal'})`);if(!projection.live)parts.flow.classList.remove('hg-flowing');}
        if(!projection.live)clearTimers();
        for(const pulse of projection.pulses||[]){
          const key=projection.cursor.runId+'|'+projection.cursor.sessionId+'|'+pulse.edgeId+'|'+pulse.seq, parts=edgeEls.get(pulse.edgeId);
          if(!projection.live||played.has(key)||!parts)continue;played.add(key);
          if(timers.has(pulse.edgeId))clearTimeout(timers.get(pulse.edgeId));
          parts.flow.classList.remove('hg-flowing');
          // Only a new observed transition restarts its CSS animation. Polling,
          // selections and resize do not rebuild SVG or replay old transitions.
          void parts.flow.getBoundingClientRect();parts.flow.classList.add('hg-flowing');
          const timer=setTimeout(()=>{parts.flow.classList.remove('hg-flowing');timers.delete(pulse.edgeId);},1700);timers.set(pulse.edgeId,timer);
        }
        return rootSvg;
      },
      select,
      destroy(){clearTimers();host.replaceChildren();nodeEls.clear();edgeEls.clear();played.clear();}
    };
  }
  return freeze({templates,resolveTemplate,mapEvent,project,mount});
});
