"""Freeze reviewed root-cause evidence; no model calls, training or new scoring.

Public exports retain aggregate evidence and source hashes. Original dialogue,
completion targets and individual generated responses remain local and unchanged.
"""
from pathlib import Path
from datetime import datetime, timezone
import ast
import copy
import hashlib
import importlib.util
import json
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
CODE = ROOT/'experiments/deep_conversation/tracker_lora'
EXPECTED_REPORT_SHA256 = 'ec0d09597640ff32725b12817d4fbd468f7e543f54d79631e913326a533d2127'
LOCAL_PATH = re.compile(rb'(?<![A-Za-z0-9])[A-Za-z]:[\\/]+')
FORBIDDEN = {'blind_id','assignment_id','output_text','raw_audit_output','raw_output',
    'per_assignment','model_messages','candidate_output','messages','conversation',
    'generated_operations','generated_token_ids','input_token_ids','raw_prompt',
    'raw_response','canonical_completion','raw_dialogue','raw_report'}

def read(p): return json.loads(p.read_text(encoding='utf-8'))
def sha(p):
    with p.open('rb') as stream: return hashlib.file_digest(stream,'sha256').hexdigest()
def encode(v): return (json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')
def relative(v):
    if isinstance(v,dict): return {relative(k):relative(x) for k,x in v.items()}
    if isinstance(v,list): return [relative(x) for x in v]
    if isinstance(v,str):
        for prefix in (str(ROOT),ROOT.as_posix()):
            v=v.replace(prefix+'\\','').replace(prefix+'/','')
        v=re.sub(r'[A-Za-z]:[\\/][^\n\r\"]*?(?=\", line|\n|$)','[local environment path]',v)
        v=re.sub(r'[A-Za-z]:[\\/][^\s\"\'<>]+','[local environment path]',v)
    return v

def public_json(v,where='$'):
    if isinstance(v,dict):
        assert not set(v)&FORBIDDEN,(where,set(v)&FORBIDDEN)
        for key,value in v.items(): public_json(value,where+'.'+key)
    elif isinstance(v,list):
        for value in v: public_json(value,where+'[]')

def omit(v,key,notes):
    assert key in v,key
    del v[key]
    notes.append('Omit '+key+' containing individual dialogue/target/output details.')

def filtered_json(name,source):
    v=copy.deepcopy(source)
    notes=[]
    if name=='data-assessment.json':
        omit(v['limited_semantic_inspection'],'reviewed_examples',notes)
    elif name=='repair-position-addendum.json':
        omit(v,'training_row_layouts',notes)
        omit(v,'six_training_fit_mappings',notes)
    elif name=='method-report.json':
        omit(v,'non_syntax_failures_observed',notes)
    elif name=='fit-selection.json':
        for case in v['cases']: del case['expected_focal_metadata']
        notes.append('Omit per-case expected owner/status values; preserve selection IDs, hashes and source-order rule.')
    elif name=='fit-source-review.json':
        keep={'case_id','source_example_id','runtime_reference_control','semantic_source_review','limitation'}
        v['cases']=[{k:x for k,x in case.items() if k in keep} for case in v['cases']]
        notes.append('Project cases to IDs and existing review verdicts; omit dialogue evidence, prior/target state, repair and semantic notes.')
    elif name=='adapter-off-post-review.json':
        remove={'records','changed_fields_with_evidence_review','raw_evidence_review'}
        v['cases']=[{k:x for k,x in case.items() if k not in remove} for case in v['cases']]
        notes.append('Omit record text, changed-field evidence details and raw-evidence commentary; preserve recorded per-case metrics and aggregate judgments.')
    elif name=='fit-post-review.json':
        remove={'records','operations_evidence_review','note'}
        v['cases']=[{k:x for k,x in case.items() if k not in remove} for case in v['cases']]
        notes.append('Omit record states, operation evidence commentary and case notes; preserve recorded per-case metrics and aggregate judgments.')
    v=relative(v)
    notes.append('JSON formatting and local path redaction only for retained fields; original source hashes are unchanged.')
    return encode(v),' '.join(notes)

def main():
    report_path=HERE/'analysis/report.json'
    assert sha(report_path)==EXPECTED_REPORT_SHA256,'Report changed: require a new independent review.'
    report=read(report_path)
    final_path=HERE/'review/final-report-review.json'
    final=read(final_path)
    assert final['status']=='passed'
    assert final['reviewed_report_sha256']==sha(report_path)
    assert final['reviewed_validation_sha256']==sha(HERE/'engineering/validation.json')
    for relative_path,expected in final['source_hashes'].items():
        assert sha(ROOT/relative_path)==expected,relative_path
    assert report['status']=='completed' and report['kind']=='root_cause_diagnostic'
    assert report['new_model_calls']==18 and report['reused_model_calls']==12 and report['training_runs']==0
    assert read(HERE/'method/adapter-off-post-review.json')['status']=='passed'
    assert read(HERE/'fit/post-review.json')['status']=='passed'
    assert read(HERE/'ablation/adapter-off-01/result.json')['status']=='failed'
    assert read(HERE/'fit/collection-01/result.json')['status']=='completed'
    dest=HERE/'publication/diagnosis-01'
    assert not dest.exists(),'Never overwrite a frozen publication package.'
    paths={
        'report.json':report_path,
        'final-report-review.json':final_path,
        'engineering-validation.json':HERE/'engineering/validation.json',
        'prior-bundles.json':HERE/'analysis/prior-bundles.json',
        'data-census.json':HERE/'data/census.json',
        'data-assessment.json':HERE/'data/assessment.json',
        'repair-position-addendum.json':HERE/'data/repair-position-addendum.json',
        'method-report.json':HERE/'method/method-report.json',
        'adapter-off-protocol.json':HERE/'method/adapter-off-protocol.json',
        'adapter-off-preflight-review-initial.json':HERE/'method/adapter-off-preflight-review.json',
        'adapter-off-preflight-review-v2.json':HERE/'method/adapter-off-preflight-review-v2.json',
        'adapter-off-post-review.json':HERE/'method/adapter-off-post-review.json',
        'adapter-off-config.json':HERE/'ablation/adapter-off-01/config.json',
        'adapter-off-result.json':HERE/'ablation/adapter-off-01/result.json',
        'adapter-off-attempts.jsonl':HERE/'ablation/adapter-off-01/attempts.jsonl',
        'training-runtime-integrity.json':HERE/'training/runtime-integrity.json',
        'training-cause-assessment.json':HERE/'training/cause-assessment.json',
        'adapter-tensor-statistics.json':HERE/'training/adapter-tensor-statistics.json',
        'adapter-context-postcheck.json':HERE/'training/adapter-context-postcheck.json',
        'fit-selection.json':HERE/'fit/selection.json',
        'fit-protocol.json':HERE/'fit/protocol.json',
        'fit-protocol-initial.json':HERE/'fit/preflight-history/protocol-initial.json',
        'fit-source-review.json':HERE/'fit/source-review.json',
        'fit-preflight-review.json':HERE/'fit/preflight-review.json',
        'fit-post-review.json':HERE/'fit/post-review.json',
        'fit-config.json':HERE/'fit/collection-01/config.json',
        'fit-result.json':HERE/'fit/collection-01/result.json',
        'fit-attempts.jsonl':HERE/'fit/collection-01/attempts.jsonl',
        'build_report.py':HERE/'build_report.py',
        'export_publication.py':Path(__file__),
        'review_final_report.py':HERE/'review/review_final_report.py',
        'inspect_training_data.py':HERE/'data/inspect_training_data.py',
        'write_repair_position_addendum.py':HERE/'data/write_repair_position_addendum.py',
        'audit_training.py':HERE/'training/audit_training.py',
        'check_adapter_context.py':HERE/'training/check_adapter_context.py',
        'method-freeze-protocol.py':HERE/'method/freeze_protocol.py',
        'method-review-preflight.py':HERE/'method/review_preflight.py',
        'method-review-preflight-v2.py':HERE/'method/review_preflight_v2.py',
        'inspect_completed_diagnostic.py':HERE/'method/inspect_completed_diagnostic.py',
        'fit-prepare-selection.py':HERE/'fit/prepare_selection.py',
        'fit-align-protocol-contract.py':HERE/'fit/align_protocol_contract.py',
        'fit-write-preflight-review.py':HERE/'fit/write_preflight_review.py',
        'inspect_generated_fit.py':HERE/'fit/inspect_generated_fit.py',
        'collect_audit_adapter_off.py':CODE/'diagnostics/collect_audit_adapter_off.py',
        'collect_training_fit.py':CODE/'diagnostics/collect_training_fit.py',
        'collect_three_arm.py':CODE/'repair_v2/collect_three_arm.py',
        'evaluate_tracker.py':CODE/'evaluate_tracker.py',
        'intention_state.py':ROOT/'experiments/deep_conversation/intention_state.py',
        'intent_audit.py':CODE/'intent_audit/audit.py',
        'intent_pipeline.py':CODE/'intent_audit/pipeline.py',
    }
    # Reuse exactly the release checker's prohibited-field validation as well as
    # the stricter local guard. Importing the checker does not run its main().
    checker_path=HERE/'release/check_release.py'
    spec=importlib.util.spec_from_file_location('root_cause_release_contract',checker_path)
    checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
    payloads={};bindings={}
    for name,path in paths.items():
        assert Path(name).name==name and not name.startswith('PRIVATE-')
        data=path.read_bytes();transformation='none'
        if path.suffix=='.json' and name!='report.json':
            data,transformation=filtered_json(name,read(path))
        assert not LOCAL_PATH.search(data),name
        assert '\ufffd' not in data.decode('utf-8'),name
        if name.endswith('.json'):
            value=json.loads(data);public_json(value,name);checker.public_json(value,name)
        elif name.endswith('.jsonl'):
            for line in data.decode('utf-8').splitlines():
                value=json.loads(line);public_json(value,name);checker.public_json(value,name)
        elif name.endswith('.py'):
            ast.parse(data.decode('utf-8'))
        payloads[name]=data
        bindings[name]={'source_path':path.relative_to(ROOT).as_posix(),'source_sha256':sha(path),
            'export_sha256':hashlib.sha256(data).hexdigest(),'transformation':transformation}
    assert payloads['report.json']==report_path.read_bytes()
    summary={**report,'independent_final_audit':'passed',
        'reviewed_interpretation_source_sha256':sha(report_path),
        'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'source_and_export_files':bindings,
        'publication_policy':{
            'originals_preserved':True,'original_reports_replaced':False,
            'excluded_content':['PRIVATE call/outcome/review files','Original conversation/prompt/completion text',
                'Individual generated outputs or operations','Full generated/input token ID sequences',
                'Manual review writer scripts that restate omitted case content'],
            'source_hashes_include_unpublished_evidence':True,
            'public_review_limits':'Public summaries are derived exports of the existing reviews, not new scoring. Exact local source files remain bound by SHA256.',
            'release_checker_sha256':sha(checker_path)}}
    data=encode(summary);public_json(summary);checker.public_json(summary)
    assert not LOCAL_PATH.search(data) and '\ufffd' not in data.decode('utf-8')
    # Validate every payload before creating the one-time destination.
    dest.mkdir(parents=True)
    for name,content in payloads.items(): (dest/name).write_bytes(content)
    (dest/'summary.json').write_bytes(data)
    assert len(list(dest.iterdir()))==len(payloads)+1
    assert (dest/'report.json').read_bytes()==report_path.read_bytes()
    for name,binding in bindings.items():
        assert sha(dest/name)==binding['export_sha256']
        assert sha(ROOT/binding['source_path'])==binding['source_sha256']
    print(json.dumps({'status':'frozen','files':len(payloads)+1,
        'report_sha256':sha(dest/'report.json'),'summary_sha256':sha(dest/'summary.json'),
        'new_model_calls':0,'new_training_runs':0,'new_semantic_scoring_runs':0},ensure_ascii=False))

if __name__=='__main__':main()
