"""One-pass owner/status audit over every existing intention.

The harness validates coverage, provenance references and legal transitions.
It does not infer what the user meant or certify that a model's verdict is true.
No model loader, training, implicit retry or hidden reference label lives here.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path
import sys

_DEEP_CONVERSATION = Path(__file__).resolve().parents[2]
if str(_DEEP_CONVERSATION) not in sys.path:
    sys.path.insert(0, str(_DEEP_CONVERSATION))
from intention_state import IntentConflictError, IntentValidationError


class AuditValidationError(ValueError):
    """The report/request fails a structural audit contract."""


_REQUEST_KEYS = {'schema', 'snapshot', 'expected_version', 'through_seq',
                 'conversation', 'intent_ids'}
_FIELD_KEYS = {'verdict', 'value', 'source_seqs'}
_VERDICTS = {'keep', 'change', 'insufficient'}
_STATUSES = {'active', 'uncertain', 'withdrawn'}


def _require(condition, message):
    if not condition:
        raise AuditValidationError(message)


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False)


def _strict_json(raw):
    _require(isinstance(raw, str), 'Audit output must be a JSON string.')

    def pairs(items):
        result = {}
        for key, value in items:
            _require(key not in result, 'Duplicate JSON object key.')
            result[key] = value
        return result

    def constant(_):
        raise AuditValidationError('Nonfinite JSON is not allowed.')

    try:
        value = json.loads(raw, object_pairs_hook=pairs, parse_constant=constant)
        _canonical(value)
        return value
    except (json.JSONDecodeError, TypeError, ValueError, RecursionError) as error:
        if isinstance(error, AuditValidationError):
            raise
        raise AuditValidationError(str(error)) from error


def build_request(store, max_intents=12, max_events=40):
    """Capture all existing records and all arrived raw dialogue, without truncation.

    The caps bound this first implementation. Exceeding a cap raises rather than
    dropping records or history. A changed snapshot during capture also raises.
    """
    _require(type(max_intents) is int and max_intents >= 0, 'Invalid intent cap.')
    _require(type(max_events) is int and max_events >= 0, 'Invalid event cap.')
    snapshot = store.snapshot()
    conversation = store.events(through_seq=snapshot['observed_event_seq'])
    if store.snapshot() != snapshot:
        raise IntentConflictError('State changed while capturing the audit input.')
    _require(len(snapshot['intents']) <= max_intents, 'Intent audit cap exceeded; no records were dropped.')
    _require(len(conversation) <= max_events, 'Event audit cap exceeded; no dialogue was dropped.')
    identifiers = [intent['intent_id'] for intent in snapshot['intents']]
    _require(len(identifiers) == len(set(identifiers)), 'Repeated stored intent ID.')
    return copy.deepcopy({'schema': 'intent-audit-request-v1', 'snapshot': snapshot,
        'expected_version': snapshot['version'], 'through_seq': snapshot['observed_event_seq'],
        'conversation': conversation, 'intent_ids': identifiers})


def _validate_request(request):
    _require(isinstance(request, dict) and set(request) == _REQUEST_KEYS, 'Unexpected audit request fields.')
    _require(request['schema'] == 'intent-audit-request-v1', 'Unknown audit request schema.')
    snapshot = request['snapshot']
    _require(isinstance(snapshot, dict) and isinstance(snapshot.get('intents'), list), 'Missing captured snapshot.')
    _require(type(request['expected_version']) is int and request['expected_version'] == snapshot.get('version'),
             'Captured version mismatch.')
    _require(type(request['through_seq']) is int and request['through_seq'] == snapshot.get('observed_event_seq'),
             'Captured cursor mismatch.')
    identifiers = [item['intent_id'] for item in snapshot['intents']]
    _require(request['intent_ids'] == identifiers and len(identifiers) == len(set(identifiers)),
             'Audit must cover the complete captured intent list.')
    _require(isinstance(request['conversation'], list), 'Missing arrived raw conversation.')
    last = -1
    for event in request['conversation']:
        _require(isinstance(event, dict), 'Invalid raw event.')
        seq = event.get('seq')
        _require(type(seq) is int and last < seq <= request['through_seq'], 'Invalid arrived event sequence.')
        _require(event.get('role', 'user') in {'user', 'assistant'}, 'Invalid raw event role.')
        _require(isinstance(event.get('text'), str), 'Invalid raw event text.')
        last = seq
    _canonical(request)


def messages(request):
    """Expose only raw dialogue and current fields, never labels or old histories.

    Old state histories may repeat the same error as current state. They are
    retained in the captured runtime snapshot but are not an authority offered
    to the audit model. Every current record remains in the model input.
    """
    _validate_request(request)
    payload = {
        'conversation': copy.deepcopy(request['conversation']),
        'intention_state': [{key: intent[key] for key in ('intent_id', 'owner', 'text', 'status')}
                            for intent in request['snapshot']['intents']],
        'required_intent_ids': list(request['intent_ids']),
        'through_seq': request['through_seq'],
    }
    system = Path(__file__).with_name('audit_prompt.txt').read_text(encoding='utf-8').strip()
    return [{'role': 'system', 'content': system}, {'role': 'user', 'content': _canonical(payload)}]


def _validate_field(field, value, current, events):
    _require(isinstance(value, dict) and set(value) == _FIELD_KEYS, f'{field}: require verdict, value, source_seqs only.')
    verdict = value['verdict']
    _require(isinstance(verdict, str) and verdict in _VERDICTS, f'{field}: invalid verdict.')
    sources = value['source_seqs']
    _require(isinstance(sources, list) and all(type(seq) is int and seq >= 0 for seq in sources),
             f'{field}: source indices must be nonnegative real integers.')
    _require(sources == sorted(set(sources)), f'{field}: sources must be sorted and unique.')
    _require(all(seq in events for seq in sources), f'{field}: source evidence has not arrived.')
    proposed = value['value']
    if verdict == 'insufficient':
        _require(proposed is None, f'{field}: insufficient evidence requires null value.')
        return
    _require(bool(sources), f'{field}: keep/change requires evidence.')
    _require(any(events[seq].get('role', 'user') == 'user' for seq in sources),
             f'{field}: keep/change requires at least one user source.')
    if field == 'owner':
        _require(isinstance(proposed, str) and bool(proposed.strip()), 'Owner must be a nonempty string.')
    else:
        _require(isinstance(proposed, str) and proposed in _STATUSES, 'Invalid status value.')
    _require((proposed == current) == (verdict == 'keep'), f'{field}: verdict and proposed value disagree.')


def _compile(request, report):
    _require(isinstance(report, dict) and set(report) == {'checks'} and isinstance(report['checks'], list),
             'Require exactly one checks-list object.')
    records = {item['intent_id']: item for item in request['snapshot']['intents']}
    events = {event['seq']: event for event in request['conversation']}
    seen = set()
    for check in report['checks']:
        _require(isinstance(check, dict) and set(check) == {'intent_id', 'owner', 'status'},
                 'Each check requires intent_id, owner and status only.')
        identifier = check['intent_id']
        _require(isinstance(identifier, str) and identifier in records, 'Unknown audited intention.')
        _require(identifier not in seen, 'Repeated audited intention.')
        seen.add(identifier)
        for field in ('owner', 'status'):
            _validate_field(field, check[field], records[identifier][field], events)
    _require(seen == set(records), 'Audit did not cover every existing intention exactly once.')
    operations, unresolved = [], []
    for check in report['checks']:
        identifier = check['intent_id']
        old = records[identifier]
        held = [field for field in ('owner', 'status') if check[field]['verdict'] == 'insufficient']
        reason = 'insufficient_evidence' if held else None
        changed = {field: check[field]['value'] for field in ('owner', 'status')
                   if check[field]['verdict'] == 'change'}
        desired_owner = changed.get('owner', old['owner'])
        desired_status = changed.get('status', old['status'])
        if not reason and changed.get('owner') == '__unresolved__':
            reason, held = 'ambiguous_ownership_deferred', ['owner']
        if not reason and desired_owner == '__unresolved__' and desired_status == 'active':
            reason, held = 'unresolved_owner_cannot_be_active', ['owner', 'status']
        if not reason and 'owner' in changed and (old['status'] == 'withdrawn' or desired_status == 'withdrawn'):
            reason, held = 'combined_owner_and_withdrawal_transition_unsupported', ['owner', 'status']
        if reason:
            unresolved.append({'intent_id': identifier, 'reason': reason, 'fields': held})
            continue
        if not changed:
            continue
        sources = sorted({seq for field in changed for seq in check[field]['source_seqs']})
        operation = {'intent_id': identifier, 'source_seqs': sources}
        if old['status'] == 'withdrawn':
            operation.update(op='reopen', status=desired_status)
        elif desired_status == 'withdrawn':
            operation.update(op='withdraw')
        else:
            operation.update(op='update', **changed)
        operations.append(operation)
    return operations, unresolved


def _empty_result(store):
    return {'status': 'rejected', 'committed': False, 'coverage_complete': False,
            'semantic_correctness': 'not_judged', 'operations': [], 'checks': [],
            'unresolved': [], 'post_state': store.snapshot(), 'error': None}


def apply_report(store, request, raw, audit_id):
    """Validate the entire report, then commit its supported operations atomically.

    A complete report can still be semantically wrong. Insufficient evidence or
    unsupported compound transitions hold the entire affected record; other
    supported records may commit in the same single patch. Empty accepted
    patches still advance the store version, as normal no-change decisions do.
    """
    result = _empty_result(store)
    try:
        _validate_request(request)
        _require(isinstance(audit_id, str) and bool(audit_id.strip()), 'audit_id must be nonempty.')
        if store.snapshot() != request['snapshot'] or store.events(through_seq=request['through_seq']) != request['conversation']:
            raise IntentConflictError('Audit snapshot or arrived dialogue is stale.')
        report = _strict_json(raw)
        operations, unresolved = _compile(request, report)
        result['checks'] = copy.deepcopy(report['checks'])
        result['coverage_complete'] = True
        result['unresolved'] = unresolved
        post = store.commit_patch('intent-audit:' + audit_id, request['expected_version'],
                                  request['through_seq'], operations)
        result.update(status='partial_unresolved' if unresolved else ('applied' if operations else 'no_change'),
                      committed=True, operations=operations, post_state=post)
    except (AuditValidationError, IntentValidationError) as error:
        result.update(status='rejected', committed=False, operations=[], post_state=store.snapshot(),
                      error={'type': type(error).__name__, 'message': str(error)})
    return result


def run_audit(store, generate, audit_id):
    """One generation callback and at most one commit; never silently retry."""
    try:
        request = build_request(store)
        raw = generate(messages(request))
    except Exception as error:
        result = _empty_result(store)
        result['error'] = {'type': type(error).__name__, 'message': str(error), 'stage': 'capture_or_generation'}
        return result
    return apply_report(store, request, raw, audit_id)

