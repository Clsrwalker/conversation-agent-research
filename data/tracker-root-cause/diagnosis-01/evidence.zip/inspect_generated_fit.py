"""Read-only integrity/replay facts for the six fixed training inputs; no model."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,sys,importlib.util

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[4]
RUN=HERE/'collection-01'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def rows(p):return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    spec=importlib.util.spec_from_file_location('fit_legacy_review',ROOT/'experiments/deep_conversation/tracker_lora/evaluate_tracker.py')
    legacy=importlib.util.module_from_spec(spec);spec.loader.exec_module(legacy)
    result=read(RUN/'result.json');assert result['status']=='completed'
    assert result['calls']==result['completed_calls']==result['durable_calls']==6
    config=read(RUN/'config.json');preflight=read(HERE/'preflight-review.json');selection=read(HERE/'selection.json');protocol=read(HERE/'protocol.json')
    assert preflight['status']=='passed' and protocol['new_model_generations']==6
    assert result['config_sha256']==sha(RUN/'config.json')
    assert result['outputs_sha256']==sha(RUN/'PRIVATE-calls.jsonl')
    assert result['outcomes_sha256']==sha(RUN/'PRIVATE-outcomes.jsonl')
    assert result['adapter_weights_unchanged'] and not result['quality_scored']
    assert config['generation']==protocol['generation']==preflight['generation']
    assert config['versions']==preflight['versions'] and config['adapter']==preflight['adapter_artifacts']
    for artifact in (selection,protocol,preflight,config):
        for rel,digest in artifact['source_hashes'].items():assert sha(ROOT/rel)==digest,rel
    calls=rows(RUN/'PRIVATE-calls.jsonl');outcomes=rows(RUN/'PRIVATE-outcomes.jsonl');journal=rows(RUN/'attempts.jsonl')
    assert len(calls)==len(outcomes)==6 and len(journal)==12
    inputrows=rows(HERE/'inputs.jsonl');targets=rows(HERE/'targets.jsonl')
    trainingrows=rows(ROOT/selection['source_records']);sfts=rows(ROOT/selection['source_sft'])
    facts=[]
    for ordinal,(case,pf,inp,target,call,outcome) in enumerate(zip(selection['cases'],preflight['cases'],inputrows,targets,calls,outcomes),1):
        identifier=case['case_id'];assert identifier==pf['case_id']==inp['case_id']==target['case_id']==call['case_id']==outcome['case_id']
        row=trainingrows[case['source_row_index']];sft=sfts[case['source_row_index']]
        assert legacy.digest(row)==case['record_sha256'] and legacy.digest(sft)==case['sft_sha256']
        assert call['messages']==inp['messages']==sft['prompt']
        assert call['input_messages_sha256']==legacy.digest(sft['prompt'])==case['canonical_prompt_sha256']
        assert call['input_token_ids_sha256']==pf['input_token_ids_sha256']
        assert call['input_tokens']==pf['prompt_tokens'] and call['config_sha256']==result['config_sha256']
        assert call['ordinal']==ordinal and call['status']=='completed'
        gate=call['actual_adapter_state']
        assert gate['adapter_name']=='tracker_lora_v2' and gate['layers']==336 and gate['disabled_layers']==0 and gate['trainable_parameters']==0
        started,ended=journal[2*ordinal-2:2*ordinal]
        assert started['event']=='started' and ended['event']=='ended'
        assert started['ordinal']==ended['ordinal']==ordinal and started['case_id']==identifier
        assert started['input_messages_sha256']==call['input_messages_sha256']
        assert started['input_token_ids_sha256']==call['input_token_ids_sha256']
        assert ended['record_sha256']==legacy.digest(call) and ended['status']==call['status']
        actual=legacy.apply_candidate(row,call)
        assert actual==outcome['result']
        assert len(call['generated_token_ids'])==call['output_tokens']
        assert call['last_generated_token']==call['generated_token_ids'][-1]
        eos=call['configured_eos_token_ids'];eos=[eos] if isinstance(eos,int) else eos
        strict=True
        try:parsed=legacy.strict_proposal(call['output_text'])
        except legacy.StrictJSONError:parsed=None;strict=False
        json_valid=True
        try:json.loads(call['output_text'])
        except (ValueError,TypeError):json_valid=False
        facts.append({'case_id':identifier,'focus':case['focus'],'language':case['language'],
            'source_example_id':case['source_example_id'],'focal_intent_id':case['focal_intent_id'],
            'conversation':row['input']['conversation'],'baseline_state':legacy.project(row['input']['intention_state']),
            'expected_state':target['expected_semantic_state'],'post_state':legacy.project(actual['post_state']),
            'json_parseable':json_valid,'strict_operations_envelope':strict,'validity':actual['validity'],'committed':actual['committed'],
            'proposal':parsed,'output_text':call['output_text'],'runtime_error':actual['error'],
            'canonical_completion_match':parsed==row['target'],
            'ended_on_configured_eos':call['last_generated_token'] in eos,'last_generated_token':call['last_generated_token'],
            'hit_token_cap':call['hit_token_cap']})
    paths=[HERE/'selection.json',HERE/'protocol.json',HERE/'preflight-review.json',HERE/'inputs.jsonl',HERE/'targets.jsonl',HERE/'source-review.json',
        RUN/'result.json',RUN/'config.json',RUN/'PRIVATE-calls.jsonl',RUN/'PRIVATE-outcomes.jsonl',RUN/'attempts.jsonl',
        ROOT/'experiments/deep_conversation/tracker_lora/evaluate_tracker.py',ROOT/'experiments/deep_conversation/intention_state.py',Path(__file__)]
    report={'status':'verified_for_semantic_review','created_at_utc':datetime.now(timezone.utc).isoformat(),
        'scope':'Six completed existing-training-input generations, six exact CPU apply_candidate replays, no model/training calls by reviewer.',
        'new_model_calls_by_reviewer':0,'new_training_runs':0,'cases':facts,
        'source_hashes':{p.relative_to(ROOT).as_posix():sha(p) for p in paths}}
    out=HERE/'PRIVATE-review-facts.json';assert not out.exists()
    out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':report['status'],'cases':len(facts),'sha256':sha(out)}))
if __name__=='__main__':main()
