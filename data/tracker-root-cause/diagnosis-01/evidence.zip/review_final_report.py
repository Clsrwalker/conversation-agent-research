"""Validate the final synthesis against frozen reviews; no generation or scoring."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,re
HERE=Path(__file__).resolve().parent
STUDY=HERE.parent
ROOT=HERE.parents[4]
REPORT=STUDY/'analysis/report.json'
VALIDATION=STUDY/'engineering/validation.json'
EXPECTED='ec0d09597640ff32725b12817d4fbd468f7e543f54d79631e913326a533d2127'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
cache={}
def sha(p):
    p=p.resolve()
    if p not in cache:cache[p]=hashlib.sha256(p.read_bytes()).hexdigest()
    return cache[p]
def main():
    assert sha(REPORT)==EXPECTED
    report=read(REPORT);validation=read(VALIDATION)
    assert report['evidence_source_sha256']==validation['source_hashes']
    bindings={};inspected=set();queue=[REPORT,VALIDATION];binding_occurrences=0;historical_bindings=[]
    def find_bindings(x):
        if isinstance(x,dict):
            for key,value in x.items():
                if key in ('source_hashes','source_bindings','evidence_source_sha256','preserved_frozen_artifacts') and isinstance(value,dict):
                    yield from value.items()
                yield from find_bindings(value)
        elif isinstance(x,list):
            for value in x:yield from find_bindings(value)
    while queue:
        path=queue.pop().resolve()
        if path in inspected:continue
        inspected.add(path)
        for rel,digest in find_bindings(read(path)):
            assert isinstance(digest,str) and re.fullmatch('[0-9a-f]{64}',digest),(path,rel)
            source=(ROOT/rel).resolve();assert source.is_file(),rel
            if sha(source)!=digest:
                assert path==STUDY/'method/adapter-off-preflight-review.json'
                assert rel=='experiments/deep_conversation/tracker_lora/diagnostics/collect_audit_adapter_off.py'
                prior_bytes=source.read_bytes().replace(b'adapter-off-preflight-review-v2.json',b'adapter-off-preflight-review.json')
                prior_bytes=b''.join(line for line in prior_bytes.splitlines(keepends=True) if b'generated_token_ids=generated,last_generated_token=' not in line and b'configured_eos_token_ids=model.generation_config.eos_token_id,' not in line)
                assert hashlib.sha256(prior_bytes).hexdigest()==digest
                historical_bindings.append({'receipt':path.relative_to(ROOT).as_posix(),'source':rel,'historical_sha256':digest,
                    'current_sha256':sha(source),'verification':'Exact original bytes recovered in memory by reversing the documented two logging lines and gate filename amendment; no source file modified.'})
                binding_occurrences+=1
                continue
            normalized=source.relative_to(ROOT).as_posix()
            assert normalized not in bindings or bindings[normalized]==digest
            bindings[normalized]=digest;binding_occurrences+=1
            if source.suffix=='.json':queue.append(source)
    off=read(STUDY/'method/adapter-off-post-review.json');fit=read(STUDY/'fit/post-review.json')
    method=read(STUDY/'method/method-report.json');runtime=read(STUDY/'training/runtime-integrity.json')
    context=read(STUDY/'training/adapter-context-postcheck.json')
    census=read(STUDY/'data/census.json');assessment=read(STUDY/'data/assessment.json');position=read(STUDY/'data/repair-position-addendum.json')
    assert report['new_model_calls']==validation['new_model_calls']==18
    assert report['component_calls']=={'adapter_off':12,'training_fit':6}
    assert report['reused_model_calls']==12 and report['training_runs']==validation['new_training_runs']==0
    assert report['weights_changed'] is False and report['new_scenarios']==0
    assert off['summary']['new_generation_calls']==12 and fit['summary']['new_model_generations']==6
    assert report['shared_pre_audit']=={'faulty_correct':0,'faulty_inputs':6,'clean_correct':5,'clean_inputs':6}
    common={'inputs':12,'faulty_inputs':6,'clean_inputs':6,'clean_correct':5,'clean_damaged':0,
        'new_other_owner_status_errors':0,'clean_full_meaning_correct':5}
    off_expected={**common,'json_valid':11,'accepted_reports':10,'faulty_correct':2,'source_error_changes':1,'executed_changed_fields':2,'faulty_full_meaning_correct':2}
    on_expected={**common,'json_valid':1,'accepted_reports':0,'faulty_correct':0,'source_error_changes':0,'executed_changed_fields':0,'faulty_full_meaning_correct':0}
    for row,expected in zip(report['comparison_rows'],[off_expected,on_expected]):
        for key,value in expected.items():assert row[key]==value,(key,row)
    os=off['summary'];assert os['disabled_json_parseable']==11 and os['disabled_contract_accepted']==10
    assert os['faulty_disabled_focal_full_meaning_correct']==2 and os['clean_disabled_focal_full_meaning_correct']==5
    assert os['executed_changed_fields']==2 and os['insufficiently_cited_changed_fields']==1 and os['evidence_supported_focal_repairs']==1
    for key in ('inputs','valid_outputs','focal_metadata_correct','full_meaning_correct','source_sufficient_repairs','full_state_meaning_correct'):
        assert report['training_fit'][key]==fit['summary'][key],key
    for row,source in zip(report['training_fit']['rows'],fit['rows']):
        for key,value in source.items():assert row[key]==value,key
    assert fit['summary']['focal_repairs_omitted']==3 and fit['summary']['unsupported_withdrawals']==1
    assert method['observed']['training_rows']==500 and method['observed']['training_target_top_keys']=={'operations':500}
    assert method['observed']['training_rows_with_checks_target']==method['observed']['training_rows_with_verdict_key_in_target']==0
    assert os['ended_on_configured_eos']+fit['summary']['ended_on_configured_eos']==18
    assert os['last_token_ids']=={'151645':12} and fit['summary']['last_token_ids']=={'151645':6}
    assert os['hit_token_cap']==fit['summary']['hit_token_cap']==0
    assert runtime['audit_inference']['calls']==24 and runtime['audit_inference']['token_caps_hit']==0
    train=census['splits']['train'];test=census['splits']['test']
    assert sum(x['rows'] for x in census['splits'].values())==750
    owner=train['fault_groups']['owner'];withdraw=train['fault_groups']['wrong_withdrawn']
    assert owner['inputs']==owner['correct_owner_is_first_speaker']==30 and owner['target_ids']=={'i2':30} and owner['repair_source_sets']=={'[0]':30}
    assert test['fault_groups']['owner']['inputs']==20 and test['fault_groups']['owner']['target_ids']['i3']==19
    assert withdraw['inputs']==8 and withdraw['target_ids']=={'i4':8} and withdraw['correct_owner_is_first_speaker']==0
    tw=test['fault_groups']['wrong_withdrawn'];assert tw['inputs']==tw['correct_owner_is_first_speaker']==5 and tw['target_ids']=={'i1':5}
    assert not census['faulty_training_prefixes_with_clean_counterfactual_in_train']
    pc=position['counts'];assert pc['fault_rows']==pc['repair_is_last']==140 and pc['has_ordinary_latest_operations_before_repair']==111
    assert train['explicit_update_fields']['owner']-owner['inputs']==4
    assert train['operations']['reopen']-withdraw['inputs']==5
    sem=assessment['limited_semantic_inspection'];assert sem['examples']==20 and sem['focal_semantic_mislabels_found']==0
    assert sem['ordinary_owner_resolution_examples']==sem['ordinary_reopen_examples']==4
    assert '4 个普通归属更新操作，以及 4 条普通样本中的 5 个 reopen 操作' in report['confirmed'][2]['limitation']
    tok=runtime['tokenization'];exe=runtime['training_execution'];adapter=runtime['adapter']
    assert tok['rows']==tok['exact_prompt_prefix_rows']==tok['base_saved_tokenizer_ids_equal_rows']==500
    assert exe['observed_microsteps']==exe['unique_rows']==500 and exe['optimizer_updates']==32
    assert exe['group_sizes']==[16]*31+[4]
    assert adapter['tensor_count']==672 and adapter['B_tensors']==336 and adapter['all_finite'] and adapter['all_B_nonzero']
    assert 0<exe['gradient_norm_min']<=exe['gradient_norm_max']
    assert len(runtime['loss_algebra_controls'])==4
    assert tok['completion_tokens_min']==6 and tok['completion_tokens_max']==148 and round(148/6,2)==24.67
    assert read(STUDY/'ablation/adapter-off-01/result.json')['status']=='failed'
    assert off['run_status']=='failed_postcheck' and context['original_result_unchanged']
    assert validation['capability_acceptance_passed'] is False
    assert next(x for x in validation['checks'] if x['name']=='Adapter-off collection')['status']=='failed_postcheck'
    assert report['next_action']['status']=='planned_not_run'
    sourcepaths=[REPORT,VALIDATION,STUDY/'method/adapter-off-post-review.json',STUDY/'fit/post-review.json',
        STUDY/'data/census.json',STUDY/'data/assessment.json',STUDY/'data/repair-position-addendum.json',STUDY/'training/runtime-integrity.json',
        STUDY/'training/cause-assessment.json',STUDY/'training/adapter-context-postcheck.json',Path(__file__)]
    review={'id':'tracker-root-cause-final-synthesis-independent-review','status':'passed',
        'status_meaning':'Final synthesis and validation accurately reflect the frozen evidence; this is not capability acceptance.',
        'date':'2026-10-27','timezone':'America/Halifax','reviewed_at_utc':datetime.now(timezone.utc).isoformat(),
        'reviewed_report_sha256':sha(REPORT),'reviewed_validation_sha256':sha(VALIDATION),
        'reviewer':'Independent method reviewer, with data-summary cross-check from the data reviewer; no new model output or semantic scoring.',
        'numeric_checks':{'new_calls':18,'adapter_off_calls':12,'native_training_fit_calls':6,'reused_calls':12,'new_training_runs':0,
            'comparison_rows_match_frozen_review':True,'fit_summary_and_rows_match_frozen_review':True,
            'data_counts_and_operation_units_match':True,'training_and_EOS_counts_match':True},
        'hash_checks':{'direct_report_bindings':len(report['evidence_source_sha256']),
            'direct_validation_bindings':len(validation['source_hashes']),
            'transitive_json_artifacts_inspected':len(inspected),'verified_binding_occurrences':binding_occurrences,
            'unique_bound_files_verified':len(bindings),'all_match':True,'verified_documented_historical_versions':historical_bindings},
        'causal_boundary_review':['Training-to-audit contract change is described as observed, with component-specific causal contribution unresolved.',
            'The adapter-off comparison retains cross-process and missing historical hardware/EOS limitations.',
            'All twelve adapter-off generations are scoreable while the original collection remains failed at its post-context guard; CPU reproduction is not presented as observing the terminated Qwen object.',
            'Six native inputs are explicitly exposed training samples, with no base-only comparison and no claim of full-training-set underfitting, overfitting or generalization.',
            'Data positional concentration and fixed repair order are facts; model shortcut use and causal error percentages remain unproven.',
            'Targeted twenty-case AI label review is not used to certify all 750 labels; passing runtime checks is not capability acceptance.',
            'Future operations-based audit and data revisions are marked planned, not completed or validated.'],
        'resolved_issue':{'location':'confirmed[2].limitation','issue':'Five ordinary reopen operations occur across four examples, so operation and example units must be distinguished.',
            'resolution':'Parent corrected the final report to four ordinary owner-update operations and five reopen operations in four ordinary examples before this review was frozen.'},
        'new_model_generations':0,'new_training_runs':0,'new_semantic_scoring_runs':0,
        'source_hashes':{p.relative_to(ROOT).as_posix():sha(p) for p in sourcepaths}}
    out=HERE/'final-report-review.json';assert not out.exists();out.write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'passed','reviewed_report_sha256':sha(REPORT),'reviewed_validation_sha256':sha(VALIDATION),'review_sha256':sha(out),'hash_checks':review['hash_checks']}))
if __name__=='__main__':main()
