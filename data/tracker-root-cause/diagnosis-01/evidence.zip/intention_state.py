"""Independent, versioned intention records and runtime result receipts.

Only the trusted runtime may call ``observe`` and ``report_result``. This module
does not authenticate a caller, infer intentions, judge evidence meaning, run a
model, or execute work. A model may propose patches; structural validation is
not proof that a proposal represents the user's wishes correctly.

Versions identify committed records, including processed no-change decisions;
they are not counts of semantic changes. Observation and receipt ingestion do
not change an intention version. SQLite transactions protect this local store,
not effects performed by external tools.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path
import sqlite3
from threading import RLock


class IntentValidationError(ValueError):
    """Malformed data or a transition unsupported by the stored record."""


class IntentConflictError(IntentValidationError):
    """A stale version, out-of-date observation, or reused identifier."""


def _json(value):
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True,
                          separators=(',', ':'), allow_nan=False)
    except (TypeError, ValueError) as error:
        raise IntentValidationError('Values must be finite JSON data.') from error


def _text(value, name):
    if not isinstance(value, str) or not value.strip():
        raise IntentValidationError(f'{name} must be a nonempty string.')
    return value


def _integer(value, name, minimum=0):
    if type(value) is not int or value < minimum:
        raise IntentValidationError(f'{name} must be an integer >= {minimum}.')
    return value


class IntentStore:
    """An independent local state boundary shared by chat and work adapters.

    ``events`` are structured, already-arrived runtime records, never strings
    parsed from actor prose. Required fields: seq, speaker, text; role defaults
    to user and may be user or assistant. Additional JSON metadata is retained.
    No external clock or future-event oracle exists here: the caller is
    responsible for authenticating roles and releasing only arrived events.
    """

    def __init__(self, path):
        self.path = Path(path) if str(path) != ':memory:' else None
        if self.path is not None:
            self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = RLock()
        self._closed = False
        self._conn = sqlite3.connect(str(path), timeout=30, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute('PRAGMA busy_timeout=30000')
        self._conn.execute('PRAGMA journal_mode=WAL')
        self._conn.execute('PRAGMA synchronous=FULL')
        self._conn.executescript('''
            CREATE TABLE IF NOT EXISTS intent_meta (
                singleton INTEGER PRIMARY KEY CHECK(singleton=1),
                version INTEGER NOT NULL, processed_seq INTEGER NOT NULL,
                observed_seq INTEGER NOT NULL
            );
            INSERT OR IGNORE INTO intent_meta VALUES (1, 0, -1, -1);
            CREATE TABLE IF NOT EXISTS intent_events (
                seq INTEGER PRIMARY KEY, event_json TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS intentions (
                intent_id TEXT PRIMARY KEY, state_json TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS intent_patches (
                patch_id TEXT PRIMARY KEY, request_json TEXT NOT NULL,
                result_json TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS intent_receipts (
                ordinal INTEGER PRIMARY KEY AUTOINCREMENT,
                receipt_id TEXT UNIQUE NOT NULL, receipt_json TEXT NOT NULL
            );
        ''')

    def _check_open(self):
        if self._closed:
            raise RuntimeError('IntentStore is closed.')

    def _meta(self):
        return self._conn.execute('SELECT * FROM intent_meta WHERE singleton=1').fetchone()

    def _snapshot(self):
        meta = self._meta()
        return {
            'version': meta['version'],
            'processed_event_seq': meta['processed_seq'],
            'observed_event_seq': meta['observed_seq'],
            'intents': [json.loads(row['state_json']) for row in self._conn.execute(
                'SELECT state_json FROM intentions ORDER BY intent_id')],
            'receipts': [json.loads(row['receipt_json']) for row in self._conn.execute(
                'SELECT receipt_json FROM intent_receipts ORDER BY ordinal')],
        }

    def snapshot(self):
        """Return one consistent, detached read of intentions and receipts."""
        with self._lock:
            self._check_open()
            self._conn.execute('BEGIN')
            try:
                result = self._snapshot()
                self._conn.commit()
                return result
            except BaseException:
                self._conn.rollback()
                raise

    def get_view(self):
        """Read-only data for either adapter; receipts do not establish success."""
        return self.snapshot()

    def observe(self, events):
        """Atomically register authenticated, arrived events in sequence order.

        Sequence numbers need not be contiguous: the source event log may also
        contain other record types. Exact replay is accepted; new records cannot
        be inserted behind the observed cursor or replace existing raw text.
        """
        if not isinstance(events, list):
            raise IntentValidationError('events must be a list of structured objects.')
        normalized = []
        previous = -1
        for event in events:
            if not isinstance(event, dict):
                raise IntentValidationError('Each event must be a structured object.')
            seq = _integer(event.get('seq'), 'event.seq')
            if seq <= previous:
                raise IntentValidationError('Events must have unique ascending seq values.')
            previous = seq
            _text(event.get('speaker'), 'event.speaker')
            if not isinstance(event.get('text'), str):
                raise IntentValidationError('event.text must be a string.')
            role = event.get('role', 'user')
            if not isinstance(role, str) or role not in {'user', 'assistant'}:
                raise IntentValidationError('event.role must be user or assistant.')
            normalized.append((seq, _json({**event, 'role': role})))
        with self._lock:
            self._check_open()
            self._conn.execute('BEGIN IMMEDIATE')
            try:
                observed = self._meta()['observed_seq']
                accepted = 0
                for seq, encoded in normalized:
                    old = self._conn.execute(
                        'SELECT event_json FROM intent_events WHERE seq=?', (seq,)).fetchone()
                    if old is not None:
                        if old['event_json'] != encoded:
                            raise IntentConflictError('An observed event cannot be rewritten.')
                        continue
                    if seq <= observed:
                        raise IntentConflictError('Cannot insert an unseen event behind the observation cursor.')
                    self._conn.execute('INSERT INTO intent_events VALUES (?, ?)', (seq, encoded))
                    observed, accepted = seq, accepted + 1
                self._conn.execute('UPDATE intent_meta SET observed_seq=? WHERE singleton=1', (observed,))
                self._conn.commit()
                return {'observed_event_seq': observed, 'accepted': accepted}
            except BaseException:
                self._conn.rollback()
                raise

    def events(self, after_seq=-1, through_seq=None):
        """Read only registered raw events; never query an unseen future cursor."""
        _integer(after_seq, 'after_seq', -1)
        with self._lock:
            self._check_open()
            observed = self._meta()['observed_seq']
            through = observed if through_seq is None else _integer(through_seq, 'through_seq', -1)
            if through > observed:
                raise IntentValidationError('The requested event cursor has not arrived.')
            return [json.loads(row['event_json']) for row in self._conn.execute(
                'SELECT event_json FROM intent_events WHERE seq>? AND seq<=? ORDER BY seq',
                (after_seq, through))]

    def commit_patch(self, patch_id, expected_version, through_seq, operations):
        """Atomically apply a model proposal after runtime validation.

        add requires intent_id, owner, text, source_seqs; status defaults to
        active or can be uncertain. update changes only supplied owner/text/
        status fields and requires source_seqs. withdraw and reopen preserve
        the record and its history; reopen defaults to active. Every operation
        requires arrived source_seqs. A patch may touch each intent only once.

        Empty operations acknowledge a no-change decision and still increment
        version. Exact patch-ID replay returns the ORIGINAL committed snapshot,
        even if later patches or receipts exist; use get_view for current state.
        """
        _text(patch_id, 'patch_id')
        _integer(expected_version, 'expected_version')
        _integer(through_seq, 'through_seq', -1)
        if not isinstance(operations, list):
            raise IntentValidationError('operations must be a list.')
        request = _json({'expected_version': expected_version, 'through_seq': through_seq,
                         'operations': operations})
        with self._lock:
            self._check_open()
            self._conn.execute('BEGIN IMMEDIATE')
            try:
                replay = self._conn.execute(
                    'SELECT request_json, result_json FROM intent_patches WHERE patch_id=?',
                    (patch_id,)).fetchone()
                if replay is not None:
                    if replay['request_json'] != request:
                        raise IntentConflictError('patch_id was reused with different arguments.')
                    result = json.loads(replay['result_json'])
                    self._conn.commit()
                    return result
                meta = self._meta()
                if expected_version != meta['version']:
                    raise IntentConflictError('Intention version changed; read the current state.')
                if through_seq != meta['observed_seq']:
                    raise IntentConflictError('Patch must cover the latest observed event cursor.')
                if through_seq < meta['processed_seq']:
                    raise IntentConflictError('Processed event cursor cannot move backwards.')
                version = meta['version'] + 1
                touched = set()
                for operation in operations:
                    self._apply_operation(operation, touched, through_seq, version, patch_id)
                self._conn.execute(
                    'UPDATE intent_meta SET version=?, processed_seq=? WHERE singleton=1',
                    (version, through_seq))
                result = self._snapshot()
                self._conn.execute('INSERT INTO intent_patches VALUES (?, ?, ?)',
                                   (patch_id, request, _json(result)))
                self._conn.commit()
                return result
            except BaseException:
                self._conn.rollback()
                raise

    def _apply_operation(self, operation, touched, through_seq, version, patch_id):
        if not isinstance(operation, dict):
            raise IntentValidationError('Each operation must be an object.')
        op = operation.get('op')
        if not isinstance(op, str) or op not in {'add', 'update', 'withdraw', 'reopen'}:
            raise IntentValidationError('Unknown intention operation.')
        fields = {'op', 'intent_id', 'source_seqs'}
        if op in {'add', 'update'}:
            fields |= {'owner', 'text', 'status'}
        if op == 'reopen':
            fields.add('status')
        if set(operation) - fields:
            raise IntentValidationError('Unexpected operation fields.')
        identifier = _text(operation.get('intent_id'), 'intent_id')
        if identifier in touched:
            raise IntentValidationError('A patch may touch each intention only once.')
        touched.add(identifier)
        source_seqs = operation.get('source_seqs')
        if not isinstance(source_seqs, list) or not source_seqs:
            raise IntentValidationError('source_seqs must be a nonempty list.')
        for seq in source_seqs:
            _integer(seq, 'source_seq')
            if seq > through_seq or self._conn.execute(
                    'SELECT 1 FROM intent_events WHERE seq=?', (seq,)).fetchone() is None:
                raise IntentValidationError('An intention source must be an arrived event within this patch.')
        if len(source_seqs) != len(set(source_seqs)):
            raise IntentValidationError('source_seqs must not contain duplicates.')
        status = operation.get('status', 'active')
        if not isinstance(status, str) or status not in {'active', 'uncertain'}:
            raise IntentValidationError('A proposed status must be active or uncertain.')
        row = self._conn.execute('SELECT state_json FROM intentions WHERE intent_id=?',
                                 (identifier,)).fetchone()
        old = json.loads(row['state_json']) if row is not None else None
        if op == 'add':
            if old is not None:
                raise IntentConflictError('intent_id already exists; use an explicit transition.')
            state = {'intent_id': identifier,
                     'owner': _text(operation.get('owner'), 'owner'),
                     'text': _text(operation.get('text'), 'text'),
                     'status': status, 'history': []}
        else:
            if old is None:
                raise IntentValidationError('Cannot change an unknown intention.')
            state = copy.deepcopy(old)
            if op == 'reopen':
                if old['status'] != 'withdrawn':
                    raise IntentValidationError('Only a withdrawn intention can be reopened.')
                state['status'] = status
            elif old['status'] == 'withdrawn':
                raise IntentValidationError('A withdrawn intention needs an explicit reopen operation.')
            elif op == 'withdraw':
                state['status'] = 'withdrawn'
            else:
                if not any(key in operation for key in ('owner', 'text', 'status')):
                    raise IntentValidationError('update must include a field to update.')
                for key in ('owner', 'text'):
                    if key in operation:
                        state[key] = _text(operation[key], key)
                if 'status' in operation:
                    state['status'] = status
        state['source_seqs'] = list(source_seqs)
        state['updated_version'] = version
        state.setdefault('created_version', version)
        state['history'].append({
            'version': version, 'patch_id': patch_id, 'op': op,
            'source_seqs': list(source_seqs),
            'state': {key: state[key] for key in ('owner', 'text', 'status')},
        })
        self._conn.execute('INSERT OR REPLACE INTO intentions VALUES (?, ?)',
                           (identifier, _json(state)))

    def report_result(self, receipt_id, intent_version, payload):
        """Store a runtime-issued receipt without changing any intention.

        Only the runtime can establish whether a tool actually ran. This store
        preserves that supplied receipt and its associated historical version;
        even a payload saying ``completed`` never marks an intention complete.
        """
        _text(receipt_id, 'receipt_id')
        _integer(intent_version, 'intent_version')
        if not isinstance(payload, dict):
            raise IntentValidationError('Receipt payload must be a structured object.')
        receipt = {'receipt_id': receipt_id, 'intent_version': intent_version,
                   'payload': payload}
        encoded = _json(receipt)
        with self._lock:
            self._check_open()
            self._conn.execute('BEGIN IMMEDIATE')
            try:
                old = self._conn.execute('SELECT receipt_json FROM intent_receipts WHERE receipt_id=?',
                                         (receipt_id,)).fetchone()
                if old is not None:
                    if old['receipt_json'] != encoded:
                        raise IntentConflictError('receipt_id was reused with different arguments.')
                    result = json.loads(old['receipt_json'])
                else:
                    if intent_version > self._meta()['version']:
                        raise IntentValidationError('Receipt refers to an uncommitted intention version.')
                    self._conn.execute('INSERT INTO intent_receipts (receipt_id, receipt_json) VALUES (?, ?)',
                                       (receipt_id, encoded))
                    result = json.loads(encoded)
                self._conn.commit()
                return result
            except BaseException:
                self._conn.rollback()
                raise

    def close(self):
        with self._lock:
            if not self._closed:
                self._conn.close()
                self._closed = True

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()
