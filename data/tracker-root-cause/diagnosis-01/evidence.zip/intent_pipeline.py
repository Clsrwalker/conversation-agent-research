"""One normal tracker decision followed by one bounded audit on the same store."""
from pathlib import Path
import importlib.util
import sys

HERE = Path(__file__).resolve().parent
LEGACY_PATH = HERE.parent/'evaluate_tracker.py'
spec = importlib.util.spec_from_file_location('intent_audit_legacy_runtime', LEGACY_PATH)
legacy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(legacy)
if __package__:
    from .audit import run_audit
else:
    from audit import run_audit

TRACKER_PROMPT = HERE.parents[3]/'output/research/2026-10-24/tracker-lora-repair-v2/annotation/system_prompt.txt'


def track_then_audit(store, tracker_generate, audit_generate, run_id, tool_receipts=None):
    """Callbacks receive only model-visible messages; no reference labels.

    There is no retry or model change. A failed normal proposal is recorded and
    leaves the store intact; the audit can still inspect existing records.
    This does not execute work or establish semantic correctness.
    """
    before = store.snapshot()
    visible = {'conversation':store.events(through_seq=before['observed_event_seq']),
               'intention_state':before,
               'tool_receipts':list(tool_receipts if tool_receipts is not None else before.get('receipts',[]))}
    messages = [{'role':'system','content':TRACKER_PROMPT.read_text(encoding='utf-8').strip()},
                {'role':'user','content':legacy.encode(visible)}]
    normal = {'status':'failed','committed':False,'output_text':None,'proposal':None,'error':None}
    try:
        normal['output_text'] = tracker_generate(messages)
        proposal = legacy.strict_proposal(normal['output_text'])
        normal['proposal'] = proposal
        store.commit_patch(run_id+'-normal',before['version'],before['observed_event_seq'],proposal['operations'])
        normal.update(status='applied',committed=True)
    except Exception as error:
        normal['error'] = {'type':type(error).__name__,'message':str(error)}
        if store.snapshot() != before:
            # Arrived events or another actor may have advanced the state while
            # generation was in flight. Never overwrite or reinterpret them as
            # a partial mutation by our rejected atomic patch.
            normal.update(status='stale_input',post_state=store.snapshot())
            skipped={'status':'not_run_stale_input','committed':False,'coverage_complete':False,
                     'semantic_correctness':'not_judged','operations':[],'checks':[],'unresolved':[],
                     'post_state':store.snapshot(),'error':normal['error']}
            return {'baseline':normal,'audit':skipped,'post_state':store.snapshot()}
    normal['post_state'] = store.snapshot()
    audit = run_audit(store,audit_generate,run_id+'-audit')
    return {'baseline':normal,'audit':audit,'post_state':store.snapshot()}
