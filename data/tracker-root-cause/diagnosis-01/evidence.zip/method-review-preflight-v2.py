"""Review a logging-only pre-inference amendment; reuse prior CPU checks."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,copy
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[4]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    old_path=HERE/'adapter-off-preflight-review.json'
    assert sha(old_path)=='b275dc932c9447021f0502be0107e8475ef4361358c3c63b1f811ec41819d7ed'
    old=json.loads(old_path.read_text(encoding='utf-8'))
    relative='experiments/deep_conversation/tracker_lora/diagnostics/collect_audit_adapter_off.py'
    for path,digest in old['source_hashes'].items():
        if path!=relative: assert sha(ROOT/path)==digest,path
    collector=ROOT/relative
    text=collector.read_text(encoding='utf-8')
    assert 'adapter-off-preflight-review-v2.json' in text
    assert all(name in text for name in ('generated_token_ids','last_generated_token','configured_eos_token_ids'))
    report=copy.deepcopy(old)
    report.update(id='tracker-root-cause-adapter-off-preflight-v2',reviewed_at_utc=datetime.now(timezone.utc).isoformat(),
      previous_review_path=old_path.relative_to(ROOT).as_posix(),previous_review_sha256=sha(old_path),
      review_amendment='Logging-only addition before any diagnostic inference: preserve generated token IDs, final generated token and configured EOS IDs; generation method/arguments, inputs, weights, protocol and scoring unchanged. Gate filename moved to this new immutable receipt.',
      new_cpu_replays=0,reused_cpu_replays=12,new_model_calls=0)
    report['checks'].append('Independent diff inspection confirms the sole behavior addition is recording already-produced generated IDs and configured EOS metadata after generation; no new stopping criteria or decoder restrictions.')
    report['source_hashes'][relative]=sha(collector)
    for p in (old_path,Path(__file__)):
        report['source_hashes'][p.relative_to(ROOT).as_posix()]=sha(p)
    target=HERE/'adapter-off-preflight-review-v2.json'
    assert not target.exists()
    target.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'passed','receipt_sha256':sha(target),'new_model_calls':0,'new_cpu_replays':0}))
if __name__=='__main__': main()
