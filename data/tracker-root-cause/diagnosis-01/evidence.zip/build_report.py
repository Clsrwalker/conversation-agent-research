"""Summarize completed bounded diagnostics without new inference or training."""
from pathlib import Path
import hashlib,json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def finding(title,evidence,implication,limitation):
    return dict(title=title,evidence=evidence,implication=implication,limitation=limitation)

def main():
    off=read(HERE/'method/adapter-off-post-review.json')
    fit=read(HERE/'fit/post-review.json')
    assert off['status']==fit['status']=='passed'
    o,f=off['summary'],fit['summary']
    assert o['new_generation_calls']==12 and f['new_model_generations']==6
    evidence_files=['data/census.json','data/assessment.json','data/repair-position-addendum.json',
      'training/runtime-integrity.json','training/cause-assessment.json','training/adapter-tensor-statistics.json',
      'training/adapter-context-postcheck.json','method/method-report.json',
      'method/adapter-off-protocol.json','method/adapter-off-preflight-review-v2.json','method/adapter-off-post-review.json',
      'ablation/adapter-off-01/result.json','ablation/adapter-off-01/config.json',
      'fit/selection.json','fit/protocol.json','fit/source-review.json','fit/preflight-review.json',
      'fit/collection-01/config.json','fit/collection-01/result.json','fit/post-review.json']
    bindings={str((HERE/n).relative_to(ROOT)).replace('\\','/'):sha(HERE/n) for n in evidence_files}
    report={
      'status':'completed','kind':'root_cause_diagnostic','date':'2026-10-27','timezone':'America/Halifax',
      'status_meaning':'本轮限定诊断与记录完成；意图核查能力未通过验收，部分训练因果解释仍未确定。',
      'title':'Tracker 为什么失败：接口错配已确认，原岗位修复也不稳定',
      'lead':'当前不应换底座或直接加训练。核查改用了没有训练过的接口；回到原生接口后，6 条原训练样本也只修复 2 条。数据覆盖存在明确偏斜，但尚不能把失败唯一归因于数据或训练步数。',
      'problem':'区分核查方法、训练数据、训练实现和推理配置的影响，解释归属、错误撤销恢复和不确定状态为什么仍会错。',
      'comparison_conditions':'复用上一轮 12 条精确核查消息及其普通跟踪后状态、同一底座文件、量化和依赖、greedy 解码与 1024 输出上限；仅在新增对照中关闭既有适配器。比较历史 v2 输出，不重跑普通跟踪。不同进程不保证逐位数值相同；历史记录未记录 GPU 名称。',
      'new_model_calls':18,'component_calls':{'adapter_off':12,'training_fit':6},'reused_model_calls':12,'training_runs':0,
      'model':'Qwen/Qwen2.5-14B-Instruct','base_revision':'cf98f3b3bbb457ad9e2bb7baf9a0125b6b88caa8',
      'adapter':'tracker-lora-repair-v2/formal-01','weights_changed':False,'new_scenarios':0,
      'confirmed':[
        finding('核查任务与训练契约不一致',
          '500 条训练 completion 全部使用 operations，零条 checks/verdict；新核查同时改变系统指令、输入状态投影和嵌套输出。相同核查输入，历史 v2 可执行报告 0/12，关闭适配器后 10/12；合法 JSON 为 1/12 对 11/12。',
          '把当前 LoRA 直接用于这个新核查岗位是未验证的方法变更；不能把全部失败先归咎于标签质量。现有证据支持新任务上存在适配器相关的不兼容。',
          '没有分别操纵输入投影、指令与输出格式，不能确认哪一项占主导，也不能证明关闭 LoRA 就能解决意图遗漏。'),
        finding('问题不止是新 JSON 格式',
          '同一 v2 在 6 条精确原训练 prompt 上，operations 6/6 可执行，但完整焦点修复只有 2/6：归属 0/2，撤销恢复 1/2，不确定状态 1/2。三条漏修，一条错误撤销。',
          '当前 checkpoint 连这些已经训练过的修复例也没有稳定复现，不能把训练完成或 loss 下降当作岗位能力验收。',
          '只有 6 条定向训练样本；没有在相同六条上关闭适配器，不能断言这些语义错误由 LoRA 单独造成，亦不能推断全量欠拟合。'),
        finding('修复数据的身份与位置覆盖偏窄',
          '30 条注入归属修复全部针对 i2、引用 seq0、修回首位说话人；原测试 20 条归属故障中 19 条在 i3。8 条训练误撤销修复全部是第二人的 i4，原测试 5 条全部是第一人的 i1。140 条故障训练没有同原文干净前态配对；140/140 修复放目标末尾，其中 111 条之前还有当前操作。',
          '训练设计给了身份、位置和动作顺序捷径，缺少同内容不同状态的反例。后续数据修订应优先修这些结构，而非无差别扩大数量。',
          '这些是已确认的数据分布事实，不是模型采用捷径的因果证明。另有 4 个普通归属更新操作，以及 4 条普通样本中的 5 个 reopen 操作，不能将固定模式泛化到所有训练操作。尾位置也解释不了六条中的空输出与错误撤销。'),
        finding('核查功能的范围不能覆盖所有遗漏',
          '当前核查只修改已有记录的 owner/status；上一轮一条正确前态经普通跟踪后 i4 文本损坏且漏掉新 i5，元数据核查无法修复。',
          '对这版功能只能宣称核查已有意图的归属和状态，不能宣称已实现完整意图恢复。',
          '本轮不新增文本恢复或缺失记录恢复，以遵守限定范围。')],
      'checked_explanations':[
        finding('未发现可解释全部失败的训练实现错误',
          '500/500 tokenizer 前缀与目标对齐；500 行各处理一次，32 次 optimizer 更新与最后 4 行累积组吻合；672 个适配器张量有限、336 个 B 矩阵非零，梯度有限且非零；CPU loss/梯度对照通过。加载工件和已记录量化设置匹配。',
          '没有证据支持“根本没训练、标签整体错位、加载了空适配器”等解释。',
          '检查通过不证明优化配方足够，也不排除量化损失或未测实现因素；没有重放完整 CUDA 训练。'),
        finding('当前不支持大面积错误标签作为主因',
          '750 条 train/dev/test 结构与输入目标对应通过，定向复核 20 条未发现焦点语义错标；发现一处冗余 assistant 引用。',
          '目前更明确的问题是覆盖与任务契约，而非已有证据证明大量标签错误。',
          '结构检查不是语义标注检查；20 条是未盲人工智能定向复核，并未逐条人工核验全部 750 条。'),
        finding('新诊断没有输出长度截断',
          '18 条新增生成全部以配置 EOS 151645 结束，均未触发 token 上限；历史 24 条输出也未触顶，但没有保存终止 token。',
          '不能用“输出上限太小”解释这些新增样本的遗漏。',
          '历史精确终止原因不可追溯；正常 EOS 不表示答案完整。')],
      'unresolved':[
        finding('训练预算与目标权重的作用尚未识别',
          '当前只训练 1 epoch、32 次更新；按样本平均 completion loss，长度 6–148 token，同组最短样本单 token 相对权重可为最长约 24.67 倍。',
          '训练强度、短输出权重和岗位监督都是候选解释，但不能据此直接加 epoch 或调 rank。',
          '没有固定其他因素的训练干预；欠拟合、过拟合、学习率、rank、量化各自影响未确定。'),
        finding('数据偏斜究竟造成多少失败尚未识别',
          '已确认身份/位置集中和缺少干净配对，但原训练样本也只修复 2/6。',
          '仅用“未见位置泛化差”不能解释全部现象；可能同时存在监督目标与学习不足。',
          '没有重训平衡数据版本，不提供各原因的百分比分摊或成功率预测。')],
      'shared_pre_audit':{'faulty_correct':0,'faulty_inputs':6,'clean_correct':5,'clean_inputs':6},
      'comparison_rows':[
        {'arm':'adapter_disabled','label':'同一底座，诊断时关闭适配器','inputs':12,
         'json_valid':o['disabled_json_parseable'],'accepted_reports':o['disabled_contract_accepted'],
         'faulty_correct':o['faulty_disabled_focal_metadata_correct'],'faulty_inputs':6,
         'clean_correct':o['clean_disabled_focal_metadata_correct'],'clean_inputs':6,
         'clean_damaged':o['clean_damaged_by_audit'],'new_other_owner_status_errors':o['new_owner_or_status_errors_all_records'],
         'source_error_changes':o['insufficiently_cited_changed_fields'],'executed_changed_fields':o['executed_changed_fields'],
         'faulty_full_meaning_correct':o['faulty_disabled_focal_full_meaning_correct'],'clean_full_meaning_correct':o['clean_disabled_focal_full_meaning_correct']},
        {'arm':'tracker_v2','label':'既有 v2 LoRA 核查（历史输出）','inputs':12,'json_valid':1,'accepted_reports':0,
         'faulty_correct':0,'faulty_inputs':6,'clean_correct':5,'clean_inputs':6,'clean_damaged':0,
         'new_other_owner_status_errors':0,'source_error_changes':0,'executed_changed_fields':0,
         'faulty_full_meaning_correct':0,'clean_full_meaning_correct':5}],
      'training_fit':{**{k:f[k] for k in ('inputs','valid_outputs','focal_metadata_correct','full_meaning_correct','source_sufficient_repairs','full_state_meaning_correct')},
        'rows':[{**r,'label':{'owner':'归属','wrong_withdrawn':'撤销恢复','uncertain_status':'不确定状态'}[r['focus']]} for r in fit['rows']],
        'limitations':['六条按类别、语言和原文件顺序事先确定，不按输出挑样；都曾用于训练，不能作为泛化测试。','评分为依据原文的未盲 AI 复核，无用户研究或人工独立金标准。','格式可执行不代表修复正确；不将这六条与上面的十二条合并为一个成功率。']},
      'failures':[
        '适配器关闭的 12 次生成全部完成，但整个 collection 的最终状态仍为 failed：退出 PEFT disable_adapter 上下文后，0 trainable 参数断言失败。原始失败记录保留，没有将其改写为成功。',
        '源码与 tiny CPU 重现表明重新启用 adapter 会改变 requires_grad 标志；不改变参数值或 eval 状态。每次实际生成前均记录 336 层 disabled、0 trainable，后验复核确认 12 条输入、日志、输出完整；原进程退出后的逐参数标志不可重建。',
        '关闭适配器只修复 2/6 故障，均属不确定状态；其中中文修复引用缺少指代所需的 assistant 原文，充分证据支持的修复仅 1/6。归属和撤销恢复仍未修复。',
        '原生六条训练复现中，一条将应为 uncertain 的要求错误 withdraw；合法 operations 不能成为自动提交的充分依据。',
        '训练审计首版根目录错误、CPU 上下文复现首版 CUDA 初始化检查失败均保留；修正的是新诊断工具，未改历史训练与输出。'],
      'limitations':[
        '保持原底座与适配器工件不变；关闭适配器仅用于定位，不是更换生产岗位或替代同底座多 LoRA 方向。',
        '只使用已暴露核查输入和已训练样本，无新场景、无新训练；不能据此声称最终任务质量、用户收益或未见组合泛化改善。',
        '对照严格绑定消息、token IDs、工件和配置，但历史/新增运行不在同一进程；没有独立硬件层记录保证逐位确定性。',
        '核查未造成误改的历史结果以零次提交为前提，不能解释为核查准确。',
        '部分根因仍是候选解释。记录完成不代表原因已全部因果识别，当前功能仍不具备启用依据。'],
      'next_action':{'status':'planned_not_run','text':'保持当前底座与 LoRA 冻结，暂不启用失败的核查。优先把核查职责限制在原生 operations 契约并保留 harness 的来源、归属和状态转换校验；是否有效仍需在原小样本验收中验证。本轮到此停止新增生成。平衡身份/位置、补干净配对和修复顺序的数据方案只作修订依据，尚未训练。'},
      'index_text':'18 次限定诊断、0 次训练：新核查接口错配；原生训练样本修复 2/6；覆盖偏斜已确认，具体训练因果仍未确定。',
      'evidence_source_sha256':bindings,
    }
    write(HERE/'analysis/report.json',report)
    validation={'id':'tracker-root-cause-engineering','type':'engineering_validation',
      'status':'diagnostics_reviewed_quality_failure_retained','date':report['date'],'timezone':report['timezone'],
      'tested_run':['ablation/adapter-off-01','fit/collection-01'],
      'new_model_calls':18,'new_training_runs':0,'capability_acceptance_passed':False,
      'checks':[
        {'name':'Dataset structural census and targeted source review','status':'passed_with_coverage_findings','result':'750 structural records; 20 targeted semantic cases, 140 repair-position records. No new generation. Data findings do not prove causal effects.'},
        {'name':'Training and loading implementation audit','status':'passed_bounded_checks','result':'500 tokenizer/masking checks, completed optimizer logs, tensor integrity, 4 CPU loss/gradient checks. Initial audit root-path failure retained.'},
        {'name':'Adapter-off collection','status':'failed_postcheck','result':'12/12 generations complete and durable; adapter restoration trainability assertion failed. Original failed result unchanged.'},
        {'name':'Post-hoc adapter-off integrity','status':'passed','result':'Exact historical messages, input hashes, 12 disabled adapter preconditions and output replay verified. Installed PEFT source plus CPU reproduction explains sufficient postcheck mechanism; no claim of observing dead-process final flags.'},
        {'name':'Native training-fit collection','status':'completed','result':'6/6 original prompts, enabled v2, EOS termination, strict execution replay and independent all-record review. Correct focal repairs 2/6.'},
        {'name':'Intent repair quality','status':'not_accepted','result':'Existing v2 audit 0/6; disabled diagnostic 2/6 with 1/6 sufficiently evidenced; native training-fit 2/6. Different tasks remain separate.'}],
      'source_hashes':bindings,
      'limits':['No new unit tests repeated because production feature was unchanged.','Software/integrity checks are not quality acceptance.','Website release validation and publication are recorded separately.']}
    write(HERE/'engineering/validation.json',validation)
    print(json.dumps({'report_sha256':sha(HERE/'analysis/report.json'),'new_calls':18,'training_runs':0}))

if __name__=='__main__': main()
