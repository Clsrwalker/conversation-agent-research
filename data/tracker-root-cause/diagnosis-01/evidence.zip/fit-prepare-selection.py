"""Freeze six original SFT training inputs for a bounded native-task fit probe.

No model outputs are read to choose inputs; no inference or training occurs.
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import importlib.util
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[4]
V2=ROOT/'output/research/2026-10-24/tracker-lora-repair-v2'
DATA=V2/'data/compiled'
CODE=ROOT/'experiments/deep_conversation/tracker_lora'
spec=importlib.util.spec_from_file_location('fit_selection_legacy',CODE/'evaluate_tracker.py')
legacy=importlib.util.module_from_spec(spec);spec.loader.exec_module(legacy)
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def rows(p):return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def jsonl(p,x):p.write_text(''.join(legacy.encode(r)+'\n' for r in x),encoding='utf-8')
def main():
    assert not (HERE/'selection.json').exists() and not (HERE/'protocol.json').exists(),'Preserve the frozen selection.'
    records=rows(DATA/'train.records.jsonl');sfts=rows(DATA/'train.sft.jsonl')
    assert len(records)==len(sfts)==500
    normal_prompt=(V2/'annotation/system_prompt.txt').read_text(encoding='utf-8').strip()
    reviewed=read(HERE.parent/'data/assessment.json')
    reviews={x['example_id']:x for x in reviewed['limited_semantic_inspection']['reviewed_examples']}
    lengths=read(V2/'training/formal-01/lengths.json')
    cases=[];inputs=[];targets=[];controls=[]
    for focus,kind in [('owner','owner'),('wrong_withdrawn','wrong_withdrawn'),('uncertain_status','status')]:
        for language in ('zh','en'):
            eligible=[]
            for index,r in enumerate(records):
                f=r.get('prior_fault_annotation',{})
                if f.get('fault_kind')!=kind or r['language']!=language:continue
                focal=next(i for i in r['expected_semantic_state'] if i['intent_id']==f['intent_id'])
                if kind=='status' and focal['status']!='uncertain':continue
                eligible.append(index)
            assert eligible
            index=eligible[0];r=records[index];s=sfts[index];fault=r['prior_fault_annotation'];key=fault['intent_id']
            expected=next(i for i in r['expected_semantic_state'] if i['intent_id']==key)
            prior=next(i for i in r['input']['intention_state']['intents'] if i['intent_id']==key)
            repair=next(op for op in r['target']['operations'] if op['intent_id']==key)
            assert r['split']=='train' and s['prompt']==[{'role':'system','content':normal_prompt},{'role':'user','content':legacy.encode(r['input'])}]
            assert s['completion']==[{'role':'assistant','content':legacy.encode(r['target'])}]
            assert r['example_id'] in reviews and reviews[r['example_id']]['focal_semantics_verdict']=='supported_by_raw_dialogue'
            events={e['seq']:e for e in r['input']['conversation']}
            sources=fault['repair_source_seqs']
            assert repair['source_seqs']==sources and sources==sorted(set(sources))
            assert all(type(q)is int and q in events for q in sources)
            assert any(events[q]['role']=='user' for q in sources)
            assert max(sources)<=r['input']['intention_state']['processed_event_seq']
            assert prior['owner']!=expected['owner'] if kind=='owner' else prior['status']!=expected['status']
            # This scripted control validates selection/target executability, not
            # whether the trained model can generate the repair.
            with legacy.restore_store(r['input']) as store:
                before=store.snapshot()
                store.commit_patch('fit-selection-reference-'+r['example_id'],before['version'],before['observed_event_seq'],r['target']['operations'])
                assert legacy.project(store.snapshot())==r['expected_semantic_state']
            case_id=f'native-fit-{focus}-{language}'
            item={'case_id':case_id,'source_row_index':index,'source_example_id':r['example_id'],
               'focus':focus,'language':language,'focal_intent_id':key,
               'expected_focal_metadata':{k:expected[k] for k in ('owner','status')},
               'record_sha256':legacy.digest(r),'sft_sha256':legacy.digest(s),
               'canonical_prompt_sha256':legacy.digest(s['prompt']),
               'canonical_completion_sha256':hashlib.sha256(s['completion'][0]['content'].encode('utf-8')).hexdigest(),
               'eligible_training_rows':len(eligible),'selection':'first eligible row in the unchanged compiled train.records source order',
               'recorded_training_prompt_tokens':lengths[index]['prompt_tokens'],
               'recorded_training_completion_tokens':lengths[index]['supervised_completion_tokens']}
            cases.append(item)
            inputs.append({'case_id':case_id,'messages':s['prompt']})
            targets.append({'case_id':case_id,'completion':s['completion'],'target':r['target'],
                'expected_semantic_state':r['expected_semantic_state'],'focal_intent_id':key})
            controls.append({'case_id':case_id,'source_example_id':r['example_id'],'runtime_reference_control':'passed',
               'semantic_source_review':'supported_by_raw_dialogue','semantic_note':reviews[r['example_id']]['finding'],
               'prior_focal':{k:prior[k] for k in ('owner','text','status')},
               'expected_focal':expected,'repair':repair,
               'repair_evidence':[events[q] for q in sources],
               'limitation':'Unblinded AI review of existing training labels; not independent human gold.'})
    assert len(cases)==len({r['source_row_index'] for r in cases})==6
    source_paths=[Path(__file__),DATA/'train.records.jsonl',DATA/'train.sft.jsonl',DATA/'manifest.json',V2/'annotation/system_prompt.txt',
       V2/'training/formal-01/result.json',V2/'training/formal-01/lengths.json',V2/'training/formal-01/adapter/adapter_config.json',
       V2/'training/formal-01/adapter/adapter_model.safetensors',HERE.parent/'data/assessment.json',CODE/'evaluate_tracker.py',
       CODE/'repair_v2/train_tracker.py',ROOT/'experiments/deep_conversation/intention_state.py']
    source_hashes={p.relative_to(ROOT).as_posix():sha(p) for p in source_paths}
    selection={'id':'tracker-native-training-fit-selection','status':'frozen_before_fit_inference',
       'date':'2026-10-27','timezone':'America/Halifax','created_at_utc':datetime.now(timezone.utc).isoformat(),
       'source_records':(DATA/'train.records.jsonl').relative_to(ROOT).as_posix(),
       'source_sft':(DATA/'train.sft.jsonl').relative_to(ROOT).as_posix(),
       'selection_rule':'In current frozen compiled training source order, take the first row for each focus/language: owner zh/en; wrong_withdrawn zh/en; status repair whose expected focal status is uncertain zh/en. No selection based on generated outputs.',
       'case_order':[c['case_id'] for c in cases],'cases':cases,'source_hashes':source_hashes,
       'canonical_digest_definition':'evaluate_tracker.digest = SHA256 of evaluate_tracker.encode(value), sorted compact UTF-8 JSON',
       'model_visible_field':'Only the unchanged source SFT row.prompt. No case ID, focal ID annotation, target, review, expected state, selection metadata or completion is appended.',
       'new_model_calls_during_selection':0,'new_training_runs':0}
    jsonl(HERE/'inputs.jsonl',inputs);jsonl(HERE/'targets.jsonl',targets)
    write(HERE/'source-review.json',{'status':'passed','date':'2026-10-27','timezone':'America/Halifax',
       'kind':'selection_semantics_and_scripted_reference_validation','source_hashes':source_hashes,
       'cases':controls,'controls_passed':6,'new_model_calls':0,'new_training_runs':0,
       'limits':['Scripted reference controls establish execution feasibility, not model capability.','Six deliberately selected existing training rows cannot establish whole-training-set fit, validation loss, overfitting or generalization.']})
    selection['frozen_artifacts']={name:sha(HERE/name) for name in ('inputs.jsonl','targets.jsonl','source-review.json')}
    write(HERE/'selection.json',selection)
    protocol={'id':'tracker-native-training-fit-protocol','status':'frozen_before_fit_inference','kind':'bounded_training_input_diagnostic_not_new_quality_evaluation',
       'date':'2026-10-27','timezone':'America/Halifax','new_model_generations':6,'new_training_runs':0,
       'source_hashes':{**source_hashes,**{(HERE/name).relative_to(ROOT).as_posix():sha(HERE/name) for name in ('selection.json','inputs.jsonl','targets.jsonl','source-review.json')}},
       'question':'Can the unchanged v2 adapter generate executable, evidence-supported repairs for six preselected original training inputs under its original operations contract?',
       'scope':{'inputs':6,'calls_per_input':1,'maximum_calls':6,'base_changes':0,'adapter_weight_changes':0,'training':0,'new_synthetic_cases':0,'retries':0},
       'model':{'base':'Qwen/Qwen2.5-14B-Instruct','revision':'cf98f3b3bbb457ad9e2bb7baf9a0125b6b88caa8',
          'adapter_run':(V2/'training/formal-01').relative_to(ROOT).as_posix(),'adapter_enabled':True,'same_frozen_loader':'experiments/deep_conversation/tracker_lora/repair_v2/train_tracker.py'},
       'generation':{'do_sample':False,'num_beams':1,'seed':20261024,'max_prompt_tokens':2048,'max_new_tokens':512,
          'repetition_penalty':1.0,'cache_implementation':'dynamic','truncation':False},
       'input_contract':'Use the exact prompt messages from the indexed train.sft.jsonl record. It contains the original tracker system prompt and full conversation/intention_state/tool_receipts input. The canonical completion is preserved for scoring only; never pass it as part of the generation input.',
       'execution':'Apply strict operations parsing and the unchanged IntentStore to a restored exact original training prior. One call per case; no subsequent audit, normalization repair, hidden retry or altered label.',
       'outcomes':['Completed/failed generation and token-cap status.','Strict JSON and executable operations acceptance.','Focal owner/status correctness and full focal meaning (including text and qualifiers) after execution.','Focal repair operation and sufficiency of its cited raw evidence.','Preservation of all unrelated pre-existing requirements and correctness of ordinary latest-turn changes.','Exact canonical completion match as a descriptive formatting metric only; semantic equivalents may differ in text.'],
       'interpretation_rules':['Failures show the selected training examples were not mastered under greedy generation; they do not quantify total training-set failure or identify the cause.',
          'Success shows local fit on these exposed training examples; it does not prove generalization or overfitting.',
          'Mixed results locate which native repair abilities were or were not reproduced here; do not label the whole model underfit or overfit from six examples.',
          'This check is separate from the 12 new adapter-off audit calls versus 12 historical adapter-on audit calls. Do not merge denominators or treat it as another arm of that comparison.'],
       'stop_rule':'Stop after the six assigned single-pass generations, retaining every failure. No prompt tuning, new data, retraining, model swap or output-dependent rerun is authorized by this protocol.'}
    write(HERE/'protocol.json',protocol)
    print(json.dumps({'status':'frozen','cases':[{'case':c['case_id'],'source':c['source_example_id'],'row':c['source_row_index']} for c in cases],
       'selection_sha256':sha(HERE/'selection.json'),'protocol_sha256':sha(HERE/'protocol.json'),'new_model_calls':0},ensure_ascii=True))
if __name__=='__main__':main()
