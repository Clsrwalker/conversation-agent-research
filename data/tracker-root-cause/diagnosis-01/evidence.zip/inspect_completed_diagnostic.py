"""Prepare independent review facts after the terminal 12-call diagnostic."""
from pathlib import Path
import json,sys,hashlib
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[4]
PRIOR=ROOT/'output/research/2026-10-27/tracker-intent-audit'
RUN=HERE.parent/'ablation/adapter-off-01'
sys.path.insert(0,str(ROOT/'experiments/deep_conversation/tracker_lora/intent_audit'))
import audit
from pipeline import legacy
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def main():
    result=read(RUN/'result.json')
    terminal_postcheck_failure=result['status']=='failed' and result['error']['type']=='AssertionError' and 'state(model,False)' in result['error']['traceback']
    assert result['status']=='completed' or terminal_postcheck_failure,'Do not review a partial collection.'
    assert result['durable_calls']==12
    if result['status']=='completed':
        assert result['calls']==12
        assert sha(RUN/'config.json')==result['config_sha256']
        assert sha(RUN/'PRIVATE-calls.jsonl')==result['outputs_sha256']
        assert sha(RUN/'PRIVATE-outcomes.jsonl')==result['outcomes_sha256']
    config=read(RUN/'config.json')
    for rel,value in config['source_hashes'].items(): assert sha(ROOT/rel)==value,rel
    old_calls=[r for r in legacy.jsonl(PRIOR/'collection-02/PRIVATE-calls.jsonl') if r['stage']=='audit']
    old_outcomes=legacy.jsonl(PRIOR/'collection-02/PRIVATE-outcomes.jsonl')
    calls=legacy.jsonl(RUN/'PRIVATE-calls.jsonl'); outcomes=legacy.jsonl(RUN/'PRIVATE-outcomes.jsonl')
    journal=legacy.jsonl(RUN/'attempts.jsonl'); cases=legacy.jsonl(PRIOR/'data/acceptance.records.jsonl')
    assert len(journal)==24 and [x['ordinal'] for x in journal]==[i for i in range(1,13) for _ in range(2)]
    assert [x['event'] for x in journal]==['started','ended']*12
    assert len(calls)==len(outcomes)==len(cases)==12
    facts=[]
    for index,(old,base,call,outcome,case) in enumerate(zip(old_calls,old_outcomes,calls,outcomes,cases)):
        assert old['case_id']==call['case_id']==outcome['case_id']==case['case_id']
        assert call['messages']==old['messages']
        for key in ('input_messages_sha256','input_token_ids_sha256','input_tokens'):
            assert call[key]==old[key]
        assert legacy.digest(call['messages'])==call['input_messages_sha256']
        assert call['config_sha256']==sha(RUN/'config.json')
        assert call['ordinal']==index+1
        assert journal[2*index]['case_id']==call['case_id']
        assert journal[2*index+1]['record_sha256']==legacy.digest(call)
        assert journal[2*index+1]['status']==call['status']
        assert call['actual_adapter_state']['disabled_layers']==call['actual_adapter_state']['layers']==336
        assert call['actual_adapter_state']['trainable_parameters']==0
        assert call['status']=='completed'
        assert len(call['generated_token_ids'])==call['output_tokens']
        assert call['last_generated_token']==call['generated_token_ids'][-1]
        before=base['result']['baseline']['post_state']; after=outcome['result']['post_state']
        payload=json.loads(call['messages'][1]['content'])
        packet={'conversation':payload['conversation'],'intention_state':before,'tool_receipts':[]}
        with legacy.restore_store(packet) as store:
            request=audit.build_request(store)
            assert audit.messages(request)==call['messages']
            replay=audit.apply_report(store,request,call['output_text'],call['case_id']+'-adapter-off')
            assert replay==outcome['result']
        b={x['intent_id']:x for x in before['intents']}; a={x['intent_id']:x for x in after['intents']}
        assert b.keys()==a.keys() and all(b[k]['text']==a[k]['text'] for k in b)
        changes=[{'intent_id':k,'field':f,'before':b[k][f],'after':a[k][f]}
          for k in b for f in ('owner','status') if b[k][f]!=a[k][f]]
        try: parsed=audit._strict_json(call['output_text']); parseable=True
        except ValueError: parsed=None; parseable=False
        eos=call['configured_eos_token_ids']; eos=eos if isinstance(eos,list) else [eos]
        focal=case['focal_intent_id']; expected=case['expected_focal_metadata']
        facts.append({'case_id':case['case_id'],'condition':case['condition'],'focus':case['focus'],
          'focal_intent_id':focal,'expected_focal_fields':expected,
          'baseline_focal_fields':{k:b[focal][k] for k in ('owner','status','text')},
          'final_focal_fields':{k:a[focal][k] for k in ('owner','status','text')},
          'baseline_focal_fields_equal_reference':all(b[focal][k]==v for k,v in expected.items()),
          'final_focal_fields_equal_reference':all(a[focal][k]==v for k,v in expected.items()),
          'json_parseable':parseable,'audit_status':outcome['result']['status'],
          'committed':outcome['result']['committed'],'operations':outcome['result']['operations'],
          'unresolved':outcome['result']['unresolved'],'changed_fields':changes,
          'raw_report':parsed if parseable else call['output_text'],
          'input_tokens':call['input_tokens'],'output_tokens':call['output_tokens'],
          'last_generated_token':call['last_generated_token'],'configured_eos_ids':eos,
          'ended_on_configured_eos':call['last_generated_token'] in eos,'hit_token_cap':call['hit_token_cap'],
          'raw_dialogue':payload['conversation']})
    out=HERE/'PRIVATE-adapter-off-review-facts.json'
    assert not out.exists()
    out.write_text(json.dumps({'status':'verified_for_semantic_review','run_status':result['status'],
      'terminal_postcheck_failure':terminal_postcheck_failure,
      'source_hashes':{p.relative_to(ROOT).as_posix():sha(p) for p in [RUN/'result.json',RUN/'config.json',RUN/'PRIVATE-calls.jsonl',RUN/'PRIVATE-outcomes.jsonl',RUN/'attempts.jsonl',Path(__file__)]},
      'cases':facts},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'verified_for_semantic_review','cases':12,'actual_record_replays':12,'facts_sha256':sha(out)}))
if __name__=='__main__': main()
