"""Count frozen repair target order; reference existing fit outputs, no inference."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
STUDY = HERE.parent
V2 = ROOT / 'output/research/2026-10-24/tracker-lora-repair-v2'
RECORDS = V2 / 'data/compiled/train.records.jsonl'

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def lines(path):
    return [json.loads(s) for s in path.read_text(encoding='utf-8').splitlines() if s.strip()]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def summarize(rows):
    return {
        'fault_rows': len(rows),
        'repair_is_last': sum(r['repair_is_last'] for r in rows),
        'has_ordinary_latest_operations_before_repair': sum(r['preceding_ordinary_operation_count'] > 0 for r in rows),
        'repair_only_no_ordinary_latest_operation': sum(r['preceding_ordinary_operation_count'] == 0 for r in rows),
        'preceding_ordinary_operation_count_distribution': dict(sorted(Counter(r['preceding_ordinary_operation_count'] for r in rows).items())),
        'preceding_ordinary_operation_types': dict(sorted(Counter(op['op'] for r in rows for op in r['preceding_ordinary_operations']).items())),
    }

def main():
    destination = HERE / 'repair-position-addendum.json'
    assert not destination.exists(), 'Do not overwrite a completed addendum.'
    protected = [HERE / 'census.json', HERE / 'assessment.json', STUDY / 'fit/protocol.json', STUDY / 'fit/selection.json']
    protected_hashes = {p.relative_to(ROOT).as_posix(): sha(p) for p in protected}
    records = lines(RECORDS)
    assert len(records) == 500
    source_paths = sorted((V2 / 'data/source').glob('*.jsonl'))
    families = {r['family_id']: r for p in source_paths for r in lines(p)}
    rows = []
    for index, record in enumerate(records):
        if 'prior_fault_annotation' not in record:
            continue
        fault = record['prior_fault_annotation']
        focal = fault['intent_id']
        operations = record['target']['operations']
        repair_positions = [i for i, operation in enumerate(operations) if operation['intent_id'] == focal]
        assert len(repair_positions) == 1
        position = repair_positions[0]
        ordinary = families[record['family_id']]['decisions'][record['decision_index']]['operations']
        assert all(operation['intent_id'] != focal for operation in ordinary)
        assert operations[:position] == ordinary and position == len(operations) - 1
        repair = operations[position]
        assert repair['source_seqs'] == fault['repair_source_seqs']
        assert max(repair['source_seqs']) <= record['input']['intention_state']['processed_event_seq']
        rows.append({
            'source_row_index': index,
            'example_id': record['example_id'],
            'family_id': record['family_id'],
            'language': record['language'],
            'fault_kind': fault.get('fault_kind', 'legacy_text'),
            'compiler_route': 'v2' if 'fault_kind' in fault else 'retained_legacy',
            'focal_intent_id': focal,
            'target_operation_count': len(operations),
            'repair_position_one_based': position + 1,
            'repair_is_last': position == len(operations) - 1,
            'preceding_ordinary_operation_count': len(ordinary),
            'preceding_ordinary_operations': ordinary,
            'repair_operation': repair,
            'source_decision_verified_equal_to_target_prefix': True,
        })
    assert len(rows) == 140
    by_example = {r['example_id']: r for r in rows}
    selection = read(STUDY / 'fit/selection.json')
    calls_path = STUDY / 'fit/collection-01/PRIVATE-calls.jsonl'
    outcomes_path = STUDY / 'fit/collection-01/PRIVATE-outcomes.jsonl'
    facts_path = STUDY / 'fit/PRIVATE-review-facts.json'
    calls = {r['case_id']: r for r in lines(calls_path)}
    outcomes = {r['case_id']: r['result'] for r in lines(outcomes_path)}
    facts = {r['case_id']: r for r in read(facts_path)['cases']}
    fit_rows = []
    for selected in selection['cases']:
        case_id = selected['case_id']
        layout = by_example[selected['source_example_id']]
        call, outcome, fact = calls[case_id], outcomes[case_id], facts[case_id]
        generated = json.loads(call['output_text'])['operations']
        assert generated == outcome['proposal']['operations'] == fact['proposal']['operations']
        emitted_focal = [op for op in generated if op['intent_id'] == selected['focal_intent_id']]
        assert len(emitted_focal) <= 1
        reference = layout['repair_operation']
        # Exact operation matching is descriptive only, not a new semantic score.
        if not emitted_focal:
            relation = 'focal_repair_omitted'
        elif emitted_focal[0] == reference:
            relation = 'focal_operation_exactly_matches_reference'
        else:
            relation = 'focal_operation_differs_from_reference'
        fit_rows.append({
            'case_id': case_id,
            'source_example_id': selected['source_example_id'],
            'focus': selected['focus'], 'language': selected['language'],
            'source_row_index': selected['source_row_index'],
            'target_operation_count': layout['target_operation_count'],
            'target_repair_position_one_based': layout['repair_position_one_based'],
            'target_prefix_ordinary_operations': layout['preceding_ordinary_operations'],
            'target_repair_operation': reference,
            'generated_operations': generated,
            'relation_to_reference_focal_operation': relation,
            'generated_equals_entire_ordinary_prefix': generated == layout['preceding_ordinary_operations'],
            'existing_execution_validity': outcome['validity'],
            'existing_execution_committed': outcome['committed'],
            'ended_on_configured_eos': fact['ended_on_configured_eos'],
            'hit_token_cap': fact['hit_token_cap'],
            'call_reference': {'path': calls_path.relative_to(ROOT).as_posix(), 'case_id': case_id, 'ordinal': call['ordinal']},
            'review_facts_reference': {'path': facts_path.relative_to(ROOT).as_posix(), 'case_id': case_id},
            'scoring_note': 'Raw sequence comparison and reference to existing execution facts; this addendum does not perform a separate semantic re-score.',
        })
    assert len(fit_rows) == 6
    assert Counter(r['relation_to_reference_focal_operation'] for r in fit_rows) == {
        'focal_repair_omitted': 3,
        'focal_operation_exactly_matches_reference': 2,
        'focal_operation_differs_from_reference': 1,
    }
    assert sum(r['generated_equals_entire_ordinary_prefix'] for r in fit_rows) == 2
    code_paths = [ROOT / 'experiments/deep_conversation/tracker_lora/repair_v2/build_dataset.py',
                  ROOT / 'experiments/deep_conversation/tracker_lora/build_dataset.py']
    source_bindings = [Path(__file__), RECORDS, *source_paths, *code_paths, *protected,
                       calls_path, outcomes_path, facts_path]
    report = {
        'id': 'tracker-repair-position-addendum',
        'status': 'completed',
        'kind': 'read_only_census_addendum_with_existing_output_references',
        'date': '2026-10-27', 'timezone': 'America/Halifax',
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'source_hashes': {p.relative_to(ROOT).as_posix(): sha(p) for p in source_bindings},
        'new_model_calls': 0, 'new_training_runs': 0, 'new_semantic_scoring_runs': 0,
        'method': 'For each annotated faulty training row, identify the unique operation on prior_fault_annotation.intent_id. Check its position and assert that preceding operations exactly equal the original source family decision operations. The 140-row census includes the retained legacy compiler route.',
        'compiler_evidence': [
            {'path': code_paths[0].relative_to(ROOT).as_posix(), 'line': 125,
             'expression': "target = {'operations': copy.deepcopy(ordinary['target']['operations']) + [repair]}"},
            {'path': code_paths[1].relative_to(ROOT).as_posix(), 'line': 135,
             'expression': "target = {'operations': copy.deepcopy(ordinary['target']['operations']) + [repair]}"},
        ],
        'counts': summarize(rows),
        'by_fault_kind': {kind: summarize([r for r in rows if r['fault_kind'] == kind]) for kind in sorted({r['fault_kind'] for r in rows})},
        'by_compiler_route': {route: summarize([r for r in rows if r['compiler_route'] == route]) for route in ('v2', 'retained_legacy')},
        'training_row_layouts': rows,
        'six_training_fit_mappings': fit_rows,
        'observed_fit_sequences': {
            'focal_repair_omitted': 3,
            'generated_only_ordinary_prefix': 2,
            'empty_operations_with_ordinary_and_repair_both_omitted': 1,
            'focal_reference_operation_reproduced': 2,
            'focal_withdraw_generated_instead_of_uncertain_update': 1,
            'all_six_ended_on_configured_eos': all(r['ended_on_configured_eos'] for r in fit_rows),
            'any_hit_token_cap': any(r['hit_token_cap'] for r in fit_rows),
        },
        'confirmed': 'All 140 faulty training targets put the historical repair last, after any ordinary current-decision operations. This is a fixed data/compiler design fact, including retained legacy rows.',
        'not_established': [
            'Whether the fixed last position causes the model to omit historical repair or finish generation before supplying it.',
            'Whether changing operation order, adding prompts, training further, or another intervention would improve repairs.',
            'Whether the six selected training examples represent full-training-set fit or held-out performance.',
        ],
        'interpretation': 'Two existing fit outputs reproduce only the ordinary prefix and omit the final repair. But one other failed case emits no operations at all, and another has a repair-only target yet emits withdraw instead of uncertain update; a tail-omission account does not explain every observed failure. All six finish on configured EOS without hitting the token cap. This coexistence is not a causal position ablation.',
        'next_action': 'No additional prompt, generation, training or ordering experiment is started by this addendum.',
        'preserved_frozen_artifacts': protected_hashes,
    }
    destination.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    for relative, expected in protected_hashes.items():
        assert sha(ROOT / relative) == expected, relative
    print(json.dumps({'status': report['status'], 'counts': report['counts'], 'by_fault_kind': report['by_fault_kind'],
                      'addendum_sha256': sha(destination), 'new_model_calls': 0}, ensure_ascii=True))

if __name__ == '__main__':
    main()
