"""Independent bounded review; tokenizer and real store only, no model loading."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import hashlib
import importlib.metadata
import json
import os
import sys

os.environ['CUDA_VISIBLE_DEVICES'] = ''
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
CODE = ROOT/'experiments/deep_conversation/tracker_lora'
V2 = ROOT/'output/research/2026-10-24/tracker-lora-repair-v2'
sys.path.insert(0, str(CODE/'diagnostics'))
import collect_audit_adapter_off as helper
legacy = helper.legacy

def read(p): return json.loads(p.read_text(encoding='utf-8'))
def sha(p):
    with p.open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()

def main():
    destination = HERE/'preflight-review.json'
    assert not destination.exists(), 'Never replace a frozen review.'
    protocol = read(HERE/'protocol.json')
    selection = read(HERE/'selection.json')
    for document in (protocol, selection):
        for rel, expected in document['source_hashes'].items():
            assert sha(ROOT/rel) == expected, rel
    for rel, expected in selection['frozen_artifacts'].items():
        assert sha(HERE/rel) == expected, rel
    assert sha(HERE/'selection.json') == 'c8028be138e7dd3acdea2caf57380f29dc4b3b8a6c1e79dfa18242f53dd3801f'
    assert sha(HERE/'protocol.json') == '2c128f8ae6fc5cf648c19146ee3727c5b449d338c5a815ebc61cb9e8bdeb883f'
    expected_generation = {'seed':20261024,'do_sample':False,'num_beams':1,
        'repetition_penalty':1.0,'cache_implementation':'dynamic','max_prompt_tokens':2048,'max_new_tokens':512}
    assert protocol['generation'] == expected_generation
    assert protocol['prompt_truncation'] is False and protocol['new_model_generations'] == 6
    assert protocol['scope'] == {'inputs':6,'calls_per_input':1,'maximum_calls':6,
        'base_changes':0,'adapter_weight_changes':0,'training':0,'new_synthetic_cases':0,'retries':0}
    old_config = read(ROOT/'output/research/2026-10-27/tracker-intent-audit/collection-02/config.json')
    versions = {n:importlib.metadata.version(n) for n in old_config['versions']}
    assert versions == old_config['versions']
    assert all(old_config[k] == v for k,v in expected_generation.items() if k != 'max_new_tokens')
    assert old_config['max_new_tokens']['normal'] == 512
    artifacts = helper.adapter_artifacts(helper.ADAPTER_RUN)
    assert artifacts == old_config['adapter']
    assert sha(helper.BASE_RECEIPT) == old_config['base_receipt_sha256']
    assert protocol['model']['base'] == helper.MODEL_ID
    assert protocol['model']['revision'] == helper.REVISION
    rows = legacy.jsonl(V2/'data/compiled/train.records.jsonl')
    sfts = legacy.jsonl(V2/'data/compiled/train.sft.jsonl')
    inputs = legacy.jsonl(HERE/'inputs.jsonl')
    targets = legacy.jsonl(HERE/'targets.jsonl')
    lengths = read(V2/'training/formal-01/lengths.json')
    assert len(rows) == len(sfts) == 500
    assert len(selection['cases']) == len(inputs) == len(targets) == 6
    assert len({c['source_row_index'] for c in selection['cases']}) == 6
    original_system = (V2/'annotation/system_prompt.txt').read_text(encoding='utf-8').strip()
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(str(helper.MODEL_PATH),local_files_only=True,trust_remote_code=False)
    checks = []
    expected_order = [(f,l) for f in ('owner','wrong_withdrawn','uncertain_status') for l in ('zh','en')]
    assert [(c['focus'],c['language']) for c in selection['cases']] == expected_order
    for case, frozen_input, frozen_target in zip(selection['cases'], inputs, targets):
        focus, language = case['focus'], case['language']
        kind = 'status' if focus == 'uncertain_status' else focus
        eligible = []
        for i, row in enumerate(rows):
            fault = row.get('prior_fault_annotation',{})
            if fault.get('fault_kind') != kind or row['language'] != language: continue
            focal = next(s for s in row['expected_semantic_state'] if s['intent_id'] == fault['intent_id'])
            if kind == 'status' and focal['status'] != 'uncertain': continue
            eligible.append(i)
        index = case['source_row_index']
        assert index == eligible[0] and len(eligible) == case['eligible_training_rows']
        row, sft = rows[index], sfts[index]
        assert row['split'] == 'train' and row['example_id'] == case['source_example_id']
        assert legacy.digest(row) == case['record_sha256'] and legacy.digest(sft) == case['sft_sha256']
        assert sft['prompt'] == [{'role':'system','content':original_system},
            {'role':'user','content':legacy.encode(row['input'])}]
        assert set(row['input']) == {'conversation','intention_state','tool_receipts'}
        assert sft['completion'] == [{'role':'assistant','content':legacy.encode(row['target'])}]
        assert frozen_input == {'case_id':case['case_id'],'messages':sft['prompt']}
        assert frozen_target['completion'] == sft['completion'] and frozen_target['target'] == row['target']
        assert legacy.digest(sft['prompt']) == case['canonical_prompt_sha256']
        prefix = tokenizer.apply_chat_template(sft['prompt'],tokenize=True,add_generation_prompt=True,return_dict=False)
        full = tokenizer.apply_chat_template(sft['prompt']+sft['completion'],tokenize=True,add_generation_prompt=False,return_dict=False)
        assert full[:len(prefix)] == prefix
        assert len(prefix) == lengths[index]['prompt_tokens'] == case['recorded_training_prompt_tokens'] <= 2048
        assert len(full)-len(prefix) == lengths[index]['supervised_completion_tokens'] == case['recorded_training_completion_tokens']
        with legacy.restore_store(row['input']) as store:
            assert store.snapshot() == row['input']['intention_state']
        reference = legacy.apply_candidate(row, {'status':'completed','output_text':sft['completion'][0]['content']})
        assert reference['validity'] == 'valid_patch' and reference['committed']
        assert legacy.project(reference['post_state']) == row['expected_semantic_state']
        checks.append({'case_id':case['case_id'],'source_row_index':index,'eligible_rows':len(eligible),
            'first_in_source_order':True,'exact_original_SFT_prompt':True,'completion_not_in_prompt':True,
            'prompt_tokens':len(prefix),'training_completion_tokens':len(full)-len(prefix),
            'input_token_ids_sha256':legacy.digest(prefix),'prior_restored_exactly':True,
            'unchanged_apply_candidate_reference_control':'passed'})
    collector_path = CODE/'diagnostics/collect_training_fit.py'
    source = collector_path.read_text(encoding='utf-8')
    tree = ast.parse(source)
    calls = [n for n in ast.walk(tree) if isinstance(n,ast.Call)]
    generate = [n for n in calls if isinstance(n.func,ast.Attribute) and n.func.attr == 'generate']
    assert len(generate) == 1
    keywords = {k.arg:ast.literal_eval(k.value) for k in generate[0].keywords
        if k.arg in ('do_sample','num_beams','max_new_tokens','repetition_penalty','cache_implementation','logits_to_keep','use_cache')}
    assert keywords == {'do_sample':False,'num_beams':1,'max_new_tokens':512,
        'repetition_penalty':1.0,'cache_implementation':'dynamic','logits_to_keep':1,'use_cache':True}
    assert not any(isinstance(n,(ast.While,ast.AsyncFor)) for n in ast.walk(tree))
    assert 'prepared.append((case,row,sft[\'prompt\'],tokens))' in source
    assert 'outcome=legacy.apply_candidate(row,record)' in source
    assert 'with torch.inference_mode(),torch.autocast' in source
    assert 'model.requires_grad_(False); model.eval()' in source
    assert 'record[\'actual_adapter_state\']=state(model,False)' in source
    assert 'generated_token_ids=generated' in source
    assert 'last_generated_token=generated[-1] if generated else None' in source
    assert 'configured_eos_token_ids=model.generation_config.eos_token_id' in source
    assert 'disable_adapter(' not in source
    assert 'optimizer' not in source and '.backward(' not in source
    import torch
    assert not torch.cuda.is_initialized()
    paths = {ROOT/rel for rel in protocol['source_hashes']}
    paths.update([Path(__file__),HERE/'protocol.json',HERE/'selection.json',collector_path,
        CODE/'diagnostics/collect_audit_adapter_off.py',CODE/'repair_v2/collect_three_arm.py',
        CODE/'repair_v2/gates.py',CODE/'intent_audit/pipeline.py',CODE/'intent_audit/audit.py',
        helper.BASE_RECEIPT,helper.MODEL_PATH/'tokenizer.json',helper.MODEL_PATH/'tokenizer_config.json',
        helper.MODEL_PATH/'generation_config.json',ROOT/'output/research/2026-10-27/tracker-intent-audit/collection-02/config.json',
        HERE.parent/'training/runtime-integrity.json',HERE.parent/'training/adapter-context-postcheck.json'])
    result = {'id':'tracker-native-training-fit-preflight-review','status':'passed',
        'date':'2026-10-27','timezone':'America/Halifax','checked_at_utc':datetime.now(timezone.utc).isoformat(),
        'kind':'source_and_CPU_tokenizer_runtime_review_not_model_quality',
        'new_model_generations':0,'new_training_runs':0,'loaded_model_weights':False,'cuda_initialized':False,
        'authorized_collection':{'maximum_calls':6,'calls_per_case':1,'training':0,'retries':0,'new_prompts':0},
        'source_hashes':{p.relative_to(ROOT).as_posix():sha(p) for p in sorted(paths)},
        'cases':checks,'versions':versions,'adapter_artifacts':artifacts,'generation':expected_generation,
        'code_review':{
            'same_loader':'Original frozen v2 NF4 loader and prepare_frozen_base, same pinned base/revision; runtime asserts all base-file hashes before model loading.',
            'input_isolation':'Only the unchanged SFT prompt is tokenized for generation. Targets are read for integrity validation and outcome scoring, never appended to messages.',
            'model_state_gate':'model.eval and requires_grad_(False), then state(model,False) requires all 336 layers enabled under tracker_lora_v2 and zero trainable parameters before each call.',
            'single_pass':'One prepared input per unique case and one generate call in the six-item loop; exceptions retained, no retry loop or output repair.',
            'postcontext_bug_not_present':'This collector never enters disable_adapter; the earlier adapter-off cleanup flag restoration does not apply.',
            'durability':'Started/ended records and raw call/output records are flushed and fsynced; generated IDs, last token, EOS config and token-cap flag retained.',
            'execution':'Unchanged legacy.apply_candidate uses strict JSON and real IntentStore; invalid output leaves original state, without fence stripping or syntax repair.',
            'after_collection':'Requires 6 calls/outcomes in assigned order, unchanged bound sources and adapter hashes; completion does not mean quality success.'},
        'initial_protocol_issue':{'resolved_before_inference':True,'description':'Initial protocol included truncation in the generation dictionary but collector did not. The preserved amendment moves the constraint to prompt_truncation=false; generation dictionaries now match exactly.','selection_changed':False},
        'limitations':['Preflight does not load or run the model; actual enabled state and generated outputs must be checked after collection.',
            'Only six exposed training inputs; local success does not establish generalization and failure does not identify underfitting, overfitting or a unique cause.',
            'Reference execution controls establish label executability, not model capability or independently human-reviewed semantics.',
            'The original 12-call adapter-off run remains failed at its post-context cleanup, with separately verified durable outputs; this six-call collection is a distinct diagnostic.']}
    destination.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({'status':result['status'],'cases_checked':len(checks),'model_generations':0,
        'sha256':sha(destination)},ensure_ascii=False))

if __name__ == '__main__': main()
