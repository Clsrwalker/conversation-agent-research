"""Durable, same-base three-arm collection. Never judges semantic quality.

Only raw input fields become model messages. All assignments, including failed
calls, remain durable and scoreable. An exclusive process lock prevents a second
collector from treating a live call as interrupted. Truncated journals are rejected.
"""
import argparse
from collections import Counter
import contextlib
from datetime import datetime, timezone
import gc
import importlib.metadata
import itertools
import json
import os
from pathlib import Path
import time
import traceback
import uuid

from gates import canonical, digest, jsonl, read, require
from train_tracker import (BASE_RECEIPT, MODEL_ID, MODEL_PATH, REVISION, emit,
                           measured_memory, prepare_frozen_base, quantized_base, sha, write)

ARMS = ('adapter_disabled', 'tracker_lora_v1', 'tracker_lora_v2')
ORDERS = tuple(itertools.permutations(ARMS))


def assignments(count):
    return [(index, arm) for index in range(count) for arm in ORDERS[index % 6]]


def durable_append(path, value):
    with Path(path).open('a', encoding='utf-8', newline='\n') as stream:
        stream.write(canonical(value) + '\n')
        stream.flush()
        os.fsync(stream.fileno())


def strict_journal(path):
    path = Path(path)
    if not path.exists():
        return []
    raw = path.read_bytes()
    require(not raw or raw.endswith(b'\n'), f'Truncated journal must be preserved and explicitly recovered: {path.name}')
    return [json.loads(line) for line in raw.decode('utf-8').splitlines()]


@contextlib.contextmanager
def exclusive_collector(path):
    """Kernel-held lock, released on process exit; lock-file existence is not liveness."""
    with Path(path).open('a+b') as stream:
        if stream.seek(0, os.SEEK_END) == 0:
            stream.write(b'0'); stream.flush()
        stream.seek(0)
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            yield
        finally:
            stream.seek(0)
            if os.name == 'nt':
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def prompt_messages(row, system):
    require(set(row['input']) == {'conversation', 'intention_state', 'tool_receipts'}, 'Unexpected input field; annotations cannot enter prompts')
    return [{'role': 'system', 'content': system}, {'role': 'user', 'content': canonical(row['input'])}]


def adapter_artifacts(run):
    run = Path(run)
    result, config = read(run / 'result.json'), read(run / 'adapter/adapter_config.json')
    require(result['status'] == 'passed' and result['mode'] == 'train', 'Adapter training did not pass')
    require(result['base_model'] == MODEL_ID and result['base_revision'] == REVISION, 'Training base differs')
    require(config['base_model_name_or_path'] == MODEL_ID and config['revision'] == REVISION and config['r'] == 16, 'Adapter base/rank differs')
    hashes = {name: sha(run / 'adapter' / name) for name in ('adapter_model.safetensors', 'adapter_config.json')}
    require(all(result['save_reload']['adapter_files'][name] == value for name, value in hashes.items()), 'Adapter artifacts differ from passed training')
    return {'training_result_sha256': sha(run / 'result.json'), 'weights_sha256': hashes['adapter_model.safetensors'], 'config_sha256': hashes['adapter_config.json']}


def actual_adapter_state(model, arm):
    layers = [module for module in model.modules() if hasattr(module, 'lora_A')]
    require(bool(layers), 'No LoRA layers found')
    disabled = sum(bool(module.disable_adapters) for module in layers)
    expected_name = 'tracker_lora_v1' if arm == 'adapter_disabled' else arm
    active = list(model.active_adapters)
    require(active == [expected_name], 'Unexpected active model adapter name')
    require(disabled == (len(layers) if arm == 'adapter_disabled' else 0), 'LoRA enablement mismatch')
    names = Counter()
    for layer in layers:
        require(set(layer.lora_A) == {'tracker_lora_v1', 'tracker_lora_v2'}, 'Layer does not contain both adapters')
        layer_active = list(layer.active_adapters)
        require(layer_active == [expected_name], 'Layer active adapter differs')
        names[canonical(layer_active)] += 1
    return {'active_adapter_names': active, 'lora_layer_count': len(layers),
            'disabled_lora_layers': disabled, 'layer_active_name_counts': dict(names)}


def validate_prior(prior, events, expected, metadata, config):
    require(len(prior) <= len(expected), 'Too many saved assignments')
    starts, ends = {}, {}
    cursor, pending = 0, None
    for event in events:
        require(event['collection_config_sha256'] == digest(config), 'Attempt journal configuration changed')
        ident = event['attempt_id']
        if event['event'] == 'attempt_started':
            require(pending is None and cursor < len(expected) and (event['row_index'], event['arm']) == expected[cursor], 'Attempt order is not the frozen assignment prefix')
            require(ident not in starts and event['attempt_number'] == len(starts) + 1, 'Duplicate or nonsequential attempt')
            require((event['row_index'], event['arm']) in expected, 'Unassigned attempt')
            for name, value in metadata[event['row_index']].items():
                require(event[name] == value, f'Attempt input changed: {name}')
            starts[ident] = event
            pending = ident
        else:
            require(event['event'] == 'attempt_ended' and ident in starts and ident not in ends, 'Orphan or duplicate attempt end')
            require(ident == pending, 'Attempt end crosses an unfinished call')
            require((event['row_index'], event['arm']) == (starts[ident]['row_index'], starts[ident]['arm']), 'Attempt key mismatch')
            ends[ident] = event
            if event['status'] != 'interrupted_no_durable_result':
                cursor += 1
            pending = None
    prior_by_attempt = {}
    for ordinal, record in enumerate(prior):
        key = (record['row_index'], record['arm'])
        require(key == expected[ordinal], 'Saved results are not an exact assignment prefix; duplicates/out-of-order results prohibited')
        require(record['status'] in {'completed', 'failed'}, 'Nonterminal durable output')
        require(record['attempt_id'] in starts and record['attempt_id'] not in prior_by_attempt, 'Durable output lacks a unique attempt')
        start = starts[record['attempt_id']]
        require(key == (start['row_index'], start['arm']), 'Durable output/attempt key mismatch')
        require(record['artifacts'] == config['adapters'] and record['collection_config_sha256'] == digest(config), 'Durable artifact binding mismatch')
        for name, value in metadata[record['row_index']].items():
            require(record[name] == value, f'Durable input changed: {name}')
        if record['status'] == 'completed':
            state = record['actual_adapter_state']
            name = 'tracker_lora_v1' if record['arm'] == 'adapter_disabled' else record['arm']
            require(state['active_adapter_names'] == [name] and state['lora_layer_count'] > 0, 'Saved adapter identity missing')
            require(state['disabled_lora_layers'] == (state['lora_layer_count'] if record['arm'] == 'adapter_disabled' else 0), 'Saved enablement mismatch')
            require(state['layer_active_name_counts'] == {canonical([name]): state['lora_layer_count']}, 'Saved layer identity mismatch')
        prior_by_attempt[record['attempt_id']] = record
    for ident, end in ends.items():
        if end['status'] == 'interrupted_no_durable_result':
            require(ident not in prior_by_attempt, 'Interrupted attempt already has durable output')
        else:
            require(ident in prior_by_attempt and end['status'] == prior_by_attempt[ident]['status'] and end['record_sha256'] == digest(prior_by_attempt[ident]), 'Ended attempt has no matching durable result')
    require(len(prior) == cursor + int(pending in prior_by_attempt), 'Durable output count differs from attempt history')
    # Every completed/failed assignment must appear exactly once; retries are only
    # possible after an explicitly journaled interruption without durable output.
    saved_keys = {(r['row_index'], r['arm']) for r in prior}
    for ident, start in starts.items():
        if ident not in prior_by_attempt and (ident not in ends or ends[ident]['status'] != 'interrupted_no_durable_result'):
            require(len(prior) < len(expected) and (start['row_index'], start['arm']) == expected[len(prior)], 'Unresolved attempt does not match next assignment')
        if ident in ends and ends[ident]['status'] == 'interrupted_no_durable_result':
            require((start['row_index'], start['arm']) in saved_keys or (len(prior) < len(expected) and (start['row_index'], start['arm']) == expected[len(prior)]), 'Interrupted attempt outside durable prefix')
    return starts, ends, prior_by_attempt


def collect(args):
    import torch
    from transformers import AutoTokenizer
    from peft import PeftModel
    require(args.max_prompt_tokens == 2048 and args.max_new_tokens == 512 and args.seed == 20261024, 'Frozen decoding recipe changed')
    out = Path(args.output); out.mkdir(parents=True, exist_ok=True)
    with exclusive_collector(out / 'collector.process.lock'):
        lock = read(args.lock)
        for name, value in lock['files'].items():
            require(sha(value['path']) == value['sha256'], f'Frozen file changed: {name}')
        required = {'test_records': args.data, 'system_prompt': args.system_prompt, 'collector': __file__,
                    'model_loader_and_trainer': Path(__file__).with_name('train_tracker.py'), 'gate': Path(__file__).with_name('gates.py')}
        for name, path in required.items():
            require(lock['files'][name]['sha256'] == sha(path), f'Protocol binding mismatch: {name}')
        protocol = read(lock['files']['protocol']['path'])
        require(protocol['model']['id'] == MODEL_ID and protocol['model']['revision'] == REVISION, 'Protocol model differs')
        decoding = protocol['decoding']
        for name, value in {'max_prompt_tokens': 2048, 'max_new_tokens': 512, 'seed': 20261024,
                            'do_sample': False, 'num_beams': 1, 'repetition_penalty': 1.0,
                            'cache_implementation': args.cache_implementation}.items():
            require(decoding[name] == value, f'Protocol decoding differs: {name}')
        rows = jsonl(args.data)
        require(len(rows) == 200 and len({r['family_id'] for r in rows}) == 40 and all(r['split'] == 'test' for r in rows), 'Require 200 heldout decisions in 40 families')
        require(len({r['example_id'] for r in rows}) == 200, 'Repeated example')
        receipt = read(BASE_RECEIPT)
        require(receipt['status'] == 'downloaded_and_verified' and receipt['revision'] == REVISION and receipt['model_id'] == MODEL_ID, 'Base receipt mismatch')
        for item in receipt['files']:
            require((MODEL_PATH / item['rfilename']).stat().st_size == item['actual_bytes'], 'Base file size mismatch')
        config = {'base_id': MODEL_ID, 'base_revision': REVISION, 'data_sha256': sha(args.data), 'protocol_lock_sha256': sha(args.lock),
                  'collector_sha256': sha(__file__), 'base_loading_implementation_sha256': sha(Path(__file__).with_name('train_tracker.py')),
                  'gate_sha256': sha(Path(__file__).with_name('gates.py')), 'base_download_receipt_sha256': sha(BASE_RECEIPT),
                  'base_generation_config_sha256': sha(MODEL_PATH / 'generation_config.json'),
                  'adapters': {'tracker_lora_v1': adapter_artifacts(args.v1_run), 'tracker_lora_v2': adapter_artifacts(args.v2_run)},
                  'max_prompt_tokens': 2048, 'max_new_tokens': 512, 'seed': 20261024, 'do_sample': False, 'num_beams': 1,
                  'repetition_penalty': 1.0, 'system_prompt_sha256': sha(args.system_prompt), 'cache_implementation': args.cache_implementation,
                  'kind': 'one_step_three_arm_generation_collection_not_semantic_score', 'arms': list(ARMS),
                  'arm_order': [list(order) for order in ORDERS], 'order_assignment': 'row_index_modulo_6',
                  'base_representation': 'same_object_nf4_double_quant_bfloat16_compute_norms_fp32', 'assigned_calls': 600,
                  'versions': {x: importlib.metadata.version(x) for x in ('torch', 'transformers', 'peft', 'bitsandbytes', 'accelerate', 'safetensors')}}
        frozen = out / 'collection-config.json'
        if frozen.exists():
            require(read(frozen) == config, 'Resume configuration differs')
        else:
            require(not (out / 'outputs.jsonl').exists() and not (out / 'attempt-events.jsonl').exists(), 'Existing journals have no configuration')
            write(frozen, config)
        for source in ('collect_three_arm.py', 'train_tracker.py', 'gates.py'):
            target = out / ('source-' + source)
            if target.exists():
                require(sha(target) == sha(Path(__file__).with_name(source)), 'Recorded source changed')
            else:
                target.write_bytes(Path(__file__).with_name(source).read_bytes())
        tokenizer = AutoTokenizer.from_pretrained(str(MODEL_PATH), local_files_only=True, trust_remote_code=False)
        messages = [prompt_messages(row, Path(args.system_prompt).read_text(encoding='utf-8').strip()) for row in rows]
        prompts = [tokenizer.apply_chat_template(message, tokenize=True, return_dict=False, add_generation_prompt=True) for message in messages]
        require(all(len(ids) <= 2048 for ids in prompts), 'Prompt exceeds context bound; truncation prohibited')
        metadata = [{'example_id': row['example_id'], 'family_id': row['family_id'], 'input_tokens': len(ids),
                     'input_messages_sha256': digest(message), 'input_token_ids_sha256': digest(ids)} for row, ids, message in zip(rows, prompts, messages)]
        expected = assignments(len(rows)); output_file = out / 'outputs.jsonl'; event_file = out / 'attempt-events.jsonl'
        prior, events = strict_journal(output_file), strict_journal(event_file)
        starts, ends, prior_by_attempt = validate_prior(prior, events, expected, metadata, config)
        require(not any(r.get('fatal_adapter_invariant') for r in prior), 'A prior adapter identity/setup failure needs explicit review; do not silently resume a compromised comparison')
        session_id = str(uuid.uuid4())
        for ident, start in starts.items():
            if ident not in ends:
                record = prior_by_attempt.get(ident)
                durable_append(event_file, {'event': 'attempt_ended', 'attempt_id': ident, 'row_index': start['row_index'], 'arm': start['arm'],
                    'status': record['status'] if record else 'interrupted_no_durable_result',
                    'record_sha256': digest(record) if record else None, 'elapsed_seconds': record['elapsed_seconds'] if record else None,
                    'collection_config_sha256': digest(config), 'utc': datetime.now(timezone.utc).isoformat(),
                    'recovery': 'exclusive_os_lock_obtained_after_previous_process_release', 'recovered_by_session': session_id})
        if len(prior) == len(expected):
            write(out / 'collection-result.json', {'status': 'collection_completed', 'assigned_calls': 600, 'records': 600,
                'actual_attempts': len(starts), 'outputs_sha256': sha(output_file), 'attempt_events_sha256': sha(event_file), 'quality_scored': False})
            emit('already_completed', records=600, actual_attempts=len(starts)); return
        model = prepare_frozen_base(quantized_base())
        model = PeftModel.from_pretrained(model, str(Path(args.v1_run) / 'adapter'), adapter_name='tracker_lora_v1', is_trainable=False)
        model.load_adapter(str(Path(args.v2_run) / 'adapter'), adapter_name='tracker_lora_v2', is_trainable=False)
        model.requires_grad_(False); model.eval()
        if model.is_gradient_checkpointing:
            model.gradient_checkpointing_disable()
        require(not any(p.requires_grad for p in model.parameters()), 'Collection model has trainable parameters')
        emit('collection_started', assigned_calls=600, completed_prior=len(prior), prior_attempts=len(starts), session_id=session_id, pid=os.getpid())
        attempt_number = len(starts)
        for ordinal, (index, arm) in enumerate(expected[len(prior):], start=len(prior)):
            torch.manual_seed(args.seed); torch.cuda.manual_seed_all(args.seed)
            attempt_number += 1; attempt_id = str(uuid.uuid4())
            record = {'row_index': index, 'arm': arm, 'attempt_id': attempt_id, 'attempt_number': attempt_number,
                      'session_id': session_id, 'base_object_scope': 'same_in_memory_base_for_this_session',
                      'started_at_utc': datetime.now(timezone.utc).isoformat(), 'model': MODEL_ID, 'revision': REVISION,
                      **metadata[index], 'artifacts': config['adapters'], 'collection_config_sha256': digest(config), 'status': 'running'}
            durable_append(event_file, {'event': 'attempt_started', 'attempt_id': attempt_id, 'attempt_number': attempt_number,
                'row_index': index, 'arm': arm, 'session_id': session_id, 'pid': os.getpid(), 'utc': record['started_at_utc'],
                'collection_config_sha256': digest(config), **metadata[index]})
            write(out / 'current-call.json', record); started = time.perf_counter()
            phase = 'adapter_setup'
            try:
                model.set_adapter('tracker_lora_v1' if arm == 'adapter_disabled' else arm)
                model.requires_grad_(False); model.eval()
                phase = 'input_allocation'
                inputs = torch.tensor([prompts[index]], device='cuda', dtype=torch.long)
                manager = model.disable_adapter() if arm == 'adapter_disabled' else contextlib.nullcontext()
                with manager, torch.inference_mode(), torch.autocast('cuda', dtype=torch.bfloat16):
                    phase = 'adapter_identity'
                    record['actual_adapter_state'] = actual_adapter_state(model, arm)
                    phase = 'generation'
                    generated = model.generate(input_ids=inputs, attention_mask=torch.ones_like(inputs), do_sample=False,
                        repetition_penalty=1.0, num_beams=1, max_new_tokens=512, use_cache=True,
                        cache_implementation=args.cache_implementation, logits_to_keep=1, pad_token_id=tokenizer.eos_token_id)
                tokens = generated[0, len(prompts[index]):].tolist()
                record.update(status='completed', output_tokens=len(tokens), output_text=tokenizer.decode(tokens, skip_special_tokens=True), hit_token_cap=len(tokens) >= 512)
                del generated, inputs
            except Exception as exc:
                record.update(status='failed', failure_phase=phase, fatal_adapter_invariant=phase in {'adapter_setup', 'adapter_identity'},
                              error={'type': type(exc).__name__, 'message': str(exc), 'traceback': traceback.format_exc()})
                gc.collect(); torch.cuda.empty_cache()
            record['elapsed_seconds'] = time.perf_counter() - started
            record['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
            record['memory'] = measured_memory()
            durable_append(output_file, record)
            durable_append(event_file, {'event': 'attempt_ended', 'attempt_id': attempt_id, 'row_index': index, 'arm': arm,
                'status': record['status'], 'record_sha256': digest(record), 'elapsed_seconds': record['elapsed_seconds'],
                'collection_config_sha256': digest(config), 'utc': record['finished_at_utc'], 'session_id': session_id})
            emit('call_recorded', row_index=index, arm=arm, status=record['status'], elapsed_seconds=record['elapsed_seconds'], completed=ordinal+1, assigned=600)
            if record.get('fatal_adapter_invariant'):
                raise RuntimeError('Adapter identity/setup invariant failed; durable failed assignment preserved and collection stopped for review')
        write(out / 'collection-result.json', {'status': 'collection_completed', 'assigned_calls': 600, 'records': 600,
            'actual_attempts': attempt_number, 'outputs_sha256': sha(output_file), 'attempt_events_sha256': sha(event_file), 'quality_scored': False})


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    for name in ('data', 'system-prompt', 'v1-run', 'v2-run', 'lock', 'output'):
        parser.add_argument('--' + name, required=True)
    parser.add_argument('--max-prompt-tokens', type=int, default=2048)
    parser.add_argument('--max-new-tokens', type=int, default=512)
    parser.add_argument('--seed', type=int, default=20261024)
    parser.add_argument('--cache-implementation', choices=['dynamic', 'offloaded'], default='dynamic')
    collect(parser.parse_args())
