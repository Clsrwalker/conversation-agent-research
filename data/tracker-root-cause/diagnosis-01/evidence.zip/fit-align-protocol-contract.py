"""Record a pre-inference collector-contract amendment without changing inputs."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    path = HERE / 'protocol.json'
    initial = path.read_bytes()
    assert hashlib.sha256(initial).hexdigest() == 'ef6c1128039d25386e842b9be56ac297c5b4007429233f75683597512d74f2c1'
    history = HERE / 'preflight-history'
    history.mkdir(exist_ok=True)
    preserved = history / 'protocol-initial.json'
    assert not preserved.exists()
    preserved.write_bytes(initial)
    protocol = json.loads(initial)
    assert protocol['generation'].pop('truncation') is False
    protocol['prompt_truncation'] = False
    expected = {'seed': 20261024, 'do_sample': False, 'num_beams': 1,
                'repetition_penalty': 1.0, 'cache_implementation': 'dynamic',
                'max_prompt_tokens': 2048, 'max_new_tokens': 512}
    assert protocol['generation'] == expected
    protocol['source_hashes'][preserved.relative_to(ROOT).as_posix()] = sha(preserved)
    protocol['source_hashes'][Path(__file__).relative_to(ROOT).as_posix()] = sha(Path(__file__))
    protocol['preflight_amendment'] = {
        'reason': 'Match the collector generation dictionary exactly; retain the unchanged no-truncation constraint as a top-level protocol field.',
        'initial_protocol_sha256': sha(preserved),
        'changed_sample_selection': False,
        'changed_model_parameters': False,
        'new_model_calls_before_amendment': 0,
    }
    path.write_text(json.dumps(protocol, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    for relative, expected_sha in protocol['source_hashes'].items():
        assert sha(ROOT / relative) == expected_sha, relative
    assert sha(HERE / 'selection.json') == 'c8028be138e7dd3acdea2caf57380f29dc4b3b8a6c1e79dfa18242f53dd3801f'
    print(json.dumps({'status': 'frozen_before_fit_inference', 'protocol_sha256': sha(path),
                      'selection_sha256': sha(HERE / 'selection.json'), 'new_model_calls': 0}))

if __name__ == '__main__':
    main()
