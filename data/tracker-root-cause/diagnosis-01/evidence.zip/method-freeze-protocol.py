"""Freeze the single adapter-off diagnostic before its 12 generations."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[4]
AUDIT=ROOT/'output/research/2026-10-27/tracker-intent-audit'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def rows(p): return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]

def main():
    calls=rows(AUDIT/'collection-02/PRIVATE-calls.jsonl')
    audits=[x for x in calls if x['stage']=='audit']
    outcomes=rows(AUDIT/'collection-02/PRIVATE-outcomes.jsonl')
    config=read(AUDIT/'collection-02/config.json')
    assert len(audits)==len(outcomes)==12
    assert [x['case_id'] for x in audits]==[x['case_id'] for x in outcomes]
    sources=[AUDIT/'collection-02/PRIVATE-calls.jsonl',AUDIT/'collection-02/PRIVATE-outcomes.jsonl',
      AUDIT/'collection-02/config.json',AUDIT/'collection-02/result.json',AUDIT/'data/acceptance.records.jsonl',
      AUDIT/'review/post-run-review.json',ROOT/'experiments/deep_conversation/tracker_lora/intent_audit/audit.py',
      ROOT/'experiments/deep_conversation/tracker_lora/intent_audit/audit_prompt.txt',
      ROOT/'experiments/deep_conversation/tracker_lora/repair_v2/train_tracker.py',Path(__file__)]
    protocol={
      'id':'tracker-root-cause-adapter-only-audit-diagnostic','status':'frozen_before_new_inference',
      'date':'2026-10-27','timezone':'America/Halifax','frozen_at_utc':datetime.now(timezone.utc).isoformat(),
      'kind':'post_hoc_bounded_component_diagnostic_not_heldout_research',
      'question':'Does disabling the trained v2 adapter change syntax, contract validity and raw-evidence correctness for the exact audit requests that previously failed?',
      'scope':{'new_model_generations':12,'historical_enabled_generations_reused':12,'input_prefix_pairs':6,
        'scenario_families':5,'training_runs':0,'new_prompts':0,'new_cases':0,'new_model_choices':0},
      'historical_arm':{'name':'v2_enabled_captured','source':'tracker-intent-audit/collection-02',
        'status':'terminal_completed_immutable','audit_reports':12,'accepted':0,'rejected':12,
        'syntax_invalid':11,'verdict_value_conflict':1},
      'new_arm':{'name':'same_base_v2_disabled','base_model':config['base_id'],
        'base_revision':config['base_revision'],'adapter_loaded_but_disabled':'tracker_lora_v2',
        'loader':'unchanged frozen NF4 double-quant bfloat16 loader and prepare_frozen_base',
        'intervention':'Use the existing PEFT disable_adapter context; no weight changes or alternate adapter.'},
      'input_contract':[
        'Use all 12 exact captured audit messages, in their original order; do not rerun the ordinary tracker.',
        'Restore each captured normal-step post_state with its original arrived conversation and receipts. This same pre-audit state is the baseline for both arms.',
        'Rebuilding audit.messages(audit.build_request(store)) must exactly equal captured messages before generation. If it does not, fail setup rather than rewriting the captured request.',
        'Verify both canonical message SHA and actual token-ID SHA against the captured call. No focal IDs, condition labels, expected metadata, reference operations or review text may enter model messages.',
        'Use the unchanged strict audit.apply_report on the restored state; record rejected/held outputs without editing or automatic retry.'
      ],
      'generation':{key:config[key] for key in ('max_prompt_tokens','seed','do_sample','num_beams','repetition_penalty','cache_implementation')},
      'max_new_tokens':config['max_new_tokens']['audit'],
      'generation_contract':[
        'Keep the same tokenizer/chat template, pad token, logits_to_keep=1, attention mask, bfloat16 autocast and local base precision.',
        'No constrained decoder, schema repair, JSON extraction, forced output prefix, temperature search, prompt edits or token-limit changes.',
        'At every actual generation, verify all LoRA-containing layers have disable_adapters=True, every parameter is frozen and model.training=False. Record loaded adapter names and number of disabled layers.',
        'Validate source/base file hashes and adapter artifacts against captured receipts; retain exact installed package versions and hardware metadata.',
        'Preserve one durable started/ended journal and one raw result for each attempt. Provider/model errors, token-cap hits and invalid reports remain in the denominator.',
        'Run one generation per assigned request, no outcome-dependent retries. Zero-generation setup recovery may be recorded separately without replacing an output.'
      ],
      'case_order':[{'case_id':x['case_id'],'original_ordinal':x['ordinal'],
          'input_messages_sha256':x['input_messages_sha256'],
          'input_token_ids_sha256':x['input_token_ids_sha256'],'input_tokens':x['input_tokens']} for x in audits],
      'primary_diagnostics':[
        'Strict JSON parseability and complete contract-accepted reports, with paired case-by-case enabled/disabled disagreement.',
        'Focal owner/status correctness after the unchanged runtime, using stable IDs and raw dialogue; report false repairs, retained errors, correct-prior damage and other-record errors.',
        'Actual executed field changes and whether cited raw evidence is sufficient. Zero changes have a zero evidence-error denominator and do not establish correctness.',
        'Assess semantic mistakes in readable rejected proposals only as qualitative failure evidence; never repair and credit them as executed outcomes.'
      ],
      'interpretation':[
        'If disabled reports are valid while historical enabled reports fail on identical token sequences, the result supports an adapter-associated incompatibility with the new audit task under this pinned setup; it does not by itself identify which training examples or optimization choice caused it.',
        'If both arms fail, disabling the adapter did not remove the failure. This does not prove that the adapter is harmless or that every base model cannot audit.',
        'If syntax improves but raw-evidence correctness does not, output validity and intention understanding are separate bottlenecks.',
        'A well-formed report that is semantically wrong remains a failure. Passing schema is not reduced intention omission.',
        'This is a frozen historical comparison across processes. Same files/config/token IDs are verified, but identical in-memory model objects or bitwise deterministic GPU behavior are not assumed.'
      ],
      'limits':[
        'The diagnostic deliberately reuses exposed synthetic cases and a post-hoc chosen failure boundary; it cannot estimate held-out generalization or statistical superiority.',
        'All audit inputs use post-states produced by v2 normal tracking. The experiment measures conditional audit behavior, not an end-to-end base-only tracker rollout.',
        'Training data quality, learning rate, training duration and rank are unchanged and not independently manipulated; their causal contributions remain unidentified by this diagnostic.',
        'No second output-format arm or new prompting method is authorized by this protocol. Any later necessity must be justified separately from these results.'
      ],
      'stop_rule':'Stop after these 12 assigned new generations and independent scoring. Keep the failed historical acceptance intact; do not replace it or expand automatically.',
      'source_hashes':{p.relative_to(ROOT).as_posix():sha(p) for p in sources}
    }
    out=HERE/'adapter-off-protocol.json'
    assert not out.exists(),'Protocol already frozen; preserve it.'
    out.write_text(json.dumps(protocol,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'frozen','new_model_generations':12,'protocol_sha256':sha(out)}))
if __name__=='__main__': main()
