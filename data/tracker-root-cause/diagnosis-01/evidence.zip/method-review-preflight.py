"""Independent source/input/replay checks for the fixed adapter-off diagnostic."""
from pathlib import Path
from datetime import datetime,timezone
import sys,json,hashlib

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[4]
PRIOR=ROOT/'output/research/2026-10-27/tracker-intent-audit'
FEATURE=ROOT/'experiments/deep_conversation/tracker_lora/intent_audit'
sys.path.insert(0,str(FEATURE))
import audit
from pipeline import legacy
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text(encoding='utf-8'))

def main():
    protocol=read(HERE/'adapter-off-protocol.json')
    assert protocol['scope']['new_model_generations']==12
    oldconfig=read(PRIOR/'collection-02/config.json')
    calls=[r for r in legacy.jsonl(PRIOR/'collection-02/PRIVATE-calls.jsonl') if r['stage']=='audit']
    outcomes=legacy.jsonl(PRIOR/'collection-02/PRIVATE-outcomes.jsonl')
    assert len(calls)==len(outcomes)==12
    assert [x['case_id'] for x in calls]==[x['case_id'] for x in protocol['case_order']]==[x['case_id'] for x in outcomes]
    bindings={**oldconfig['source_hashes'],**protocol['source_hashes']}
    for rel,digest in bindings.items(): assert sha(ROOT/rel)==digest,rel
    replay=[]
    for call,outcome,planned in zip(calls,outcomes,protocol['case_order']):
        assert legacy.digest(call['messages'])==call['input_messages_sha256']==planned['input_messages_sha256']
        assert call['input_token_ids_sha256']==planned['input_token_ids_sha256']
        assert call['ordinal']==planned['original_ordinal']
        payload=json.loads(call['messages'][1]['content'])
        before=outcome['result']['baseline']['post_state']
        assert before['receipts']==[]
        packet={'conversation':payload['conversation'],'intention_state':before,'tool_receipts':[]}
        with legacy.restore_store(packet) as store:
            assert store.snapshot()==before
            request=audit.build_request(store)
            assert audit.messages(request)==call['messages']
            result=audit.apply_report(store,request,call['output_text'],call['case_id']+'-audit')
            assert result==outcome['result']['audit']
            replay.append({'case_id':call['case_id'],'baseline_restored_exactly':True,
              'captured_messages_rebuilt_exactly':True,'historical_complete_result_reproduced':True,
              'historical_status':result['status']})
    collector=ROOT/'experiments/deep_conversation/tracker_lora/diagnostics/collect_audit_adapter_off.py'
    for p in (collector,HERE/'adapter-off-protocol.json',Path(__file__)):
        bindings[p.relative_to(ROOT).as_posix()]=sha(p)
    receipt={'id':'tracker-root-cause-adapter-off-preflight','status':'passed',
      'date':'2026-10-27','timezone':'America/Halifax','reviewed_at_utc':datetime.now(timezone.utc).isoformat(),
      'reviewer':'Independent Codex method-design subagent; source review plus 12 CPU store replays, not model quality.',
      'scope':'One new adapter-disabled generation for each of the 12 already captured audit requests; historical enabled outputs remain immutable.',
      'checks':[
        'Protocol/source hashes verified; case order, original ordinals and captured message/token hashes match.',
        'Twelve captured normal post-states restored exactly; rebuilt messages exactly match; old audit.apply_report results replay exactly.',
        'Collector verifies pinned base receipt, every local base file size/hash, adapter artifacts and package versions before model loading.',
        'Collector independently retokenizes all 12 exact messages and checks captured token-ID hashes before any generation.',
        'Generation config equals protocol and captured config; same local loader, tokenizer, mask, pad, autocast and decoding parameters.',
        'Collector loads the same v2 adapter frozen, then uses disable_adapter and checks all 336 LoRA layers disabled at every generation.',
        'No normal tracker rerun, no reference-label input, no prompt change, no forced decoder, no syntax repair, no output retry.',
        'Same strict audit.apply_report applies the raw outputs to captured baseline states; all errors and token caps remain recorded.',
        'Hardware fields are recorded for the new run, with explicit lack of historical GPU identity evidence.'
      ],
      'corrected_before_generation':[
        'Initial draft used a nonexistent top-level protocol new_calls key; now reads scope.new_model_generations.',
        'Explicit protocol case/source/decoding bindings and new-run hardware metadata added before this gate.'
      ],
      'cpu_replays':replay,'new_model_calls':0,'new_training_runs':0,
      'tokenizer_execution_by_reviewer':False,
      'limits':['Runtime adapter state and retokenized IDs still require the collector live checks. No model was loaded by this reviewer.',
        'Historical enabled and new disabled results use different processes; same numerical objects or hardware conditions are not asserted.',
        'Passing this preflight does not predict syntax or semantic diagnostic outcomes.'],
      'source_hashes':bindings}
    out=HERE/'adapter-off-preflight-review.json'
    assert not out.exists()
    out.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'passed','cpu_replays':12,'source_bindings':len(bindings),'receipt_sha256':sha(out)}))
if __name__=='__main__': main()
