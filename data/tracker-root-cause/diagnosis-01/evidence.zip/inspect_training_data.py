"""Read-only census of frozen tracker supervision and its audit-task mismatch.

No inference, training, state mutation, labels, or causal quality estimates.
"""
from pathlib import Path
from collections import Counter, defaultdict
from statistics import mean, median
from datetime import datetime,timezone
import hashlib
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[4]
V2=ROOT/'output/research/2026-10-24/tracker-lora-repair-v2'
AUDIT=ROOT/'output/research/2026-10-27/tracker-intent-audit'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def rows(p):return [json.loads(x) for x in p.read_text(encoding='utf-8-sig').splitlines() if x.strip()]
def encode(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def digest(x):return hashlib.sha256(encode(x).encode()).hexdigest()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def describe(values):
    return {'n':len(values),'min':min(values),'max':max(values),'mean':mean(values),'median':median(values)} if values else {'n':0}
def strict(text):
    def pairs(items):
        d={}
        for k,v in items:
            assert k not in d,'Duplicate key'
            d[k]=v
        return d
    return json.loads(text,object_pairs_hook=pairs)
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def fault_kind(r):
    f=r.get('prior_fault_annotation')
    return f.get('fault_kind','legacy_text') if f else None
def main():
    source=[Path(__file__),V2/'annotation/system_prompt.txt',ROOT/'experiments/deep_conversation/tracker_lora/repair_v2/build_dataset.py',
       V2/'data/authoring/train_author.py',V2/'data/authoring/eval_author.py',V2/'data/authoring/replace_two_leakage_families.py',
       V2/'data/compiled/manifest.json',V2/'review/admission.json',V2/'training/formal-01/lengths.json',
       AUDIT/'data/acceptance.records.jsonl',AUDIT/'collection-02/PRIVATE-calls.jsonl']
    prompt=(V2/'annotation/system_prompt.txt').read_text(encoding='utf-8').strip()
    split_rows={}; sfts={}; summaries={}; all_inputs=defaultdict(list); all_dialogues=defaultdict(list)
    for split in ('train','dev','test'):
        rp=V2/f'data/compiled/{split}.records.jsonl'; sp=V2/f'data/compiled/{split}.sft.jsonl'
        source.extend([rp,sp]); data=rows(rp); sft=rows(sp); split_rows[split]=data;sfts[split]=sft
        assert len(data)==len(sft)
        operations=Counter(); fields=Counter(); roots=Counter(); input_keys=Counter(); state_types=Counter()
        bad_sources=[]; same_value_updates=[]; uncertain_targets=Counter(); faultgroups=defaultdict(list)
        for r,s in zip(data,sft):
            assert len(s['prompt'])==2 and s['prompt'][0]=={'role':'system','content':prompt}
            assert s['prompt'][1]['role']=='user' and strict(s['prompt'][1]['content'])==r['input']
            assert len(s['completion'])==1 and s['completion'][0]['role']=='assistant'
            target=strict(s['completion'][0]['content']);assert target==r['target']
            roots[','.join(sorted(target))]+=1;input_keys[','.join(sorted(r['input']))]+=1
            state_types[type(r['input']['intention_state']).__name__]+=1
            all_inputs[digest(r['input'])].append((split,r['example_id'],digest(target)))
            all_dialogues[digest(r['input']['conversation'])].append((split,r['example_id'],fault_kind(r)))
            events={e['seq']:e for e in r['input']['conversation']}; old={i['intent_id']:i for i in r['input']['intention_state']['intents']}
            for op in target['operations']:
                operations[op['op']]+=1
                for k in ('text','owner','status'):
                    if op['op']=='update' and k in op:fields[k]+=1
                if op.get('status')=='uncertain':uncertain_targets[op['op']]+=1
                seqs=op['source_seqs']
                if seqs!=sorted(set(seqs)) or not seqs or not all(type(x)is int and x in events for x in seqs):
                    bad_sources.append(r['example_id'])
                if op['op']=='update' and all(old[op['intent_id']][k]==v for k,v in op.items() if k in ('text','owner','status')):
                    same_value_updates.append(r['example_id'])
            k=fault_kind(r)
            if k:faultgroups[k].append(r)
        groups={}
        for k,group in faultgroups.items():
            detail={'inputs':len(group),'target_ids':dict(Counter(r['prior_fault_annotation']['intent_id'] for r in group)),
                'languages':dict(Counter(r['language'] for r in group)),
                'decision_ordinals':dict(Counter(str(r['decision_index']+1) for r in group)),
                'repair_source_sets':dict(Counter(encode(r['prior_fault_annotation'].get('repair_source_seqs',[])) for r in group))}
            if k in ('owner','status','wrong_withdrawn'):
                correct_owners=[];correct_statuses=[];before_statuses=[];source_available=0;old_evidence=0;wrong_owner_unmentioned=[]
                for r in group:
                    f=r['prior_fault_annotation'];key=f['intent_id'];b=next(i for i in r['input']['intention_state']['intents'] if i['intent_id']==key)
                    expected=next(i for i in r['expected_semantic_state'] if i['intent_id']==key)
                    correct_owners.append(expected['owner']==r['input']['conversation'][0]['speaker'])
                    correct_statuses.append(expected['status']);before_statuses.append(b['status'])
                    ev={e['seq'] for e in r['input']['conversation']}; seqs=f['repair_source_seqs']
                    source_available+=all(q in ev for q in seqs)
                    old_evidence+=max(seqs)<=r['input']['intention_state']['processed_event_seq']
                    if k=='owner' and f['wrong_value'] not in {e['speaker'] for e in r['input']['conversation']}:
                        wrong_owner_unmentioned.append(r['example_id'])
                detail.update(correct_owner_is_first_speaker=sum(correct_owners),expected_statuses=dict(Counter(correct_statuses)),
                    before_statuses=dict(Counter(before_statuses)),all_repair_evidence_available=source_available,
                    historical_evidence_only=old_evidence,wrong_owner_never_speaks_in_prefix=wrong_owner_unmentioned)
            groups[k]=detail
        summaries[split]={'rows':len(data),'families':len({r['family_id'] for r in data}),
          'language_rows':dict(Counter(r['language'] for r in data)),
          'target_root_keys':dict(roots),'input_keys':dict(input_keys),'intention_state_types':dict(state_types),
          'operations':dict(operations),'explicit_update_fields':dict(fields),
          'empty_target_rows':sum(not r['target']['operations'] for r in data),
          'uncertain_output_operations':dict(uncertain_targets),
          'prefix_events':describe([len(r['input']['conversation']) for r in data]),
          'prior_records':describe([len(r['input']['intention_state']['intents']) for r in data]),
          'nonempty_tool_receipts':sum(bool(r['input']['tool_receipts']) for r in data),
          'bad_source_structure':bad_sources,'semantically_unchanged_update_fields':same_value_updates,
          'fault_groups':groups}
    exact_duplicates=[v for v in all_inputs.values() if len(v)>1]
    contradictory=[v for v in exact_duplicates if len({x[2] for x in v})>1]
    cross_split=[v for v in exact_duplicates if len({x[0] for x in v})>1]
    train=split_rows['train']; fresh=[r for r in train if r['family_id'].startswith('fresh-train-')]
    matched=[]
    for r in train:
        if fault_kind(r):
            candidates=all_dialogues[digest(r['input']['conversation'])]
            if any(x[0]=='train' and x[1]!=r['example_id'] and x[2] is None for x in candidates):matched.append(r['example_id'])
    lengths=read(V2/'training/formal-01/lengths.json');assert len(lengths)==len(train) and [r['row'] for r in lengths]==list(range(500))
    token_groups=defaultdict(list)
    for r,l in zip(train,lengths):
        category=fault_kind(r) or ('ordinary_empty' if not r['target']['operations'] else 'ordinary_nonempty')
        token_groups[category].append(l['supervised_completion_tokens'])
    source_families=rows(V2/'data/source/fresh-train.jsonl');source.append(V2/'data/source/fresh-train.jsonl')
    template_counts={'fresh_families':len(source_families),'families_with_five_decisions':sum(len(f['decisions'])==5 for f in source_families),
      'first_step_three_adds_i1_i2_i3':sum([op['intent_id'] for op in f['decisions'][0]['operations']]==['i1','i2','i3'] and all(op['op']=='add' for op in f['decisions'][0]['operations']) for f in source_families),
      'second_step_single_add_i4':sum(len(f['decisions'][1]['operations'])==1 and f['decisions'][1]['operations'][0]['op']=='add' and f['decisions'][1]['operations'][0]['intent_id']=='i4' for f in source_families)}
    acceptance=rows(AUDIT/'data/acceptance.records.jsonl');calls=rows(AUDIT/'collection-02/PRIVATE-calls.jsonl')
    audit_calls=[c for c in calls if c['stage']=='audit'];audit_inputs=[json.loads(c['messages'][1]['content']) for c in audit_calls]
    audit_shift={'calls':12,'new_system_prompt_unique_hashes':sorted({digest(c['messages'][0]['content']) for c in audit_calls}),
      'training_same_system_prompt_calls':sum(c['messages'][0]['content']==prompt for c in audit_calls),
      'input_key_sets':dict(Counter(','.join(sorted(i)) for i in audit_inputs)),
      'intention_state_types':dict(Counter(type(i['intention_state']).__name__ for i in audit_inputs)),
      'required_intent_id_list_present':sum('required_intent_ids'in i for i in audit_inputs),
      'audit_prompt_contract':'checks list, per-ID owner/status verdict/value/source_seqs; full-record coverage required',
      'trained_checks_root_completions':sum('checks'in r['target'] for r in train),
      'trained_verdict_fields':sum('"verdict"' in s['completion'][0]['content'] for s in sfts['train']),
      'training_prompt_tokens':describe([l['prompt_tokens'] for l in lengths]),
      'audit_prompt_tokens':describe([c['input_tokens'] for c in audit_calls]),
      'training_completion_tokens':describe([l['supervised_completion_tokens'] for l in lengths]),
      'audit_generated_tokens':describe([c['output_tokens'] for c in audit_calls]),
      'focal_acceptance_faults':{k:dict(Counter(r['focal_intent_id'] for r in acceptance if r['condition']=='faulty' and r['focus']==k)) for k in ('owner','wrong_withdrawn','uncertain_status')}}
    manifest=read(V2/'data/compiled/manifest.json');admission=read(V2/'review/admission.json')
    assert admission['training_sft_sha256']==sha(V2/'data/compiled/train.sft.jsonl')
    result={'id':'tracker-root-cause-training-data-census','status':'completed','kind':'read_only_data_contract_diagnostic',
      'date':'2026-10-27','timezone':'America/Halifax','created_at_utc':datetime.now(timezone.utc).isoformat(),
      'source_hashes':{p.relative_to(ROOT).as_posix():sha(p) for p in source},
      'training_artifact_bound_to_admission':True,'splits':summaries,
      'exact_input_duplicates':exact_duplicates,'exact_input_conflicting_targets':contradictory,'exact_cross_split_input_duplicates':cross_split,
      'faulty_training_prefixes_with_clean_counterfactual_in_train':matched,
      'fresh_training_template':template_counts,
      'training_completion_tokens_by_row_kind':{k:describe(v) for k,v in token_groups.items()},
      'audit_task_shift':audit_shift,
      'no_new_model_calls':True,'new_training_runs':0,
      'limits':['Exact-input duplicate checks do not rule out semantic contradictions or broader template overlap.',
        'A data-contract shift and sparse repair supervision are observable; their causal contribution requires a controlled model comparison.',
        'Per-row completion lengths do not by themselves quantify useful learning or effective gradient contributions.',
        'Counts describe model-authored/model-reviewed synthetic supervision, not human-validated annotation quality.']}
    write(HERE/'census.json',result)
    print(json.dumps({'status':'completed','train_rows':len(train),'schema_checks_training_examples':0,'target_operation_counts':summaries['train']['operations'],
       'fresh_template':template_counts,'exact_input_conflicts':len(contradictory),'clean_counterfactual_pairs':len(matched)},ensure_ascii=True))
if __name__=='__main__':main()
