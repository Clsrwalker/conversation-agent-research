"""Six existing training examples, original operations task, frozen adapter.

This measures local free-generation fit, not held-out generalization. No training,
new prompt, adapter switching, repeated attempt or dataset expansion is performed.
"""
from pathlib import Path
from datetime import datetime,timezone
import argparse,sys,json,time,importlib.metadata,traceback
from collect_audit_adapter_off import (ROOT,STUDY,ADAPTER_RUN,MODEL_ID,REVISION,MODEL_PATH,BASE_RECEIPT,
    legacy,read,write,durable,emit,state,sha,quantized_base,prepare_frozen_base,adapter_artifacts,exclusive_collector)

SOURCE=ROOT/'output/research/2026-10-24/tracker-lora-repair-v2/data/compiled'
def main():
    if not __debug__: raise RuntimeError('Run without -O/-OO.')
    p=argparse.ArgumentParser(); p.add_argument('--output',type=Path,required=True); a=p.parse_args()
    assert not a.output.exists(); a.output.mkdir(parents=True)
    started=time.perf_counter(); result={'status':'setup','date':'2026-10-27','timezone':'America/Halifax','assigned_calls':6,
      'new_training_runs':0,'new_prompt_variants':0,'retries':0}
    write(a.output/'result.json',result)
    try:
        import torch
        from transformers import AutoTokenizer
        from peft import PeftModel
        with exclusive_collector(a.output/'collector.lock'):
            preflight=read(STUDY/'fit/preflight-review.json')
            assert preflight['status']=='passed'
            for rel,digest in preflight['source_hashes'].items(): assert sha(ROOT/rel)==digest,rel
            protocol=read(STUDY/'fit/protocol.json'); selection=read(STUDY/'fit/selection.json')
            assert protocol['new_model_generations']==6
            for rel,digest in protocol['source_hashes'].items(): assert sha(ROOT/rel)==digest,rel
            rows=legacy.jsonl(SOURCE/'train.records.jsonl'); sfts=legacy.jsonl(SOURCE/'train.sft.jsonl')
            assert len(rows)==len(sfts)==500 and len(selection['cases'])==6
            tokenizer=AutoTokenizer.from_pretrained(str(MODEL_PATH),local_files_only=True,trust_remote_code=False)
            prepared=[]
            for case in selection['cases']:
                index=case['source_row_index']; row=rows[index]; sft=sfts[index]
                assert legacy.digest(row)==case['record_sha256'] and legacy.digest(sft)==case['sft_sha256']
                assert sft['prompt'][0]['content']==(ROOT/'output/research/2026-10-24/tracker-lora-repair-v2/annotation/system_prompt.txt').read_text(encoding='utf-8').strip()
                assert json.loads(sft['prompt'][1]['content'])==row['input']
                assert json.loads(sft['completion'][0]['content'])==row['target']
                tokens=tokenizer.apply_chat_template(sft['prompt'],tokenize=True,add_generation_prompt=True,return_dict=False)
                assert len(tokens)<=2048
                with legacy.restore_store(row['input']) as st: assert st.snapshot()==row['input']['intention_state']
                prepared.append((case,row,sft['prompt'],tokens))
            artifacts=adapter_artifacts(ADAPTER_RUN)
            prior_config=read(ROOT/'output/research/2026-10-27/tracker-intent-audit/collection-02/config.json')
            assert artifacts==prior_config['adapter']
            versions={n:importlib.metadata.version(n) for n in prior_config['versions']}
            assert versions==prior_config['versions']
            base=read(BASE_RECEIPT)
            assert base['model_id']==MODEL_ID and base['revision']==REVISION
            assert sha(BASE_RECEIPT)==prior_config['base_receipt_sha256']
            for f in base['files']:
                path=MODEL_PATH/f['rfilename']
                assert path.stat().st_size==f['actual_bytes'] and sha(path)==f['actual_sha256']
            generation={'seed':20261024,'do_sample':False,'num_beams':1,'repetition_penalty':1.0,
                        'cache_implementation':'dynamic','max_prompt_tokens':2048,'max_new_tokens':512}
            assert protocol['generation']==generation
            assert prior_config['max_new_tokens']['normal']==512
            assert all(prior_config[k]==v for k,v in generation.items() if k!='max_new_tokens')
            source_paths=[Path(__file__),Path(__file__).with_name('collect_audit_adapter_off.py'),
              STUDY/'fit/selection.json',STUDY/'fit/protocol.json',STUDY/'fit/preflight-review.json',
              SOURCE/'train.records.jsonl',SOURCE/'train.sft.jsonl']
            config={'kind':'six_training_examples_free_generation_fit_not_generalization','date':'2026-10-27','timezone':'America/Halifax',
              'base_id':MODEL_ID,'base_revision':REVISION,'adapter':artifacts,'generation':generation,'versions':versions,
              'gpu':torch.cuda.get_device_name(0),'cuda':torch.version.cuda,
              'cases':[r['case_id'] for r in selection['cases']],
              'source_hashes':{str(f.relative_to(ROOT)):sha(f) for f in source_paths}}
            write(a.output/'config.json',config); cfg_hash=sha(a.output/'config.json')
            emit('loading_model',calls=6,training=False)
            model=prepare_frozen_base(quantized_base())
            model=PeftModel.from_pretrained(model,str(ADAPTER_RUN/'adapter'),adapter_name='tracker_lora_v2',is_trainable=False)
            model.requires_grad_(False); model.eval()
            if model.is_gradient_checkpointing: model.gradient_checkpointing_disable()
            state(model,False)
            for ordinal,(case,row,messages,tokens) in enumerate(prepared,1):
                event={'ordinal':ordinal,'case_id':case['case_id'],'config_sha256':cfg_hash,
                  'input_messages_sha256':legacy.digest(messages),'input_token_ids_sha256':legacy.digest(tokens),
                  'input_tokens':len(tokens),'started_at_utc':datetime.now(timezone.utc).isoformat()}
                durable(a.output/'attempts.jsonl',{'event':'started',**event})
                record={**event,'messages':messages,'status':'failed'}; call_start=time.perf_counter()
                try:
                    record['actual_adapter_state']=state(model,False)
                    torch.manual_seed(20261024); torch.cuda.manual_seed_all(20261024)
                    inputs=torch.tensor([tokens],device='cuda',dtype=torch.long)
                    with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
                        output=model.generate(input_ids=inputs,attention_mask=torch.ones_like(inputs),do_sample=False,
                          repetition_penalty=1.0,num_beams=1,max_new_tokens=512,use_cache=True,cache_implementation='dynamic',
                          logits_to_keep=1,pad_token_id=tokenizer.eos_token_id)
                    generated=output[0,len(tokens):].tolist()
                    record.update(status='completed',output_text=tokenizer.decode(generated,skip_special_tokens=True),
                      output_tokens=len(generated),hit_token_cap=len(generated)>=512,generated_token_ids=generated,
                      last_generated_token=generated[-1] if generated else None,configured_eos_token_ids=model.generation_config.eos_token_id)
                    del output,inputs
                except Exception as error:
                    record['error']={'type':type(error).__name__,'message':str(error)}
                finally:
                    record['elapsed_seconds']=time.perf_counter()-call_start
                    record['finished_at_utc']=datetime.now(timezone.utc).isoformat()
                    durable(a.output/'PRIVATE-calls.jsonl',record)
                    durable(a.output/'attempts.jsonl',{'event':'ended','ordinal':ordinal,'status':record['status'],'record_sha256':legacy.digest(record)})
                outcome=legacy.apply_candidate(row,record)
                durable(a.output/'PRIVATE-outcomes.jsonl',{'case_id':case['case_id'],'result':outcome})
                emit('call_completed',ordinal=ordinal,case=case['case_id'],generation=record['status'],validity=outcome['validity'])
            state(model,False)
            calls=legacy.jsonl(a.output/'PRIVATE-calls.jsonl'); outputs=legacy.jsonl(a.output/'PRIVATE-outcomes.jsonl')
            assert len(calls)==len(outputs)==6
            assert [r['ordinal'] for r in calls]==list(range(1,7))
            assert [r['case_id'] for r in calls]==config['cases']==[r['case_id'] for r in outputs]
            for rel,digest in config['source_hashes'].items(): assert sha(ROOT/rel)==digest,rel
            assert adapter_artifacts(ADAPTER_RUN)==artifacts
            result.update(status='completed',calls=6,completed_calls=sum(r['status']=='completed' for r in calls),
              config_sha256=cfg_hash,outputs_sha256=sha(a.output/'PRIVATE-calls.jsonl'),outcomes_sha256=sha(a.output/'PRIVATE-outcomes.jsonl'),
              adapter_weights_unchanged=True,quality_scored=False)
    except Exception as error:
        result.update(status='failed',error={'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()})
        raise
    finally:
        result['durable_calls']=len(legacy.jsonl(a.output/'PRIVATE-calls.jsonl')) if (a.output/'PRIVATE-calls.jsonl').exists() else 0
        result['elapsed_seconds']=time.perf_counter()-started; result['finished_at_utc']=datetime.now(timezone.utc).isoformat()
        write(a.output/'result.json',result); emit('finished',status=result['status'],durable_calls=result['durable_calls'])
if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8'); main()
