"""Read-only CPU evidence audit. No model load, generation, or training."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import ast
import hashlib
import json
import math
import random
import statistics
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[4]
FEATURE=ROOT/'experiments/deep_conversation/tracker_lora'
STUDY=ROOT/'output/research/2026-10-24/tracker-lora-repair-v2'
RUN=STUDY/'training/formal-01'
AUDIT=ROOT/'output/research/2026-10-27/tracker-intent-audit/collection-02'
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def rows(p): return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def func(path,name):
    tree=ast.parse(path.read_text(encoding='utf-8'))
    return next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
def main():
    import torch
    import torch.nn.functional as F
    from transformers import AutoTokenizer
    from safetensors import safe_open
    torch.set_num_threads(2)
    assert not torch.cuda.is_initialized()
    result=read(RUN/'result.json'); lengths=read(RUN/'lengths.json')
    data=rows(STUDY/'data/compiled/train.sft.jsonl')
    log=rows(STUDY/'training/formal-01.stdout.jsonl')
    config=read(RUN/'adapter/adapter_config.json')
    callconfig=read(AUDIT/'config.json')
    calls=rows(AUDIT/'PRIVATE-calls.jsonl')
    base=FEATURE/'model-cache/Qwen2.5-14B-Instruct'/result['base_revision']
    bindings=[RUN/'result.json',RUN/'run-config.json',RUN/'lengths.json',RUN/'runner_source.py',
       FEATURE/'repair_v2/train_tracker.py',FEATURE/'train_tracker.py',FEATURE/'repair_v2/collect_three_arm.py',
       FEATURE/'intent_audit/collect_acceptance.py',FEATURE/'intent_audit/pipeline.py',
       STUDY/'data/compiled/train.sft.jsonl',STUDY/'training/formal-01.stdout.jsonl',
       RUN/'adapter/adapter_config.json',RUN/'adapter/adapter_model.safetensors',
       base/'config.json',base/'generation_config.json',base/'tokenizer_config.json',base/'tokenizer.json',
       RUN/'adapter/tokenizer_config.json',RUN/'adapter/tokenizer.json',
       AUDIT/'config.json',AUDIT/'result.json',AUDIT/'PRIVATE-calls.jsonl',Path(__file__)]
    hashes={p.relative_to(ROOT).as_posix():sha(p) for p in bindings}
    assert hashes[(FEATURE/'repair_v2/train_tracker.py').relative_to(ROOT).as_posix()]==result['runner_sha256']==sha(RUN/'runner_source.py')
    assert sha(STUDY/'data/compiled/train.sft.jsonl')==result['data']['sha256']
    for name,value in result['save_reload']['adapter_files'].items(): assert sha(RUN/'adapter'/name)==value,name
    assert callconfig['adapter']['weights_sha256']==sha(RUN/'adapter/adapter_model.safetensors')
    ast_matches={name:ast.dump(func(FEATURE/'train_tracker.py',name))==ast.dump(func(FEATURE/'repair_v2/train_tracker.py',name))
                 for name in ('tokenize_row','completion_loss','prepare_frozen_base','quantized_base')}
    assert all(ast_matches.values())
    tokenizer=AutoTokenizer.from_pretrained(str(base),local_files_only=True,trust_remote_code=False)
    saved_tokenizer=AutoTokenizer.from_pretrained(str(RUN/'adapter'),local_files_only=True,trust_remote_code=False)
    suffixes=Counter(); observed_lengths=[]
    for index,row in enumerate(data):
        prefix=tokenizer.apply_chat_template(row['prompt'],tokenize=True,add_generation_prompt=True,return_dict=False)
        full=tokenizer.apply_chat_template(row['prompt']+row['completion'],tokenize=True,add_generation_prompt=False,return_dict=False)
        assert full[:len(prefix)]==prefix
        assert prefix==saved_tokenizer.apply_chat_template(row['prompt'],tokenize=True,add_generation_prompt=True,return_dict=False)
        assert full==saved_tokenizer.apply_chat_template(row['prompt']+row['completion'],tokenize=True,add_generation_prompt=False,return_dict=False)
        assert len(full)==lengths[index]['total_tokens'] and len(prefix)==lengths[index]['prompt_tokens']
        n=len(full)-len(prefix)
        assert n==lengths[index]['supervised_completion_tokens'] and n>0 and len(full)<=2048
        suffixes[tuple(full[-2:])]+=1; observed_lengths.append(n)
    order=list(range(500)); random.Random(result['configuration']['seed']).shuffle(order)
    forward=[r for r in log if r.get('event')=='microstep_phase' and r.get('phase')=='forward_and_finite_check' and r.get('boundary')=='begin']
    assert [r['row_index'] for r in forward]==order
    steps=[r for r in log if r.get('event')=='optimizer_step']
    assert [r['microsteps'] for r in steps]==list(range(16,497,16))+[500]
    assert [r['update'] for r in steps]==list(range(1,33))
    assert all(math.isfinite(r['grad_norm']) and r['grad_norm']>0 for r in steps)
    assert len(result['training']['losses'])==500 and all(math.isfinite(v) for v in result['training']['losses'])
    groups=[min(16,500-i) for i in range(0,500,16)]
    assert groups==[16]*31+[4]
    # CPU algebra control of the executed loss indexing; no model is loaded.
    math_checks=[]
    for prompt,completion in [(1,1),(5,3),(9,7),(20,11)]:
        torch.manual_seed(prompt*100+completion)
        total=prompt+completion; logits=torch.randn(1,total,37,dtype=torch.float64,requires_grad=True)
        ids=torch.randint(0,37,(1,total),device='cpu')
        labels=ids.clone(); labels[:,:prompt]=-100
        full_loss=F.cross_entropy(logits[:,:-1,:].reshape(-1,37),labels[:,1:].reshape(-1),ignore_index=-100)
        tail_loss=F.cross_entropy(logits[:,-(completion+1):-1,:].reshape(-1,37),ids[:,-completion:].reshape(-1))
        g1=torch.autograd.grad(full_loss,logits,retain_graph=True)[0]
        g2=torch.autograd.grad(tail_loss,logits)[0]
        assert torch.allclose(full_loss,tail_loss,atol=1e-12,rtol=1e-12) and torch.allclose(g1,g2,atol=1e-12,rtol=1e-12)
        math_checks.append({'prompt_tokens':prompt,'completion_tokens':completion,'loss_max_difference':float(abs(full_loss-tail_loss).detach()),'gradient_max_difference':float((g1-g2).abs().max())})
    tensors=[]
    with safe_open(str(RUN/'adapter/adapter_model.safetensors'),framework='pt',device='cpu') as weights:
        for name in weights.keys():
            tensor=weights.get_tensor(name)
            assert tensor.device.type=='cpu' and torch.isfinite(tensor).all()
            norm=float(torch.linalg.vector_norm(tensor.float()))
            tensors.append({'name':name,'shape':list(tensor.shape),'dtype':str(tensor.dtype),'elements':tensor.numel(),'l2_norm':norm,'nonzero':bool(torch.count_nonzero(tensor))})
    a=[t for t in tensors if '.lora_A.' in t['name']]; b=[t for t in tensors if '.lora_B.' in t['name']]
    assert len(a)==len(b)==336 and all(t['nonzero'] for t in b)
    assert sum(t['elements'] for t in tensors)==result['trainable_parameters']==68812800
    assert all(c['actual_adapter_state']=={'name':'tracker_lora_v2','layers':336,'enabled':True,'trainable_parameters':0} for c in calls)
    assert len(calls)==24 and all(c['status']=='completed' and not c['hit_token_cap'] for c in calls)
    assert not torch.cuda.is_initialized()
    summary={
       'id':'tracker-training-runtime-readonly-audit','status':'passed','status_meaning':'Integrity and arithmetic checks completed; model quality is not certified.',
       'date':'2026-10-27','timezone':'America/Halifax','checked_at_utc':datetime.now(timezone.utc).isoformat(),
       'new_model_calls':0,'new_training_runs':0,'loaded_model_weights':False,'loaded_adapter_tensors_on_cpu':True,'cuda_initialized':False,
       'source_hashes':hashes,'core_functions_AST_equal_to_previously_checked_runner':ast_matches,
       'tokenization':{'rows':len(data),'base_saved_tokenizer_ids_equal_rows':len(data),'exact_prompt_prefix_rows':len(data),'length_receipt_exact_rows':len(data),
          'completion_token_count':sum(observed_lengths),'completion_tokens_min':min(observed_lengths),'completion_tokens_max':max(observed_lengths),
          'completion_tokens_mean':statistics.mean(observed_lengths),'last_two_token_ids_and_counts':[{'ids':list(k),'tokens':tokenizer.convert_ids_to_tokens(list(k)),'count':v} for k,v in suffixes.items()],
          'eos_token':tokenizer.eos_token,'eos_token_id':tokenizer.eos_token_id,'generation_config':read(base/'generation_config.json')},
       'training_execution':{'observed_microsteps':len(forward),'unique_rows':len(set(r['row_index'] for r in forward)),'random_seed_order_exact':True,
          'optimizer_updates':len(steps),'group_sizes':groups,'gradient_norm_min':min(r['grad_norm'] for r in steps),'gradient_norm_max':max(r['grad_norm'] for r in steps),
          'updates_with_preclip_norm_over_1':sum(r['grad_norm']>1 for r in steps),'loss_first_50_mean':statistics.mean(result['training']['losses'][:50]),
          'loss_last_50_mean':statistics.mean(result['training']['losses'][-50:]),'loss_trend_limit':'Different shuffled rows/checkpoints; not a train-vs-validation convergence or overfitting test.'},
       'loss_algebra_controls':math_checks,
       'adapter':{'tensor_count':len(tensors),'A_tensors':len(a),'B_tensors':len(b),'all_finite':True,'all_B_nonzero':True,'parameter_elements':sum(t['elements'] for t in tensors),
          'B_l2_min':min(t['l2_norm'] for t in b),'B_l2_max':max(t['l2_norm'] for t in b),'configuration':config,'weight_sha256':sha(RUN/'adapter/adapter_model.safetensors'),
          'historical_save_reload_probe':result['save_reload'],'probe_limit':'One final-position logit comparison on one training-row probe; adapter activity is not quality or full reload-equivalence evidence.'},
       'audit_inference':{'calls':24,'correct_v2_active_layer_receipts':24,'completed':24,'token_caps_hit':0,
           'same_loader_source_sha256':result['runner_sha256'],'same_recorded_common_library_versions':all(callconfig['versions'][k]==result['versions'][k] for k in callconfig['versions']),
           'max_observed_input_tokens':max(c['input_tokens'] for c in calls),'max_observed_output_tokens':max(c['output_tokens'] for c in calls)},
       'limits':['CPU algebra controls do not replay CUDA kernels or repeat the original optimizer run.','No model-generation or quality evaluation is performed here.',
         'Nonzero finite LoRA tensors and finite training gradients rule out obvious inactive/all-zero corruption, not harmful specialization or inadequate training.',
         'No checkpoint-matched training/validation loss or train-example generation probe is available here to separate underfitting, overfitting, and format/domain shift.']}
    out=HERE/'runtime-integrity.json'
    assert not out.exists()
    out.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (HERE/'adapter-tensor-statistics.json').write_text(json.dumps(tensors,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'passed','tokenizer_rows':500,'adapter_tensors':len(tensors),'CPU_loss_controls':len(math_checks),'optimizer_updates':32,'cuda_initialized':False,'report_sha256':sha(out)}))
if __name__=='__main__': main()
