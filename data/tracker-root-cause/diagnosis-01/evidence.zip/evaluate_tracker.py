"""Offline runtime evaluation and blinded semantic review for tracker LoRA.

Never invokes a model. No string/ID equality is used to assign semantic quality.
The runtime judges patch legality; independent blinded annotations judge meaning.
"""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import random
import secrets
import statistics
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'experiments/deep_conversation'))
from intention_state import IntentStore, IntentValidationError

ARMS = ('adapter_disabled', 'tracker_lora_enabled')

# Assertions below are admission/review-contract checks, never optional hints.
if not __debug__:
    raise RuntimeError('Do not run this evaluator with Python optimization (-O/-OO).')


def encode(x):
    return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(x):
    return hashlib.sha256(encode(x).encode('utf-8')).hexdigest()


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def jsonl(path):
    return [json.loads(s) for s in Path(path).read_text(encoding='utf-8').splitlines() if s.strip()]


def project(state):
    return [{k: i[k] for k in ('intent_id', 'owner', 'text', 'status')} for i in state['intents']]


class StrictJSONError(ValueError):
    pass


def strict_proposal(raw):
    """No fence stripping, extraction, duplicate-key acceptance or NaN coercion."""
    if not isinstance(raw, str):
        raise StrictJSONError('Output must be text containing one JSON object.')
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise StrictJSONError('Duplicate JSON object key.')
            result[key] = value
        return result
    def constant(_):
        raise StrictJSONError('Nonfinite JSON number.')
    try:
        value = json.loads(raw, object_pairs_hook=pairs, parse_constant=constant)
    except (json.JSONDecodeError, TypeError, RecursionError) as error:
        raise StrictJSONError(str(error)) from error
    if not isinstance(value, dict) or set(value) != {'operations'} or not isinstance(value['operations'], list):
        raise StrictJSONError('Require exactly one operations-list object.')
    # This also rejects overflow such as 1e999, not caught by parse_constant.
    try:
        encode(value)
    except (ValueError, TypeError) as error:
        raise StrictJSONError('Output must contain finite JSON values.') from error
    return value


def restore_store(packet):
    """Reconstruct the supplied visible state through real public store methods.

Snapshot histories carry all committed semantic transitions, including version
numbers. Empty versions are replayed as empty patches. Original historical
through-cursors are not in snapshots, so replay uses the snapshot's processed
cursor for those setup commits, then observes remaining arrived events. The
visible snapshot must match byte-equivalent JSON data exactly; no state edits,
SQL writes or gold target operations are used to restore the input.
"""
    original = packet['intention_state']
    arrived = packet['conversation']
    st = IntentStore(':memory:')
    try:
        st.observe([e for e in arrived if e['seq'] <= original['processed_event_seq']])
        histories = defaultdict(list)
        for intent in original['intents']:
            for entry in intent['history']:
                histories[entry['version']].append((intent['intent_id'], entry))
        for version in range(1, original['version'] + 1):
            entries = histories[version]
            patch_ids = {entry['patch_id'] for _, entry in entries}
            if len(patch_ids) > 1:
                raise ValueError('Input history has conflicting patch IDs within a version.')
            patch_id = next(iter(patch_ids)) if patch_ids else f'replay-empty-{version}'
            previous = {i['intent_id']: i for i in st.snapshot()['intents']}
            operations = []
            for identifier, entry in sorted(entries):
                op = {'op': entry['op'], 'intent_id': identifier, 'source_seqs': entry['source_seqs']}
                state = entry['state']
                if op['op'] == 'add':
                    op.update(state)
                elif op['op'] == 'update':
                    changed = {k: v for k, v in state.items() if previous[identifier][k] != v}
                    # A legal redundant update still leaves a history entry.
                    op.update(changed or {'text': state['text']})
                elif op['op'] == 'reopen':
                    op['status'] = state['status']
                operations.append(op)
            st.commit_patch(patch_id, version - 1, original['processed_event_seq'], operations)
        st.observe(arrived)
        for receipt in original.get('receipts', []):
            st.report_result(receipt['receipt_id'], receipt['intent_version'], receipt['payload'])
        if st.snapshot() != original or st.events() != arrived:
            raise ValueError('Reconstructed input snapshot does not exactly match supplied input.')
        return st
    except BaseException:
        st.close()
        raise


def apply_candidate(row, output):
    """Invalid or failed output keeps original state and remains scoreable."""
    with restore_store(row['input']) as st:
        before = st.snapshot()
        result = {'committed': False, 'validity': 'generation_failure', 'proposal': None,
                  'post_state': before, 'error': None}
        if output.get('status') != 'completed':
            result['error'] = {'type': 'GenerationFailure', 'message': 'No completed model output.'}
            return result
        try:
            proposal = strict_proposal(output.get('output_text'))
            result['proposal'] = proposal
        except StrictJSONError as error:
            result.update(validity='invalid_json_or_envelope', error={'type': type(error).__name__, 'message': str(error)})
            return result
        try:
            post = st.commit_patch('evaluation-candidate', before['version'], before['observed_event_seq'], proposal['operations'])
            result.update(committed=True, validity='valid_patch', post_state=post)
        except IntentValidationError as error:
            if st.snapshot() != before:
                raise AssertionError('Rejected patch changed state.')
            result.update(validity='invalid_patch', error={'type': type(error).__name__, 'message': str(error)})
        return result


def lock_protocol(args):
    """Freeze exact artifacts after root review; never replace an earlier lock."""
    protocol = json.loads(Path(args.protocol).read_text(encoding='utf-8'))
    records = jsonl(args.records)
    manifest = json.loads(Path(args.manifest).read_text(encoding='utf-8'))
    if manifest['status'] != 'approved_for_pilot':
        raise ValueError('Dataset must pass the independent admission gate first.')
    assert manifest['update_counts'] == {'train': 500, 'dev': 50, 'test': 100}
    assert len(records) == 100 and len({r['family_id'] for r in records}) == 20
    assert Counter(bool(r.get('prior_fault_annotation')) for r in records) == {False: 90, True: 10}
    assert all(r['split'] == 'test' for r in records)
    assert sha(args.records) == manifest['files']['test.records.jsonl']['sha256']
    assert sha(args.system_prompt) == manifest['system_prompt_sha256']
    assert protocol['training']['epochs'] == 1 and protocol['training']['seed'] == 20261024
    paths = {'protocol': args.protocol, 'test_records': args.records, 'dataset_manifest': args.manifest,
             'system_prompt': args.system_prompt, 'evaluator': __file__,
             'runtime': ROOT / 'experiments/deep_conversation/intention_state.py',
             'model_loader_and_trainer': ROOT / 'experiments/deep_conversation/tracker_lora/train_tracker.py',
             'collector': ROOT / 'experiments/deep_conversation/tracker_lora/collect_ab.py'}
    locked = {'status': 'frozen_before_test_collection', 'created_at_utc': datetime.now(timezone.utc).isoformat(),
              'files': {k: {'path': str(Path(p).resolve()), 'sha256': sha(p)} for k, p in paths.items()},
              'test_rows': 100, 'families': 20, 'assigned_calls': 200,
              'normal_rows': 90, 'fault_rows': 10}
    target = Path(args.output)
    if target.exists():
        old = json.loads(target.read_text(encoding='utf-8'))
        if old['files'] != locked['files']:
            raise ValueError('Existing freeze differs; preserve it and create a new prospective protocol version.')
        return old
    write(target, locked)
    return locked


def check_lock(path):
    lock = json.loads(Path(path).read_text(encoding='utf-8'))
    assert lock['status'] == 'frozen_before_test_collection'
    for key, value in lock['files'].items():
        if sha(value['path']) != value['sha256']:
            raise ValueError(f'Frozen input changed: {key}')
    return lock


RUBRIC = {
    'unit': 'One independently reviewed intention record is one atomic requirement unit; coupled conditions stay one rule. Do not infer atomicity from word count.',
    'semantic_matching': 'Match requirements by meaning against raw evidence. IDs and exact strings are not semantic truth. Equivalent wording, including multilingual paraphrases, can fully match. Different new IDs can preserve meaning but violate identity separately.',
    'reference_checks': 'For every reference record supply reference_intent_id, matched_candidate_ids, meaning (equivalent/wrong_value/missing), owner_correct, status_correct, rationale. Wrong_value includes missing scope/conditions/units/strength; missing means the requirement concept is absent, not merely a wrong value. For missing use [] and null booleans. For matched use actual candidate IDs and boolean owner/status judgments.',
    'extra_records': 'List unsupported_candidate_ids (unsupported active or uncertain requirements) and duplicate_candidate_ids (semantic duplicates). Do not count an equivalent alternative ID as unsupported only because its name differs.',
    'identity': 'identity_errors is a list of prose explanations with affected IDs. Existing stable-ID replacement or duplicate semantic IDs are errors even when meaning is covered; new ID spelling alone is not a semantic failure.',
    'evidence': 'source_error_operation_indices lists zero-based operations of a valid patch whose cited arrived sources do not sufficiently support their meaning, owner, status, or scope. Referent-only citations without necessary antecedents are errors. Runtime validation only establishes that sources arrived. Explain every flagged operation in notes; an assistant proposal alone is not an accepted user wish.',
    'no_change': 'false_update_on_no_change is a boolean. On a true reference no-op, mark true only for a semantic change, not an equivalent rewording or runtime version increment. On other examples it must be false.',
    'invalid': 'An invalid output is not automatically zero across all quality dimensions. Score its actual retained pre-state against the reference after-state; every assigned item stays in all applicable denominators.',
    'owner_status': 'Uncertain candidates are not active needs. A correctly worded need with wrong owner or status fails complete coverage. A withdrawn record with matching text may still be matched and fail status.',
    'independence': 'Do not consult the private mapping, model names, latency, training loss or other arm outputs. Record uncertain judgments as needs_adjudication rather than guessing; final aggregation requires adjudication.'}


def prepare_blind(args):
    lock = check_lock(args.lock)
    rows = jsonl(lock['files']['test_records']['path'])
    outputs = jsonl(args.outputs)
    protocol = json.loads(Path(lock['files']['protocol']['path']).read_text(encoding='utf-8'))
    config = json.loads(Path(args.collection_config).read_text(encoding='utf-8'))
    assert config['data_sha256'] == lock['files']['test_records']['sha256']
    assert config['system_prompt_sha256'] == lock['files']['system_prompt']['sha256']
    assert config['collector_sha256'] == lock['files']['collector']['sha256']
    assert config['base_loading_implementation_sha256'] == lock['files']['model_loader_and_trainer']['sha256']
    assert config['base_id'] == protocol['model']['id'] and config['base_revision'] == protocol['model']['revision']
    assert config['seed'] == protocol['decoding']['seed'] and config['do_sample'] is False
    assert config['repetition_penalty'] == protocol['decoding']['repetition_penalty']
    assert config['num_beams'] == protocol['decoding']['num_beams']
    assert config['max_new_tokens'] == protocol['decoding']['max_new_tokens']
    assert config['max_prompt_tokens'] == protocol['decoding']['max_prompt_tokens']
    assert config['cache_implementation'] == protocol['decoding']['cache_implementation']
    assert config['limit'] == 0 and config['base_representation'] == protocol['model']['representation']
    keyed = {}
    for output in outputs:
        key = (output['row_index'], output['arm'])
        if key in keyed or output['arm'] not in ARMS or not 0 <= output['row_index'] < len(rows):
            raise ValueError('Duplicate or unassigned collection record.')
        keyed[key] = output
    assert len(keyed) == 200, 'All 200 assigned output records, including failures, are required.'
    directory = Path(args.output)
    if directory.exists() and any(directory.iterdir()):
        raise ValueError('Use a new directory; do not overwrite an earlier blind mapping.')
    directory.mkdir(parents=True, exist_ok=True)
    public, private, applied = [], {}, []
    system = Path(lock['files']['system_prompt']['path']).read_text(encoding='utf-8').strip()
    for index, row in enumerate(rows):
        pair = [keyed[(index, arm)] for arm in ARMS]
        expected_input_hash = digest([{'role': 'system', 'content': system}, {'role': 'user', 'content': encode(row['input'])}])
        for output in pair:
            assert output['example_id'] == row['example_id'] and output['family_id'] == row['family_id']
            assert output['input_messages_sha256'] == expected_input_hash
            assert output['model'] == config['base_id'] and output['revision'] == config['base_revision']
            assert output['adapter_weights_sha256'] == config['adapter_weights_sha256']
            if output['status'] == 'completed':
                actual = output['actual_adapter_state']
                assert actual['lora_layer_count'] > 0
                assert actual['disabled_lora_layers'] == (actual['lora_layer_count'] if output['arm'] == ARMS[0] else 0)
        assert pair[0]['input_token_ids_sha256'] == pair[1]['input_token_ids_sha256']
        for output in pair:
            result = apply_candidate(row, output)
            blind_id = secrets.token_hex(12)
            packet = {'blind_id': blind_id, 'conversation': row['input']['conversation'],
                      'before_state': project(row['input']['intention_state']),
                      'reference_state': row['expected_semantic_state'],
                      'unchanged_reference_ids': row['preserve_ids'],
                      'reference_no_change': not row['target']['operations'],
                      'candidate_output': output.get('output_text'),
                      'candidate_operations': result['proposal']['operations'] if result['proposal'] else None,
                      'candidate_state': project(result['post_state']),
                      'candidate_validity': result['validity']}
            public.append(packet)
            private[blind_id] = {'row_index': index, 'example_id': row['example_id'], 'family_id': row['family_id'],
                                 'arm': output['arm'], 'fault_case': bool(row.get('prior_fault_annotation')),
                                 'language': row['language'], 'output_sha256': digest(output),
                                 'validity': result['validity'], 'generation_status': output['status'], 'generation_seconds': output.get('elapsed_seconds'),
                                 'input_tokens': output.get('input_tokens'), 'output_tokens': output.get('output_tokens'),
                                 'hit_token_cap': output.get('hit_token_cap')}
            applied.append({'blind_id': blind_id, 'result': result})
    secrets.SystemRandom().shuffle(public)
    write(directory / 'review-packets.json', {'rubric': RUBRIC, 'packets': public})
    write(directory / 'PRIVATE-mapping.json', {'do_not_give_to_blind_reviewer': True, 'mapping': private})
    write(directory / 'PRIVATE-runtime-results.json', applied)
    write(directory / 'review-template.json', [{'blind_id': p['blind_id'], 'status': 'needs_review',
        'reference_checks': [{'reference_intent_id': r['intent_id'], 'matched_candidate_ids': [],
            'meaning': None, 'owner_correct': None, 'status_correct': None, 'rationale': ''} for r in p['reference_state']],
        'unsupported_candidate_ids': [], 'duplicate_candidate_ids': [], 'identity_errors': [],
        'source_error_operation_indices': [],
        'false_update_on_no_change': False, 'notes': ''} for p in public])
    manifest = {'kind': 'offline_runtime_replay_and_blind_review_preparation_not_quality_score',
                'packets': len(public), 'assigned_outputs': 200, 'runtime_validities': dict(Counter(x['validity'] for x in private.values())),
                'input_lock_sha256': sha(args.lock), 'outputs_sha256': sha(args.outputs),
                'collection_config_sha256': sha(args.collection_config),
                'files': {p.name: sha(p) for p in directory.iterdir() if p.is_file()}}
    write(directory / 'preparation.json', manifest)
    return manifest


def score_packet(packet, judgment):
    """Count reviewed semantic findings; never infer them from string matching."""
    if judgment['status'] != 'adjudicated':
        raise ValueError('Every item needs a completed/adjudicated semantic judgment.')
    refs = {x['intent_id']: x for x in packet['reference_state']}
    candidates = {x['intent_id']: x for x in packet['candidate_state']}
    checks = judgment['reference_checks']
    assert len(checks) == len(refs) and {c['reference_intent_id'] for c in checks} == set(refs)
    m = Counter(decisions=1, active_units=sum(r['status'] == 'active' for r in refs.values()),
                uncertain_units=sum(r['status'] == 'uncertain' for r in refs.values()),
                invalid_output=int(packet['candidate_validity'] != 'valid_patch'),
                true_no_change_decisions=int(packet['reference_no_change']))
    accounted = set()
    for c in checks:
        ref = refs[c['reference_intent_id']]
        ids = c['matched_candidate_ids']
        assert len(ids) == len(set(ids)) and set(ids) <= set(candidates)
        assert c['meaning'] in {'equivalent', 'wrong_value', 'missing'} and c['rationale'].strip()
        if c['meaning'] == 'missing':
            assert not ids and c['owner_correct'] is None and c['status_correct'] is None
        else:
            assert ids and type(c['owner_correct']) is bool and type(c['status_correct']) is bool
        accounted.update(ids)
        correct = c['meaning'] == 'equivalent' and c['owner_correct'] is True and c['status_correct'] is True
        if ref['status'] == 'active':
            m['omitted_active_units'] += c['meaning'] == 'missing'
            m['wrong_value_active_units'] += c['meaning'] == 'wrong_value'
            m['wrong_owner_active_units'] += c['owner_correct'] is False
            m['wrong_status_active_units'] += c['status_correct'] is False
            m['fully_correct_active_units'] += correct
            m['wrongly_withdrawn_active_units'] += bool(ids) and all(candidates[i]['status'] == 'withdrawn' for i in ids)
            if ref['intent_id'] in packet['unchanged_reference_ids']:
                m['unchanged_active_units'] += 1
                m['lost_or_corrupted_unchanged_units'] += not correct
        elif ref['status'] == 'uncertain':
            m['omitted_uncertain_units'] += c['meaning'] == 'missing'
            m['wrong_value_uncertain_units'] += c['meaning'] == 'wrong_value'
            m['wrong_owner_uncertain_units'] += c['owner_correct'] is False
            m['wrong_status_uncertain_units'] += c['status_correct'] is False
            m['fully_correct_uncertain_units'] += correct
            m['uncertain_promoted_to_active_units'] += any(candidates[i]['status'] == 'active' for i in ids)
        elif ref['status'] == 'withdrawn':
            m['withdrawn_reactivated_units'] += any(candidates[i]['status'] == 'active' for i in ids)
    unsupported = judgment['unsupported_candidate_ids']
    duplicates = judgment['duplicate_candidate_ids']
    assert len(set(unsupported)) == len(unsupported) and set(unsupported) <= set(candidates)
    assert len(set(duplicates)) == len(duplicates) and set(duplicates) <= set(candidates)
    assert not (set(unsupported) & accounted), 'A matched equivalent/wrong-value concept is not also an unsupported extra.'
    assert not (set(unsupported) & set(duplicates)), 'An unsupported extra and a duplicate of an existing concept are different categories.'
    assert set(candidates) <= accounted | set(unsupported) | set(duplicates), 'Every candidate record must be accounted for.'
    m['unsupported_active_additions'] = sum(candidates[i]['status'] == 'active' for i in unsupported)
    m['unsupported_uncertain_additions'] = sum(candidates[i]['status'] == 'uncertain' for i in unsupported)
    m['false_addition_decisions'] = int(bool(m['unsupported_active_additions'] or m['unsupported_uncertain_additions']))
    m['duplicate_candidate_units'] = len(duplicates)
    assert all(isinstance(s, str) and s.strip() for s in judgment['identity_errors'])
    m['identity_error_decisions'] = bool(judgment['identity_errors'])
    evidence_errors = judgment['source_error_operation_indices']
    assert len(set(evidence_errors)) == len(evidence_errors)
    assert all(type(i) is int and 0 <= i < len(packet['candidate_operations'] or []) for i in evidence_errors)
    assert not evidence_errors or (packet['candidate_validity'] == 'valid_patch' and judgment['notes'].strip())
    m['source_error_operations'] = len(evidence_errors)
    m['source_error_decisions'] = int(bool(evidence_errors))
    m['valid_patch_operations'] = len(packet['candidate_operations'] or []) if packet['candidate_validity'] == 'valid_patch' else 0
    assert type(judgment['false_update_on_no_change']) is bool
    if not packet['reference_no_change']:
        assert judgment['false_update_on_no_change'] is False
    m['no_change_false_update_decisions'] = judgment['false_update_on_no_change']
    return dict(m)


def count_rates(c):
    denominators = {
        'active_omission_rate': ('omitted_active_units', 'active_units'),
        'wrong_value_active_rate': ('wrong_value_active_units', 'active_units'),
        'wrong_owner_active_rate': ('wrong_owner_active_units', 'active_units'),
        'wrong_status_active_rate': ('wrong_status_active_units', 'active_units'),
        'wrong_withdrawal_rate': ('wrongly_withdrawn_active_units', 'active_units'),
        'fully_correct_active_fraction': ('fully_correct_active_units', 'active_units'),
        'lost_or_corrupted_unchanged_rate': ('lost_or_corrupted_unchanged_units', 'unchanged_active_units'),
        'uncertain_omission_rate': ('omitted_uncertain_units', 'uncertain_units'),
        'wrong_value_uncertain_rate': ('wrong_value_uncertain_units', 'uncertain_units'),
        'wrong_owner_uncertain_rate': ('wrong_owner_uncertain_units', 'uncertain_units'),
        'wrong_status_uncertain_rate': ('wrong_status_uncertain_units', 'uncertain_units'),
        'fully_correct_uncertain_fraction': ('fully_correct_uncertain_units', 'uncertain_units'),
        'uncertain_promotion_rate': ('uncertain_promoted_to_active_units', 'uncertain_units'),
        'false_addition_decision_rate': ('false_addition_decisions', 'decisions'),
        'invalid_output_rate': ('invalid_output', 'decisions'),
        'identity_error_decision_rate': ('identity_error_decisions', 'decisions'),
        'source_error_decision_rate': ('source_error_decisions', 'decisions'),
        'source_error_operation_rate': ('source_error_operations', 'valid_patch_operations'),
        'false_update_rate_on_true_no_change': ('no_change_false_update_decisions', 'true_no_change_decisions')}
    return {'counts': dict(c), **{name: c[n] / c[d] if c[d] else None for name, (n, d) in denominators.items()}}


def completed_costs(mapping, arm):
    assigned = [x for x in mapping.values() if x['arm'] == arm]
    completed = [x for x in assigned if x['generation_status'] == 'completed']
    values = [x['generation_seconds'] for x in completed]
    return {'assigned_calls': len(assigned), 'completed_calls': len(completed),
            'failed_calls_excluded_from_completed_cost_summary': len(assigned) - len(completed),
            'completed_elapsed_seconds_total': sum(values),
            'completed_elapsed_seconds_mean': statistics.mean(values) if values else None,
            'completed_elapsed_seconds_median': statistics.median(values) if values else None,
            'completed_input_tokens_total': sum(x['input_tokens'] for x in completed),
            'completed_output_tokens_total': sum(x['output_tokens'] for x in completed),
            'completed_token_cap_hits': sum(bool(x['hit_token_cap']) for x in completed),
            'completed_token_cap_rate': sum(bool(x['hit_token_cap']) for x in completed) / len(completed) if completed else None}


def aggregate(args):
    directory = Path(args.prepared)
    prep = json.loads((directory / 'preparation.json').read_text(encoding='utf-8'))
    for name, value in prep['files'].items():
        assert sha(directory / name) == value, 'Prepared blind artifacts changed.'
    packets = {p['blind_id']: p for p in json.loads((directory / 'review-packets.json').read_text(encoding='utf-8'))['packets']}
    mapping = json.loads((directory / 'PRIVATE-mapping.json').read_text(encoding='utf-8'))['mapping']
    judgments = json.loads(Path(args.judgments).read_text(encoding='utf-8'))
    assert len(judgments) == len(packets) == 200 and {j['blind_id'] for j in judgments} == set(packets)
    by_arm, by_family = {arm: Counter() for arm in ARMS}, defaultdict(Counter)
    by_stratum = defaultdict(Counter)
    detailed = []
    for j in judgments:
        ident = j['blind_id']; meta = mapping[ident]; metrics = score_packet(packets[ident], j)
        by_arm[meta['arm']].update(metrics); by_family[(meta['family_id'], meta['arm'])].update(metrics)
        by_stratum[(meta['arm'], 'prior_state', 'wrong_text' if meta['fault_case'] else 'ordinary')].update(metrics)
        by_stratum[(meta['arm'], 'language', meta['language'])].update(metrics)
        detailed.append({'blind_id': ident, **meta, 'counts': metrics})
    rates = {}
    for arm, c in by_arm.items():
        family_rates = [v['omitted_active_units']/v['active_units'] for (f,a),v in by_family.items() if a==arm and v['active_units']]
        rates[arm] = {**count_rates(c), 'family_macro_active_omission': statistics.mean(family_rates) if family_rates else None}
    families = sorted({f for f,a in by_family})
    diffs = []
    for f in families:
        a,b = by_family[(f,ARMS[0])],by_family[(f,ARMS[1])]
        assert a['active_units'] == b['active_units']
        if a['active_units']:
            diffs.append(a['omitted_active_units']/a['active_units'] - b['omitted_active_units']/b['active_units'])
    rng=random.Random(20261024)
    boot=sorted(statistics.mean(rng.choices(diffs,k=len(diffs))) for _ in range(10000)) if diffs else []
    result={'kind':'one_step_blind_semantic_pilot_results','review_kind':'independent model judgments unless separately documented human review exists',
            'arms':rates,'paired_family_macro_omission_reduction':statistics.mean(diffs) if diffs else None,
            'paired_family_bootstrap_95_interval':[boot[249],boot[9749]] if boot else None,'bootstrap_resamples':10000,
            'strata': [{'arm': a, 'dimension': d, 'value': v, **count_rates(c)} for (a,d,v),c in sorted(by_stratum.items())],
            'per_family_counts': [{'family_id': f, 'arm': a, 'counts': dict(c)} for (f,a),c in sorted(by_family.items())],
            'completed_generation_costs': {arm: completed_costs(mapping, arm) for arm in ARMS},
            'eligible_families':len(diffs),'zero_active_families_excluded_from_omission_mean':len(families)-len(diffs),
            'judgments_sha256':sha(args.judgments),'preparation_sha256':sha(directory/'preparation.json'),
            'limits':['100 decisions are 20 correlated scenario families, not 100 independent conversations.',
                      '90 normal and 10 designed wrong-text pre-states; no own-state rollout or final-answer benefit is established.',
                      'No automatic semantic verdict from exact string or ID match.',
                      'Wrong values, owners, status and false additions must accompany omission results; omission reduction alone is insufficient.'],
            'per_decision':detailed}
    write(args.output,result)
    return {k:v for k,v in result.items() if k!='per_decision'}


def fixtures(args):
    """Small acceptance probes for causal/atomic failures and paraphrase support."""
    events=[{'seq':0,'speaker':'Nia','role':'user','text':'Choose a free desktop app.'},
            {'seq':2,'speaker':'Nia','role':'user','text':'Switch to mobile; keep it free.'}]
    with IntentStore(':memory:') as st:
        st.observe(events[:1]);st.commit_patch('setup-0',0,0,[
            {'op':'add','intent_id':'i1','owner':'Nia','text':'Use a desktop app','source_seqs':[0]},
            {'op':'add','intent_id':'i2','owner':'Nia','text':'The app must be free','source_seqs':[0]}])
        # An empty historical decision must be reconstructed, too.
        st.commit_patch('setup-1',1,0,[]);st.observe(events);before=st.snapshot()
        gold=st.commit_patch('decision-2',2,2,[{'op':'update','intent_id':'i1','text':'Use a mobile app','source_seqs':[2]}])
    row={'input':{'conversation':events,'intention_state':before,'tool_receipts':[]},'expected_semantic_state':project(gold)}
    cases=[
      ('unknown_id',{'operations':[{'op':'update','intent_id':'missing','text':'Use a mobile app','source_seqs':[2]}]},'invalid_patch'),
      ('future_evidence',{'operations':[{'op':'update','intent_id':'i1','text':'Use a mobile app','source_seqs':[99]}]},'invalid_patch'),
      ('duplicate_id_atomic_rollback',{'operations':[{'op':'update','intent_id':'i1','text':'Use a mobile app','source_seqs':[2]},{'op':'withdraw','intent_id':'i1','source_seqs':[2]}]},'invalid_patch'),
      ('markdown_fence','```json\n{"operations":[]}\n```','invalid_json_or_envelope'),
      ('duplicate_json_key','{"operations":[],"operations":[]}','invalid_json_or_envelope'),
      ('nonfinite_json','{"operations":[{"x":NaN}]}','invalid_json_or_envelope'),
      ('trailing_text','{"operations":[]} done','invalid_json_or_envelope'),
      ('equivalent_paraphrase',{'operations':[{'op':'update','intent_id':'i1','text':'Choose an app for mobile devices','source_seqs':[2]}]},'valid_patch')]
    results=[]
    for name,candidate,expected in cases:
        result=apply_candidate(row,{'status':'completed','output_text':candidate if isinstance(candidate,str) else encode(candidate)})
        assert result['validity']==expected
        if expected!='valid_patch':assert result['post_state']==before
        else:
            assert result['post_state']!=gold
            packet={'reference_state':project(gold),'candidate_state':project(result['post_state']), 'candidate_operations': result['proposal']['operations'],
                    'candidate_validity':'valid_patch','unchanged_reference_ids':['i2'],'reference_no_change':False}
            judgment={'status':'adjudicated','reference_checks':[{'reference_intent_id':i,'matched_candidate_ids':[i],'meaning':'equivalent','owner_correct':True,'status_correct':True,'rationale':'Fixture author verifies mobile-device paraphrase or retained free condition.'} for i in ('i1','i2')],
                      'unsupported_candidate_ids':[],'duplicate_candidate_ids':[],'identity_errors':[], 'source_error_operation_indices': [], 'false_update_on_no_change':False}
            counts=score_packet(packet,judgment)
            assert counts['omitted_active_units']==0 and counts['fully_correct_active_units']==2
        results.append({'case':name,'expected':expected,'actual':result['validity'],'passed':True})
    # A valid no-op can still omit a new independent requirement. The explicit
    # fixture judgment, not the runtime or a string matcher, identifies that miss.
    later = events + [{'seq':3,'speaker':'Nia','role':'user','text':'It also needs to work offline.'}]
    with restore_store({'conversation':events,'intention_state':gold,'tool_receipts':[]}) as st:
        st.observe(later); later_before=st.snapshot()
        later_gold=st.commit_patch('setup-offline',later_before['version'],3,[
            {'op':'add','intent_id':'i3','owner':'Nia','text':'The app must work offline','source_seqs':[3]}])
    omission_row={'input':{'conversation':later,'intention_state':later_before,'tool_receipts':[]}}
    omitted=apply_candidate(omission_row,{'status':'completed','output_text':'{"operations":[]}'})
    assert omitted['validity']=='valid_patch'
    omission_packet={'reference_state':project(later_gold),'candidate_state':project(omitted['post_state']),
        'candidate_validity':'valid_patch','candidate_operations':[], 'unchanged_reference_ids':['i1','i2'],'reference_no_change':False}
    omission_judgment={'status':'adjudicated','reference_checks':[
        {'reference_intent_id':i,'matched_candidate_ids':[i],'meaning':'equivalent','owner_correct':True,'status_correct':True,'rationale':'Previously required mobile or free condition remains.'} for i in ('i1','i2')
        ]+[{'reference_intent_id':'i3','matched_candidate_ids':[],'meaning':'missing','owner_correct':None,'status_correct':None,'rationale':'Offline operation is an independent arrived requirement absent from both retained records.'}],
        'unsupported_candidate_ids':[],'duplicate_candidate_ids':[],'identity_errors':[],
        'source_error_operation_indices':[], 'false_update_on_no_change':False}
    counts=score_packet(omission_packet,omission_judgment)
    assert counts['active_units']==3 and counts['omitted_active_units']==1 and counts['fully_correct_active_units']==2
    results.append({'case':'valid_json_missing_new_requirement','expected':'valid_patch with 1 of 3 active units omitted',
        'actual':omitted['validity'], 'counts':counts,'passed':True})
    failed=apply_candidate(omission_row,{'status':'failed'})
    assert failed['validity']=='generation_failure' and failed['post_state']==later_before
    failed_packet={**omission_packet,'candidate_state':project(failed['post_state']),'candidate_validity':'generation_failure','candidate_operations':None}
    failed_counts=score_packet(failed_packet,omission_judgment)
    assert failed_counts['active_units']==3 and failed_counts['omitted_active_units']==1 and failed_counts['invalid_output']==1
    results.append({'case':'failed_generation_retained_in_denominator','expected':'pre-state retained and 3 active units scored',
        'actual':failed['validity'],'counts':failed_counts,'passed':True})
    result={'kind':'engineering_acceptance_fixtures_not_model_evaluation','status':'passed','cases':results,
            'runtime_sha256':sha(ROOT/'experiments/deep_conversation/intention_state.py'),'evaluator_sha256':sha(__file__),
            'real_model_calls':0,'semantic_paraphrase_fixture':'Manually authored fixture judgment exercises semantic review pathway; it is not an automatic semantic recognizer.'}
    write(args.output,result);return result


def check_inputs(args):
    """Offline admission check only: reconstruct actual supplied pre-states."""
    rows=jsonl(args.records); checks=[]
    for row in rows:
        with restore_store(row['input']) as st:
            checks.append({'example_id':row['example_id'],'input_sha256':digest(row['input']),
                'reconstructed_state_sha256':digest(st.snapshot()),'fault_case':bool(row.get('prior_fault_annotation')),'passed':True})
    result={'kind':'engineering_input_state_reconstruction_not_model_evaluation','status':'passed',
        'records_sha256':sha(args.records),'evaluator_sha256':sha(__file__),
        'runtime_sha256':sha(ROOT/'experiments/deep_conversation/intention_state.py'),
        'checked_updates':len(checks),'fault_updates':sum(c['fault_case'] for c in checks),
        'real_model_calls':0,'checks':checks}
    write(args.output,result)
    return {k:v for k,v in result.items() if k!='checks'}


def main():
    p=argparse.ArgumentParser();sub=p.add_subparsers(dest='mode',required=True)
    f=sub.add_parser('freeze');f.add_argument('--protocol',required=True);f.add_argument('--records',required=True);f.add_argument('--manifest',required=True);f.add_argument('--system-prompt',required=True);f.add_argument('--output',required=True)
    b=sub.add_parser('prepare');b.add_argument('--lock',required=True);b.add_argument('--outputs',required=True);b.add_argument('--collection-config',required=True);b.add_argument('--output',required=True)
    s=sub.add_parser('score');s.add_argument('--prepared',required=True);s.add_argument('--judgments',required=True);s.add_argument('--output',required=True)
    t=sub.add_parser('fixtures');t.add_argument('--output',required=True)
    c=sub.add_parser('check-inputs');c.add_argument('--records',required=True);c.add_argument('--output',required=True)
    a=p.parse_args();fn={'freeze':lock_protocol,'prepare':prepare_blind,'score':aggregate,'fixtures':fixtures,'check-inputs':check_inputs}[a.mode]
    print(json.dumps(fn(a),ensure_ascii=False,indent=2))

if __name__=='__main__':main()
