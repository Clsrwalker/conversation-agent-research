"""CPU PEFT lifecycle control and terminal-artifact audit; no Qwen load/calls."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import hashlib
import json
import sys
import os

# PEFT imports bitsandbytes, whose discovery initializes CUDA when visible.
# Isolate this tiny algebra/lifecycle control from GPU discovery entirely.
os.environ['CUDA_VISIBLE_DEVICES']=''

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[4]
STUDY=HERE.parent
RUN=STUDY/'ablation/adapter-off-01'
PRIOR=ROOT/'output/research/2026-10-27/tracker-intent-audit/collection-02'
ADAPTER=ROOT/'output/research/2026-10-24/tracker-lora-repair-v2/training/formal-01'
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def rows(p): return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(v): return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8')).hexdigest()
def main():
    import torch
    from torch import nn
    import peft
    from peft import LoraConfig,get_peft_model
    assert peft.__version__=='0.21.2' and not torch.cuda.is_initialized()
    torch.manual_seed(17)
    class Tiny(nn.Module):
        def __init__(self):
            super().__init__(); self.proj=nn.Linear(4,3,bias=False); self.config={'model_type':'custom'}
        def forward(self,x): return self.proj(x)
    model=get_peft_model(Tiny(),LoraConfig(r=2,lora_alpha=4,lora_dropout=0.05,
                           target_modules=['proj'],bias='none',inference_mode=True),adapter_name='tracker_lora_v2')
    model.requires_grad_(False); model.eval()
    def capture():
        layers=[m for m in model.modules() if hasattr(m,'lora_A')]
        return {'training':model.training,'any_nested_training':any(m.training for m in model.modules()),
          'adapter_config_inference_mode':model.peft_config['tracker_lora_v2'].inference_mode,
          'disabled_layers':sum(m.disable_adapters for m in layers),'lora_layers':len(layers),
          'requires_grad_names':[n for n,p in model.named_parameters() if p.requires_grad],
          'trainable_parameters':sum(p.numel() for p in model.parameters() if p.requires_grad)}
    tensors={n:p.detach().clone() for n,p in model.named_parameters()}
    before=capture()
    with model.disable_adapter(): inside=capture()
    after=capture()
    unchanged=all(torch.equal(tensors[n],p.detach()) for n,p in model.named_parameters())
    assert before['trainable_parameters']==inside['trainable_parameters']==0
    assert before['disabled_layers']==after['disabled_layers']==0 and inside['disabled_layers']==1
    assert after['trainable_parameters']==14 and not after['training'] and not after['any_nested_training']
    assert after['adapter_config_inference_mode'] and unchanged
    model.requires_grad_(False)
    refrozen=capture(); assert refrozen['trainable_parameters']==0
    assert not torch.cuda.is_initialized()

    terminal=read(RUN/'result.json'); config=read(RUN/'config.json')
    calls=rows(RUN/'PRIVATE-calls.jsonl'); outcomes=rows(RUN/'PRIVATE-outcomes.jsonl'); journal=rows(RUN/'attempts.jsonl')
    old_calls=[r for r in rows(PRIOR/'PRIVATE-calls.jsonl') if r['stage']=='audit']
    assert terminal['status']=='failed' and terminal['durable_calls']==12
    assert 'state(model,False)' in terminal['error']['traceback'] and terminal['error']['type']=='AssertionError'
    assert len(calls)==len(outcomes)==len(old_calls)==12
    assert [r['ordinal'] for r in calls]==list(range(1,13))
    assert [r['case_id'] for r in calls]==config['case_order']==[r['case_id'] for r in outcomes]
    assert len(journal)==24 and [r['event'] for r in journal]==['started','ended']*12
    expected_state={'adapter_name':'tracker_lora_v2','layers':336,'disabled_layers':336,'trainable_parameters':0}
    for index,(call,old) in enumerate(zip(calls,old_calls)):
        assert call['status']=='completed' and call['actual_adapter_state']==expected_state
        assert call['config_sha256']==sha(RUN/'config.json')
        assert call['messages']==old['messages'] and digest(call['messages'])==call['input_messages_sha256']==old['input_messages_sha256']
        assert call['input_token_ids_sha256']==old['input_token_ids_sha256'] and call['input_tokens']==old['input_tokens']
        assert call['output_tokens']==len(call['generated_token_ids']) and call['last_generated_token']==call['generated_token_ids'][-1]
        assert not call['hit_token_cap'] and call['last_generated_token'] in call['configured_eos_token_ids']
        start,end=journal[2*index:2*index+2]
        assert start['ordinal']==end['ordinal']==call['ordinal'] and start['case_id']==call['case_id']
        assert end['status']==call['status'] and end['record_sha256']==digest(call)
        for k in ('config_sha256','input_messages_sha256','input_token_ids_sha256','input_tokens','started_at_utc'):
            assert start[k]==call[k],k
    verified={}
    for name in ('source_hashes',):
        for rel,expected in config[name].items():
            assert sha(ROOT/rel)==expected,rel
            verified[rel.replace('\\','/')]=expected
    for binding_file in [STUDY/'method/adapter-off-protocol.json',STUDY/'method/adapter-off-preflight-review-v2.json',PRIOR/'config.json']:
        for rel,expected in read(binding_file)['source_hashes'].items():
            assert sha(ROOT/rel)==expected,rel
            verified[rel.replace('\\','/')]=expected
    trained=read(ADAPTER/'result.json')
    artifacts={'training_result_sha256':sha(ADAPTER/'result.json'),'weights_sha256':sha(ADAPTER/'adapter/adapter_model.safetensors'),
      'config_sha256':sha(ADAPTER/'adapter/adapter_config.json')}
    assert artifacts==config['adapter_artifacts']==read(PRIOR/'config.json')['adapter']
    for name,value in trained['save_reload']['adapter_files'].items(): assert sha(ADAPTER/'adapter'/name)==value,name
    # Reapply recorded reports through the unchanged real store, without generating.
    sys.path.insert(0,str(ROOT/'experiments/deep_conversation/tracker_lora/intent_audit'))
    from pipeline import legacy
    import audit
    historical_outcomes=rows(PRIOR/'PRIVATE-outcomes.jsonl')
    for call,old,outcome,old_outcome in zip(calls,old_calls,outcomes,historical_outcomes):
        payload=json.loads(call['messages'][1]['content'])
        packet={'conversation':payload['conversation'],'intention_state':old_outcome['result']['baseline']['post_state'],'tool_receipts':[]}
        with legacy.restore_store(packet) as store:
            request=audit.build_request(store)
            assert audit.messages(request)==old['messages']
            replay=audit.apply_report(store,request,call['output_text'],call['case_id']+'-adapter-off')
            assert replay==outcome['result']
    peft_root=Path(peft.__file__).parent
    report={'id':'adapter-disable-context-postcheck','status':'postchecks_passed_original_collection_failed',
      'date':'2026-10-27','timezone':'America/Halifax','checked_at_utc':datetime.now(timezone.utc).isoformat(),
      'original_collection_status':'failed','original_result_unchanged':True,'repeated_Qwen_generations':0,'new_training_runs':0,
      'scope':'One tiny CPU Linear+LoRA lifecycle reproduction with CUDA devices hidden, source inspection and saved artifact replay. No Qwen load, forward or generation. Final control does not initialize CUDA.',
      'CPU_reproduction_startup_deviation':'The first control attempt imported PEFT before hiding CUDA devices; PEFT import initialized the CUDA runtime, failing the no-CUDA-initialization gate before Tiny model creation. No Qwen model or generated output was involved. The failed script/log are retained; final control explicitly hides CUDA devices.',
      'cpu_reproduction':{'peft_version':peft.__version__,'base_linear_shape':[3,4],'rank':2,'lora_parameters':14,
         'before':before,'inside_disable_adapter':inside,'after_context':after,'after_explicit_refreeze':refrozen,
         'all_parameter_values_unchanged':unchanged,'model_forward_calls':0,'optimizer_steps':0,'cuda_initialized':False},
      'source_mechanism':[
         'PeftModel.disable_adapter finally calls base_model.enable_adapter_layers when entry state was enabled.',
         'BaseTuner._enable_adapter_layers calls each BaseTunerLayer.enable_adapters(True).',
         'BaseTunerLayer.enable_adapters(True) calls set_adapter(active_adapters) without inference_mode=True.',
         'BaseTunerLayer.set_adapter defaults inference_mode=False and enables active adapter requires_grad; it does not call model.train().'],
      'source_provenance':{'peft/peft_model.py':sha(peft_root/'peft_model.py'),'peft/tuners/tuners_utils.py':sha(peft_root/'tuners/tuners_utils.py'),
         'peft/tuners/lora/layer.py':sha(peft_root/'tuners/lora/layer.py')},
      'diagnosis':'The collector added a post-context all-parameters-frozen requirement that PEFT disable_adapter does not restore. The CPU control reproduces the exact sufficient condition for the observed assertion failure: eval remains false-training while LoRA requires_grad becomes true.',
      'chronology_evidence':'All 12 calls and all 12 applied/rejected audit outcomes were durably appended before leaving disable_adapter; only then did line149 state(model,False) fail.',
      'independent_postchecks':{'calls':12,'completed_generations':12,'outcomes':12,'started_journal_entries':12,'ended_journal_entries':12,
         'all_call_record_journal_digests_match':True,'all_exact_captured_inputs_match':True,'per_generation_disabled_layer_gate_matches':12,
         'all_actual_generation_gates_336_disabled_0_trainable':True,'generated_EOS_counts':dict(Counter(str(c['last_generated_token']) for c in calls)),
         'token_caps_hit':0,'source_bindings_verified':len(verified),'adapter_artifacts_unchanged':artifacts,
         'all_saved_adapter_files_match_training_receipt':True,'actual_audit_outcome_replays_equal':12,
         'outcome_status_counts':dict(Counter(o['result']['status'] for o in outcomes))},
      'data_use_assessment':'The post-context flag assertion does not invalidate previously captured outputs by itself. The pre-generation gates, chronology, exact-input journals, unchanged files and 12 exact runtime replays support retaining and scoring all12 with this disclosed terminal failure. Do not label the original run successful or rerun to replace outputs.',
      'limits':['The terminated Qwen process did not log its decomposed state after context exit. The specific flag transition is source-supported and reproduced on a tiny CPU model, not directly re-observed on the dead Qwen object.',
         'Frozen flags do not independently inspect hardware or every operation inside generation. The recorded source uses torch.inference_mode and contains no optimizer/training path.',
         'Unchanged on-disk adapter hashes do not alone prove in-memory weights unchanged; source and before-generation state records supply additional evidence.',
         'This verifies engineering integrity only. Semantic correctness and cross-process comparison limitations require separate review.'],
      'source_bindings':verified,
      'artifact_sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in [RUN/'result.json',RUN/'config.json',RUN/'PRIVATE-calls.jsonl',RUN/'PRIVATE-outcomes.jsonl',RUN/'attempts.jsonl',Path(__file__),HERE/'check_adapter_context_initial.py',HERE/'adapter-context-postcheck-initial.log']}}
    out=HERE/'adapter-context-postcheck.json'; assert not out.exists()
    out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    assert sha(RUN/'result.json')==report['artifact_sha256'][(RUN/'result.json').relative_to(ROOT).as_posix()]
    print(json.dumps({'status':report['status'],'completed_saved_calls':12,'replayed_outcomes':12,'post_exit_trainable_cpu_parameters':after['trainable_parameters'],
       'new_Qwen_generations':0,'report_sha256':sha(out)}))
if __name__=='__main__': main()
