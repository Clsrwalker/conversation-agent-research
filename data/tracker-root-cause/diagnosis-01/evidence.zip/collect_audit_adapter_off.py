"""Twelve exact captured audit requests, with the existing adapter disabled.

Historical enabled outputs stay immutable. This is a cross-process diagnostic,
not a new model, training run, repaired product or same-process paired trial.
"""
from pathlib import Path
from datetime import datetime,timezone
import sys,json,os,time,argparse,hashlib,traceback,importlib.metadata

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
sys.path.insert(0,str(HERE.parent/'intent_audit'))
import audit
from pipeline import legacy
sys.path.insert(0,str(HERE.parent/'repair_v2'))
from train_tracker import MODEL_ID,REVISION,MODEL_PATH,BASE_RECEIPT,quantized_base,prepare_frozen_base,sha
from collect_three_arm import adapter_artifacts,exclusive_collector

STUDY=ROOT/'output/research/2026-10-27/tracker-root-cause'
PRIOR=ROOT/'output/research/2026-10-27/tracker-intent-audit'
ADAPTER_RUN=ROOT/'output/research/2026-10-24/tracker-lora-repair-v2/training/formal-01'
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def write(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def durable(p,v):
    with p.open('a',encoding='utf-8',newline='\n') as f:
        f.write(legacy.encode(v)+'\n'); f.flush(); os.fsync(f.fileno())
def emit(name,**v): print(json.dumps({'event':name,**v},ensure_ascii=False),flush=True)
def state(model,disabled):
    layers=[m for m in model.modules() if hasattr(m,'lora_A')]
    assert len(layers)==336 and list(model.active_adapters)==['tracker_lora_v2']
    assert all(set(m.lora_A)=={'tracker_lora_v2'} and list(m.active_adapters)==['tracker_lora_v2'] and bool(m.disable_adapters)==disabled for m in layers)
    assert not model.training and not any(p.requires_grad for p in model.parameters())
    return {'adapter_name':'tracker_lora_v2','layers':len(layers),'disabled_layers':sum(bool(m.disable_adapters) for m in layers),'trainable_parameters':0}
def main():
    if not __debug__: raise RuntimeError('Run without -O/-OO.')
    p=argparse.ArgumentParser(); p.add_argument('--output',type=Path,required=True); a=p.parse_args()
    assert not a.output.exists(),'Preserve all attempts; never overwrite.'
    a.output.mkdir(parents=True)
    started=time.perf_counter(); result={'status':'setup','date':'2026-10-27','timezone':'America/Halifax',
      'pid':os.getpid(),'assigned_calls':12,'training_runs':0,'new_prompt_variants':0,'retries':0}
    write(a.output/'result.json',result)
    try:
        import torch
        from transformers import AutoTokenizer
        from peft import PeftModel
        with exclusive_collector(a.output/'collector.lock'):
            review=read(STUDY/'method/adapter-off-preflight-review-v2.json')
            assert review['status']=='passed'
            for rel,digest in review['source_hashes'].items(): assert sha(ROOT/rel)==digest,rel
            protocol=read(STUDY/'method/adapter-off-protocol.json')
            assert protocol['scope']['new_model_generations']==12
            for rel,digest in protocol['source_hashes'].items(): assert sha(ROOT/rel)==digest,rel
            old_result=read(PRIOR/'collection-02/result.json'); old_config=read(PRIOR/'collection-02/config.json')
            assert old_result['status']=='completed' and old_result['calls']==24
            assert sha(PRIOR/'collection-02/PRIVATE-calls.jsonl')==old_result['outputs_sha256']
            assert sha(PRIOR/'collection-02/PRIVATE-outcomes.jsonl')==old_result['outcomes_sha256']
            assert sha(PRIOR/'collection-02/config.json')==old_result['config_sha256']
            for rel,digest in old_config['source_hashes'].items(): assert sha(ROOT/rel)==digest,rel
            old_calls=[r for r in legacy.jsonl(PRIOR/'collection-02/PRIVATE-calls.jsonl') if r['stage']=='audit']
            old_outcomes=legacy.jsonl(PRIOR/'collection-02/PRIVATE-outcomes.jsonl')
            assert len(old_calls)==len(old_outcomes)==12
            assert [r['case_id'] for r in old_calls]==old_config['case_order']==[r['case_id'] for r in old_outcomes]
            assert len(protocol['case_order'])==12
            for frozen,call in zip(protocol['case_order'],old_calls):
                assert frozen['case_id']==call['case_id'] and frozen['original_ordinal']==call['ordinal']
                for key in ('input_messages_sha256','input_token_ids_sha256'):
                    assert frozen[key]==call[key],key
            expected_generation={'max_prompt_tokens':2048,'seed':20261024,'do_sample':False,'num_beams':1,
                                 'repetition_penalty':1.0,'cache_implementation':'dynamic'}
            assert protocol['generation']==expected_generation
            assert all(old_config[k]==v for k,v in expected_generation.items())
            assert protocol['max_new_tokens']==old_config['max_new_tokens']['audit']==1024
            artifacts=adapter_artifacts(ADAPTER_RUN); assert artifacts==old_config['adapter']
            versions={n:importlib.metadata.version(n) for n in old_config['versions']}
            assert versions==old_config['versions'],'Runtime package versions changed.'
            receipt=read(BASE_RECEIPT)
            assert receipt['model_id']==MODEL_ID and receipt['revision']==REVISION
            assert sha(BASE_RECEIPT)==old_config['base_receipt_sha256']
            for item in receipt['files']:
                f=MODEL_PATH/item['rfilename']
                assert f.stat().st_size==item['actual_bytes'] and sha(f)==item['actual_sha256'],item['rfilename']
            tokenizer=AutoTokenizer.from_pretrained(str(MODEL_PATH),local_files_only=True,trust_remote_code=False)
            prepared=[]
            for call,outcome in zip(old_calls,old_outcomes):
                tokens=tokenizer.apply_chat_template(call['messages'],tokenize=True,add_generation_prompt=True,return_dict=False)
                assert legacy.digest(call['messages'])==call['input_messages_sha256']
                assert legacy.digest(tokens)==call['input_token_ids_sha256'] and len(tokens)==call['input_tokens']<=2048
                payload=json.loads(call['messages'][1]['content'])
                packet={'conversation':payload['conversation'],'intention_state':outcome['result']['baseline']['post_state'],'tool_receipts':[]}
                with legacy.restore_store(packet) as st:
                    request=audit.build_request(st)
                    assert audit.messages(request)==call['messages']
                    replay=audit.apply_report(st,request,call['output_text'],call['case_id']+'-audit')
                    assert replay==outcome['result']['audit'],'Historical output replay differs.'
                prepared.append((call,packet,tokens))
            bindings={str(p.relative_to(ROOT)):sha(p) for p in [Path(__file__),STUDY/'method/adapter-off-protocol.json',STUDY/'method/adapter-off-preflight-review-v2.json',PRIOR/'collection-02/PRIVATE-calls.jsonl',PRIOR/'collection-02/PRIVATE-outcomes.jsonl',PRIOR/'collection-02/config.json',PRIOR/'collection-02/result.json']}
            config={'kind':'adapter_only_cross_process_diagnostic','date':'2026-10-27','timezone':'America/Halifax',
              'base_id':MODEL_ID,'base_revision':REVISION,'adapter_artifacts':artifacts,'adapter_disabled':True,
              'versions':versions,'source_hashes':bindings,'exact_captured_audit_inputs':12,'replayed_enabled_results':12,
              'gpu_name':torch.cuda.get_device_name(0),'cuda_version':torch.version.cuda,
              'hardware_limit':'Historical collection config has no GPU name; identical runtime packages and artifact hashes are checked, but exact historical hardware identity is not independently proved.',
              'case_order':old_config['case_order'],'max_prompt_tokens':2048,'max_new_tokens':1024,'seed':20261024,
              'do_sample':False,'num_beams':1,'repetition_penalty':1.0,'cache_implementation':'dynamic',
              'comparison_limit':'Enabled arm is the existing collection-02 in a different process, not simultaneous paired generation. No normal step is regenerated.'}
            write(a.output/'config.json',config); config_hash=sha(a.output/'config.json')
            emit('loading_fixed_base_with_adapter',exact_inputs=12)
            model=prepare_frozen_base(quantized_base())
            model=PeftModel.from_pretrained(model,str(ADAPTER_RUN/'adapter'),adapter_name='tracker_lora_v2',is_trainable=False)
            model.requires_grad_(False); model.eval()
            if model.is_gradient_checkpointing: model.gradient_checkpointing_disable()
            state(model,False)
            with model.disable_adapter():
                state(model,True)
                for index,(old,packet,tokens) in enumerate(prepared):
                    event={'ordinal':index+1,'case_id':old['case_id'],'config_sha256':config_hash,
                      'input_messages_sha256':old['input_messages_sha256'],'input_token_ids_sha256':old['input_token_ids_sha256'],
                      'input_tokens':len(tokens),'started_at_utc':datetime.now(timezone.utc).isoformat()}
                    durable(a.output/'attempts.jsonl',{'event':'started',**event})
                    call_start=time.perf_counter(); record={**event,'status':'failed','messages':old['messages']}
                    try:
                        record['actual_adapter_state']=state(model,True)
                        torch.manual_seed(20261024); torch.cuda.manual_seed_all(20261024)
                        inputs=torch.tensor([tokens],device='cuda',dtype=torch.long)
                        with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
                            output=model.generate(input_ids=inputs,attention_mask=torch.ones_like(inputs),do_sample=False,
                               repetition_penalty=1.0,num_beams=1,max_new_tokens=1024,use_cache=True,cache_implementation='dynamic',
                               logits_to_keep=1,pad_token_id=tokenizer.eos_token_id)
                        generated=output[0,len(tokens):].tolist()
                        record.update(status='completed',output_text=tokenizer.decode(generated,skip_special_tokens=True),
                          generated_token_ids=generated,last_generated_token=generated[-1] if generated else None,
                          configured_eos_token_ids=model.generation_config.eos_token_id,
                          output_tokens=len(generated),hit_token_cap=len(generated)>=1024)
                        del output,inputs
                    except Exception as error:
                        record['error']={'type':type(error).__name__,'message':str(error)}
                    finally:
                        record['elapsed_seconds']=time.perf_counter()-call_start
                        record['finished_at_utc']=datetime.now(timezone.utc).isoformat()
                        durable(a.output/'PRIVATE-calls.jsonl',record)
                        durable(a.output/'attempts.jsonl',{'event':'ended','ordinal':index+1,'status':record['status'],'record_sha256':legacy.digest(record)})
                    with legacy.restore_store(packet) as st:
                        if record['status']=='completed':
                            answer=audit.apply_report(st,audit.build_request(st),record['output_text'],old['case_id']+'-adapter-off')
                        else:
                            answer={'status':'generation_failed','committed':False,'coverage_complete':False,'operations':[],
                              'unresolved':[],'post_state':st.snapshot(),'error':record['error']}
                    durable(a.output/'PRIVATE-outcomes.jsonl',{'case_id':old['case_id'],'result':answer})
                    emit('call_completed',ordinal=index+1,case=old['case_id'],status=record['status'],audit_status=answer['status'],seconds=round(record['elapsed_seconds'],2))
            state(model,False)
            calls=legacy.jsonl(a.output/'PRIVATE-calls.jsonl'); outcomes=legacy.jsonl(a.output/'PRIVATE-outcomes.jsonl')
            assert len(calls)==len(outcomes)==12 and [r['ordinal'] for r in calls]==list(range(1,13))
            for rel,digest in config['source_hashes'].items(): assert sha(ROOT/rel)==digest,rel
            assert adapter_artifacts(ADAPTER_RUN)==artifacts
            result.update(status='completed',calls=12,completed_calls=sum(r['status']=='completed' for r in calls),
              config_sha256=config_hash,outputs_sha256=sha(a.output/'PRIVATE-calls.jsonl'),outcomes_sha256=sha(a.output/'PRIVATE-outcomes.jsonl'),
              adapter_weights_unchanged=True,quality_scored=False)
    except Exception as error:
        result.update(status='failed',error={'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()})
        raise
    finally:
        result['durable_calls']=len(legacy.jsonl(a.output/'PRIVATE-calls.jsonl')) if (a.output/'PRIVATE-calls.jsonl').exists() else 0
        result['elapsed_seconds']=time.perf_counter()-started; result['finished_at_utc']=datetime.now(timezone.utc).isoformat()
        write(a.output/'result.json',result); emit('finished',status=result['status'],durable_calls=result['durable_calls'])
if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8'); main()
