"""Exercise the two stale HTTP services and current question service once each."""
import json
from pathlib import Path
import time
from urllib.request import Request, urlopen
import uuid

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / 'output/research/records/question-diagnostics/worker-ingress-check.json'
PLAN = {'date': '2026-10-10', 'timezone': 'America/Halifax',
        'type': 'engineering_integration_check',
        'question': 'what is concept of agent harness',
        'harness': 'agent-led', 'documents': [],
        'conditions': 'One submission to each already-running service; unchanged local model and question adapter. Old services must be rejected before model loading; the current service must retain direct-response delivery. This does not test an answer-quality improvement.',
        'ports': [8767, 8768, 8769]}

def request(base, path, payload=None, token=None):
    headers = {} if payload is None else {'Content-Type': 'application/json', 'Origin': base, 'X-Lab-Token': token}
    data = None if payload is None else json.dumps(payload).encode()
    with urlopen(Request(base + path, data=data, headers=headers), timeout=20) as response:
        return json.load(response)

result = {'plan': PLAN, 'runs': []}
OUT.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
for port in PLAN['ports']:
    base = f'http://127.0.0.1:{port}'
    config = request(base, '/api/lab/config')
    payload = {key: PLAN[key] for key in ('question', 'documents', 'harness')}
    payload['request_id'] = 'ingress-check-' + uuid.uuid4().hex
    job = request(base, '/api/lab/runs', payload, config['csrf_token'])
    deadline = time.monotonic() + 600
    while True:
        detail = request(base, '/api/lab/runs/' + job['id'])
        if detail['job']['status'] not in {'starting', 'running'}:
            break
        if time.monotonic() > deadline:
            raise TimeoutError(job['id'])
        time.sleep(1)
    folder = ROOT / 'experiments/deep_conversation/runs' / ('lab-' + job['id'])
    log = (ROOT / 'experiments/deep_conversation/lab_jobs' / job['id'] / 'worker.log').read_text(encoding='utf-8')
    entry = {'port': port, 'job_id': job['id'], 'protocol_version': config.get('task_contract_version'),
             'status': detail['job']['status'], 'output_directory_created': folder.exists(),
             'outdated_service_rejection': 'This job came from an outdated Lab service.' in log,
             'direct_response': detail.get('direct_response')}
    if port != 8769:
        assert entry['status'] == 'error' and not folder.exists() and entry['outdated_service_rejection'], entry
        entry['model_calls'] = 0
    else:
        summary = json.loads((folder / 'summary.json').read_text())
        entry['model_calls'] = summary['model_calls']
        entry['total_tokens'] = summary['token_usage']['total_tokens']
        entry['model_wall_ms'] = summary['api_wall_ms']
        assert detail['job']['input_mode'] == 'direct_request'
        assert entry['status'] == 'completed' and entry['direct_response']['status'] == 'response'
    result['runs'].append(entry)
    OUT.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(entry), flush=True)
