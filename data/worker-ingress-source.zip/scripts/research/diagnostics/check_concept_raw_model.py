"""One raw-model diagnostic to distinguish an entry bug from concept familiarity."""
import json
from pathlib import Path
import sys
import time
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'experiments/deep_conversation'))
from config import Settings
from lab import PROFILE
from local_runtime import local_model_metadata

path = ROOT / 'output/research/records/question-diagnostics/concept-raw-model-check.json'
settings = Settings(**{k: v for k, v in PROFILE.items() if k != 'temperature'})
identity = local_model_metadata(settings)
payload = {'model': PROFILE['model'], 'stream': False,
           'messages': [{'role': 'system', 'content': "You are a helpful assistant. Answer the user's question."},
                        {'role': 'user', 'content': 'what is concept of agent harness'}],
           'options': {'temperature': 0, 'num_ctx': 16384, 'num_predict': 1200}}
record = {'date': '2026-10-10', 'timezone': 'America/Halifax', 'type': 'diagnostic',
          'plan': 'One raw call, same user question and local model/options, minimal general system message and no tools. This tests whether the failure also occurs outside the harness. Changed prompt context prevents an orchestration-only or speed claim.',
          'request': payload, 'model_identity': identity, 'response': None}
path.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
start = time.monotonic()
with urlopen(Request(PROFILE['local_base_url'] + '/api/chat',
                     data=json.dumps(payload).encode(), headers={'Content-Type': 'application/json'}), timeout=180) as response:
    result = json.load(response)
record.update(response=result, measured_wall_ms=(time.monotonic() - start) * 1000,
              same_model_after=local_model_metadata(settings) == identity)
path.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'text': result['message']['content'], 'prompt_eval_count': result.get('prompt_eval_count'),
                  'eval_count': result.get('eval_count'), 'same_model_after': record['same_model_after']}))
