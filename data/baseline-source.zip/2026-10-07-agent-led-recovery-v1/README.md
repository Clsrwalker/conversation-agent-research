# Frozen research baseline — 2026-10-07

This snapshot fixes the current **agent-led-recovery** implementation as the
starting point for future research improvements. It does not claim that this
configuration is already better than other harnesses.

The live application has not been changed. Its CLI default remains `native`.
`native` remains a separate Deep Agents reference adapted to this conversation
environment; it is not a pristine, unmodified upstream application. Future
studies should compare an explicitly named modification against this frozen
baseline, and retain the native reference when it answers a useful question.

## What is frozen

- A Deep Agents / LangGraph single-investigator loop, event-boundary input,
  optional tools and bounded recovery feedback; no mandatory answer schema or
  semantic approval gate.
- The 21 files fingerprinted by the latest 18-run batch, plus its batch runner,
  dependency declaration and evaluation utilities. All 21 current files matched
  the batch fingerprints and every run's stored source snapshot when frozen.
- Local Qwen2.5 14B Instruct, GGUF Q4_K_M, via Ollama 0.35.1; temperature 0 and
  16,384-token context. The full model digest is in `manifest.json`.
- Six synthetic development scenarios, documents and evaluator-only annotations.
  The directory's historical `holdout` name does **not** mean these are unseen
  test data. They have been inspected and reused during development.

`source/` preserves workspace-relative layout so the imports and runner paths
remain valid. The runtime dependency lock is included. Model weights, `.venv`,
credentials, raw model logs and SQLite run databases are not bundled. Public
metadata uses relative paths and does not include the user's local paths.

## Observed performance

These numbers describe the existing local development batch, not a new run.

| Configuration | Required help | Appropriate silence | Material-error cases | Model calls | Tokens | Recovery hints |
| --- | --- | --- | --- | --- | --- | --- |
| native | 2/5 | 1/1 | 0 | 73 | 337,744 | 0 |
| agent-led | 3/5 | 1/1 | 1 | 63 | 338,848 | 0 |
| **agent-led-recovery (this baseline)** | **3/5** | **1/1** | **1** | **59** | **307,804** | **0** |

Each configuration ran once on each of six scenarios. The route case produced a
materially wrong answer in both agent-led configurations; the browser-recording
case exhausted the token budget without delivering help in all three groups.
Recovery hints never fired in these 18 model runs. Their execution behavior was
tested separately with scripted models, but this batch does not establish their
benefit. Differences in cost cannot be attributed to a branch that did not run.

Scores came from blinded AI review, not an independent human study. Repeated
development use, six scenarios and one run per configuration do not support a
generalization or statistical-significance claim. Keep help and silence scores
separate; a pooled 4/6 would obscure the different requirements.

The machine-readable evidence summary and references are in
`observed_results.json`. Original records remain at
`../../benchmarks/results/local14-tool-recovery-paired-v1/` in the working
project. This snapshot deliberately does not relabel old runs as a new study.

## Budgets: defaults versus observed experiment

| Setting | `run.py` CLI default | Observed 18-run experiment |
| --- | --- | --- |
| Preset | native | native / agent-led / agent-led-recovery |
| Maximum calls | 24 | 24 |
| Token soft limit | 100,000 | 120,000 |
| Output tokens per call | 1,000 | 1,200 |
| Context | 16,384 | 16,384 |

The token budget is soft: a final completed call can pass its limit. Simulated
model latency is 250 ms; this is not measured speech-to-card latency. Real ASR,
mobile delivery, real web retrieval and long-term semantic memory are outside
the implemented baseline. The current retriever ranks synthetic documents by
lexical overlap.

## Verify and reproduce

Integrity verification uses only the Python standard library and makes no model
calls. Run from this directory:

```powershell
python verify.py
python verify.py --workspace ..\..\..\..
```

The optional comparison checks the live workspace against the frozen source.
After future changes, that comparison should fail while snapshot-only verification
continues to pass. `checksums.json` is an integrity inventory, not a cryptographic
signature or protection against deliberate simultaneous edits.

To rerun the baseline, use Python 3.12.14 with the pinned requirements in an isolated
environment and install the exact model/runtime recorded in `manifest.json`.
From this directory, after configuring the local Ollama service:

```powershell
python source/experiments/deep_conversation/bench.py --dataset source/experiments/deep_conversation/benchmarks/orchestration-holdout-v1 --output rerun-baseline --presets agent-led-recovery --provider ollama --model qwen2.5:14b-instruct --context-window 16384 --request-timeout 180 --max-calls 24 --max-tokens 120000 --max-output-tokens 1200 --repeats 1 --workers 1 --seed 20261007 --evaluation-protocol source/experiments/deep_conversation/benchmarks/TOOL_RECOVERY.md
```

This command starts new local inference; it has not been run as part of freezing.
For the original three-arm ordering, use
`--presets native agent-led agent-led-recovery`. The historical shuffled order is
also preserved in the manifest. Do not change this snapshot to add experiments;
write new variants and protocols in separate directories.

Temperature zero does not guarantee identical tool decisions or wording. Hardware,
runtime, dependencies and model files can affect outputs. Freeze hashes and
versions before each study, and evaluate new independent scenarios before claiming
an improvement. The exact six-case batch is useful for regression diagnosis.
