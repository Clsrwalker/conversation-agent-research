"""A native Deep Agent chooses its own investigation and publication actions.

The outer graph delivers arrived events, enforces runtime budgets and optionally
offers bounded feedback after retrieval failure. It does not impose task/evidence
schemas, a calculation stage, or release approval.
LangGraph checkpoints persist execution state; they are not semantic milestones.
"""
from __future__ import annotations

import json
from typing import NotRequired

from deepagents import (GeneralPurposeSubagentProfile, HarnessProfile,
                        create_deep_agent, register_harness_profile)
from deepagents._models import get_model_identifier, get_model_provider
from langchain_core.messages import AIMessage, HumanMessage
from langgraph.graph import END, START, StateGraph

from agent import (Accounting, COMMON_PROMPT, ConversationState, EventBoundary,
                   RunContext, assert_paired)
from agent_led_tools import make_tools
from providers import make_model


class AgentLedState(ConversationState):
    # Written with the recovery message in the parent checkpoint. The durable
    # tool ledger can redeliver an issued message if that checkpoint was lost.
    recovery_feedback_seq: NotRequired[int]


PROMPT = COMMON_PROMPT + """
Choose how to investigate and when to offer help. There is no fixed sequence of
planning, searching, calculating, checking and publishing. You can read more,
use a tool, answer from sufficient evidence, revise an existing card or stay quiet.
Working notes can be ordinary prose; no special record format is required.

calculate is available for arithmetic when useful. Think about what each input
means: a process's duration starts at that process's start, which may differ
from an earlier process's end. evidence_check is available for another look at a
draft or uncertain interpretation; its advice is optional, not permission to
publish. Both tools are choices, not prerequisites for an answer.

Address the full question, including what the facts mean for the people talking.
An intermediate number alone may not settle their question. Distinguish an
input rating from an output capability, an observed value from a requested
threshold, and a stated fact from an inference. Source text can leave a question
unresolved; explain the useful part and the missing information when appropriate.

To show help, call publish_card with the text; source_ids and card_id are optional.
Include supporting sources when you have them. Reusing a card_id updates that
card. Ordinary final prose remains private and does not display a card. No user
approval is needed for investigation or publication.
"""


def build_agent_led_graph(world, settings, checkpointer, *, model=None,
                          review_model=None, extra_middleware=(), interrupt_after=()):
    """Build the event loop while leaving tool choice to the native investigator."""
    model = model if model is not None else make_model(settings)
    review_model = review_model if review_model is not None else model
    single_investigator = HarnessProfile(
        general_purpose_subagent=GeneralPurposeSubagentProfile(enabled=False))
    identifier, provider = get_model_identifier(model), get_model_provider(model)
    if provider and identifier:
        register_harness_profile(f'{provider}:{identifier}', single_investigator)
    if identifier and ':' in identifier:
        register_harness_profile(identifier, single_investigator)

    investigator = create_deep_agent(
        model=model, tools=make_tools(world, settings, review_model),
        system_prompt=PROMPT, state_schema=AgentLedState,
        context_schema=RunContext,
        middleware=[EventBoundary(world, settings), *extra_middleware],
        # The parent owns persistence for the native subgraph and its tool loop.
        checkpointer=None,
    )

    def observe(state):
        assert_paired(state.get('messages', []))
        if world.done:
            return {'stop_reason': 'window_closed'}
        metrics = world.metrics()
        if (metrics['model_calls'] >= settings.max_calls or
                metrics['token_usage']['total_tokens'] >= settings.max_tokens):
            return {'stop_reason': 'budget_exhausted'}
        payload, cursor = world.observation(state.get('event_cursor', -1))
        if not payload['events'] and not world.done:
            messages = state.get('messages', [])
            final_response = (bool(messages) and isinstance(messages[-1], AIMessage)
                              and not messages[-1].tool_calls)
            last_batch = next((message.tool_calls for message in reversed(messages)
                               if isinstance(message, AIMessage) and message.tool_calls), [])
            explicit_wait = any(call['name'] == 'wait_for_event' for call in last_batch)
            if settings.mechanisms.failure_recovery and final_response and not explicit_wait:
                recovery = world.recovery_feedback(
                    state.get('recovery_feedback_seq', -1),
                    max_calls=settings.max_calls, max_tokens=settings.max_tokens)
                if recovery is not None:
                    return {'stop_reason': '', 'event_cursor': cursor,
                            'recovery_feedback_seq': recovery['seq'],
                            'messages': [HumanMessage(
                                content=json.dumps(recovery['feedback'], ensure_ascii=False),
                                id=f"recovery-{recovery['seq']}")]}
            world.advance_next()
            payload, cursor = world.observation(state.get('event_cursor', -1))
        if world.done:
            return {'stop_reason': 'window_closed', 'event_cursor': cursor}
        world.record('observation_step', context_revision=payload['context_revision'])
        return {'event_cursor': cursor, 'stop_reason': '', 'messages': [HumanMessage(
            content=json.dumps(payload, ensure_ascii=False), id=f'observation-{cursor}')]}

    def route(state):
        return END if state.get('stop_reason') else 'investigate'

    builder = StateGraph(AgentLedState, context_schema=RunContext)
    builder.add_node('observe', observe)
    builder.add_node('investigate', investigator)
    builder.add_edge(START, 'observe')
    builder.add_conditional_edges('observe', route, {END: END, 'investigate': 'investigate'})
    builder.add_edge('investigate', 'observe')
    graph = builder.compile(checkpointer=checkpointer, interrupt_after=list(interrupt_after))
    return graph, investigator, Accounting(world, settings)
