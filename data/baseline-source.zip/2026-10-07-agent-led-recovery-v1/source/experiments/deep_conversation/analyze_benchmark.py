"""Join frozen anonymous semantic ratings with costs; no model-based grading."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from pathlib import Path
import statistics

from config import PRESETS
from run import read, write

FLAGS = ['material_error', 'missed_required_help', 'unnecessary_publication',
         'unnecessary_revision', 'stale_new_publication', 'uncertain']


def analyze(batch, mapping_path, score_paths):
    manifest, results = read(batch / 'batch_manifest.json'), read(batch / 'batch_results.json')
    mapping = read(mapping_path)
    scores = {}
    for path in score_paths:
        for item in read(path):
            if item['blind_id'] in scores:
                raise ValueError('Duplicate rating: ' + item['blind_id'])
            if any(type(item[field]) is not bool for field in ['primary_success', *FLAGS]):
                raise ValueError('Ratings must use explicit booleans')
            scores[item['blind_id']] = item
    if set(scores) != {item['blind_id'] for item in mapping}:
        raise ValueError('Scores and blind mapping differ')
    result_map = {item['directory']: item for item in results}
    rows = []
    for identity in mapping:
        job = result_map[identity['directory']]
        summary = job['summary']
        events = read(batch / job['directory'] / 'environment_log.json')
        reviews = [e for e in events if e['kind'] == 'release_review']
        staged_reviews = [e for e in events if e['kind'] == 'orchestration_applicability']
        row = {**identity, **scores[identity['blind_id']],
               'status': summary['status'], 'stop_reason': summary['stop_reason'],
               'agent_stop_ms': summary['simulated_at_ms'], 'evaluation_deadline_ms': summary['close_at_ms'],
               'model_calls': summary['model_calls'], 'tokens': summary['token_usage']['total_tokens'],
               'role_counts': summary['role_counts'], 'domain_tool_counts': summary['domain_tool_counts'],
               'usage_missing': summary['model_usage_missing'], 'api_wall_ms': summary['api_wall_ms'],
               'boundary_injections': sum(e['kind'] == 'boundary_input' for e in events),
               'review_count': len(reviews),
               'staged_review_count': len(staged_reviews),
               'staged_review_noncommits': sum(e['report'].get('decision') != 'commit' for e in staged_reviews),
               'orchestration_outcome': summary.get('orchestration_state', {}).get('orchestration_outcome'),
               'review_rejections': sum(not e['decision']['approved'] for e in reviews),
               'review_race_rejections': sum(e['decision']['reason'].startswith('Conversation changed during review') for e in reviews)}
        rows.append(row)
    arms = []
    for preset in PRESETS:
        group = [row for row in rows if row['preset'] == preset]
        if not group:
            continue
        role_counts, tool_counts = Counter(), Counter()
        for row in group:
            role_counts.update(row['role_counts'])
            tool_counts.update(row['domain_tool_counts'])
        arms.append({'preset': preset, 'runs': len(group),
                     'primary_successes': sum(row['primary_success'] for row in group),
                     **{flag: sum(row[flag] for row in group) for flag in FLAGS},
                     'model_calls': sum(row['model_calls'] for row in group),
                     'tokens': sum(row['tokens'] for row in group),
                     'median_tokens': statistics.median(row['tokens'] for row in group),
                     'budget_stops': sum(row['stop_reason'] == 'budget_exhausted' for row in group),
                     'execution_errors': sum(row['status'] == 'error' for row in group),
                     'boundary_injections': sum(row['boundary_injections'] for row in group),
                     'review_count': sum(row['review_count'] for row in group),
                     'staged_review_count': sum(row['staged_review_count'] for row in group),
                     'staged_review_noncommits': sum(row['staged_review_noncommits'] for row in group),
                     'review_rejections': sum(row['review_rejections'] for row in group),
                     'review_race_rejections': sum(row['review_race_rejections'] for row in group),
                     'role_counts': dict(role_counts), 'domain_tool_counts': dict(tool_counts)})
    report = {'manifest': str(batch / 'batch_manifest.json'), 'rating_source': 'Blinded AI semantic review; not independent human labels',
              'independent_cases': len({row['case_id'] for row in rows}), 'total_runs': len(rows),
              'arms': arms, 'rows': rows,
              'limits': ['Synthetic fixtures only', 'Repeated runs are not independent scenarios',
                         'No significance or real-user-benefit claim', 'Model/time/token settings are identical; prompts differ by intervention']}
    write(batch / 'analysis.json', report)
    lines = ['# 对照汇总', '', '由匿名 AI 语义评分解盲计算；不是独立人工评测。', '',
             '| 组别 | 成功 | 调用 | token | 错误 | 遗漏 | 无益发布 | 预算耗尽 |',
             '| --- | --- | --- | --- | --- | --- | --- | --- |']
    for arm in arms:
        lines.append(f"| {arm['preset']} | {arm['primary_successes']}/{arm['runs']} | {arm['model_calls']} | {arm['tokens']:,} | {arm['material_error']} | {arm['missed_required_help']} | {arm['unnecessary_publication']} | {arm['budget_stops']} |")
    lines += ['', '## 逐案例', '', '| 案例 | ' + ' | '.join(arm['preset'] for arm in arms) + ' |',
              '| --- | ' + ' | '.join('---' for _ in arms) + ' |']
    for case in sorted({row['case_id'] for row in rows}):
        values = []
        for arm in arms:
            group = [row for row in rows if row['case_id'] == case and row['preset'] == arm['preset']]
            values.append(f"{sum(row['primary_success'] for row in group)}/{len(group)}")
        lines.append('| ' + case + ' | ' + ' | '.join(values) + ' |')
    lines += ['', f"{report['independent_cases']} 个独立场景，共 {report['total_runs']} 次运行；重复不增加独立场景数。完整评分理由、来源和中途错误在 analysis.json 中。", '']
    (batch / 'comparison.md').write_text('\n'.join(lines), encoding='utf-8')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('batch', type=Path)
    parser.add_argument('mapping', type=Path)
    parser.add_argument('scores', nargs='+', type=Path)
    args = parser.parse_args()
    result = analyze(args.batch.resolve(), args.mapping.resolve(), [p.resolve() for p in args.scores])
    print({'runs': result['total_runs'], 'cases': result['independent_cases'],
           'arms': [{k: a[k] for k in ['preset', 'primary_successes', 'runs', 'tokens']} for a in result['arms']]})
