"""Bounded, shuffled five-arm experiment runner. Never loads gold annotations."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import json
from pathlib import Path
import random
import shutil
import subprocess
import sys

from config import PRESETS, Settings
from local_runtime import local_model_metadata
from run import HERE, add_model_arguments, model_arguments, fingerprint, read, sha, write


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dataset', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--presets', nargs='+', choices=list(PRESETS),
                        default=['native', 'full', 'no-boundary', 'no-worklog', 'no-release'])
    parser.add_argument('--cases', nargs='+')
    parser.add_argument('--repeats', type=int, default=1)
    parser.add_argument('--workers', type=int, default=1)
    parser.add_argument('--seed', type=int, default=20261006)
    parser.add_argument('--evaluation-protocol', type=Path, default=HERE / 'benchmarks/EVALUATION.md',
                        help='Study protocol to snapshot alongside this batch; never sent to the agent.')
    add_model_arguments(parser)
    parser.add_argument('--max-calls', type=int, default=24)
    parser.add_argument('--max-tokens', type=int, default=120000)
    parser.add_argument('--max-output-tokens', type=int, default=1200)
    parser.add_argument('--run-timeout', type=float,
                        help='Per-run wall seconds; locally defaults to max-calls * request-timeout + 120.')
    args = parser.parse_args()
    settings = Settings(**model_arguments(args), max_calls=args.max_calls,
                        max_tokens=args.max_tokens, max_output_tokens=args.max_output_tokens)
    if min(settings.max_calls, settings.max_tokens, settings.max_output_tokens) <= 0:
        raise ValueError('Budgets must be positive')
    local_model = local_model_metadata(settings) if args.provider == 'ollama' else None
    if not 1 <= args.workers <= 4 or not 1 <= args.repeats <= 5:
        raise ValueError('Use 1-4 workers and 1-5 repeats')
    run_timeout = args.run_timeout if args.run_timeout is not None else (
        args.max_calls * args.request_timeout + 120 if args.provider == 'ollama' else 600)
    if run_timeout <= 0:
        raise ValueError('Run timeout must be positive')
    dataset, output = args.dataset.resolve(), args.output.resolve()
    evaluation_protocol = args.evaluation_protocol.resolve()
    if not evaluation_protocol.is_file():
        raise ValueError('Evaluation protocol file does not exist')
    cases = [case['case_id'] for case in read(dataset / 'cases.json')]
    if args.cases:
        if not set(args.cases).issubset(cases):
            raise ValueError('Unknown case ID')
        cases = args.cases
    for case_id in cases:
        if not case_id or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789-_' for c in case_id):
            raise ValueError('Case IDs must be simple directory names')
    frozen = read(dataset / 'freeze.json')
    # Hash annotations to verify the freeze, but never parse or pass them to runs.
    for name, metadata in frozen.get('files', frozen.get('files_sha256', {})).items():
        expected = metadata['sha256'] if isinstance(metadata, dict) else metadata
        if Path(name).name != name or sha(dataset / name) != expected:
            raise ValueError('Frozen file changed: ' + name)
    actual = {name: sha(dataset / name) for name in ['cases.json', 'corpus.json']}
    jobs = [{'preset': preset, 'case_id': case, 'repeat': repeat,
             'directory': f'{preset}__{case}__r{repeat}'}
            for repeat in range(1, args.repeats + 1) for case in cases for preset in args.presets]
    random.Random(args.seed).shuffle(jobs)
    output.mkdir(parents=True, exist_ok=False)
    shutil.copy2(evaluation_protocol, output / 'evaluation_protocol.md')
    baseline_fingerprint = fingerprint()
    manifest = {'created_at': datetime.now(timezone.utc).isoformat(), 'dataset': str(dataset),
                'dataset_sha256': actual, 'dataset_freeze': frozen, 'fingerprint': baseline_fingerprint,
                **model_arguments(args), 'local_model': local_model,
                'max_calls': args.max_calls, 'max_tokens_soft': args.max_tokens,
                'max_output_tokens': args.max_output_tokens, 'model_latency_ms': 250,
                'workers': args.workers, 'order_seed': args.seed, 'jobs': jobs,
                'run_timeout_seconds': run_timeout,
                'batch_runner_sha256': sha(Path(__file__)),
                'evaluation_protocol': str(evaluation_protocol),
                'evaluation_protocol_sha256': sha(output / 'evaluation_protocol.md'),
                'gold_read_by_runner': False, 'quality_scoring': 'Separate blinded semantic review',
                'evaluation_close': 'Fixed scenario deadline; cards persist after agent stops.'}
    write(output / 'batch_manifest.json', manifest)

    def execute(job):
        if fingerprint() != baseline_fingerprint or any(sha(dataset / name) != digest for name, digest in actual.items()):
            raise RuntimeError('Code, dependencies or dataset changed during the batch')
        if args.provider == 'ollama' and local_model_metadata(settings) != local_model:
            raise RuntimeError('Local model or Ollama version changed during the batch')
        folder = output / job['directory']
        command = [sys.executable, str(HERE / 'run.py'), '--provider', args.provider,
                   '--preset', job['preset'], '--case', job['case_id'], '--dataset', str(dataset),
                   '--output', str(folder), '--max-calls', str(args.max_calls),
                   '--max-tokens', str(args.max_tokens), '--max-output-tokens', str(args.max_output_tokens),
                   '--model', settings.model, '--reasoning-effort', settings.reasoning_effort,
                   '--local-base-url', settings.local_base_url,
                   '--context-window', str(settings.context_window),
                   '--request-timeout', str(settings.request_timeout)]
        try:
            process = subprocess.run(command, capture_output=True, text=True, encoding='utf-8',
                                     errors='replace', timeout=run_timeout,
                                     env={**__import__('os').environ, 'PYTHONIOENCODING': 'utf-8'})
            # Do not save provider exception bodies; run.py already exports safe error classes.
            summary = read(folder / 'summary.json') if (folder / 'summary.json').exists() else None
            if args.provider == 'ollama' and (folder / 'manifest.json').exists():
                if read(folder / 'manifest.json').get('local_model') != local_model:
                    return {**job, 'exit_code': 1, 'summary': summary,
                            'error': 'Model provenance differs from the frozen batch; exclude this run.'}
            return {**job, 'exit_code': process.returncode, 'summary': summary,
                    'error': None if summary else 'No summary produced; inspect the preserved local checkpoint'}
        except subprocess.TimeoutExpired:
            return {**job, 'exit_code': None, 'summary': None,
                    'error': f'Per-run {run_timeout:g}-second wall-time limit'}

    results = []
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {pool.submit(execute, job): job for job in jobs}
        for future in as_completed(futures):
            result = future.result()
            results.append(result)
            write(output / 'batch_results.json', results)
            summary = result.get('summary') or {}
            print(json.dumps({'completed': len(results), 'total': len(jobs),
                'preset': result['preset'], 'case': result['case_id'], 'repeat': result['repeat'],
                'status': summary.get('status', result['error']),
                'calls': summary.get('model_calls'), 'tokens': summary.get('token_usage', {}).get('total_tokens')},
                ensure_ascii=True), flush=True)
    return 1 if any(item['exit_code'] != 0 for item in results) else 0


if __name__ == '__main__':
    sys.exit(main())
