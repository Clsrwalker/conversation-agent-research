# Tool feedback and optional continuation

Date: 2026-10-07. This iteration addresses misunderstood tool failures and an
idle exit after a failed retrieval. It does not add mandatory answer records,
semantic approval, calculation stages, or human confirmation.

## Changes and comparisons

All presets use the same improved Replay tools. Search results keep their
existing ranking, top-three limit and 150-character excerpts, but identify
excerpt/full content and truncation. A failed read explains that no job started,
lists only already arrived source IDs/titles and actual pending searches, and
suggests how to recover. It does not resolve hidden document titles, return
unrequested full text, or reveal future sources. Tool descriptions clarify the
same read contract for every group.

`agent-led-recovery` differs from `agent-led` only by optional continuation after
a recoverable retrieval error and a private final response. When there is no
pending work, subsequent successful action, fresh input, or explicit wait, the
runtime offers one ordinary-language recovery message per conversation update.
The model can change approach or stop. Budget and deadline limits still apply.
The message is durably issued and acknowledged through graph state, so recovery
does not reset the allowance or duplicate its delivery after a saved checkpoint.

## Frozen local replay

Run `native`, `agent-led`, and `agent-led-recovery` once each on the six exposed
orchestration development scenarios, shuffled and serial. Use local Qwen2.5 14B
Instruct, temperature 0, context 16,384, at most 24 model calls, soft 120,000 tokens
and 1,200 output tokens per call. No paid API fallback. Save exact source,
dependency, dataset and model fingerprints before running; do not change them
during the batch.

The paired `agent-led` comparison isolates the added recovery opportunity on
shared improved tools. The native comparison is between complete harness
variants. Historical runs used different tool feedback; comparing with them
does not isolate recovery or establish a causal benefit of feedback alone.

Use the existing frozen semantic rubric and anonymous packets. Keep five
required-help scenarios separate from the one silence scenario. Report material
errors, missed help, unnecessary/stale publication and resource use, as well as
how often recovery was actually offered and what the model did afterward.
If no run triggers recovery, the experiment does not establish its real-model
benefit even if graph tests pass. These exposed cases and a single repeat cannot
establish statistical significance, generalization, or real-user benefit.
