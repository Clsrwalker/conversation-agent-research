"""Deduplicate evidence text for anonymous reviewers; preserve full raw packets."""
import json
from pathlib import Path
import sys
from run import read, write


def main(folder):
    groups = {
        'a': ['holdout-stable-positive', 'holdout-incidental-mention'],
        'b': ['holdout-excerpt-exception', 'holdout-already-resolved'],
        'c': ['holdout-asr-number-repair', 'holdout-future-revision'],
    }
    packets = [read(path) for path in folder.glob('item-*.json')]
    for label, case_ids in groups.items():
        dictionary, reverse, cases = {}, {}, []

        def reference(evidence):
            result = []
            for source_id, value in evidence.items():
                data = {k: v for k, v in value.items() if k != 'retrieval_score'}
                data['source_id'] = source_id
                key = json.dumps(data, sort_keys=True, ensure_ascii=False)
                if key not in reverse:
                    name = f'ev-{len(dictionary)+1:03d}'
                    reverse[key], dictionary[name] = name, data
                result.append(reverse[key])
            return result

        for case_id in case_ids:
            items = [p for p in packets if p['case']['case_id'] == case_id]
            if len(items) != 10:
                raise ValueError(f'Expected ten complete runs for {case_id}, got {len(items)}')
            first = items[0]
            case = {k: first[k] for k in ['case', 'rubric', 'shared_rubric', 'corpus', 'evaluation_rule', 'evaluation_deadline_ms']}
            case['items'] = []
            for item in items:
                views = []
                for event in item['display_events']:
                    view = {k: v for k, v in event.items() if k not in ['visible_evidence_at_this_event', 'evidence_in_actual_model_inputs_before_publication']}
                    view['arrived_evidence_refs'] = reference(event['visible_evidence_at_this_event'])
                    view['actual_model_input_evidence_refs'] = reference(event['evidence_in_actual_model_inputs_before_publication'])
                    views.append(view)
                case['items'].append({'blind_id': item['blind_id'], 'display_events': views,
                                      'final_active_cards': item['final_active_cards'],
                                      'execution_error': item['execution_error']})
            cases.append(case)
        write(folder.parent / f'holdout-group-{label}.json', {
            'notice': 'Evidence refs point to evidence_dictionary below. actual_model_input_evidence_refs are evidence actually sent to a model before publication; arrived_evidence_refs only mean environment availability. Full corpus is reference truth, not a substitute for consumed evidence. No arm names or costs are included.',
            'evidence_dictionary': dictionary, 'cases': cases})


if __name__ == '__main__':
    main(Path(sys.argv[1]))
