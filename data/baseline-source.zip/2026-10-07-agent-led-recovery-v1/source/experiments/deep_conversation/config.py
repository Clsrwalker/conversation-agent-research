"""Frozen experimental switches; none changes the model or available domain tools."""
from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class Mechanisms:
    boundary_input: bool = False
    worklog: bool = False
    release_check: bool = False
    orchestration: bool = False
    stage_acceptance: bool = False
    answer_contract: bool = False
    evidence_interface: bool = False
    agent_led: bool = False
    failure_recovery: bool = False


PRESETS = {
    'native': Mechanisms(),
    'agent-led': Mechanisms(boundary_input=True, agent_led=True),
    'agent-led-recovery': Mechanisms(boundary_input=True, agent_led=True, failure_recovery=True),
    'full': Mechanisms(True, True, True),
    'no-boundary': Mechanisms(False, True, True),
    'no-worklog': Mechanisms(True, False, True),
    'no-release': Mechanisms(True, True, False),
    # Preserve the previous staged implementation as an explicit comparator.
    'orchestrated-v4': Mechanisms(orchestration=True),
    'orchestrated': Mechanisms(orchestration=True, stage_acceptance=True),
    'orchestrated-contract': Mechanisms(orchestration=True, stage_acceptance=True, answer_contract=True),
    'orchestrated-interface': Mechanisms(orchestration=True, stage_acceptance=True,
                                       answer_contract=True, evidence_interface=True),
}


@dataclass(frozen=True)
class Settings:
    preset: str = 'native'
    provider: str = 'ollama'
    model: str = 'qwen2.5:14b-instruct'
    local_base_url: str = 'http://127.0.0.1:11434'
    context_window: int = 16384
    request_timeout: float = 180
    reasoning_effort: str = 'none'
    max_calls: int = 24
    max_tokens: int = 100000
    max_output_tokens: int = 1000
    model_latency_ms: int = 250
    recursion_limit: int = 500

    @property
    def mechanisms(self):
        return PRESETS[self.preset]

    def to_dict(self):
        return {**asdict(self), 'mechanisms': asdict(self.mechanisms)}
