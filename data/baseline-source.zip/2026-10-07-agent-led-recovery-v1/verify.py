"""Verify the frozen baseline without loading a model or making a network request."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path,
                        help='Optionally compare the current workspace with frozen source files.')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / 'manifest.json').read_text(encoding='utf-8'))
    checksums = json.loads((root / 'checksums.json').read_text(encoding='utf-8'))
    failures = []
    for relative, expected in checksums['files_sha256'].items():
        path = (root / relative).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            failures.append(f'Missing or invalid snapshot path: {relative}')
        elif sha256(path) != expected:
            failures.append(f'Snapshot changed: {relative}')
    for relative, expected in manifest['source_sha256'].items():
        path = root / 'source' / relative
        if not path.is_file() or sha256(path) != expected:
            failures.append(f'Source differs from manifest: {relative}')
        if args.workspace:
            working = args.workspace.resolve() / relative
            if not working.is_file() or sha256(working) != expected:
                failures.append(f'Working source differs: {relative}')
    result = {
        'baseline_id': manifest['baseline_id'],
        'passed': not failures,
        'files_checked': len(checksums['files_sha256']),
        'manifest_sha256': sha256(root / 'manifest.json'),
        'current_workspace_compared': args.workspace is not None,
        'failures': failures,
        'model_calls': 0,
        'note': 'Integrity checks do not prove model output reproducibility or research efficacy.',
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 1 if failures else 0


if __name__ == '__main__':
    raise SystemExit(main())
