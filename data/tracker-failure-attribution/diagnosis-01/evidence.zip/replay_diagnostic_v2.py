"""Post-hoc CPU replay of recorded tracker outputs and original reference patches.

Revision 2: missing targets require sealed semantic candidate matching for target
identity; literal reference-ID reuse is reported separately. Revision 1 retained.

No new semantic labels or model calls. Identity-touch counts are structural;
meaning, ownership and status correctness come only from sealed model reviews.
"""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = next(p for p in Path(__file__).resolve().parents if (p / 'AGENTS.md').exists())
STUDY = ROOT / 'output/research/2026-10-24/tracker-lora-repair-v2'
HERE = Path(__file__).resolve().parent
ARMS = ('adapter_disabled', 'tracker_lora_v1', 'tracker_lora_v2')
BINDINGS = {}


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def bound(path):
    p = Path(path).resolve()
    if not p.is_relative_to(ROOT):
        raise ValueError('Source outside project')
    BINDINGS[p.relative_to(ROOT).as_posix()] = sha(p)
    return p


def read(path):
    return json.loads(bound(path).read_text(encoding='utf-8-sig'))


def lines(path):
    return [json.loads(line) for line in bound(path).read_text(encoding='utf-8-sig').splitlines() if line.strip()]


def write_new(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


def check(value, message):
    if not value:
        raise ValueError(message)


def full_correct(value):
    return value['meaning'] == 'equivalent' and value['owner_correct'] is True and value['status_correct'] is True


def state_map(value):
    return {item['intent_id']: item for item in value}


def changes(before, after):
    a, b = state_map(before), state_map(after)
    return {'added_ids': sorted(set(b) - set(a)), 'removed_ids': sorted(set(a) - set(b)),
            'changed_existing_ids': sorted(k for k in set(a) & set(b) if a[k] != b[k])}


def add_fault(counter, item):
    counter['assignments'] += 1
    counter['runtime_' + item['validity']] += 1
    counter['frozen_target_fully_correct'] += item['target_fully_correct']
    counter['reference_id_touched_in_proposal'] += item['reference_id_touched']
    counter['meaning_matched_candidate_id_touched_in_proposal'] += item['meaning_match_id_touched']
    counter['target_identity_touched_in_proposal'] += item['target_related_operation_present']
    counter['target_literal_fields_unchanged_from_input'] += item['target_literal_fields_unchanged']
    counter['no_parsed_proposal'] += not item['proposal_present']
    counter['empty_parsed_proposal'] += item['proposal_present'] and item['proposal_operation_count'] == 0
    counter['only_other_identity_operations_proposed'] += item['proposal_operation_count'] > 0 and not item['target_related_operation_present']
    counter['source_error_decisions_any_operation'] += bool(item['source_error_operation_indices'])
    counter['source_error_decisions_target_related_operation'] += bool(item['target_related_source_error_operation_indices'])
    counter['boundary_' + item['observable_boundary']] += 1
    for op in item['reference_id_operations']:
        counter['reference_id_operation_' + op.get('op', '<missing>')] += 1
        if op.get('op') == 'update':
            for field in ('owner', 'text', 'status'):
                counter['reference_id_update_field_' + field] += field in op
    for op in item['target_related_operations']:
        counter['target_related_operation_' + op.get('op', '<missing>')] += 1
        if op.get('op') == 'update':
            for field in ('owner', 'text', 'status'):
                counter['target_related_update_field_' + field] += field in op


def run(output, date):
    datetime.strptime(date, '%Y-%m-%d')
    output = Path(output).resolve()
    check(output.is_relative_to(HERE) and not output.exists(), 'Use a fresh runtime run directory')
    output.mkdir(parents=True)
    lock = read(STUDY / 'evaluation/protocol-lock.json')
    dependency_checks = []
    for name, item in lock['files'].items():
        current = sha(bound(item['path']))
        check(current == item['sha256'], 'Frozen dependency changed: ' + name)
        dependency_checks.append({'name': name, 'sha256': current, 'matches_frozen': True})
    sys.path.insert(0, str(ROOT / 'experiments/deep_conversation/tracker_lora/repair_v2'))
    import evaluate_three_arm as evaluator
    import review_workflow
    replay = evaluator.legacy
    check(Path(replay.__file__).resolve() == Path(lock['files']['legacy_evaluator']['path']).resolve(), 'Wrong imported replay module')
    prep_dir = STUDY / 'evaluation/blind-prepared-reference-01'
    sealed = STUDY / 'evaluation/blind-sealed-reference-01'
    seal_verification = review_workflow.verify_sealed_review(str(prep_dir), str(sealed / 'final-judgments.json'), str(sealed / 'review-lock.json'))
    prep = read(prep_dir / 'preparation.json')
    for name, expected in prep['files'].items():
        check(sha(bound(prep_dir / name)) == expected, 'Prepared source changed: ' + name)
    read(sealed / 'review-lock.json')
    judgments = {j['blind_id']: j for j in read(sealed / 'final-judgments.json')}
    packets = {p['blind_id']: p for p in read(prep_dir / 'review-packets.json')['packets']}
    mapping = read(prep_dir / 'PRIVATE-mapping.json')['assignments']
    historical_runtime = {item['assignment_id']: item['result'] for item in read(prep_dir / 'PRIVATE-runtime-results.json')}
    rows = lines(STUDY / 'data/compiled/test.records.jsonl')
    model_outputs = {(o['row_index'], o['arm']): o for o in lines(STUDY / 'evaluation/collection-01/outputs.jsonl')}
    reported = read(STUDY / 'analysis/three-arm-results.json')
    reported_assignments = {r['assignment_id']: r for r in reported['per_assignment']}
    config = read(STUDY / 'evaluation/collection-01/collection-config.json')
    check(config['data_sha256'] == sha(STUDY / 'data/compiled/test.records.jsonl'), 'Collection/test identity mismatch')
    check(len(rows) == 200 and len(mapping) == len(model_outputs) == 600, 'Required coverage mismatch')
    check(set(model_outputs) == {(i, a) for i in range(200) for a in ARMS}, 'Incomplete paired assignments')
    check(len({m['assignment_id'] for m in mapping}) == 600, 'Duplicate mapping')
    ledger = read(STUDY / 'evaluation/reference-amendment-01/ledger.json')
    approval = read(STUDY / 'evaluation/reference-amendment-01/approval.json')
    check(approval['status'] == 'approved' and approval['ledger_sha256'] == sha(STUDY / 'evaluation/reference-amendment-01/ledger.json'), 'Amendment approval mismatch')
    amendments_by_row = defaultdict(list)
    for item in ledger['changes']:
        matched_rows = {m['row_index'] for m in mapping if m['blind_id'] == item['blind_id']}
        check(len(matched_rows) == 1, 'Ambiguous amendment row')
        amendments_by_row[next(iter(matched_rows))].append(item)

    assignments, fault_rows = [], []
    counters = defaultdict(Counter)
    replay_validities = defaultdict(Counter)
    for meta in mapping:
        index, arm, ident = meta['row_index'], meta['arm'], meta['assignment_id']
        row, packet = rows[index], packets[meta['blind_id']]
        actual = replay.apply_candidate(row, model_outputs[index, arm])
        check(actual == historical_runtime[ident], 'Complete historical runtime replay differs: ' + ident)
        before, after = replay.project(row['input']['intention_state']), replay.project(actual['post_state'])
        check(before == packet['before_state'] and after == packet['candidate_state'], 'Prepared semantic projection differs: ' + ident)
        ops = actual['proposal']['operations'] if actual['proposal'] is not None else []
        check(packet['candidate_operations'] == (ops if actual['proposal'] is not None else None) and packet['candidate_validity'] == actual['validity'], 'Prepared proposal/validity differs: ' + ident)
        if not actual['committed']:
            check(actual['post_state'] == row['input']['intention_state'], 'Rejected/failed output mutated state')
        replay_validities[arm][actual['validity']] += 1
        j = judgments[meta['blind_id']]
        record = {'assignment_id': ident, 'row_index': index, 'example_id': row['example_id'], 'family_id': row['family_id'],
            'arm': arm, 'language': row['language'], 'validity': actual['validity'], 'committed': actual['committed'],
            'proposal_present': actual['proposal'] is not None, 'proposal_operations': ops, 'runtime_error': actual['error'],
            'before_projected_sha256': replay.digest(before), 'after_projected_sha256': replay.digest(after),
            'complete_replay_equal_to_record': True, 'literal_state_changes': changes(before, after)}
        fault = row.get('prior_fault_annotation')
        if fault:
            target = fault['intent_id']
            judge = next(c for c in j['reference_checks'] if c['reference_intent_id'] == target)
            matched_ids = set(judge['matched_candidate_ids'])
            # The absent intent has no prior identity; an ID reused by an
            # unrelated add is not evidence that the missing intent was touched.
            related = matched_ids if fault['fault_kind'] == 'missing' else matched_ids | {target}
            related_indices = [i for i, op in enumerate(ops) if op.get('intent_id') in related]
            direct_ops = [op for op in ops if op.get('intent_id') == target]
            a, b = state_map(before).get(target), state_map(after).get(target)
            target_correct = full_correct(judge)
            check(int(target_correct) == reported_assignments[ident]['counts']['fully_correct_repair_targets'], 'Frozen repair count differs')
            boundary = (actual['validity'] if not actual['committed'] else
                        'correct_target_under_frozen_review' if target_correct else
                        'target_related_operation_committed_but_not_fully_correct' if related_indices else
                        'no_target_related_operation_proposed')
            evidence_seq = fault['repair_source_seqs']
            arrived = {e['seq']: e for e in row['input']['conversation']}
            check(all(seq in arrived for seq in evidence_seq), 'Repair evidence not arrived')
            input_cursor = row['input']['intention_state']['processed_event_seq']
            analysis = {'assignment_id': ident, 'row_index': index, 'example_id': row['example_id'], 'family_id': row['family_id'],
                'arm': arm, 'fault_kind': fault['fault_kind'], 'reference_intent_id': target,
                'validity': actual['validity'], 'target_before': a, 'target_after_same_id': b,
                'target_existed_in_input': a is not None, 'target_literal_fields_unchanged': a == b,
                'target_fully_correct': target_correct, 'frozen_reference_check': judge,
                'meaning_matched_candidate_ids': sorted(matched_ids),
                'reference_id_touched': bool(direct_ops), 'reference_id_operations': direct_ops,
                'meaning_match_id_touched': any(op.get('intent_id') in matched_ids for op in ops),
                'target_related_identity_rule': 'sealed_matched_ids_only_absent_target' if fault['fault_kind'] == 'missing' else 'existing_reference_id_or_sealed_matched_ids',
                'target_related_operation_present': bool(related_indices), 'target_related_operation_indices': related_indices,
                'target_related_operations': [ops[i] for i in related_indices],
                'proposal_present': actual['proposal'] is not None,
                'proposal_operation_count': len(ops), 'source_error_operation_indices': j['source_error_operation_indices'],
                'target_related_source_error_operation_indices': sorted(set(related_indices) & set(j['source_error_operation_indices'])),
                'repair_source_seqs': evidence_seq, 'all_repair_sources_arrived': True,
                'input_processed_event_seq': input_cursor,
                'repair_evidence_all_at_or_before_processed_cursor': all(seq <= input_cursor for seq in evidence_seq),
                'observable_boundary': boundary}
            add_fault(counters[arm, fault['fault_kind']], analysis)
            add_fault(counters[arm, 'all_faults'], analysis)
            fault_rows.append(analysis)
            record['fault_target_analysis'] = analysis
        assignments.append(record)

    oracle = []
    for index, row in enumerate(rows):
        actual = replay.apply_candidate(row, {'status': 'completed', 'output_text': canonical(row['target'])})
        after = replay.project(actual['post_state'])
        check(actual['validity'] == 'valid_patch', 'Original annotated patch rejected: ' + row['example_id'])
        check(after == row['expected_semantic_state'], 'Annotated patch differs from original full projected reference: ' + row['example_id'])
        before_map, after_map = state_map(replay.project(row['input']['intention_state'])), state_map(after)
        unchanged_ids = row['preserve_ids']
        check(all(before_map[k] == after_map[k] for k in unchanged_ids), 'Reference control changed unrelated preserved requirement')
        amended = packets[next(m['blind_id'] for m in mapping if m['row_index'] == index)]['reference_state']
        differences = [{'intent_id': a['intent_id'], 'original_control': a, 'amended_reference': b}
                       for a, b in zip(after, amended) if a != b]
        check(len(after) == len(amended), 'Reference length changed')
        expected_changes = amendments_by_row.get(index, [])
        check(len(differences) == len(expected_changes), 'Unexpected original/amended reference difference')
        for diff in differences:
            change = next(c for c in expected_changes if c['reference_intent_id'] == diff['intent_id'])
            check(diff['original_control']['text'] == change['old_text'] and diff['amended_reference']['text'] == change['new_text'], 'Amendment mismatch')
            check({k:v for k,v in diff['original_control'].items() if k != 'text'} == {k:v for k,v in diff['amended_reference'].items() if k != 'text'}, 'Unexpected nontext amendment')
        fault = row.get('prior_fault_annotation')
        if fault:
            check(not differences, 'Fault control unexpectedly affected by reference amendment')
            target = fault['intent_id']
            check(after_map[target] == state_map(amended)[target], 'Reference control target mismatch')
        oracle.append({'example_id': row['example_id'], 'row_index': index, 'fault_kind': fault['fault_kind'] if fault else None,
            'reference_patch': row['target'], 'validity': actual['validity'],
            'all_original_reference_records_equal': True, 'all_preserve_ids_unchanged': True,
            'preserve_ids_checked': unchanged_ids, 'matches_amended_full_reference_literally': not differences,
            'known_original_reference_text_differences': differences,
            'fault_target_matches_amended_reference_literally': True if fault else None,
            'after_projected_sha256': replay.digest(after)})

    check(len(fault_rows) == 240 and len([r for r in oracle if r['fault_kind']]) == 80, 'Fault coverage mismatch')
    for arm in ARMS:
        count = counters[arm, 'all_faults']['frozen_target_fully_correct']
        check(count == reported['arms'][arm]['counts']['fully_correct_repair_targets'], 'Aggregate repair result changed')
    fault_input_counts = Counter(r['prior_fault_annotation']['fault_kind'] for r in rows if r.get('prior_fault_annotation'))
    controls = {'original_annotated_patches_executed': len(oracle), 'runtime_accepted': sum(r['validity'] == 'valid_patch' for r in oracle),
        'full_original_projected_reference_exact_matches': sum(r['all_original_reference_records_equal'] for r in oracle),
        'all_preserve_id_fields_unchanged': sum(r['all_preserve_ids_unchanged'] for r in oracle),
        'full_amended_projected_reference_exact_matches': sum(r['matches_amended_full_reference_literally'] for r in oracle),
        'known_ordinary_reference_text_mismatches': len([r for r in oracle if r['known_original_reference_text_differences']]),
        'fault_targets_matching_amended_reference': sum(r['fault_target_matches_amended_reference_literally'] is True for r in oracle),
        'fault_inputs': sum(fault_input_counts.values()), 'faults_by_kind': dict(sorted(fault_input_counts.items())),
        'amendment_policy': 'No patched oracle targets were created. Two original ordinary targets omit clauses added by the approved reference overlay; both explicit mismatches are retained. No fault-target row has an amended reference.'}
    bound(__file__)
    summary = {'kind': 'post_hoc_recorded_tracker_runtime_and_reference_patch_diagnostic', 'status': 'completed', 'diagnostic_revision': 2,
        'date': date, 'timezone': 'America/Halifax', 'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'new_model_calls': 0, 'new_training_runs': 0, 'frozen_files_modified': False,
        'frozen_dependency_checks': dependency_checks, 'sealed_review_verification': seal_verification,
        'captured_replay': {'assignments': len(assignments), 'all_complete_runtime_results_exactly_reproduced': True,
            'projected_candidate_and_validity_match_prepared_packets': True, 'all_rejections_preserve_complete_input_state': True,
            'validities_by_arm': {a: dict(v) for a, v in replay_validities.items()}},
        'reference_patch_controls': controls,
        'target_identity_rule': 'For missing targets, only candidate IDs matched by the sealed semantic review count as target-related. For already-existing targets, existing reference ID or sealed matched IDs count. Raw reference-ID touch remains a distinct structural metric.',
        'revision_note': 'Supersedes run-01 target-related counts for missing intents; run-01 and its code are retained. This is a deterministic diagnostic refinement, not a new model trial.',
        'fault_assignment_aggregates': [{'arm': a, 'fault_kind': k, 'counts': dict(sorted(v.items()))} for (a, k), v in sorted(counters.items())],
        'evidence_availability': {'fault_inputs': 80,
            'all_repair_sources_arrived': all(x['all_repair_sources_arrived'] for x in fault_rows),
            'all_repair_evidence_at_or_before_processed_cursor': all(x['repair_evidence_all_at_or_before_processed_cursor'] for x in fault_rows),
            'interpretation': 'The frozen interface accepts supported repairs citing already-processed arrived evidence. Presence does not prove that the model used or understood it.'},
        'source_hashes': dict(sorted(BINDINGS.items())),
        'limitations': ['Deterministic replay reproduces captured behavior; it is not another model evaluation or a causal intervention on model understanding.',
            'Correctness labels are the original sealed model reviews, not new human adjudication. No baseline label was changed.',
            'Reference-patch controls establish that the runtime can execute these annotated repairs and preserve annotated unrelated records. Their semantic correctness depends on existing review and separate diagnostic source inspection.',
            'Reference-ID touch and literal field retention are structural descriptions. Missing-target identity is based on sealed-review matched IDs; untouched target identity does not mean no other operation was proposed.',
            'No-target-operation failure cannot distinguish attention, trust in old state, policy interpretation, insufficient training or another internal model mechanism.',
            'The two known ordinary original reference omissions remain explicit; original control operations are not silently amended.',
            'All examples were exposed by the earlier evaluation. This is post-hoc diagnosis, not fresh held-out evidence of a repair benefit.']}
    for relative, expected in BINDINGS.items():
        check(sha(ROOT / relative) == expected, 'Source changed during diagnostic: ' + relative)
    write_new(output / 'PRIVATE-assignment-analysis.json', assignments)
    write_new(output / 'PRIVATE-fault-target-analysis.json', fault_rows)
    write_new(output / 'PRIVATE-reference-controls.json', oracle)
    summary['private_record_hashes'] = {p.name: sha(p) for p in output.glob('PRIVATE-*.json')}
    write_new(output / 'summary.json', summary)
    print(canonical({'status': summary['status'], 'captured_assignments_replayed': len(assignments),
        'reference_controls': controls, 'summary_sha256': sha(output / 'summary.json')}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True)
    parser.add_argument('--date', required=True)
    args = parser.parse_args()
    run(args.output, args.date)
