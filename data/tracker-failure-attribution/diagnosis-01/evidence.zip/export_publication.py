"""Freeze a public allowlist after independent diagnostic review; no model calls."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]

def read(p):
    return json.loads(p.read_text(encoding='utf-8'))

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def write(p, value):
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')

def main():
    audit = read(HERE/'audit/final-review.json')
    assert audit['status'] == 'passed'
    assert audit['reviewed_report_sha256'] == sha(HERE/'analysis/report.json')
    report = read(HERE/'analysis/report.json')
    assert read(HERE/'semantic/owner-withdrawal-review.json')['coverage']['assignments'] == 75
    runtime = read(HERE/'runtime/run-02/summary.json')
    assert runtime['captured_replay']['all_complete_runtime_results_exactly_reproduced']
    assert read(HERE/'runtime/artifact-qa.json')['fault_controls_with_full_projected_amended_state_equality'] == 80
    paths = {
        'runtime-final.json':'runtime/run-02/summary.json',
        'runtime-superseded-run-01.json':'runtime/run-01/summary.json',
        'runtime-artifact-qa.json':'runtime/artifact-qa.json',
        'runtime-execution-receipt.json':'runtime/execution-receipt.json',
        'replay_diagnostic.py':'runtime/replay_diagnostic.py',
        'replay_diagnostic_v2.py':'runtime/replay_diagnostic_v2.py',
        'verify_runtime_artifacts.py':'runtime/verify_runtime_artifacts.py',
        'curriculum-audit.json':'data-audit/result-01.json',
        'inspect_curriculum.py':'data-audit/inspect_curriculum.py',
        'owner-withdrawal-review.json':'semantic/owner-withdrawal-review.json',
        'uncertainty-review.json':'semantic/uncertainty-review.json',
        'independent-audit.json':'audit/final-review.json',
        'independent-computed-checks.json':'audit/computed-checks.json',
        'independent_verify_claims.py':'audit/verify_claims.py',
        'prior-bundles.json':'analysis/prior-bundles.json',
        'build_report.py':'build_report.py',
        'export_publication.py':'export_publication.py',
    }
    dest = HERE/'publication/diagnosis-01'
    assert not dest.exists(), 'Frozen package already exists; do not overwrite.'
    bindings = {}
    payloads = {}
    for name, rel in paths.items():
        source = HERE/rel
        data = source.read_bytes()
        transformation = 'none; publication-safe aggregate or diagnostic source'
        if name == 'runtime-execution-receipt.json':
            def relative(value):
                if isinstance(value,dict):
                    return {k:relative(v) for k,v in value.items()}
                if isinstance(value,list):
                    return [relative(v) for v in value]
                if isinstance(value,str):
                    for prefix in (str(ROOT),ROOT.as_posix()):
                        if value == prefix:
                            return '.'
                        if value.startswith(prefix+'\\') or value.startswith(prefix+'/'):
                            return value[len(prefix)+1:].replace('\\','/')
                return value
            data = (json.dumps(relative(read(source)),ensure_ascii=False,indent=2)+'\n').encode('utf-8')
            transformation = 'Local workspace and Python paths made project-relative; execution results unchanged.'
        assert not re.search(rb'(?<![A-Za-z0-9])[A-Za-z]:[\\/]+',data), name
        assert '\ufffd' not in data.decode('utf-8'), name
        assert not name.startswith('PRIVATE-')
        payloads[name] = data
        bindings[name] = {'source_path':source.relative_to(ROOT).as_posix(), 'source_sha256':sha(source),'export_sha256':hashlib.sha256(data).hexdigest(),'transformation':transformation}
    engineering = {
        'id':'tracker-failure-attribution-engineering','type':'engineering_validation','status':'passed',
        'date':'2026-10-27','timezone':'America/Halifax',
        'scope':'Grouped recorded-output replay, scripted reference controls, curriculum structure and diagnostic consistency checks; publication checks are separate.',
        'checks':[
            {'name':'Frozen runtime dependencies','status':'passed','result':'18/18 source bindings match the experimental lock.'},
            {'name':'Captured runtime replay','status':'passed','result':'600 complete runtime returns reproduced; rejected outputs preserve input state.'},
            {'name':'Original reference patch controls','status':'passed','result':'200/200 accepted, 200/200 match original projected references, 80/80 fault inputs match amended projected references; two ordinary known reference differences retained.'},
            {'name':'Artifact and target identity audit','status':'passed_after_diagnostic_correction','result':'Run-02 corrects missing-intent ID reuse; run-01/code retained. All 240 fault assignment joins, 21 aggregate groups and private output hashes verified.'},
            {'name':'Curriculum structure audit','status':'passed_after_schema_handling','result':'500/50/200 source updates verified; 140/20/80 corrupted priors including 20 legacy-schema train cases. Initial KeyError preserved in audit record.'},
            {'name':'Independent interpretation audit','status':'passed','record':'independent-audit.json'}
        ],
        'new_model_calls':0,'new_training_runs':0,
        'tested_source_sha256':{k:v['source_sha256'] for k,v in bindings.items()},
        'limitations':['CPU replay and reference execution do not demonstrate a model-quality improvement.','Semantic review is retrospective model review; no new independent human labels.','Website and deployment checks are recorded after this package is frozen.']
    }
    dest.mkdir(parents=True)
    for name,data in payloads.items():
        (dest/name).write_bytes(data)
    write(dest/'engineering-validation.json',engineering)
    summary = dict(report)
    summary.update({
        'status':'completed','independent_final_audit':'passed','display_date':'27 Oct 2026',
        'index_text':'Post-hoc diagnosis: 58/80 v2 fault inputs have no target operation; annotated repairs are executable. No new model calls or demonstrated improvement.',
        'reviewed_interpretation_source_sha256':sha(HERE/'analysis/report.json'),
        'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'source_and_export_files':bindings,
        'generated_metadata':{'engineering-validation.json':{'sha256':sha(dest/'engineering-validation.json')}}
    })
    write(dest/'summary.json',summary)
    print(json.dumps({'status':'frozen_publication_package','files':len(list(dest.iterdir())),'summary_sha256':sha(dest/'summary.json')}))

if __name__ == '__main__':
    main()
