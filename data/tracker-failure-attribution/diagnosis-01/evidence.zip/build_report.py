"""Assemble the bounded diagnostic interpretation from preserved local records."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
SITE = ROOT / 'sites/conversation-agent-research'
OLD = ROOT / 'output/research/2026-10-24/tracker-lora-repair-v2'

def read(p):
    return json.loads(p.read_text(encoding='utf-8'))

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def write(p, value):
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')

def main():
    runtime = read(HERE / 'runtime/run-02/summary.json')
    curriculum = read(HERE / 'data-audit/result-01.json')
    old = read(OLD / 'analysis/three-arm-results.json')
    assert runtime['captured_replay']['assignments'] == 600
    assert runtime['captured_replay']['all_complete_runtime_results_exactly_reproduced']
    groups = {(r['arm'],r['fault_kind']):r['counts'] for r in runtime['fault_assignment_aggregates']}
    v2 = groups['tracker_lora_v2','all_faults']
    assert v2['boundary_correct_target_under_frozen_review'] == 20
    assert v2['boundary_no_target_related_operation_proposed'] == 58
    assert v2['boundary_target_related_operation_committed_but_not_fully_correct'] == 2
    assert v2.get('runtime_invalid_patch',0) == 0
    assert v2['empty_parsed_proposal'] == 14 and v2['only_other_identity_operations_proposed'] == 44
    rows = []
    for kind, label in [('missing','Missing intent'),('owner','Wrong owner'),('stale_active','Withdrawn request still active'),('status','Wrong status'),('text','Wrong value or qualifier'),('wrong_withdrawn','Active request wrongly withdrawn')]:
        g = groups['tracker_lora_v2',kind]
        rows.append({'kind':kind, 'label':label, 'inputs':g['assignments'],
            'fully_correct':g.get('frozen_target_fully_correct',0),
            'no_target_operation':g.get('boundary_no_target_related_operation_proposed',0),
            'related_operation_still_incorrect':g.get('boundary_target_related_operation_committed_but_not_fully_correct',0),
            'invalid':g.get('runtime_invalid_patch',0)})
    assert sum(r['inputs'] for r in rows) == 80
    counts = curriculum['splits']['train']['groups']
    assert counts['owner']['explicit_fields']['owner'] == 30
    assert counts['wrong_withdrawn']['operation_types']['reopen'] == 8
    prior = read(OLD / 'publication/prior-bundles.json')['files']
    prior = prior + [{'path_relative_to_site':'dist/data/tracker-lora-repair-v2/results-01/evidence.zip',
                      'sha256':'6cb402fa6c67caa26a814bb13a01681f98d2bfbedec2a801f2b20b6d8eee95e4'}]
    assert len(prior) == 10 and all(sha(SITE / p['path_relative_to_site']) == p['sha256'] for p in prior)
    write(HERE / 'analysis/prior-bundles.json', {'kind':'prior_evidence_preservation','date':'2026-10-27','files':prior})
    report = {
        'id':'tracker-failure-attribution','type':'post_hoc_scripted_diagnostic',
        'status':'completed_pending_independent_audit', 'date':'2026-10-27', 'timezone':'America/Halifax',
        'created_at_utc':datetime.now(timezone.utc).isoformat(),
        'title':'Where tracker repairs fail before state execution',
        'lead':'In the captured v2 outputs, 58 of 80 corrupted-prior inputs propose no operation on the erroneous intent. All 80 annotated repair controls can be executed by the frozen runtime. This locates an observable failure boundary; it does not establish why the model missed the repair or prove a better tracker.',
        'problem':'The revised tracker failed every wrong-owner and mistaken-withdrawal case and regressed on uncertain intents. Determine whether source evidence, repair proposals, runtime execution or label ambiguity explain the observed outcomes.',
        'baseline':'The frozen 24 October three-arm experiment: adapter disabled, tracker LoRA v1 and tracker LoRA v2, sharing the same base model and runtime; 200 independently compiled prefix inputs from 40 families per arm. Overall v1-to-v2 quality benefit remains unestablished.',
        'change':'No model, adapter, prompt, training data or runtime change. Replay captured proposals; execute original annotated patches as scripted feasibility controls; inspect source evidence and existing sealed judgments.',
        'comparison_conditions':'All 18 protocol-locked dependencies match. All 600 captured complete runtime results reproduce exactly. Original reviewed quality labels are reused, with no re-scoring or replacement of earlier results.',
        'new_model_calls':0, 'new_training_runs':0,
        'captured_assignments':600, 'scenario_families':40, 'unique_inputs':200,
        'v2_fault_breakdown':rows,
        'v2_fault_totals':{'inputs':80,'fully_correct':20,'no_target_operation':58,'related_operation_still_incorrect':2,'invalid':0,'empty_proposals':14,'other_identity_only':44},
        'observations':[
            'V2 repairs 20/80 corrupted targets. Of the 60 remaining failures, 58 have no operation on the existing or semantically matched target; 14 proposals are empty and 44 contain only other-identity operations. Two contain a related committed operation but remain incorrect. All 80 proposals are accepted.',
            'All three arms repair 0/20 wrong-owner targets. The adapter-disabled arm touches 12 targets, including 10 text updates that omit owner and two withdrawals; both tracker LoRAs touch none. Some captured text updates cite the original ownership evidence, so a blanket claim that the model never encountered the historical source is unsupported.',
            'V2 touches and repairs 0/5 mistakenly withdrawn targets. The adapter-disabled and v1 arms each restore 2/5 target states, but those four reopen operations cite insufficient evidence. State correctness and evidence sufficiency remain distinct.',
            'V1-to-v2 uncertain-intent correctness decreases from 18/24 to 14/24: 14 retained correct, four regressed, none recovered, six incorrect in both. The regressions comprise two empty patches at initial introduction, one unrelated content overwrite, and one explicit promotion to active.',
            'Five injected active-status faults on uncertain intentions remain active in all three arms. The current metadata and stored history agree on the wrong status; raw dialogue and record wording say the user is undecided. A check only comparing the state with its own history would miss these contradictions.',
            'The original 200 annotated patches are accepted and exactly match their original projected references while preserving annotated unrelated fields. They match 198/200 amended references; the two known ordinary text omissions are disclosed. All 80 corrupted-prior controls match the complete amended reference projection (intent ID, text, owner and status).',
            'All 80 repair evidence sets are available in the arrived dialogue and at or before the processed cursor. The runtime accepts these historical citations. This rules out an interface prohibition on citing processed evidence for these cases; it does not establish model attention or a cursor-induced cause.',
            'Training already contains 30 explicit owner updates, 14 status updates and eight reopen repairs, within 140 corrupted-prior inputs out of 500 updates. These counts rule out zero exposure to the operations, not insufficient diversity, weighting or learning.'
        ],
        'hypotheses_not_established':[
            'A tracker may prioritize the latest delta over auditing prior state.',
            'Repeated wrong metadata in state and history may be treated as more authoritative than raw dialogue.',
            'Field-specific repair supervision may be insufficient despite examples being present.',
            'A separate audit step or revised training distribution may improve repair; this requires a controlled model experiment.'
        ],
        'next_discriminating_experiment_proposal':{
            'status':'not_run',
            'first_test':'Freeze a fresh development set of paired correct/corrupted priors, including no-change and uncertain-intent negative controls. With the same trained adapter, compare the current single-pass tracker against an explicit field-by-field evidence audit under a matched total inference budget.',
            'separate_followup':'Only after mechanism tests, compare matched-training-budget curricula that vary repair diversity or weight; do not simultaneously change data, prompt and runtime.',
            'success_conditions':['More fully correct repairs, including owner and reopen, without increased false repairs of already-correct state.','Preserve uncertainty, source sufficiency and unrelated constraints; report cost and family-level uncertainty.','Reserve another unseen family set for final evaluation; current exposed cases remain diagnostic material.']
        },
        'review_scope':'Retrospective unblinded model inspection of all 25 owner/withdrawal inputs across three arms (75 assignments), plus all 24 uncertain reference units across three arms (72 arm-unit checks; eight families, three independent prefixes each). These views overlap and are not 147 independent scenarios. No independent human annotation is claimed.',
        'limitations':[
            'This is post-hoc diagnosis on exposed synthetic data with existing model-authored/model-reviewed labels, not fresh held-out evidence or a human study.',
            'The structural replay covers all 600 outputs; new detailed source inspection focuses on owner, mistaken withdrawal and uncertainty. It does not newly adjudicate every semantic label across all fault types.',
            'The unit is an independently supplied one-step prefix. Later correctness does not demonstrate longitudinal self-recovery or end-to-end work completion.',
            'Reference patch controls demonstrate executable annotated operations, not model ability to produce them.',
            'Target matching inherits the sealed semantic judgments. A literal ID reused for an unrelated new intent is not evidence of missing-intent repair.',
            'The observed boundaries cannot distinguish attention, state authority, prompt interpretation, data balance or optimization as internal causes.',
            'No new model inference, training, ASR, user study or end-to-end quality benefit is claimed.'
        ],
        'diagnostic_corrections':[
            'The initial curriculum inspection encountered the legacy fault schema; the final audit explicitly recognizes 20 legacy text faults and checks manifest counts without modifying inputs.',
            'Runtime diagnostic run-01 counted a missing target\u2019s reference ID as target-related even when reused for another intent. Run-02 uses sealed semantic candidate matching for missing targets; both scripts and summaries are preserved. The v2 no-target-operation count changes from 54 to 58, with no change to original quality results.'
        ],
        'sources':{p.relative_to(ROOT).as_posix():sha(p) for p in [HERE/'runtime/run-02/summary.json', HERE/'data-audit/result-01.json', OLD/'analysis/three-arm-results.json', Path(__file__).resolve()]}
    }
    write(HERE / 'analysis/report.json', report)
    print(json.dumps({'status':'report_prepared_for_independent_review','v2_breakdown':report['v2_fault_totals'],'preserved_prior_bundles':10}))

if __name__ == '__main__':
    main()
