"""Independent source-to-claim audit; no model inference or training.

Uses captured proposals/sealed labels directly rather than trusting the new
diagnostic aggregates. Reexecutes only the 200 original reference patches as a
bounded independent check of the executable-control claim.
"""
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = next(p for p in Path(__file__).resolve().parents if (p / 'AGENTS.md').exists())
HERE = Path(__file__).resolve().parent
NEW = HERE.parent
OLD = ROOT / 'output/research/2026-10-24/tracker-lora-repair-v2'
ARMS = ('adapter_disabled','tracker_lora_v1','tracker_lora_v2')
BINDINGS = {}

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def bind(p):
    p = Path(p).resolve()
    BINDINGS[p.relative_to(ROOT).as_posix()] = sha(p)
    return p

def read(p):
    return json.loads(bind(p).read_text(encoding='utf-8-sig'))

def lines(p):
    return [json.loads(s) for s in bind(p).read_text(encoding='utf-8-sig').splitlines() if s]

def digest(v):
    return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def project(state):
    return [{k:r[k] for k in ('intent_id','owner','text','status')} for r in state['intents']]

def full(c):
    return c['meaning']=='equivalent' and c['owner_correct'] is True and c['status_correct'] is True

def smap(state):
    return {r['intent_id']:r for r in state}

def main():
    report = read(NEW/'analysis/report.json')
    assert report['date']=='2026-10-27'
    for p,h in report['sources'].items():
        assert sha(bind(ROOT/p))==h
    lock=read(OLD/'evaluation/protocol-lock.json')
    assert len(lock['files'])==18
    for item in lock['files'].values():
        assert sha(bind(Path(item['path'])))==item['sha256']
    rows=lines(OLD/'data/compiled/test.records.jsonl')
    outputs={(x['row_index'],x['arm']):x for x in lines(OLD/'evaluation/collection-01/outputs.jsonl')}
    maps=read(OLD/'evaluation/blind-prepared-reference-01/PRIVATE-mapping.json')['assignments']
    packets={x['blind_id']:x for x in read(OLD/'evaluation/blind-prepared-reference-01/review-packets.json')['packets']}
    judgments={x['blind_id']:x for x in read(OLD/'evaluation/blind-sealed-reference-01/final-judgments.json')}
    historic={x['assignment_id']:x['result'] for x in read(OLD/'evaluation/blind-prepared-reference-01/PRIVATE-runtime-results.json')}
    previous=read(OLD/'analysis/three-arm-results.json')
    published=read(OLD/'publication/results-01/results.json')
    assert previous['arms']==published['arms']
    assignments={x['assignment_id']:x for x in read(NEW/'runtime/run-02/PRIVATE-assignment-analysis.json')}
    faults={x['assignment_id']:x for x in read(NEW/'runtime/run-02/PRIVATE-fault-target-analysis.json')}
    run2=read(NEW/'runtime/run-02/summary.json')
    run1=read(NEW/'runtime/run-01/summary.json')
    for run in (run1,run2):
        for p,h in run['source_hashes'].items():
            assert sha(bind(ROOT/p))==h
    assert len(rows)==200 and len({r['family_id'] for r in rows})==40
    assert len(maps)==len(outputs)==len(assignments)==600 and len(faults)==240
    assert set(outputs)=={(i,a) for i in range(200) for a in ARMS}
    mapping={(x['row_index'],x['arm']):x for x in maps}
    counts=defaultdict(Counter)
    source_owner_citations=0
    for m in maps:
        i,a,ident=m['row_index'],m['arm'],m['assignment_id']
        row,out,h,p,j=rows[i],outputs[i,a],historic[ident],packets[m['blind_id']],judgments[m['blind_id']]
        assert digest(out)==m['output_sha256']
        assert json.loads(out['output_text'])==h['proposal']
        assert h['proposal']['operations']==p['candidate_operations']
        assert project(h['post_state'])==p['candidate_state']
        ar=assignments[ident]
        assert ar['proposal_operations']==h['proposal']['operations']
        assert ar['validity']==h['validity'] and ar['committed']==h['committed'] and ar['runtime_error']==h['error']
        assert ar['before_projected_sha256']==digest(project(row['input']['intention_state']))
        assert ar['after_projected_sha256']==digest(project(h['post_state']))
        if not h['committed']:
            assert h['post_state']==row['input']['intention_state']
        f=row.get('prior_fault_annotation')
        if not f:continue
        c=next(c for c in j['reference_checks'] if c['reference_intent_id']==f['intent_id'])
        ops=h['proposal']['operations']
        target_ids=set(c['matched_candidate_ids'])
        if f['fault_kind']!='missing':target_ids.add(f['intent_id'])
        inds=[ix for ix,op in enumerate(ops) if op['intent_id'] in target_ids]
        detail=faults[ident]
        assert detail['frozen_reference_check']==c
        assert detail['target_fully_correct']==full(c)
        assert detail['target_related_operation_indices']==inds
        assert detail['target_related_operations']==[ops[ix] for ix in inds]
        sources=f['repair_source_seqs']
        assert set(sources)<={e['seq'] for e in row['input']['conversation']}
        assert all(s<=row['input']['intention_state']['processed_event_seq'] for s in sources)
        boundary=(h['validity'] if not h['committed'] else 'correct_target_under_frozen_review' if full(c) else 'target_related_operation_committed_but_not_fully_correct' if inds else 'no_target_related_operation_proposed')
        assert detail['observable_boundary']==boundary
        for kind in ('all_faults',f['fault_kind']):
            g=counts[a,kind]
            g['assignments']+=1
            g['boundary_'+boundary]+=1
            g['frozen_target_fully_correct']+=full(c)
            g['target_identity_touched_in_proposal']+=bool(inds)
            g['empty_parsed_proposal']+=not ops
            g['only_other_identity_operations_proposed']+=bool(ops) and not inds
            g['runtime_'+h['validity']]+=1
        if f['fault_kind']=='owner' and a=='adapter_disabled':
            direct=[op for op in ops if op['intent_id']==f['intent_id']]
            source_owner_citations+=any(set(sources)<=set(op['source_seqs']) for op in direct)
    for g in run2['fault_assignment_aggregates']:
        c=counts[g['arm'],g['fault_kind']]
        for k,v in c.items():assert g['counts'].get(k,0)==v
    assert source_owner_citations==7
    for a in ARMS:
        assert counts[a,'all_faults']['frozen_target_fully_correct']==previous['arms'][a]['counts']['fully_correct_repair_targets']
    v2=counts['tracker_lora_v2','all_faults']
    assert [v2[k] for k in ('assignments','frozen_target_fully_correct','boundary_no_target_related_operation_proposed','boundary_target_related_operation_committed_but_not_fully_correct','empty_parsed_proposal','only_other_identity_operations_proposed')]==[80,20,58,2,14,44]
    for r in report['v2_fault_breakdown']:
        c=counts['tracker_lora_v2',r['kind']]
        assert r['inputs']==c['assignments'] and r['fully_correct']==c['frozen_target_fully_correct']
        assert r['no_target_operation']==c['boundary_no_target_related_operation_proposed']
        assert r['related_operation_still_incorrect']==c['boundary_target_related_operation_committed_but_not_fully_correct']
        assert r['invalid']==c['runtime_invalid_patch']

    # Independently reproduce the bounded original controls in the frozen runtime.
    path=Path(lock['files']['legacy_evaluator']['path'])
    spec=importlib.util.spec_from_file_location('independent_frozen_replay',path)
    legacy=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(legacy)
    controls=read(NEW/'runtime/run-02/PRIVATE-reference-controls.json')
    assert len(controls)==200
    amended_equal=fault_equal=0
    for i,(row,control) in enumerate(zip(rows,controls)):
        result=legacy.apply_candidate(row,{'status':'completed','output_text':json.dumps(row['target'],ensure_ascii=False)})
        assert result['committed'] and result['validity']=='valid_patch'
        candidate=project(result['post_state'])
        assert candidate==row['expected_semantic_state']
        assert digest(candidate)==control['after_projected_sha256']
        before=smap(project(row['input']['intention_state']))
        after=smap(candidate)
        assert all(before[k]==after[k] for k in row['preserve_ids'])
        ref=packets[mapping[i,ARMS[0]]['blind_id']]['reference_state']
        equal=candidate==ref
        assert equal==control['matches_amended_full_reference_literally']
        amended_equal+=equal
        if row.get('prior_fault_annotation'):
            assert equal
            fault_equal+=1
    assert amended_equal==198 and fault_equal==80

    # Curriculum claims are reconstructed from the exact training records.
    curriculum=read(NEW/'data-audit/result-01.json')
    manifest=read(OLD/'data/compiled/manifest.json')
    for split in ('train','dev','test'):
        path=OLD/f'data/compiled/{split}.records.jsonl'
        rs=lines(path)
        assert sha(path)==manifest['files'][path.name]['sha256']
        bykind=Counter()
        fieldops=defaultdict(Counter)
        for r in rs:
            f=r.get('prior_fault_annotation')
            if not f:continue
            k=f.get('fault_kind','legacy_text')
            if k=='legacy_text':assert split=='train' and 'wrong_text' in f and 'repair_text' in f
            bykind[k]+=1
            op=next(o for o in r['target']['operations'] if o['intent_id']==f['intent_id'])
            fieldops[k]['op_'+op['op']]+=1
            for field in ('owner','status','text'):fieldops[k][field]+=field in op
        assert dict(bykind)==manifest['fault_kinds_by_split'][split]
        assert len(rs)==curriculum['splits'][split]['updates']
        assert sum(bykind.values())==curriculum['splits'][split]['fault_inputs']
        for k,n in bykind.items():
            cg=curriculum['splits'][split]['groups'][k]
            assert n==cg['inputs']
            for field,nf in cg['explicit_fields'].items():assert fieldops[k][field]==nf
            for op,no in cg['operation_types'].items():assert fieldops[k]['op_'+op]==no

    owner=read(NEW/'semantic/owner-withdrawal-review.json')
    odetail=read(NEW/'semantic/PRIVATE-owner-withdrawal-review-details.json')
    assert len(odetail['cases'])==25 and sum(len(c['arms']) for c in odetail['cases'])==75
    owner_groups=defaultdict(Counter)
    for c in odetail['cases']:
        row=rows[c['source_row_index']]
        assert c['arrived_conversation']==row['input']['conversation']
        assert c['actual_prior_full_state']==row['input']['intention_state']
        assert c['compiled_all_operations']==row['target']['operations']
        for a in c['arms']:
            m=mapping[c['source_row_index'],a['arm']]
            h=historic[m['assignment_id']]
            assert a['actual_operations']==h['proposal']['operations']
            check=next(x for x in judgments[m['blind_id']]['reference_checks'] if x['reference_intent_id']==c['repair_reference_id'])
            assert a['frozen_target_check_unchanged']==check
            g=owner_groups[c['fault_kind'],a['arm']]
            g['assignments']+=1
            g['target_state_fully_correct_frozen']+=full(check)
            direct=[op for op in a['actual_operations'] if op['intent_id']==c['repair_reference_id']]
            g['target_touched']+=bool(direct)
            g['target_text_update']+=any(op['op']=='update' and 'text' in op for op in direct)
            g['target_reopen_proposed']+=any(op['op']=='reopen' for op in direct)
            g['target_wrongly_withdrawn']+=any(op['op']=='withdraw' for op in direct)
            g['correct_fault_field_revision_proposed']+=a['observable_attribution']['correct_fault_field_revision_explicitly_proposed']
            g['candidate_retains_faulty_supplied_field']+=a['observable_attribution']['candidate_retains_faulty_supplied_field']
    for g in owner['aggregates_by_fault_and_arm']:
        for k,n in owner_groups[g['fault_kind'],g['arm']].items():assert g[k]==n

    # Uncertainty checks derive units and pair outcomes directly from sealed sources.
    uncertain={}
    uncertain_families=Counter()
    for i,row in enumerate(rows):
        ref=packets[mapping[i,ARMS[0]]['blind_id']]['reference_state']
        for r in ref:
            if r['status']!='uncertain':continue
            uncertain_families[row['family_id']]+=1
            checks={}
            for a in ARMS:
                j=judgments[mapping[i,a]['blind_id']]
                checks[a]=next(c for c in j['reference_checks'] if c['reference_intent_id']==r['intent_id'])
            uncertain[i,r['intent_id']]=checks
    assert len(uncertain)==24 and len(uncertain_families)==8 and set(uncertain_families.values())=={3}
    joint=Counter((full(c['tracker_lora_v1']),full(c['tracker_lora_v2'])) for c in uncertain.values())
    assert joint==Counter({(True,True):14,(True,False):4,(False,True):0,(False,False):6})
    ucorrect={a:sum(full(c[a]) for c in uncertain.values()) for a in ARMS}
    for a,n in ucorrect.items():assert previous['arms'][a]['counts']['fully_correct_uncertain_units']==n
    status_cases=[]
    for (i,k),cs in uncertain.items():
        row=rows[i];f=row.get('prior_fault_annotation')
        if not f or f['fault_kind']!='status' or f['intent_id']!=k:continue
        prior=next(r for r in row['input']['intention_state']['intents'] if r['intent_id']==k)
        assert prior['status']=='active' and prior['history'][-1]['state']['status']=='active'
        for a in ARMS:
            candidate=smap(packets[mapping[i,a]['blind_id']]['candidate_state'])
            assert candidate[k]['status']=='active'
        status_cases.append(i)
    assert len(status_cases)==5
    # This source record must exist and agree before the audit passes.
    uncertainty=read(NEW/'semantic/uncertainty-review.json')
    ud=read(NEW/'semantic/PRIVATE-uncertainty-case-review.json')
    assert len(ud['cases'])==24 and sum(len(c['arms']) for c in ud['cases'])==72
    assert uncertainty['scope']['arm_unit_assignments_reviewed']==72
    assert uncertainty['v1_to_v2_matched_unit_transitions']=={'retained_correct':14,'regressed':4,'recovered':0,'both_wrong':6}
    umat=defaultdict(Counter)
    uerrors=defaultdict(Counter)
    for c in ud['cases']:
        i,k=c['row_index'],c['reference_intent_id']
        row=rows[i]
        assert c['arrived_conversation']==row['input']['conversation']
        assert c['full_before_state']==row['input']['intention_state']
        assert c['prior_fault_annotation']==row.get('prior_fault_annotation')
        for a in c['arms']:
            arm=a['arm'];m=mapping[i,arm];h=historic[m['assignment_id']];p=packets[m['blind_id']]
            assert a['actual_operations']==h['proposal']['operations']
            assert a['actual_candidate_state']==p['candidate_state']
            assert a['sealed_reference_check_unchanged']==uncertain[i,k][arm]
            assert a['source_output_record_sha256']==digest(outputs[i,arm])
            assert a['sealed_fully_correct']==full(uncertain[i,k][arm])
            assert h['validity']=='valid_patch' and h['committed'] and not h['error']
            umat[arm][a['manual_attribution']]+=1
            uerrors[arm]['units']+=1
            uerrors[arm]['fully_correct']+=a['sealed_fully_correct']
            for dim,flag in a['sealed_errors'].items():uerrors[arm][dim]+=flag
    for arm in ARMS:
        assert dict(umat[arm])==uncertainty['manual_attribution_counts'][arm]
        for k,n in uerrors[arm].items():assert uncertainty['sealed_uncertainty_results'][arm][k]==n
    for record in (owner,odetail):
        for s in record['source_artifacts']:assert sha(bind(ROOT/s['path']))==s['sha256']
    for record in (uncertainty,ud):
        for s in record['source_bindings'].values():assert sha(bind(OLD/s['study_relative_path']))==s['sha256']

    prior=read(NEW/'analysis/prior-bundles.json')
    assert len(prior['files'])==10
    for p in prior['files']:
        assert sha(bind(ROOT/'sites/conversation-agent-research'/p['path_relative_to_site']))==p['sha256']
    bind(__file__)
    for p,h in BINDINGS.items():assert sha(ROOT/p)==h
    receipt={'status':'passed','date':'2026-10-27','timezone':'America/Halifax',
             'created_at_utc':datetime.now(timezone.utc).isoformat(),
             'reviewed_report_sha256':sha(NEW/'analysis/report.json'),
             'scope':'Independent source-to-claim structural audit; separate manual representative source inspection is recorded in final-review.json.',
             'counts':{'protocol_dependencies':18,'captured_output_and_record_joins':600,'fault_target_source_checks':240,'aggregate_groups':21,
                 'independently_reexecuted_original_controls':200,'controls_equal_original_reference':200,'controls_equal_amended_reference':198,'fault_controls_equal_full_amended_projection':80,
                 'owner_withdrawal_assignments':75,'uncertainty_arm_units':72,'uncertainty_families':8,'uncertainty_correct_v1':18,'uncertainty_correct_v2':14,'injected_active_status_faults_retained_in_all_arms':5,
                 'v2_faults_correct':20,'v2_faults_without_target_operation':58,'v2_related_operations_still_incorrect':2,'v2_empty_proposals':14,'v2_other_identity_only':44,'base_owner_operations_citing_original_evidence':7,'prior_bundles_preserved':10},
             'new_model_inference_calls':0,'new_training_runs':0,'source_hashes':dict(sorted(BINDINGS.items()))}
    dest=HERE/'computed-checks.json'
    with dest.open('x',encoding='utf-8') as out:json.dump(receipt,out,ensure_ascii=False,indent=2);out.write('\n')
    print(json.dumps({'status':'passed','reviewed_report_sha256':receipt['reviewed_report_sha256'],'source_bindings':len(BINDINGS),'receipt_sha256':sha(dest)}))

if __name__=='__main__':
    main()
