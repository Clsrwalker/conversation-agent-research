"""Read-only output integrity and aggregate QA; writes one new receipt."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = next(p for p in HERE.parents if (p / 'AGENTS.md').exists())

def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def check(condition, message):
    if not condition:
        raise ValueError(message)

summaries = {n: read(HERE / n / 'summary.json') for n in ('run-01', 'run-02')}
source_count = {}
for run, summary in summaries.items():
    for relative, expected in summary['source_hashes'].items():
        check(sha(ROOT / relative) == expected, f'{run} source binding: {relative}')
    for name, expected in summary['private_record_hashes'].items():
        check(sha(HERE / run / name) == expected, f'{run} output binding: {name}')
    source_count[run] = len(summary['source_hashes'])

old = read(HERE / 'run-01/PRIVATE-fault-target-analysis.json')
faults = read(HERE / 'run-02/PRIVATE-fault-target-analysis.json')
assignments = read(HERE / 'run-02/PRIVATE-assignment-analysis.json')
controls = read(HERE / 'run-02/PRIVATE-reference-controls.json')
check(len(assignments) == 600 and len(faults) == 240 and len(controls) == 200, 'Coverage')
check(len({r['assignment_id'] for r in assignments}) == 600, 'Duplicate assignments')
check(len({r['assignment_id'] for r in faults}) == 240, 'Duplicate fault assignments')
assigned = {r['assignment_id']: r for r in assignments}
old_faults = {r['assignment_id']: r for r in old}
old_assignments = {r['assignment_id']: r for r in read(HERE / 'run-01/PRIVATE-assignment-analysis.json')}
changed_identity = Counter()
for f in faults:
    a = assigned[f['assignment_id']]
    check(a['fault_target_analysis'] == f, 'Private row join')
    check(a['proposal_present'], 'Unexpected unparseable output in captured study')
    check(a['proposal_operations'] == old_assignments[a['assignment_id']]['proposal_operations'], 'Captured operations changed')
    operations = a['proposal_operations']
    identities = set(f['meaning_matched_candidate_ids'])
    if f['fault_kind'] != 'missing':
        identities.add(f['reference_intent_id'])
    expected_indices = [i for i, op in enumerate(operations) if op.get('intent_id') in identities]
    check(expected_indices == f['target_related_operation_indices'], 'Target identity accounting')
    check([operations[i] for i in expected_indices] == f['target_related_operations'], 'Target operation list')
    previous = old_faults[f['assignment_id']]
    check(f['frozen_reference_check'] == previous['frozen_reference_check'], 'Frozen semantic judgment changed')
    check(f['target_fully_correct'] == previous['target_fully_correct'], 'Correctness changed')
    if bool(expected_indices) != previous['target_related_operation_present']:
        check(f['fault_kind'] == 'missing' and not expected_indices, 'Unexpected revision effect')
        changed_identity[f['arm']] += 1

checked_groups = 0
compact_groups = []
for aggregate in summaries['run-02']['fault_assignment_aggregates']:
    arm, kind, counts = aggregate['arm'], aggregate['fault_kind'], aggregate['counts']
    group = [f for f in faults if f['arm'] == arm and (kind == 'all_faults' or f['fault_kind'] == kind)]
    observed = {
        'assignments': len(group),
        'frozen_target_fully_correct': sum(f['target_fully_correct'] for f in group),
        'target_identity_touched_in_proposal': sum(bool(f['target_related_operations']) for f in group),
        'target_literal_fields_unchanged_from_input': sum(f['target_before'] == f['target_after_same_id'] for f in group),
        'empty_parsed_proposal': sum(f['proposal_present'] and f['proposal_operation_count'] == 0 for f in group),
        'only_other_identity_operations_proposed': sum(f['proposal_operation_count'] > 0 and not f['target_related_operations'] for f in group),
    }
    check(all(counts.get(k, 0) == v for k, v in observed.items()), 'Aggregate mismatch')
    boundaries = Counter(f['observable_boundary'] for f in group)
    check(sum(v for k, v in counts.items() if k.startswith('boundary_')) == len(group), 'Boundary partition')
    check(all(counts.get('boundary_' + k, 0) == v for k, v in boundaries.items()), 'Boundary count')
    checked_groups += 1
    compact_groups.append({'arm': arm, 'fault_kind': kind, **observed})

fault_controls = [c for c in controls if c['fault_kind']]
check(len(fault_controls) == 80 and all(c['matches_amended_full_reference_literally'] for c in fault_controls), 'Full fault control state match')
check(all(c['all_preserve_ids_unchanged'] for c in controls), 'Unrelated preservation')
check(controls == read(HERE / 'run-01/PRIVATE-reference-controls.json'), 'Reference controls changed between revisions')
mismatches = [c for c in controls if not c['matches_amended_full_reference_literally']]
check(len(mismatches) == 2 and all(c['fault_kind'] is None for c in mismatches), 'Known ordinary-only overlay mismatch')
check(all(len(c['known_original_reference_text_differences']) == 1 for c in mismatches), 'Expected single text amendment')
check(changed_identity == Counter({'adapter_disabled': 6, 'tracker_lora_v1': 6, 'tracker_lora_v2': 4}), 'Revision correction size')

receipt = {
    'status': 'passed', 'created_at_utc': datetime.now(timezone.utc).isoformat(),
    'date': summaries['run-02']['date'], 'timezone': 'America/Halifax',
    'source_bindings_rechecked': source_count, 'private_output_hashes_rechecked': 6,
    'captured_assignments': 600, 'fault_assignment_joins_checked': 240, 'aggregate_groups_checked': checked_groups,
    'all_reference_controls_unchanged_between_diagnostic_revisions': True,
    'fault_controls_with_full_projected_amended_state_equality': 80,
    'all_200_controls_preserve_all_annotated_unrelated_fields': True,
    'known_ordinary_original_target_vs_amended_reference_mismatches': 2,
    'semantic_judgments_unchanged': 240,
    'revision_correction': {
        'reason': 'An absent target has no prior identity. A newly added intent reusing its annotated reference ID is not automatically the same semantic target. Run-02 uses only sealed semantic matched candidate IDs for missing-target touches; existing-target rules are unchanged.',
        'missing_assignments_reclassified_from_target_touched_to_other_identity_only': dict(changed_identity),
        'original_code_and_run_retained': True,
        'run_01_superseded_only_for_missing_target_identity_aggregates': True,
        'new_model_trials': 0,
    },
    'aggregate_checks': compact_groups,
    'evidence_files': {name: sha(HERE / name) for name in ('replay_diagnostic.py', 'replay_diagnostic_v2.py', 'run-01/summary.json', 'run-02/summary.json', 'run-01.log', 'run-02.log', 'verify_runtime_artifacts.py')},
    'limits': ['This QA validates recorded-data consistency and deterministic runtime capability, not new semantic labels, internal cognition or a training benefit. Full state means the complete evaluation projection (intent ID, text, owner, status); replay equality additionally checked the entire runtime return against the historical record.'],
}
with (HERE / 'artifact-qa.json').open('x', encoding='utf-8') as stream:
    json.dump(receipt, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps({'status': 'passed', 'aggregate_groups_checked': checked_groups, 'fault_full_state_controls': 80, 'receipt_sha256': sha(HERE / 'artifact-qa.json')}, sort_keys=True))
