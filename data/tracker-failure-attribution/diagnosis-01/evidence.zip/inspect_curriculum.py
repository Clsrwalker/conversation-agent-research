"""Read-only post-hoc curriculum structure audit; no semantic inference or model calls."""
import argparse
from collections import Counter
from datetime import date, datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[5]
STUDY = ROOT / 'output/research/2026-10-24/tracker-lora-repair-v2'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--date', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    date.fromisoformat(args.date)
    assert not args.output.exists()
    manifest_path = STUDY / 'data/compiled/manifest.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    sources = {manifest_path.relative_to(ROOT).as_posix(): sha(manifest_path),
               Path(__file__).resolve().relative_to(ROOT).as_posix(): sha(Path(__file__))}
    splits = {}
    for split in ('train', 'dev', 'test'):
        path = STUDY / f'data/compiled/{split}.records.jsonl'
        assert sha(path) == manifest['files'][path.name]['sha256']
        rows = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()]
        assert len(rows) == manifest['files'][path.name]['rows']
        sources[path.relative_to(ROOT).as_posix()] = sha(path)
        faults = [r for r in rows if r.get('prior_fault_annotation')]
        def kind(row):
            fault = row['prior_fault_annotation']
            if 'fault_kind' in fault:
                return fault['fault_kind']
            assert split == 'train' and 'wrong_text' in fault and 'repair_text' in fault
            return 'legacy_text'
        groups = {}
        for fault_kind in sorted({kind(r) for r in faults}):
            selected = [r for r in faults if kind(r) == fault_kind]
            operations = [op for r in selected for op in r['target']['operations']
                          if op['intent_id'] == r['prior_fault_annotation']['intent_id']]
            assert len(operations) == len(selected)
            assert all(set(r['prior_fault_annotation']['repair_source_seqs']) <=
                       {e['seq'] for e in r['input']['conversation']} for r in selected)
            groups[fault_kind] = {
                'inputs': len(selected), 'annotated_target_operations': len(operations),
                'operation_types': dict(Counter(op['op'] for op in operations)),
                'explicit_fields': dict(Counter(k for op in operations for k in ('owner', 'text', 'status') if k in op)),
                'all_repair_evidence_at_or_before_processed_cursor': sum(
                    all(seq <= r['input']['intention_state']['processed_event_seq']
                        for seq in r['prior_fault_annotation']['repair_source_seqs']) for r in selected),
                'all_repair_source_ids_arrived': True}
        assert {k:v['inputs'] for k,v in groups.items()} == manifest['fault_kinds_by_split'][split]
        splits[split] = {'updates': len(rows), 'fault_inputs': len(faults), 'groups': groups}
    result = {'kind':'posthoc_curriculum_structure_diagnostic', 'status':'completed',
              'date':args.date, 'timezone':'America/Halifax',
              'created_at_utc':datetime.now(timezone.utc).isoformat(),
              'source_hashes':sources, 'splits':splits, 'new_model_calls':0,
              'preserved_initial_inspection_failure':{
                  'error':'KeyError: fault_kind',
                  'cause':'Twenty retained training faults use the earlier wrong_text/repair_text annotation schema.',
                  'resolution':'Explicitly recognize that schema as legacy_text and verify counts against the frozen manifest; no source data changes.'},
              'limits':['Counts inspect annotated operations and evidence indices, not whether the model learned them or whether labels are semantically correct.',
                        'Evidence existing at or before the processed cursor does not establish model attention or prove the cursor caused a failure.',
                        'This is a retrospective description of exposed data, not a new training ablation.']}
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'completed','output_sha256':sha(args.output),'faults':{k:v['fault_inputs'] for k,v in splits.items()}}))

if __name__ == '__main__':
    main()
