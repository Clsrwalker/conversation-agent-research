# Locate errors before changing the intention-role mechanism

Date: 2026-10-23, America/Halifax. Requested outcome: test the current implementation and identify where its errors occur.

This follow-up diagnoses the already executed 48-trajectory pilot. It is not a new model-quality comparison and makes no repair claim. Keep the original code freeze, logs, labels and results unchanged. No LoRA, live Lab change or new inference is required to reproduce the interface failures.

Completion requires:

1. Check current source against the original freeze and retain exact code locations.
2. Reproduce recorded tracker rejections and distinguish correct atomic rejection from missing corrective feedback and actor starvation.
3. Run a controlled private-prose versus saved-notes handoff through the actual role session and tools. Separate absent conclusions from raw evidence availability.
4. Trace all final failures back through user input, evidence, state, model proposal, executed receipt and active display. Check missing delivery separately from incorrect answer content.
5. Test the actual publication boundary with a deliberately incomplete scripted answer and a valid control, recording what the guard does and does not check.
6. Retain failing desired properties as failures. A diagnostic script completing successfully does not mean the tested behavior passed.
7. Review the evidence and update the same research page with one grouped diagnostic/validation record. Publish through the existing Sites and Pages workflow.

The scripted model is a test double. Its calls and tokens must not be presented as new model inference or measured assistance quality. Existing semantic scores are reused explicitly; string/snippet analysis is only a way to locate evidence. Seeing a fact in input does not establish that the model attended to it. Existing native optional delivery recovery is a separate path and must not be described as absent from the whole project.
