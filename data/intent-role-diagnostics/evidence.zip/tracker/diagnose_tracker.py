"""Read-only replay + network-disabled scripted diagnostics of the current tracker.

Run from any cwd with the repository virtualenv and -B. Outputs are new-only.
No source, original SQLite store, fixture, model answer, or original score is edited.
Expected product-property failures are reported as failures, not green unit tests.
"""
from __future__ import annotations

import argparse
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
ROOT = next(parent for parent in HERE.parents if (parent / 'experiments/deep_conversation').is_dir())
sys.path.insert(0, str(ROOT / 'experiments/deep_conversation'))
sys.dont_write_bytecode = True

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from pydantic import PrivateAttr

from config import Settings
from intention_state import IntentStore
from intent_roles import IntentRoleSession
from world import WorldStore

STUDY = ROOT / 'output/research/2026-10-23/intent-role-separation'


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False)


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def relative(path):
    return path.relative_to(ROOT).as_posix()


class TracedStore(IntentStore):
    """Observe the first failing original method without changing its behavior."""
    def _apply_operation(self, operation, touched, through_seq, version, patch_id):
        index = len(touched)
        old = next((i for i in self._snapshot()['intents']
                    if i['intent_id'] == operation.get('intent_id')), None)
        try:
            return super()._apply_operation(operation, touched, through_seq, version, patch_id)
        except Exception as error:
            self.failure = {'operation_index': index, 'operation': deepcopy(operation),
                            'target_before_operation': old,
                            'error_type': type(error).__name__, 'message': str(error)}
            raise


def classify(failure):
    if failure is None:
        return 'proposal_parse_or_envelope'
    message, operation = failure['message'], failure['operation']
    if 'explicit reopen' in message:
        return operation['op'] + '_withdrawn_intent'
    if 'touch each intention only once' in message:
        return 'duplicate_target_in_one_patch'
    if 'arrived event' in message:
        return 'unregistered_or_future_source_seq'
    return message


def replay_recorded(output):
    runs, all_errors, mismatches = [], [], []
    for original in sorted((STUDY / 'evaluation/runs').glob('*--tracked--*/steps.jsonl')):
        records = [json.loads(line) for line in original.read_text(encoding='utf-8').splitlines()]
        store = TracedStore(output / 'recorded-replay' / original.parent.name / 'intention.sqlite')
        tracker_count = 0
        try:
            for record in records:
                store.observe(record['input']['conversation'])
                expected = record['input']['intention_state']
                for receipt in expected['receipts']:
                    store.report_result(receipt['receipt_id'], receipt['intent_version'], receipt['payload'])
                before = store.snapshot()
                if before != expected:
                    mismatches.append({'run': original.parent.name, 'step': record['step'], 'kind': 'prestate'})
                if record['role'] != 'tracker':
                    continue
                tracker_count += 1
                store.failure = None
                error = None
                result = None
                try:
                    proposal = json.loads(record['response']['content'])
                    if set(proposal) != {'operations'}:
                        raise ValueError('Tracker must return exactly an operations object')
                    result = store.commit_patch(f'intent-role-step-{record["step"]}',
                                                before['version'], before['observed_event_seq'],
                                                proposal['operations'])
                except Exception as caught:
                    error = {'type': type(caught).__name__, 'message': str(caught)}
                if error != record.get('error'):
                    mismatches.append({'run': original.parent.name, 'step': record['step'],
                                       'kind': 'error', 'actual': error, 'recorded': record.get('error')})
                if result != record.get('tracker_commit'):
                    mismatches.append({'run': original.parent.name, 'step': record['step'], 'kind': 'commit'})
                if error:
                    entry = {'run_id': original.parent.name, 'step': record['step'],
                             'stage': record['step'] // 6 + 1, 'class': classify(store.failure),
                             'error': error, 'rollback_unchanged': before == store.snapshot(),
                             'prestate_matches_record': before == expected,
                             'input_source': relative(original), 'input_line': record['step'] + 1,
                             'before': before, 'first_rejected_operation': store.failure,
                             'recorded_usage': record['response'].get('usage_metadata')}
                    all_errors.append(entry)
            runs.append({'run_id': original.parent.name, 'steps_reconstructed': len(records),
                         'tracker_proposals_replayed': tracker_count})
        finally:
            store.close()
    write(output / 'recorded-errors.json', all_errors)
    return {'runs': runs, 'run_count': len(runs),
            'pre_call_snapshots_reconstructed': sum(r['steps_reconstructed'] for r in runs),
            'tracker_proposals_replayed': sum(r['tracker_proposals_replayed'] for r in runs),
            'rejected_proposals': len(all_errors),
            'failure_classes': dict(Counter(e['class'] for e in all_errors)),
            'affected_runs': sorted({e['run_id'] for e in all_errors}),
            'affected_run_stages': sorted({f"{e['run_id']}::stage-{e['stage']}" for e in all_errors}),
            'all_failed_patches_rolled_back': all(e['rollback_unchanged'] for e in all_errors),
            'mismatches': mismatches,
            'interpretation': 'Replays recorded proposals through current validation. No model rerun and no new quality score.'}


class ScriptedTrackerModel(BaseChatModel):
    """A deterministic protocol double; zero real inference or HTTP requests."""
    model_name: str = 'scripted:tracker-diagnostics'
    scenario: str
    _requests: list = PrivateAttr(default_factory=list)

    @property
    def _llm_type(self):
        return 'offline-tracker-diagnostic'

    def bind_tools(self, tools, **kwargs):
        return self

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        self._requests.append(deepcopy(messages))
        packet = json.loads(messages[-1].content)
        role = next(r for r in ('tracker', 'work', 'chat') if f'ROLE: {r}.' in messages[0].content)
        content = 'Private scripted actor response; no delivery is being tested.'
        if role == 'tracker':
            source = packet['conversation'][-1]['seq']
            stage = len(packet['conversation'])
            if stage == 1:
                operation = {'op': 'add', 'intent_id': 'request', 'owner': 'Ada',
                             'text': 'Explain Beacon desktop offline support, using a free option.',
                             'source_seqs': [source]}
            elif self.scenario == 'valid_update':
                operation = {'op': 'update', 'intent_id': 'request', 'source_seqs': [source],
                             'text': ('Explain Beacon mobile offline support, using a free option.'
                                      if stage == 2 else
                                      'Explain Beacon mobile offline support and export, using a free option.')}
            elif stage == 2:
                operation = {'op': 'withdraw', 'intent_id': 'request', 'source_seqs': [source]}
            elif self.scenario == 'explicit_reopen':
                operation = {'op': 'reopen', 'intent_id': 'request', 'source_seqs': [source]}
            else:
                operation = {'op': 'update', 'intent_id': 'request', 'status': 'active',
                             'text': 'Explain Beacon desktop offline support, using a free option.',
                             'source_seqs': [source]}
            content = json.dumps({'operations': [operation]})
        return ChatResult(generations=[ChatGeneration(message=AIMessage(content=content,
            usage_metadata={'input_tokens': 11, 'output_tokens': 3, 'total_tokens': 14}))])


def scripted_scenario(output, scenario, restart=False):
    directory = output / 'scripted' / (scenario + ('-restart' if restart else ''))
    texts = ['Explain Beacon desktop offline support, using a free option.']
    texts += (['Switch to mobile, retaining the free option.', 'Also explain its export support.']
              if scenario == 'valid_update' else
              ['Withdraw that request.', 'Reopen my original desktop request, retaining the free option.'])
    case = {'case_id': 'scripted-tracker-diagnostic', 'corpus_ids': [], 'close_at_ms': 18000,
            'tool_latency_ms': {'search': 50, 'read': 50},
            'events': [{'kind': 'asr_final', 'at_ms': index * 6000, 'segment_id': f's{index}',
                        'speaker': 'Ada', 'text': text} for index, text in enumerate(texts)]}
    settings = Settings(preset='agent-led', model='scripted:tracker-diagnostics',
                        max_calls=18, max_tokens=180000, model_latency_ms=100)
    world = WorldStore(directory / 'world.sqlite', case, [], model_latency_ms=100)
    model = ScriptedTrackerModel(scenario=scenario)
    session = IntentRoleSession(world, settings, directory / 'session', 'tracked', model)
    records, rollback_checks, stages = [], [], []
    try:
        for stage in range(3):
            while world.now < stage * 6000:
                world.advance_until_or_event(stage * 6000)
            stage_records = []
            for slot in range(6):
                record = session.step((stage + 1) * 6000)
                records.append(record)
                stage_records.append(record)
                if record['status'] == 'error':
                    rollback_checks.append(session.tracker.snapshot() == record['input']['intention_state'])
                if restart and stage == 2 and slot == 2:
                    session.close()
                    session = IntentRoleSession(world, settings, directory / 'session', 'tracked', model)
            stages.append({'stage': stage + 1, 'roles': dict(Counter(r['role'] for r in stage_records)),
                           'errors': sum(r['status'] == 'error' for r in stage_records)})
        stopped = session.step(18000)
        final = session.export()
        errors = [r for r in records if r['status'] == 'error']
        consecutive = []
        for first, second in zip(records, records[1:]):
            if first['status'] == 'error' and second['role'] == 'tracker':
                packet = deepcopy(second['input'])
                before_packet = deepcopy(first['input'])
                packet.pop('at_ms', None)
                before_packet.pop('at_ms', None)
                consecutive.append({'from_step': first['step'], 'to_step': second['step'],
                                    'same_packet_except_at_ms': before_packet == packet,
                                    'rejection_message_in_next_messages': first['error']['message'] in
                                        encoded([second['system_prompt'], second['input']]),
                                    'next_input_keys': sorted(second['input'])})
        result = {'scenario': scenario, 'restart_after_third_rejection': restart,
                  'stages': stages, 'calls': final['metrics']['model_calls'],
                  'synthetic_callback_usage_not_real_tokens': final['metrics']['token_usage'],
                  'error_count': len(errors), 'error_types': dict(Counter(r['error']['message'] for r in errors)),
                  'all_rejected_patches_preserved_prestate': all(rollback_checks) if errors else None,
                  'retry_pairs': consecutive, 'stopped': stopped,
                  'final_intention_state': final['intention_state'],
                  'actor_calls': sum(r['role'] in ('work', 'chat') for r in records),
                  'actual_tools_executed': len(world.export()['tool_calls']),
                  'path': relative(directory)}
        write(directory / 'result.json', result)
        write(directory / 'execution.json', world.export())
        return result
    finally:
        session.close()
        world.close()


def source_locations():
    fragments = {
        'experiments/deep_conversation/intent_roles.py': {
            'tracker_role_gate': "if view['observed_event_seq'] > view['processed_event_seq']:",
            'packet_construction': "packet = {**observation, 'conversation': history,",
            'tracker_commit': "record['tracker_commit'] = self.tracker.commit_patch(",
            'exception_logged_only': "record['error'] = {'type': type(error).__name__, 'message': str(error)}",
            'global_budget_gate': "if (metrics['model_calls'] >= self.settings.max_calls or"},
        'experiments/deep_conversation/intention_state.py': {
            'commit_transaction': 'def commit_patch(',
            'one_operation_per_id': "raise IntentValidationError('A patch may touch each intention only once.')",
            'source_event_guard': "raise IntentValidationError('An intention source must be an arrived event within this patch.')",
            'withdrawn_requires_explicit_reopen': "raise IntentValidationError('A withdrawn intention needs an explicit reopen operation.')"},
        'experiments/deep_conversation/test_intent_roles.py': {
            'existing_test_expects_retry_without_recovery': 'def test_invalid_tracker_retries_without_acting_on_stale_state('}}
    result = []
    for name, markers in fragments.items():
        lines = (ROOT / name).read_text(encoding='utf-8').splitlines()
        result.append({'path': name, 'sha256': digest(ROOT / name),
                       'locations': {key: next(i + 1 for i, line in enumerate(lines) if marker in line)
                                     for key, marker in markers.items()}})
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=HERE / 'run-01')
    args = parser.parse_args()
    output = args.output.resolve()
    output.relative_to(HERE)
    output.mkdir(parents=True, exist_ok=False)
    manifest = load(STUDY / 'evaluation/manifest.json')
    tracked_inputs = sorted((STUDY / 'evaluation/runs').glob('*--tracked--*/steps.jsonl'))
    preserved = {relative(path): digest(path) for path in tracked_inputs}
    preserved.update({name: digest(ROOT / name) for name in manifest['source_sha256']})
    freeze_matches = {name: value == manifest['source_sha256'][name]
                      for name, value in preserved.items() if name in manifest['source_sha256']}
    if not all(freeze_matches.values()):
        raise RuntimeError('Current sources differ from frozen evaluation; diagnosis must explicitly account for drift.')
    with patch('socket.socket.connect', side_effect=AssertionError('Network forbidden in scripted diagnostics')):
        recorded = replay_recorded(output)
        scripted = [scripted_scenario(output, name) for name in
                    ('repeated_invalid', 'valid_update', 'explicit_reopen')]
        scripted.append(scripted_scenario(output, 'repeated_invalid', restart=True))
    invalid = scripted[0]
    controls = scripted[1:3]
    properties = [
        {'id': 'recorded_trace_replay', 'expected': 'All recorded pre-call snapshots, commits and rejections reproduce.',
         'status': 'pass' if not recorded['mismatches'] else 'fail'},
        {'id': 'rejected_patch_atomicity', 'expected': 'Invalid proposal leaves durable intent and cursor unchanged.',
         'status': 'pass' if recorded['all_failed_patches_rolled_back'] and invalid['all_rejected_patches_preserved_prestate'] else 'fail'},
        {'id': 'rejection_feedback_visible', 'expected': 'Next tracker request receives the actual preceding validation rejection.',
         'status': 'pass' if all(p['rejection_message_in_next_messages'] for p in invalid['retry_pairs']) else 'fail',
         'classification': 'diagnostic recovery requirement; not an existing implemented contract'},
        {'id': 'actor_opportunity_after_persistent_tracker_failure',
         'expected': 'Persistent invalid tracker output does not consume every one of the six stage calls.',
         'status': 'pass' if sum(invalid['stages'][2]['roles'].get(r, 0) for r in ('work', 'chat')) else 'fail',
         'classification': 'diagnostic recovery requirement; current policy intentionally fails closed but has no bounded fallback'},
        {'id': 'global_budget_accounting', 'expected': 'All rejected scripted calls count and the nineteenth call is stopped.',
         'status': 'pass' if invalid['calls'] == 18 and invalid['stopped'].get('reason') == 'budget_exhausted' else 'fail'},
        {'id': 'valid_update_and_explicit_reopen_controls', 'expected': 'Valid transitions commit, permitting five actor calls per stage.',
         'status': 'pass' if all(c['error_count'] == 0 and c['actor_calls'] == 15 for c in controls) else 'fail'},
        {'id': 'restart_does_not_recover_or_forgive_failed_state',
         'expected': 'Restart preserves the cursor and reproduced six-rejection starvation pattern.',
         'status': 'pass' if scripted[3]['error_count'] == 6 and scripted[3]['stages'][2]['roles'] == {'tracker': 6} else 'fail',
         'interpretation': 'Reproduced persistence; not successful error recovery.'},
    ]
    unchanged = all(digest(ROOT / name) == value for name, value in preserved.items())
    result = {'schema_version': 1, 'kind': 'scripted_diagnostic_and_captured_proposal_replay',
              'created_at_utc': datetime.now(timezone.utc).isoformat(),
              'study_date': '2026-10-23', 'display_timezone': 'America/Halifax',
              'real_model_calls': 0, 'repairs_implemented': False,
              'status': 'completed_with_recovery_properties_failing',
              'source_locations': source_locations(), 'diagnostic_script_sha256': digest(Path(__file__)),
              'frozen_source_match_count': sum(freeze_matches.values()),
              'preserved_input_sha256': preserved, 'all_inputs_unchanged_after': unchanged,
              'recorded_replay': recorded, 'scripted_results': scripted, 'properties': properties,
              'limitations': ['Deterministic scripted model outputs do not measure model quality or a repair benefit.',
                  'Scripted usage numbers are fixed callback fixtures, not measured tokens or latency.',
                  'Actor calls return private text; their availability is measured, not useful answer delivery.',
                  'Observed patch replay tests structure and exact rollback, not whether valid intentions are semantically correct.',
                  'No retry cap, feedback, fallback or model change was implemented.',
                  'Recovery expectations are diagnostic desired properties; failing them does not mean the storage guard should accept invalid patches.']}
    write(output / 'diagnosis.json', result)
    print(json.dumps({'output': relative(output / 'diagnosis.json'),
                      'recorded_replay': {k: v for k, v in recorded.items() if k not in ('runs', 'affected_runs', 'affected_run_stages')},
                      'properties': properties, 'all_inputs_unchanged_after': unchanged}, indent=2))
    if recorded['mismatches'] or not unchanged:
        return 2
    # Exit 1 honestly signals identified expected-property failures; the JSON distinguishes execution completion.
    return 1 if any(p['status'] == 'fail' for p in properties) else 0


if __name__ == '__main__':
    raise SystemExit(main())
