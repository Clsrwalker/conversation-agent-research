# Tracker rejection and recovery diagnosis

Date: 2026-10-23, America/Halifax. This is **scripted engineering diagnosis plus replay of captured proposals**, not a new model-quality experiment. No repair was implemented. No real model calls were made.

The completed diagnostic identifies **two recovery properties that fail**: the next tracker input contains no previous validation error, and repeated invalid proposals consume all six stage calls without a work/chat opportunity. The state validator itself correctly rejects the observed malformed transitions and rolls them back.

## Reproduction

From the repository root:

```powershell
& .\experiments\deep_conversation\.venv\Scripts\python.exe -B output/research/2026-10-23/intent-role-diagnostics/tracker/diagnose_tracker.py --output output/research/2026-10-23/intent-role-diagnostics/tracker/run-02
```

Use a fresh output directory under `tracker/`; the script refuses to overwrite a previous run. It blocks socket connections and supplies an explicit scripted model to the existing `IntentRoleSession`. The original source and captured evaluation files are read only. Script exit **1** means the diagnosis completed but identified the expected recovery-property failures; it must not be presented as all tests passing. Exit 2 indicates a replay or source-integrity problem.

- [Actual stdout](stdout-run-01.txt)
- [Machine-readable results, source hashes and current line locations](run-01/diagnosis.json)
- [Every captured rejected proposal, its reconstructed pre-state and first failing operation](run-01/recorded-errors.json)
- [Reproducible script](diagnose_tracker.py)

## Captured-proposal replay

All **16 tracked trajectories**, **288 pre-call snapshots**, and **69 tracker proposals** were reconstructed using their recorded arrived conversation, previously accepted patches and runtime receipts. No intention snapshot was inserted directly into SQLite. All pre-call snapshots, successful commits and errors matched the original logs exactly. Current hashes match all **40 frozen files**, and all inspected source/log files remain unchanged after the diagnostic.

The **25 rejected proposals** occur in **5 trajectories / 5 stages / 3 case families**. They are correlated repeated attempts, not 25 independent failures.

| First rejection class | Calls | Exact issue |
| --- | ---: | --- |
| Update of a withdrawn intention | 9 | The model requests `update` with `status: active` on the old withdrawn workshop ID. The store correctly requires an explicit `reopen`. |
| Invalid proposed status | 3 | The model uses `update` with `status: withdrawn` on that same old workshop ID. The store permits only active/uncertain proposed statuses and has a separate withdrawal operation. |
| Duplicate target within one patch | 12 | Both multiple-owner repeats issue an `update` followed by `withdraw` for the same refund ID. The one-operation-per-ID guard rejects the second operation, and the first operation is rolled back. |
| Non-conversation source reference | 1 | Assistant-proposal repeat 2 cites seq 17, an already-arrived full-document `read` job result, alongside valid seq 1. Its actual conversation seqs are [1, 22, 23]. The guard correctly rejects the document event as an intention source. This is not future-information leakage. |

All **25 rejected patches leave the entire pre-call intention state and processed cursor unchanged**. No invalid partial update was observed. There are **zero mismatches** between the replay and original logs. The first rejection matters: three workshop calls fail at status validation before reaching the withdrawn-target transition check, so describing all twelve workshop failures as one identical exception would be inaccurate.

## Scripted current-harness diagnosis

The scripted double supplies three conversation stages and a fixed budget of 18 calls, six calls per stage. It uses the real session, state store, callback accounting and role selection. Actor calls deliberately return private prose; the diagnostic measures their availability, not answer quality. Callback usage is fixed synthetic data (11 input + 3 output units per call), not measured tokens.

| Scenario | Stage-3 tracker / work / chat calls | Errors | Outcome |
| --- | --- | ---: | --- |
| Repeated invalid update of withdrawn ID | 6 / 0 / 0 | 6 | All failed patches roll back; budget is exhausted; no actor opportunity remains. |
| Same invalid scenario, restart after third rejection | 6 / 0 / 0 | 6 | Persistence preserves the stuck cursor; restarting does not create recovery or erase state. |
| Valid update control | 1 / 3 / 2 | 0 | Updates commit and actors get the remaining five slots. |
| Explicit reopen control | 1 / 3 / 2 | 0 | The withdrawn intention reopens and actors get the remaining five slots. |

In both invalid scenarios, all five consecutive retry input pairs are equal after removing top-level `at_ms`. The previous rejection message is absent from every next request. All six failures still count against the shared call budget, and the next attempted call correctly returns `budget_exhausted` without invoking the scripted model.

The result separates **working safety behavior** from **missing recovery**:

- **Pass:** structural rejection, atomic rollback, original trace reconstruction, persistent state, call accounting, valid update and explicit reopen controls.
- **Fail:** actual validation feedback reaches the next tracker call.
- **Fail:** actor opportunities remain after persistent tracker rejection under the six-call stage budget.

The two failed properties are diagnostic recovery requirements, not claims that the current implementation already promised fallback. The existing test explicitly expects repeated invalid tracker calls without actor action. Its passing result protects the fail-closed behavior; it does not test useful recovery.

## Where the mechanism fails

Locations refer to current source hashes recorded in `run-01/diagnosis.json`:

1. `experiments/deep_conversation/intention_state.py:192` commits a patch transactionally. The duplicate-target, source-reference and withdrawn-transition guards are at lines **263, 272 and 297**. These guards passed the captured replay and scripted rollback checks.
2. `experiments/deep_conversation/intent_roles.py:173` selects tracker while `observed_event_seq > processed_event_seq`. A rejected patch leaves that inequality true.
3. `intent_roles.py:256` builds the next input from observations, raw conversation, tool receipts and intention state. Previous rejected tracker output/error is absent.
4. `intent_roles.py:311` logs the exception externally but does not add a corrective receipt to the next model input.
5. `intent_roles.py:246` has a global call/token budget. There is no tracker-specific retry limit or fallback in this path, so the overall budget ends the loop after actor opportunities have been consumed.
6. `experiments/deep_conversation/test_intent_roles.py:168` tests three repeated invalid calls and no effects; it does not assert feedback or recovery.

The demonstrated defect is therefore in **error feedback and scheduling/recovery**, triggered by invalid model proposals. Weakening the store guard would not constitute a verified remedy. Successful `reopen` in the control proves that an explicit allowed transition works; it does not prove every observed workshop proposal should be reopened, nor that a future repair will produce a correct answer.

## Limits

No model was retrained or rerun, no actor answer was newly scored, and no retry/feedback/fallback repair was tested. The captured replay validates structural behavior; a structurally accepted patch can still misrepresent the user's intention. The scripted model forces failures and successes, so these results locate the mechanism but do not estimate real-world frequency or benefit from any proposed fix.

A preparatory exploratory command initially used Windows' default GBK decoding and failed while reading a UTF-8 log. The diagnostic script explicitly reads UTF-8, completed on its first run, and preserves the resulting stdout and JSON. The decoding failure was a diagnostic command issue, not a tracker failure.
