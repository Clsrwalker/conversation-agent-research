"""Fingerprint the tested current source and preserve the earlier study boundary."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
PRIOR = HERE.parent / 'intent-role-separation'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

manifest = json.loads((PRIOR / 'evaluation/manifest.json').read_text(encoding='utf-8'))
checks = []
for name, expected in manifest['source_sha256'].items():
    actual = sha(ROOT / name)
    frozen = sha(PRIOR / 'evaluation/frozen-source' / name)
    checks.append({'path':name,'expected':expected,'current':actual,'frozen_copy':frozen,
                   'matches':actual == expected == frozen})
assert len(checks) == 40 and all(x['matches'] for x in checks)
files = ['analysis/results.json','analysis/rows.csv','scoring/final-scores.json',
         'analysis/INDEPENDENT-AUDIT.json','analysis/EXECUTION-AUDIT.json','engineering/validation.json']
records = {f: sha(PRIOR / f) for f in files}
value = {'date':'2026-10-23','timezone':'America/Halifax','kind':'current_source_integrity_check',
    'status':'passed','freeze_files_checked':40,'freeze_files':checks,
    'prior_study_manifest_sha256':sha(PRIOR / 'evaluation/manifest.json'),
    'prior_records_sha256':records,'new_real_model_calls':0,
    'scope':'Source identity only; does not establish semantic correctness or regression-test results.'}
(HERE / 'source-integrity.json').write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':'passed','frozen_files':40,'new_real_model_calls':0}))
