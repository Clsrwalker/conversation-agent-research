# Work-to-chat boundary diagnostic

Date: 2026-10-23 (America/Halifax). Category: scripted engineering diagnostics and trace inspection. No implementation was changed; no new external model inference was performed.

**The missing interface is a durable, explicit work conclusion.** Each role call receives a newly constructed observation. A work response written only as ordinary prose is recorded for audit, but it is not included in the next chat call. The same model object does not provide shared message memory. Shared raw documents and the `save_notes` route do work.

## Actual checks

Run from the repository root:

```powershell
& .\experiments\deep_conversation\.venv\Scripts\python.exe -B output/research/2026-10-23/intent-role-diagnostics/handoff/diagnose_handoff.py
```

The command executed four isolated scenarios using the actual `IntentRoleSession`, `WorldStore`, native tool functions, callbacks, receipts and card commits. It made ten deterministic scripted model calls, with network socket connections blocked, and zero external inference calls. Its actual exit code is **1**: one desired-interface expectation failed and seven control/invariant checks passed. See [results.json](results.json), [stdout.txt](stdout.txt), [source-hashes.json](source-hashes.json) and the per-scenario records under `runs/`. The script refuses to overwrite its runs.

| Scenario | Observed outcome | Interpretation |
| --- | --- | --- |
| Work emits a useful conclusion in private prose | Next chat input omits the conclusion; notes are empty | Failed desired handoff capability |
| Identical work conclusion also sent through actual `save_notes` | Next chat input contains it; chat makes a real `publish_card` call and a card is committed | Existing explicit handoff route works |
| Both handoff scenarios | Work and chat both receive the complete raw room document | Failure is not loss of original evidence |
| Chat proposes deliberately false text while a read result arrives during inference | Receipt is `new_observations`; no card is committed | A rejected proposal is not a delivered answer |
| Same false text, after source arrival has settled | Receipt is `displayed`; false card is committed | Freshness guard is not a factual truth validator |

The scripted chat intentionally acts only on an explicit work conclusion. Its abstention without one measures the transport boundary; it does not estimate whether a real model could independently derive the answer from the raw document. The first failed expectation is a desired interface capability, not a violation of the current documented private-prose contract. A reproduced problem is not a product pass.

## Exact implementation locations

- `experiments/deep_conversation/intent_roles.py:51`, `ROLE_PROMPTS['work']`: instructs work to save useful findings in notes. Compliance is left to the model.
- `experiments/deep_conversation/intent_roles.py:256`, `IntentRoleSession.step`: builds the next packet from the world observation, raw conversation and tool receipts, plus tracker state where applicable.
- `experiments/deep_conversation/intent_roles.py:261`, `IntentRoleSession.step`: constructs a fresh two-message input for every call. No previous work `AIMessage` is carried across calls.
- `experiments/deep_conversation/intent_roles.py:279` and `:314`: response prose is retained in the step audit log. Saving the log does not expose it to a later role.
- `experiments/deep_conversation/intent_roles.py:299`: actual tool receipts are persisted in shared session state.
- `experiments/deep_conversation/agent.py:246`, `make_tools.save_notes`, and `experiments/deep_conversation/world.py:229`, `WorldStore.observation`: notes are written to the world and returned in future observations.
- `experiments/deep_conversation/agent_led_tools.py:222`, `make_tools.publish_card`, calls the guarded native commit. `experiments/deep_conversation/world.py:435` checks for arrivals after the observed cursor and returns `new_observations` at line 437.

Exact line contents and file hashes are recorded in the JSON outputs so these claims can be matched to the tested revision.

## Evidence from the existing real-model run

`irs-room-withdrawal--tracked--r2`, step 8, correctly identifies **Shaft / $12 / sixteen seats** in private work prose after the Wi-Fi requirement is removed. It makes no tool call. Step 9 chat receives empty notes, does not receive that work conclusion, and retains **Gauge / $18 / twelve seats**. Both steps receive the full guide, including both rooms. The final card still names Gauge. See [trace-evidence.json](trace-evidence.json).

This localizes a missing conclusion handoff alongside a chat selection error. It does **not** establish that adding a handoff alone will correct the real-model answer: chat can still misread raw evidence or ignore a note, and subsequent work calls in this trace also repeat the wrong Gauge choice. A repair needs a separate model comparison.

`irs-unaccepted-assistant-proposal--split--r2`, steps 1 and 3, proposes **10:00 AM / Room 201**. The actual fictional notice says **14:20 / Room T6**. Both false proposals receive `new_observations`, and the next step's active-card snapshot is empty. They are model hallucination attempts, **not delivered hallucinations**. The paired scripted guard check independently reproduces receipt-versus-delivery separation. This success comes from timing protection, not semantic evaluation of the proposed facts.

## What to test next

Candidate work, not implemented here: require an explicit concise result handoff with source references and the current intent version; define how chat acknowledges or disputes it; preserve raw evidence access; measure whether it changes final answers under the same model/call budget. Passing transport checks alone would not establish better intention handling or assistance quality.
