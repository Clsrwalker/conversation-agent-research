"""Scripted boundary diagnostics; zero external inference and no old-run mutation.

Exit 1 retains a failed desired-interface expectation. It does not mean the
diagnostic failed to execute, and a reproduced limitation is not a product pass.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
ROOT = next(p for p in HERE.parents if (p / 'experiments/deep_conversation/intent_roles.py').exists())
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'experiments/deep_conversation'))
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from pydantic import PrivateAttr
from config import Settings
from intent_roles import IntentRoleSession
from world import WorldStore

STUDY = ROOT / 'output/research/2026-10-23/intent-role-separation'
CONCLUSION = 'WORK_CONCLUSION_742: Choose Shaft: $12, sixteen seats; Wi-Fi is no longer required.'
DOCUMENT = ('Foundry Room guide. Gauge: $18, twelve seats, Wi-Fi. '
            'Shaft: $12, sixteen seats, no Wi-Fi. Spindle: $10, eight seats, Wi-Fi. '
            'Furnace: $24, twenty seats, Wi-Fi.')
FALSE_DRAFT = 'Shaft costs $999 and has nine hundred seats.'
USAGE = {'input_tokens': 11, 'output_tokens': 3, 'total_tokens': 14}


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class ScriptedBoundaryModel(BaseChatModel):
    model_name: str = 'local:scripted-handoff-diagnostic'
    scenario: str
    _requests: list = PrivateAttr(default_factory=list)

    @property
    def _llm_type(self):
        return 'offline-handoff-diagnostic'

    def bind_tools(self, tools, **kwargs):
        return self

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        self._requests.append(deepcopy(messages))
        packet = json.loads(messages[-1].content)
        role = next(r for r in ('tracker', 'work', 'chat') if f'ROLE: {r}.' in messages[0].content)
        content, calls = '', []
        if role == 'tracker':
            content = json.dumps({'operations': [{'op': 'add', 'intent_id': 'room',
                'owner': 'Nadia', 'text': packet['conversation'][-1]['text'],
                'source_seqs': [packet['conversation'][-1]['seq']]}]})
        elif role == 'work':
            content = CONCLUSION
            if self.scenario == 'saved_notes':
                calls = [('save_notes', {'notes': CONCLUSION})]
        elif self.scenario.startswith('publish_'):
            calls = [('publish_card', {'text': FALSE_DRAFT, 'source_ids': ['room-guide']})]
        elif CONCLUSION in packet['notes']:
            calls = [('publish_card', {'text': 'Choose Shaft: $12, sixteen seats.',
                                      'source_ids': ['room-guide']})]
        else:
            content = 'SCRIPTED_ABSTENTION: no explicit work conclusion was handed off.'
        actions = [{'id': f'scripted-{index}', 'name': name, 'args': args, 'type': 'tool_call'}
                   for index, (name, args) in enumerate(calls)]
        return ChatResult(generations=[ChatGeneration(message=AIMessage(
            content=content, tool_calls=actions, usage_metadata=USAGE))])


def has_full_document(packet):
    return any(e.get('kind') == 'job_result' and e.get('operation') == 'read'
               and e.get('result', {}).get('text') == DOCUMENT for e in packet['events'])


def run_case(name):
    folder = HERE / 'runs' / name
    folder.mkdir(parents=True, exist_ok=False)
    pending = name == 'publish_arrival_during_chat'
    condition = 'split' if name.startswith('publish_') else 'tracked'
    case = {'case_id': 'diagnostic-only', 'corpus_ids': ['room-guide'], 'close_at_ms': 5000,
            'events': [{'kind': 'asr_final', 'at_ms': 0, 'speaker': 'Nadia', 'segment_id': 'q',
                        'text': 'Choose the cheapest room for at least twelve people and at most $20. '
                                'Wi-Fi is not required. Give name, price and capacity.'}],
            'tool_latency_ms': {'search': 1, 'read': 150 if pending else 1}}
    corpus = [{'id': 'room-guide', 'title': 'Foundry Room guide', 'text': DOCUMENT,
               'kind': 'document', 'available_at_ms': 0}]
    world = WorldStore(folder / 'world.sqlite', case, corpus, model_latency_ms=100)
    session = None
    try:
        world.apply('setup-search', 'search', {'query': 'Foundry Room'})
        world.advance_next()
        world.apply('setup-read', 'read_document', {'source_id': 'room-guide'})
        if not pending:
            world.advance_next()
        model = ScriptedBoundaryModel(scenario=name)
        settings = Settings(preset='agent-led', model=model.model_name, max_calls=10,
                            model_latency_ms=100)
        session = IntentRoleSession(world, settings, folder / 'session', condition, model)
        session.ingest_receipts(['setup-search', 'setup-read'])
        records = [session.step(4000) for _ in range(3 if condition == 'tracked' else 2)]
        work = next(r for r in records if r['role'] == 'work')
        chat = next(r for r in records if r['role'] == 'chat')
        cards = world.observation(-1)[0]['active_cards']
        result = {'case': name, 'condition': condition, 'same_model_instance': session.model is model,
                  'roles': [r['role'] for r in records], 'steps_status': [r['status'] for r in records],
                  'external_model_calls': 0, 'scripted_model_calls': world.metrics()['model_calls'],
                  'work_private_content': work['response']['content'],
                  'work_tool_receipts': work['receipts'],
                  'work_saw_full_document': has_full_document(work['input']),
                  'chat_saw_full_document': has_full_document(chat['input']),
                  'chat_saw_exact_work_conclusion': CONCLUSION in json.dumps(chat['input']),
                  'chat_notes': chat['input']['notes'], 'chat_receipts': chat['receipts'],
                  'chat_content': chat['response']['content'], 'active_cards': cards,
                  'all_original_documents_remain_available_after_step': has_full_document(world.observation(-1)[0]),
                  'metrics': world.metrics()}
        save(folder / 'result.json', result)
        save(folder / 'execution.json', world.export())
        return result
    finally:
        if session:
            session.close()
        world.close()


def read_steps(run):
    return [json.loads(line) for line in (STUDY / 'evaluation/runs' / run / 'steps.jsonl').read_text(
        encoding='utf-8').splitlines()]


def source_anchor(relative, text):
    for line, content in enumerate((ROOT / relative).read_text(encoding='utf-8').splitlines(), 1):
        if text in content:
            return {'path': relative, 'line': line, 'text': content.strip()}
    raise AssertionError(text)


def main():
    with patch('socket.socket.connect', side_effect=AssertionError('No network in scripted diagnostic')):
        results = {name: run_case(name) for name in
                   ('private_prose', 'saved_notes', 'publish_arrival_during_chat', 'publish_settled')}
    private, notes = results['private_prose'], results['saved_notes']
    rejected, accepted = results['publish_arrival_during_chat'], results['publish_settled']
    checks = []

    def check(name, passed, kind, expected, observed):
        checks.append({'name': name, 'status': 'pass' if passed else 'fail', 'kind': kind,
                       'expected': expected, 'observed': observed})

    check('useful_private_work_conclusion_survives_role_boundary_without_explicit_tool',
          private['chat_saw_exact_work_conclusion'], 'desired_interface_expectation', True,
          private['chat_saw_exact_work_conclusion'])
    check('save_notes_makes_work_conclusion_visible_to_chat', notes['chat_saw_exact_work_conclusion'],
          'positive_control', True, notes['chat_saw_exact_work_conclusion'])
    check('raw_document_available_to_both_roles_in_both_handoff_arms',
          all(r['work_saw_full_document'] and r['chat_saw_full_document'] for r in (private, notes)),
          'isolation_control', True,
          {n: [results[n]['work_saw_full_document'], results[n]['chat_saw_full_document']]
           for n in ('private_prose', 'saved_notes')})
    check('notes_control_uses_native_persisted_save_notes',
          any(r['name'] == 'save_notes' for r in notes['work_tool_receipts']) and notes['chat_notes'] == CONCLUSION,
          'positive_control', 'actual save_notes receipt and persisted notes', notes['work_tool_receipts'])
    check('notes_control_delivers_through_native_publish_card',
          notes['chat_receipts'][0]['result']['status'] == 'displayed' and bool(notes['active_cards']),
          'positive_control', 'displayed receipt plus committed card', notes['chat_receipts'])
    check('rejected_hallucinated_proposal_is_not_delivered',
          rejected['chat_receipts'][0]['result']['status'] == 'new_observations' and not rejected['active_cards'],
          'delivery_invariant', 'new_observations receipt and no committed card',
          {'receipt': rejected['chat_receipts'], 'active_cards': rejected['active_cards']})
    check('publish_guard_does_not_validate_factual_truth',
          accepted['chat_receipts'][0]['result']['status'] == 'displayed' and
          next(iter(accepted['active_cards'].values()))['text'] == FALSE_DRAFT,
          'scope_control_not_quality_pass', 'same false proposal can display when no input race',
          {'receipt': accepted['chat_receipts'], 'active_cards': accepted['active_cards']})
    check('all_diagnostics_use_same_instance_and_complete_with_no_network',
          all(r['same_model_instance'] and set(r['steps_status']) == {'completed'} for r in results.values()),
          'execution_check', True,
          {'scripted_calls': sum(r['scripted_model_calls'] for r in results.values()), 'external_calls': 0})

    room_id = 'irs-room-withdrawal--tracked--r2'
    room = read_steps(room_id)
    work, chat = room[8], room[9]
    original = {'run_id': room_id, 'work_step': 8, 'chat_step': 9,
                'work_content': work['response']['content'], 'work_receipts': work['receipts'],
                'next_chat_notes': chat['input']['notes'],
                'exact_work_content_in_chat_input': work['response']['content'] in json.dumps(chat['input']),
                'raw_read_events_work': [e for e in work['input']['events'] if e.get('operation') == 'read'],
                'raw_read_events_chat': [e for e in chat['input']['events'] if e.get('operation') == 'read'],
                'chat_receipts': chat['receipts'], 'final_active_cards': room[-1]['input']['active_cards']}
    hallucination_id = 'irs-unaccepted-assistant-proposal--split--r2'
    hallucination = read_steps(hallucination_id)
    original['rejected_hallucination_example'] = {
        'run_id': hallucination_id,
        'steps': [{'step': i, 'receipts': hallucination[i]['receipts'],
                   'next_step_active_cards': hallucination[i + 1]['input']['active_cards']}
                  for i in (1, 3)]}
    save(HERE / 'trace-evidence.json', original)
    sources = ['experiments/deep_conversation/intent_roles.py', 'experiments/deep_conversation/world.py',
               'experiments/deep_conversation/agent_led_tools.py', 'experiments/deep_conversation/agent.py',
               'experiments/deep_conversation/config.py', 'experiments/deep_conversation/test_intent_roles.py',
               'experiments/conversation_harness/runner.py']
    hashes = {p: digest(ROOT / p) for p in sources}
    for run in (room_id, hallucination_id):
        for file in ('steps.jsonl', 'result.json', 'execution.json'):
            p = STUDY / 'evaluation/runs' / run / file
            hashes[p.relative_to(ROOT).as_posix()] = digest(p)
    hashes[Path(__file__).resolve().relative_to(ROOT).as_posix()] = digest(Path(__file__))
    save(HERE / 'source-hashes.json', hashes)
    anchors = [source_anchor('experiments/deep_conversation/intent_roles.py', t) for t in
               ("'work': ('ROLE: work.", "packet = {**observation", 'messages = [SystemMessage(prompt)',
                "record['response'] =", "self.state['receipts'].append(receipt)", 'self._append(record)')]
    anchors += [source_anchor('experiments/deep_conversation/world.py', t) for t in
                ('def observation(', '"at_ms": replay.now, "events": events, "notes"',
                 "result = {'status': 'new_observations'")]
    anchors += [source_anchor('experiments/deep_conversation/agent.py', 'def save_notes('),
                source_anchor('experiments/deep_conversation/agent_led_tools.py', 'def publish_card(')]
    summary = {'date': '2026-10-23', 'timezone': 'America/Halifax', 'run_status': 'completed',
               'category': 'scripted engineering diagnostics, not model quality experiment',
               'desired_interface_status': 'failed', 'implemented_fixes': False,
               'external_model_calls': 0, 'scripted_model_calls': 10,
               'checks': checks, 'cases': results, 'code_anchors': anchors,
               'limitations': ['The scripted chat intentionally consumes an explicit work note; its abstention '
                              'without a note is not evidence that a real model cannot rederive the answer.',
                              'Private prose is documented as private. The failed expectation is a desired '
                              'cross-role handoff capability, not a contradiction of the existing tool contract.',
                              'The original trace establishes co-occurring handoff loss and wrong chat choice, '
                              'not that a handoff repair alone would improve end-to-end quality.',
                              'Rejected hallucination is rejected for a new-observation race, not for false content.',
                              'No real inference, ASR, user study, or production deployment was performed.']}
    save(HERE / 'results.json', summary)
    lines = [f"{c['status'].upper()}: {c['name']} ({c['kind']})" for c in checks]
    lines += ['Completed: four scripted scenarios, ten scripted calls, zero external inference calls.',
              'Result: one desired-interface expectation failed; no implementation changes.',
              'Exit 1 preserves that failure. Passing controls are not an assistance-quality claim.']
    stdout = '\n'.join(lines) + '\n'
    (HERE / 'stdout.txt').write_text(stdout, encoding='utf-8')
    print(stdout, end='')
    return 1 if any(c['status'] == 'fail' for c in checks) else 0


if __name__ == '__main__':
    raise SystemExit(main())
