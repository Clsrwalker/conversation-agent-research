# 意图角色实验：交付链路定位

日期：2026-10-23，America/Halifax。类型：既有轨迹的脚本审计及工程诊断。新增模型调用 0；没有修改 runtime、冻结数据、原评分或网站。此报告定位已出现的错误，不报告修复收益。

审计重新读取全部 48 条正式轨迹、864 次模型输入和返回、阶段快照与最终评分，确认最终失败仍为 10/48：unified 4、split 2、tracked 4。10 条失败的最后六个输入中，最新用户原文和完整原始文档都存在。这里排除了这些步骤的“请求未传入／来源未到达”解释，但输入存在不证明模型注意到或正确理解了它。

## 十条失败具体发生在哪里

步骤编号从 0 开始；`steps.jsonl` 行号等于步骤编号加 1。最终评分直接沿用既有两名条件盲评审及裁决结果，没有重评。

| Run（前缀 `irs-`） | 原评分中的失败 | 具体可见断点 |
| --- | --- | --- |
| combined-workshop-change--unified--r1 | 漏价格，并保留已撤销的停车回答 | 步骤 12–17 私有回答都漏 `$23`，且不调用 publish。最终留着步骤 11 的卡片，里面仍有 South car park。理解/组织内容不完整，同时未更新交付。 |
| combined-workshop-change--unified--r2 | 漏价格 | 步骤 12–17 私有回答都漏 `$23`，且不调用 publish。旧卡只有 `$25` 预算上限，不能算价格已回答。 |
| combined-workshop-change--split--r1 | 漏价格 | 步骤 12/14/16 工作回答及 13/15/17 聊天发布均漏 `$23`；发布状态依次 displayed、unchanged、unchanged。真实发布执行成功，但内容缺字段。 |
| combined-workshop-change--split--r2 | 漏价格 | 同样三次工作调用、三次聊天发布；实际发布也漏 `$23`。不是仅 tracked 的重试问题。 |
| combined-workshop-change--tracked--r1 | 漏价格 | 步骤 12–17 全是被拒绝的 tracker 更新，没有工作/聊天机会。保留步骤 7 的卡；所有这些更新提议也没有把新增“price”字段纳入 text。 |
| combined-workshop-change--tracked--r2 | 漏价格 | 步骤 12–17 全是对 withdrawn 旧 ID 的非法 update，原子拒绝后继续同一角色。没有发布机会，留下旧卡；提议本身也漏 price。 |
| room-withdrawal--tracked--r1 | 更新条件后仍选错房间；另有事实错误标签 | tracker 已把 Wi-Fi 改为“不要求”，但步骤 7 聊天仍发布 Gauge `$18`。后续私有回答反复认定旧答案已满足；最终应选 Shaft `$12`、16 席。 |
| room-withdrawal--tracked--r2 | 更新条件后仍选错房间 | 步骤 7 发布 Gauge；步骤 8 工作私有回答正确推导 Shaft `$12`、16 席，但没有 save_notes；步骤 9 聊天看不到该推导，又发布 Gauge。步骤 16 最终仍为 Gauge。 |
| unaccepted-assistant-proposal--unified--r1 | 超出明确限制的范围 | 用户要求 only 时间和房间，未接受录制提议。步骤 6 实际发布中加入 “No recording will be made.”，以后持续保留。事实有来源，但不在授权回答范围内。 |
| multiple-request-owners--unified--r2 | 漏新增到场时间 | 步骤 12–17 六次私有回答都正确写 `08:40–08:55`，六次均无任何工具调用。最终两张卡只有报名截止和轮椅通道。这是明确的正确内容未交付。 |

每条的原始用户消息、完整来源、tracker 当前文本、notes、候选工具调用、真实回执、最终卡和逐步私有回答均在 [delivery-audit.json](delivery-audit.json) 的 `detailed_failure_and_same_family_controls` 中。该字段还保留同四个 family 的所有 14 条成功轨迹，合计 24 条，方便比较。

## 能确定的机制问题与不能确定的原因

**跨角色的私有工作成果没有自动交接。** `intent_roles.py:256` 每次只构造 observation、原始 conversation、tool_receipts 和可选 intention_state；`:261` 重新建立 System + Human 两条消息。全部 864 次 capture 确认此结构。`:291` 的本步 response 和 tool messages 只在本步工具执行期间使用；`:299` 持久保存的是工具回执。工作调用若只输出普通 prose，其结论既不成为下一角色消息，也不会自动进入 notes。房间 tracked r2 的步骤 8→9 是实际例子：正确结论消失，但原文档仍可见。`save_notes` 工具存在（`agent.py:246`），这个 run 没有调用它；所有 10 条失败也都没有 save_notes。缺少交接是确定的数据路径，强制交接是否能改变最终质量仍需新对照实验，不能由本轨迹证明。

**交付动作与“回答已经完成”的判断分离。** 多 owner unified r2 已经生成正确到场时间，却没有发布调用；没有工具拒绝或发布冲突可解释这个遗漏。同 family 的 unified r1 在步骤 12 实际发布第三张卡，内容是 `08:40–08:55`，因此最终成功。反过来，两条 unified room 成功轨迹最后阶段也没有发布，但已有正确卡继续可见；“最后阶段没有 publish”本身不是通用错误指标，必须核对有效请求和最终卡。

本实验 `run_intent_roles.py:42` 使用 `preset='agent-led'`，而且直接运行 `IntentRoleSession.step()`。整个项目的原生图 **已有**可选 `AnswerDelivery`（`agent_led.py:240–252`，`config.py:35–36`），只是此次路径未调用它。因此不能说“整个项目没有交付恢复”，也没有测试或证明已有恢复节点能修复这些案例。

**正确 tracker 文本不等于重新求解答案。** 两条 room tracked 的 tracker 都正确撤销 Wi-Fi，并保留至少 12 席、预算 20、最便宜等要求；最终房间选择仍错。统一和 split 的四条相同 family 对照最终都选 Shaft。日志与“旧答案锚定”“未重新计算候选资格”相容，但不能唯一归因到其中一个心理机制。r2 甚至一度正确算出又丢失，说明至少还有交接因素。

**六条 workshop 的遗漏并非同一种单点故障。** 全部最后六步原文档都含 `Glaze Lab: Friday, $23, Room G4, step-free route`，用户最后消息明确要求 price。两条 unified 无发布且候选漏价；两条 split 已发布但候选也漏价；两条 tracked 被重试挤占且更新提议漏 price。仅修复 tracker 重试，不能据此推断六条价格遗漏都会消失。冻结 gold 在前两个阶段已经包含 price，而原始用户到第三阶段才明确要求；本诊断只用第三阶段明示请求支持价格遗漏定位，避免把 gold 额外字段误当早期用户要求。

**范围错误发生在答案选择和发布内容。** recording 失败来自实际发布了额外内容，并非事实检索失败。记录不足以证明模型内部把提议正式变成了任务；可确定的是输出违反了用户的 only 限制。其他五条同 family 对照最终没有 recording 内容。workshop unified r1 的停车内容同理，撤销消息已在输入中，但旧卡继续带着停车答案。

## 当前发布边界究竟检查什么

[diagnose_publish_guard.py](diagnose_publish_guard.py) 在六个隔离 WorldStore 中，使用当前 `make_tools()` 的真实 `search`、`read_document`、`publish_card.func` 及 SQLite 事务路径执行诊断。网络 connect 被显式阻止，模型调用为 0，draft 由脚本提供，没有向 runtime 加入 gold 驱动校验。结果保存于 [publish-guard-diagnostic.json](publish-guard-diagnostic.json)，包括实际来源到达、输入 snapshot、持久回执和最终卡。

| 脚本输入 | 实际状态 | 含义 |
| --- | --- | --- |
| workshop 漏用户已明确要求的价格 | displayed | 当前发布 guard 不校验回答字段覆盖 |
| workshop 完整答案对照 | displayed | 正常发布路径可以运行 |
| 撤销 Wi-Fi 后仍说 Gauge 最便宜 | displayed | 当前 guard 不重新求解/核实结论 |
| only 时间和房间，但额外加 recording | displayed | 当前 guard 不校验内容范围 |
| 空白文本对照 | not_published | 空白检查生效 |
| 观察后又到达用户修改的旧回答对照 | new_observations | 新输入保护生效 |

六项工程断言均通过，代表观察符合现有代码边界，**不代表前三个错误答案通过质量测试**。`agent_led_tools.py:222–261` 处理引用 ID、空文本、卡片和观察状态；`world.py:413–454` 原子检查新观察、并发卡版本、重复交付。工具说明也明确 source IDs 不能证明事实正确。这是设计边界的实证，不是发现现有 freshness 检查失效，也不是已实现语义验证。

## 复现与限制

从仓库根目录运行：

```powershell
& .\experiments\deep_conversation\.venv\Scripts\python.exe -B output/research/2026-10-23/intent-role-diagnostics/delivery/audit_delivery.py
& .\experiments\deep_conversation\.venv\Scripts\python.exe -B output/research/2026-10-23/intent-role-diagnostics/delivery/diagnose_publish_guard.py
```

读取审计通过：864 组输入/返回 capture 与 steps 一致、48 个 result 与 JSONL 一致、48 个最终标签与原评分一致、6 个当前相关源码文件与原冻结哈希一致。10 条失败均有完整文档和最后用户请求。完整输出见 [audit-stdout.txt](audit-stdout.txt)；源码行号与 147 项输入文件哈希在 JSON 中（144 个 run 文件、评分 CSV/JSON、fixture）。

字符串存在只作可复现诊断，不能代替语义评分；源文档在客户端输入存在不证明模型注意、服务端完整消费或理解。工作成果未交接和 tracker 饥饿都是真实链路，但改动后的因果收益未知。未测试新模型、LoRA、语音、真实用户或长对话。初次探索脚本遇到 Windows 默认 GBK 读取 UTF-8 文件失败，已显式指定 UTF-8；这发生在只读诊断工具，未改变原实验与评分。`exploration.txt` 是辅助浏览输出，权威复现产物为两个诊断脚本及其 JSON。
