"""Read-only trace diagnosis; no model calls, semantic rescoring or runtime edits."""
from __future__ import annotations
import csv, hashlib, json
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
STUDY = ROOT / 'output/research/2026-10-23/intent-role-separation'

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def jsonl(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8-sig').splitlines() if line]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def full_sources(packet):
    return [event for event in packet['events'] if event.get('kind') == 'job_result'
            and event.get('operation') == 'read' and isinstance(event.get('result', {}).get('text'), str)]

def locations():
    targets = {
        'experiments/deep_conversation/intent_roles.py': [
            'def _role(', 'def _execute(', 'packet = {**observation',
            'messages = [SystemMessage(prompt)', 'tool_messages = [*messages, response]',
            "self.state['receipts'].append(receipt)", "record['status'] = 'error'"],
        'experiments/deep_conversation/agent_led_tools.py': [
            'def publish_card(', 'if not text.strip():', 'expected_observation_cursor=cursor)'],
        'experiments/deep_conversation/world.py': [
            'def apply(', "result = {'status': 'new_observations'", "result = {'status': 'conflict'",
            "result['committed_card'] ="],
        'experiments/deep_conversation/run_intent_roles.py': ["return Settings(preset='agent-led'"],
        'experiments/deep_conversation/agent_led.py': [
            'if settings.mechanisms.answer_delivery:', 'from answer_delivery import AnswerDelivery'],
        'experiments/deep_conversation/config.py': [
            "'agent-led': Mechanisms", "'agent-led-answer-delivery': Mechanisms"],
    }
    result = []
    for path, needles in targets.items():
        lines = (ROOT / path).read_text(encoding='utf-8').splitlines()
        result.append({'path': path, 'sha256': digest(ROOT / path), 'locations': [
            {'needle': needle, 'lines': [i + 1 for i, line in enumerate(lines) if needle in line]}
            for needle in needles]})
    return result

def main():
    rows = list(csv.DictReader((STUDY / 'analysis/rows.csv').open(encoding='utf-8-sig', newline='')))
    manifest = read(STUDY / 'evaluation/manifest.json')
    cases = {case['case_id']: case for case in read(STUDY / 'fixtures/cases.json')['cases']}
    assert len(rows) == len({row['run_id'] for row in rows}) == 48
    assert {row['run_id'] for row in rows} == {row['run_id'] for row in manifest['assignments']}
    results, selected, hashes, checks = [], [], {}, Counter()
    hashes['analysis/rows.csv'] = digest(STUDY / 'analysis/rows.csv')
    hashes['scoring/final-scores.json'] = digest(STUDY / 'scoring/final-scores.json')
    hashes['fixtures/cases.json'] = digest(STUDY / 'fixtures/cases.json')
    final_scores = {row['packet_id']: row for row in read(STUDY / 'scoring/final-scores.json')}
    for row in rows:
        failure = row['complete_and_correct'] == 'False'
        for field in ('complete_and_correct', 'omission', 'scope_error',
                      'unnecessary_clarification', 'factual_error'):
            expected = final_scores[row['packet_id']][field]
            assert row[field] == str(expected), (row['packet_id'], field, row[field], expected)
        folder = STUDY / 'evaluation/runs' / row['run_id']
        result = read(folder / 'result.json')
        steps = jsonl(folder / 'steps.jsonl')
        captures = jsonl(folder / 'model_capture.jsonl')
        requests = {item['metadata']['role_step']: item for item in captures if item['kind'] == 'request'}
        responses = {item['run_id']: item for item in captures if item['kind'] == 'response'}
        assert steps == [step for stage in result['stages'] for step in stage['steps']]
        assert len(steps) == len(requests) == len(responses) == 18
        for filename in ('result.json', 'steps.jsonl', 'model_capture.jsonl'):
            hashes[f'evaluation/runs/{row["run_id"]}/{filename}'] = digest(folder / filename)
        for step in steps:
            request = requests[step['step']]
            messages = request['messages'][0]
            assert len(messages) == 2
            assert messages[0]['content'] == step['system_prompt']
            assert json.loads(messages[1]['content']) == step['input']
            response = responses[request['run_id']]['generations'][0][0]['message']
            assert response['content'] == step['response']['content']
            assert response['tool_calls'] == step['response']['tool_calls']
            checks['captured_requests_and_responses_reconciled'] += 1
        case = cases[row['case_id']]
        expected_documents = {item['id']: item['text'] for item in case['corpus']}
        final_request = case['replay']['events'][-1]['text']
        def source_matches(step):
            return any(event['result'].get('source_id') in expected_documents
                       and event['result']['text'] == expected_documents[event['result']['source_id']]
                       for event in full_sources(step['input']))
        stage3 = steps[12:]
        stage3_receipts = [receipt for step in stage3 for receipt in step['receipts']]
        final_cards = result['stages'][-1]['active_cards']
        summary = {
            'run_id': row['run_id'], 'packet_id': row['packet_id'], 'case_id': row['case_id'],
            'condition': row['condition'], 'repeat': int(row['repeat']),
            'primary_labels_copied_without_rescoring': final_scores[row['packet_id']],
            'primary_failure': failure,
            'first_full_source_input_step': next((step['step'] for step in steps if source_matches(step)), None),
            'all_final_stage_inputs_contain_exact_raw_latest_request': all(
                any(event['text'] == final_request for event in step['input']['conversation']) for step in stage3),
            'final_stage_steps_with_full_original_source': [step['step'] for step in stage3 if source_matches(step)],
            'final_stage_roles': dict(Counter(step['role'] for step in stage3)),
            'final_stage_errors': [step['step'] for step in stage3 if step['status'] == 'error'],
            'final_stage_publish_calls': sum(receipt['name'] == 'publish_card' for receipt in stage3_receipts),
            'final_stage_publish_statuses': dict(Counter(receipt['result']['status'] for receipt in stage3_receipts
                                                        if receipt['name'] == 'publish_card')),
            'final_cards': final_cards,
            'notes_nonempty_steps': [step['step'] for step in steps if step['input']['notes']],
            'save_notes_calls': sum(receipt['name'] == 'save_notes' for step in steps for receipt in step['receipts']),
        }
        if row['case_id'] == 'irs-combined-workshop-change':
            summary['lexical_diagnostic_not_semantic_score'] = {
                'price_literal': '$23',
                'final_card_contains_price_literal': '$23' in json.dumps(final_cards),
                'final_stage_response_contains_price_literal': [step['step'] for step in stage3
                    if '$23' in json.dumps(step['response'], ensure_ascii=False)],
                'final_stage_source_contains_price_literal': [step['step'] for step in stage3
                    if any('$23' in event['result']['text'] for event in full_sources(step['input']))],
                'final_stage_tracker_proposals_mention_price': [step['step'] for step in stage3
                    if step['role'] == 'tracker' and 'price' in step['response']['content'].lower()],
            }
        results.append(summary)
        if row['case_id'] in {'irs-combined-workshop-change', 'irs-room-withdrawal',
                              'irs-multiple-request-owners', 'irs-unaccepted-assistant-proposal'}:
            trace = {**summary, 'raw_conversation': steps[-1]['input']['conversation'],
                     'original_full_sources': case['corpus'], 'steps': []}
            for step in steps:
                trace['steps'].append({
                    'step_zero_based': step['step'], 'jsonl_line_one_based': step['step'] + 1,
                    'at_ms': step['at_ms'], 'role': step['role'], 'status': step['status'],
                    'error': step.get('error'), 'conversation_seqs': [e['seq'] for e in step['input']['conversation']],
                    'full_sources_in_input': [{'seq': e['seq'], 'at_ms': e['at_ms'],
                        'source_id': e['result']['source_id'], 'text': e['result']['text']}
                        for e in full_sources(step['input'])],
                    'notes': step['input']['notes'],
                    'current_intents': [{k: intent[k] for k in ('intent_id', 'owner', 'text', 'status', 'source_seqs')}
                        for intent in step['input'].get('intention_state', {}).get('intents', [])],
                    'private_response_prose': step['response']['content'],
                    'proposed_tool_calls': step['response']['tool_calls'], 'actual_receipts': step['receipts'],
                })
            selected.append(trace)
    failures = [run for run in results if run['primary_failure']]
    assert len(failures) == 10
    by_id = {run['run_id']: run for run in selected}
    room = by_id['irs-room-withdrawal--tracked--r2']
    work, chat = room['steps'][8], room['steps'][9]
    assert 'is the **Shaft** room' in work['private_response_prose']
    assert work['proposed_tool_calls'] == work['actual_receipts'] == []
    assert chat['notes'] == '' and 'Gauge' in chat['proposed_tool_calls'][0]['args']['text']
    orchard = by_id['irs-multiple-request-owners--unified--r2']
    assert all('08:40–08:55' in step['private_response_prose'] and step['proposed_tool_calls'] == []
               for step in orchard['steps'][12:])
    assert '08:40' not in json.dumps(orchard['final_cards'])
    workshops = [run for run in results if run['case_id'] == 'irs-combined-workshop-change']
    assert len(workshops) == 6
    assert all(run['lexical_diagnostic_not_semantic_score']['final_card_contains_price_literal'] is False
               and run['lexical_diagnostic_not_semantic_score']['final_stage_response_contains_price_literal'] == []
               and len(run['lexical_diagnostic_not_semantic_score']['final_stage_source_contains_price_literal']) == 6
               for run in workshops)
    checks['specific_delivery_and_price_trace_invariants'] = 3
    checks['all_48_final_primary_labels_match_original_scores'] = 48
    checks['all_48_result_steps_equal_jsonl'] = 48
    checks['all_48_captures_have_exactly_2_messages_per_request'] = 48
    for item in locations():
        assert item['sha256'] == manifest['source_sha256'][item['path']]
        checks['current_mechanism_files_equal_frozen_sources'] += 1
    output = {
        'kind': 'read_only_scripted_trace_diagnostic_not_new_experiment_or_semantic_scoring',
        'date': '2026-10-23', 'timezone': 'America/Halifax', 'status': 'passed',
        'original_trajectories': 48, 'original_model_calls_read': 864, 'new_model_calls': 0,
        'checks': dict(checks), 'final_failure_count': len(failures),
        'failures_by_condition': dict(Counter(run['condition'] for run in failures)),
        'failures_by_family': dict(Counter(run['case_id'] for run in failures)),
        'failed_run_final_stage_full_sources': sum(len(run['final_stage_steps_with_full_original_source']) == 6 for run in failures),
        'failed_run_final_raw_requests_present': sum(run['all_final_stage_inputs_contain_exact_raw_latest_request'] for run in failures),
        'all_runs': results, 'detailed_failure_and_same_family_controls': selected,
        'source_locations': locations(), 'original_input_hashes': hashes,
        'limitations': [
            'Lexical presence is diagnostic and is not semantic grading.',
            'Full source and user text in client messages establish availability, not model attention or comprehension.',
            'No new model calls, repairs, causal ablations, training, human review, or default harness changes.',
            'Primary scores are copied from the original frozen study; this does not independently validate their semantics.',
            'Model captures are client messages and returned generations, not raw HTTP or server internals.',
            'Failure localization may involve multiple boundaries; observed traces do not establish a single causal root.',
        ]}
    (HERE / 'delivery-audit.json').write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: output[k] for k in ('status', 'checks', 'original_trajectories', 'new_model_calls',
          'final_failure_count', 'failures_by_condition', 'failures_by_family',
          'failed_run_final_stage_full_sources', 'failed_run_final_raw_requests_present')}, ensure_ascii=False))

if __name__ == '__main__':
    main()
