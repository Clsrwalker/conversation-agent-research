import json, csv
from pathlib import Path
ROOT=Path(__file__).resolve().parents[5]
STUDY=ROOT/'output/research/2026-10-23/intent-role-separation'
rows=list(csv.DictReader((STUDY/'analysis/rows.csv').open(encoding='utf-8-sig')))
for row in rows:
    if row['complete_and_correct']!='False': continue
    run=STUDY/'evaluation/runs'/row['run_id']
    data=json.loads((run/'result.json').read_text(encoding='utf-8'))
    print('\nRUN',row['run_id'])
    print('FINAL',json.dumps(data['stages'][-1]['active_cards'],ensure_ascii=False))
    for stage in data['stages']:
        for step in stage['steps']:
            if step['step']<12: continue
            print('STEP',step['step'],step['role'],step['status'],step.get('error'))
            if step['role']=='tracker': print('STATE',json.dumps(step['input']['intention_state']['intents'],ensure_ascii=False))
            print('NOTES',step['input']['notes'])
            print('RESPONSE',json.dumps(step['response'].get('content'),ensure_ascii=False),json.dumps(step['response'].get('tool_calls'),ensure_ascii=False))
            print('RECEIPTS',json.dumps(step['receipts'],ensure_ascii=False))
