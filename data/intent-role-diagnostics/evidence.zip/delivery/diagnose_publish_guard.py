"""Exercise the current publication tool with scripted drafts; never invoke a model."""
from __future__ import annotations
import hashlib, json, socket, sys, tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
sys.path.insert(0, str(ROOT / 'experiments/deep_conversation'))
from agent_led_tools import make_tools
from config import Settings
from intent_roles import normalize_history
from langchain_core.messages import HumanMessage
from world import WorldStore

def main():
    source = ROOT / 'output/research/2026-10-23/intent-role-separation/fixtures/cases.json'
    cases = {case['case_id']: case for case in json.loads(source.read_text(encoding='utf-8'))['cases']}
    scripts = [
        ('workshop_missing_price', 'irs-combined-workshop-change',
         'Glaze Lab is the cheapest Friday workshop at or below $25, in Room G4 with a step-free route.', 'displayed'),
        ('workshop_complete_control', 'irs-combined-workshop-change',
         'Glaze Lab on Friday costs $23, is in Room G4 and has a step-free route.', 'displayed'),
        ('room_wrong_selection', 'irs-room-withdrawal',
         'The cheapest eligible room after dropping Wi-Fi is Gauge, $18, twelve seats.', 'displayed'),
        ('demo_unrequested_recording', 'irs-unaccepted-assistant-proposal',
         'The session starts at 14:20 in Room T6. No recording will be made.', 'displayed'),
        ('blank_control', 'irs-combined-workshop-change', '   ', 'not_published'),
        ('stale_observation_control', 'irs-combined-workshop-change',
         'Clay Basics on Tuesday costs $18 and is in Room C2.', 'new_observations'),
    ]
    records = []
    with patch.object(socket.socket, 'connect', side_effect=AssertionError('Network forbidden for scripted diagnosis')):
        for name, case_id, text, expected in scripts:
            case = cases[case_id]
            with tempfile.TemporaryDirectory(prefix='publish-guard-', dir=HERE) as folder:
                world = WorldStore(Path(folder) / 'world.sqlite', case=case['replay'], corpus=case['corpus'])
                try:
                    settings = Settings(preset='agent-led', max_calls=18, max_tokens=180000,
                                        max_output_tokens=1200, model_latency_ms=100)
                    tools = {tool.name: tool for tool in make_tools(world, settings, None)}
                    def runtime(call_id):
                        packet, cursor = world.observation(-1)
                        packet['conversation'] = normalize_history(world.history())
                        return SimpleNamespace(tool_call_id=call_id,
                            state={'event_cursor': cursor, 'messages': [HumanMessage(
                                json.dumps(packet), id=f'observation-{cursor}')]},
                            config={}, context=None, store=None, stream_writer=None), packet, cursor
                    state, _, _ = runtime('setup-search')
                    search = json.loads(tools['search'].func(query=case['corpus'][0]['title'], runtime=state))
                    assert search['job_started'] is True
                    world.advance_next()
                    state, _, _ = runtime('setup-read')
                    read = json.loads(tools['read_document'].func(source_id=case['corpus'][0]['id'], runtime=state))
                    assert read['job_started'] is True
                    world.advance_next()
                    if name == 'stale_observation_control':
                        state, packet, cursor = runtime('scripted-publish')
                        world.advance_until_or_event(6000)
                    else:
                        while world.now < 12000:
                            world.advance_until_or_event(12000)
                        state, packet, cursor = runtime('scripted-publish')
                    actual = json.loads(tools['publish_card'].func(text=text,
                        source_ids=[case['corpus'][0]['id']], card_id='diagnostic-card', runtime=state))
                    assert actual['status'] == expected, (name, actual)
                    persisted = world.lookup_tool_record('scripted-publish')
                    assert persisted is not None and persisted['result']['status'] == expected
                    final_observation, _ = world.observation(-1)
                    displayed = final_observation['active_cards'].get('diagnostic-card')
                    assert (displayed is not None) == (expected == 'displayed')
                    if displayed:
                        assert displayed['text'] == text
                    assert world.metrics()['model_calls'] == 0
                    records.append({'script_id': name, 'case_id': case_id,
                        'expected_code_boundary_status': expected, 'actual_receipt': actual,
                        'draft': text, 'source_read_receipt': read, 'observation_cursor': cursor,
                        'model_visible_snapshot': packet, 'persisted_tool_record': persisted,
                        'final_active_cards': final_observation['active_cards'],
                        'execution': world.export(), 'check': 'passed'})
                finally:
                    world.close()
    output = {'kind': 'scripted_engineering_diagnostic_not_model_quality_evaluation',
        'date': '2026-10-23', 'timezone': 'America/Halifax', 'status': 'passed',
        'new_model_calls': 0, 'network_connections_permitted': False,
        'fixture_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'conditions': 'Same current agent-led publish_card.func and WorldStore transaction path; isolated worlds; scripted drafts; real search/read receipts; no gold runtime guard or changed production code.',
        'tests': records,
        'result': 'Four nonempty current drafts were displayed, including an omitted requested price, a wrong room selection and an unrequested recording fact. Blank and stale-observation controls were rejected. The boundary guards freshness/transaction conditions, not semantic coverage or correctness.',
        'limitations': ['No model generated these drafts. This is not a new assistance-quality score.',
            'No proposed semantic checker was implemented or tested.',
            'No claim that existing optional AnswerDelivery would repair any case; this experiment uses IntentRoleSession with agent-led settings, not the optional native graph delivery node.']}
    (HERE / 'publish-guard-diagnostic.json').write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': output['status'], 'new_model_calls': 0,
        'checks': [{'script_id': row['script_id'], 'status': row['actual_receipt']['status'], 'check': row['check']} for row in records]}))

if __name__ == '__main__':
    main()
