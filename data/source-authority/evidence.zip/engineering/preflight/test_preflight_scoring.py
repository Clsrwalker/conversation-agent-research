"""Offline annotation-contract checks; no semantic inference or model calls."""
from pathlib import Path
import socket
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[6]
sys.path.insert(0, str(ROOT / 'experiments/deep_conversation'))
import source_authority_score as score
from source_authority_study import write


class ScoringContracts(unittest.TestCase):
    def setUp(self):
        self.guard = patch.object(socket.socket, 'connect', side_effect=AssertionError('Offline test attempted network'))
        self.guard.start()
        self.packet = {'id': 'fixture', 'output': {'role': 'assistant', 'content': '',
            'tool_calls': [{'function': {'name': 'search', 'arguments': {'query': 'search the optional alternative'}}}]},
            'gold': {'private_evaluator_only': 'gold must not serve as actor evidence'}}
        self.row = {'id': 'fixture', **{f: 'no' for f in score.FIELDS},
            'scope_error': 'yes', 'scope_error_excluding_reconfirmation': 'yes',
            'scope_failure_type': 'expansion', 'reason': 'Synthetic fixture: the given alternative is explicitly outside scope.',
            'evidence_quotes': ['search the optional alternative']}

    def tearDown(self):
        self.guard.stop()

    def validate(self, rows, packet=None, partial=False):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as folder:
            path = Path(folder) / 'review.json'
            write(path, rows)
            return score.validate_reviews(path, {'fixture': packet or self.packet}, partial=partial)

    def test_actual_tool_argument_quote_is_accepted(self):
        self.assertEqual(self.validate([self.row])['fixture'], self.row)

    def test_evaluator_gold_is_not_accepted_as_actor_evidence(self):
        row = {**self.row, 'evidence_quotes': ['gold must not serve as actor evidence']}
        with self.assertRaisesRegex(ValueError, 'quote'):
            self.validate([row])

    def test_duplicate_unknown_and_missing_review_ids_are_rejected(self):
        for rows in ([self.row, self.row], [{**self.row, 'id': 'unknown'}], []):
            with self.subTest(rows=rows), self.assertRaises(ValueError):
                self.validate(rows)
        self.assertEqual(self.validate([], partial=True), {})

    def test_empty_output_all_no_needs_no_fabricated_quote(self):
        row = {**self.row, **{f: 'no' for f in score.FIELDS}, 'scope_failure_type': 'none',
               'reason': 'Empty response demonstrates no particular scope assertion.', 'evidence_quotes': []}
        packet = {'id': 'fixture', 'output': {'role': 'assistant', 'content': ''}}
        self.assertEqual(self.validate([row], packet)['fixture'], row)

    def test_reconfirmation_and_sensitivity_consistency_are_enforced(self):
        pure = {**self.row, 'scope_failure_type': 'contraction',
                'unnecessary_reconfirmation': 'yes', 'scope_error_excluding_reconfirmation': 'no'}
        self.validate([pure])
        for update in ({'scope_error': 'no', 'scope_failure_type': 'none'},
                       {'scope_error': 'no', 'scope_failure_type': 'none', 'unnecessary_reconfirmation': 'no',
                        'scope_error_excluding_reconfirmation': 'yes'},
                       {'scope_error': 'yes', 'scope_failure_type': 'none'}):
            with self.subTest(update=update), self.assertRaises(ValueError):
                self.validate([{**self.row, **update}])


if __name__ == '__main__':
    unittest.main(verbosity=2)
