"""Offline study-runner contracts. No model inference or tool execution."""
from __future__ import annotations

from copy import deepcopy
import json
from pathlib import Path
import socket
import sys
import tempfile
import unittest
from unittest.mock import patch

import httpx

ROOT = Path(__file__).resolve().parents[6]
sys.path.insert(0, str(ROOT / 'experiments/deep_conversation'))
import source_authority_study as study
from source_authority import SOURCE_AUTHORITY_GUIDANCE


class FakeClient:
    def __init__(self, responses):
        self.responses = iter(responses)
        self.sent = []

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass

    def build_request(self, method, path, json):
        return httpx.Request(method, 'http://127.0.0.1:11434' + path, json=json)

    def send(self, request):
        self.sent.append(request)
        result = next(self.responses)
        if isinstance(result, Exception):
            raise result
        return result


class RunnerContracts(unittest.TestCase):
    def setUp(self):
        self.network_guard = patch.object(socket.socket, 'connect', side_effect=AssertionError('Offline test attempted network'))
        self.network_guard.start()
        self.source = study.read(study.SOURCE)
        self.cases = study.materials()

    def tearDown(self):
        self.network_guard.stop()

    def test_all_24_cases_generate_exactly_five_conditions_and_one_no_summary(self):
        self.assertEqual(len(self.cases), 24)
        self.assertEqual(sum(split == 'seen_regression' for split, _ in self.cases), 12)
        self.assertEqual(sum(split == 'new_challenge' for split, _ in self.cases), 12)
        self.assertEqual(len({case['case_id'] for _, case in self.cases}), 24)
        expected = [('baseline', 'none'), ('baseline', 'correct'), ('baseline', 'incorrect'),
                    ('source_authority', 'correct'), ('source_authority', 'incorrect')]
        generated = []
        for split, case in self.cases:
            for guidance, summary in expected:
                request = study.make_request(case, guidance, summary, self.source, SOURCE_AUTHORITY_GUIDANCE)
                generated.append((case['case_id'], guidance, summary, request))
        self.assertEqual(len(generated), 120)
        self.assertEqual(sum(summary == 'none' for _, _, summary, _ in generated), 24)

    def test_visible_data_baseline_and_candidate_are_exactly_matched(self):
        for _, case in self.cases:
            for summary in ('correct', 'incorrect'):
                a = study.make_request(case, 'baseline', summary, self.source, SOURCE_AUTHORITY_GUIDANCE)
                b = study.make_request(case, 'source_authority', summary, self.source, SOURCE_AUTHORITY_GUIDANCE)
                self.assertEqual(a['messages'][0]['content'], self.source['messages'][0]['content'])
                self.assertEqual(b['messages'][0]['content'], a['messages'][0]['content'] + '\n\n' + SOURCE_AUTHORITY_GUIDANCE)
                self.assertEqual(a['messages'][1:], b['messages'][1:])
                self.assertEqual({k: v for k, v in a.items() if k != 'messages'},
                                 {k: v for k, v in b.items() if k != 'messages'})
                observation = json.loads(a['messages'][1]['content'].split('\n', 1)[1])
                self.assertEqual(observation, {'conversation': case['raw_turns'],
                    'provenance': case['model_observation']['provenance'], 'pending_jobs': [], 'active_cards': {}})
                self.assertEqual(a['tools'], self.source['tools'])
                self.assertEqual(len(a['tools']), 16)
                self.assertEqual(a['options'], {'num_ctx': 16384, 'num_predict': 1000, 'temperature': 0.0})
                self.assertIs(a['think'], False)

    def test_summary_conditions_change_only_selected_summary_message(self):
        for _, case in self.cases:
            none = study.make_request(case, 'baseline', 'none', self.source, SOURCE_AUTHORITY_GUIDANCE)
            correct = study.make_request(case, 'baseline', 'correct', self.source, SOURCE_AUTHORITY_GUIDANCE)
            incorrect = study.make_request(case, 'baseline', 'incorrect', self.source, SOURCE_AUTHORITY_GUIDANCE)
            self.assertEqual(len(none['messages']), 3)
            self.assertEqual(len(correct['messages']), 4)
            self.assertEqual(correct['messages'][:2], incorrect['messages'][:2])
            self.assertEqual(correct['messages'][3:], incorrect['messages'][3:])
            self.assertEqual(none['messages'], correct['messages'][:2] + correct['messages'][3:])
            self.assertEqual(correct['messages'][2], {'role': 'user', 'content': 'Saved working summary:\n' + case['summaries']['correct']})
            self.assertEqual(incorrect['messages'][2], {'role': 'user', 'content': 'Saved working summary:\n' + case['summaries']['incorrect']})

    def test_evaluator_fields_and_unselected_summary_do_not_leak(self):
        marker = '__EVALUATOR_SENTINEL_NEVER_RENDER__'
        case = deepcopy(self.cases[0][1])
        for key in ('case_id', 'scenario_id', 'state', 'scenario_title', 'evaluation_only', 'probe', 'shared_facts', 'gold'):
            case[key] = marker
        case['model_observation']['observed_tool_results'] = marker
        case['model_observation']['source_records_mentioned'] = marker
        case['summaries']['incorrect'] = marker
        for summary in ('none', 'correct'):
            request = study.make_request(case, 'source_authority', summary, self.source, SOURCE_AUTHORITY_GUIDANCE)
            self.assertNotIn(marker, json.dumps(request))

    def test_new_pairs_only_change_final_turn_and_swap_one_summary_sentence(self):
        groups = {}
        for split, case in self.cases:
            if split == 'new_challenge':
                groups.setdefault(case['scenario_id'], []).append(case)
        self.assertEqual(len(groups), 6)
        for pair in groups.values():
            self.assertEqual(len(pair), 2)
            a, b = pair
            self.assertEqual(a['raw_turns'][:-1], b['raw_turns'][:-1])
            self.assertNotEqual(a['raw_turns'][-1], b['raw_turns'][-1])
            self.assertEqual(a['raw_turns'][-1]['role'], 'user')
            self.assertEqual(a['raw_turns'][-1]['speaker'], b['raw_turns'][-1]['speaker'])
            self.assertEqual(a['model_observation'], b['model_observation'])
            self.assertEqual(a['summaries']['correct'], b['summaries']['incorrect'])
            self.assertEqual(a['summaries']['incorrect'], b['summaries']['correct'])
            correct, incorrect = a['summaries']['correct'].split('. '), a['summaries']['incorrect'].split('. ')
            self.assertEqual(len(correct), len(incorrect))
            self.assertEqual(sum(c != i for c, i in zip(correct, incorrect)), 1)

    def test_every_new_gold_evidence_quote_matches_visible_turn(self):
        gold = study.read(study.OUT / 'materials/novel-gold.json')['cases']
        self.assertEqual(len(gold), 12)
        cases = {c['case_id']: c for split, c in self.cases if split == 'new_challenge'}
        self.assertEqual(set(cases), {g['case_id'] for g in gold})
        for item in gold:
            case = cases[item['case_id']]
            self.assertEqual(item['scenario_id'], case['scenario_id'])
            self.assertEqual(item['state'], case['state'])
            for evidence in item['source_evidence']:
                turn = case['raw_turns'][evidence['turn_index']]
                self.assertEqual(evidence['speaker'], turn['speaker'])
                self.assertEqual(evidence['role'], turn['role'])
                self.assertEqual(evidence['exact_quote'], turn['text'])

    def test_prepare_rejects_nonapproved_preflight_before_provider_access(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as folder:
            out = Path(folder)
            study.write(out / 'materials/PREFLIGHT.json', {'approved_for_freeze': False})
            with patch.object(study, 'OUT', out), patch.object(study, 'client', side_effect=AssertionError('must not create provider client')):
                with self.assertRaisesRegex(ValueError, 'preflight'):
                    study.prepare()
            self.assertFalse((out / 'prepared').exists())

    def test_verify_rejects_changed_and_missing_frozen_and_historical_files(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as folder:
            root = Path(folder)
            out = root / 'out'
            a, b = root / 'input.txt', root / 'old.txt'
            a.write_text('input')
            b.write_text('history')
            study.write(out / 'FREEZE.json', {'files': {'input.txt': study.sha(a)}, 'historical_files': {'old.txt': study.sha(b)}})
            with patch.object(study, 'ROOT', root), patch.object(study, 'OUT', out):
                study.verify()
                a.write_text('changed')
                with self.assertRaisesRegex(ValueError, 'input.txt'):
                    study.verify()
                a.write_text('input')
                b.write_text('changed')
                with self.assertRaisesRegex(ValueError, 'old.txt'):
                    study.verify()
                b.unlink()
                with self.assertRaisesRegex(ValueError, 'old.txt'):
                    study.verify()

    def run_fixture(self, responses, expect_error=None, already_started=False):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as folder:
            out = Path(folder)
            jobs = []
            request = study.make_request(self.cases[0][1], 'baseline', 'none', self.source, SOURCE_AUTHORITY_GUIDANCE)
            for i in range(2):
                job = {'job_id': f'fixture-{i}', 'request': f'prepared/{i}.json'}
                jobs.append(job)
                study.write(out / job['request'], request)
            study.write(out / 'prepared/jobs.json', jobs)
            if already_started:
                study.write(out / 'run-start.json', {'fixture': True})
            client = FakeClient(responses)
            frozen = {'model': {'fixture': True}, 'historical_files': {'old': 'digest'}}
            with patch.object(study, 'OUT', out), patch.object(study, 'client', return_value=client), \
                 patch.object(study, 'runtime', return_value=frozen['model']), patch.object(study, 'verify', return_value=frozen):
                if expect_error:
                    with self.assertRaises(expect_error):
                        study.run()
                else:
                    study.run()
            records = {p.relative_to(out).as_posix(): p.read_bytes() for p in out.rglob('*') if p.is_file()}
            return client, records

    def test_success_retains_wire_output_and_terminal_record_without_executing_tool(self):
        body = {'done': True, 'done_reason': 'stop', 'message': {'role': 'assistant', 'content': '',
                'tool_calls': [{'function': {'name': 'publish_card', 'arguments': {'text': 'fixture'}}}]}}
        client, records = self.run_fixture([httpx.Response(200, json=body), httpx.Response(200, json=body)])
        self.assertEqual(len(client.sent), 2)
        self.assertEqual(json.loads(records['run-end.json'])['calls'], 2)
        for i in range(2):
            self.assertEqual(records[f'calls/fixture-{i}/request-body.bin'], client.sent[i].content)
            self.assertEqual(json.loads(records[f'calls/fixture-{i}/response-body.bin']), body)
            self.assertNotIn(f'calls/fixture-{i}/error.json', records)

    def test_provider_failure_preserved_and_stops_without_retry(self):
        client, records = self.run_fixture([httpx.Response(503, json={'error': 'fixture unavailable'})], RuntimeError)
        self.assertEqual(len(client.sent), 1)
        self.assertIn('calls/fixture-0/response-body.bin', records)
        self.assertEqual(json.loads(records['calls/fixture-0/response.json'])['http_status'], 503)
        self.assertEqual(json.loads(records['calls/fixture-0/error.json'])['type'], 'RuntimeError')
        self.assertNotIn('run-end.json', records)
        self.assertFalse(any(p.startswith('calls/fixture-1/') for p in records))

    def test_non_json_response_and_timeout_preserve_failure_without_retry(self):
        for response, expected in [(httpx.Response(200, content=b'not json'), ValueError),
                                   (httpx.ReadTimeout('fixture timeout'), httpx.ReadTimeout)]:
            client, records = self.run_fixture([response], expected)
            self.assertEqual(len(client.sent), 1)
            self.assertIn('calls/fixture-0/request-body.bin', records)
            self.assertIn('calls/fixture-0/error.json', records)
            self.assertNotIn('run-end.json', records)

    def test_existing_run_start_prevents_a_second_dispatch(self):
        client, records = self.run_fixture([], FileExistsError, already_started=True)
        self.assertEqual(len(client.sent), 0)
        self.assertFalse(any(p.startswith('calls/') for p in records))

    def test_blind_dedup_preserves_all_120_calls_and_isolates_case_and_stop(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as folder:
            out = Path(folder)
            cases = [case for split, case in self.cases if split == 'new_challenge'][:2]
            real_gold = study.read(study.OUT / 'materials/novel-gold.json')
            study.write(out / 'materials/novel-gold.json', real_gold)
            jobs = []
            for i in range(120):
                case = cases[i % 2]
                job = {'job_id': f'fixture-{i}', 'case_id': case['case_id'],
                       'guidance': 'PRIVATE_ARM_SENTINEL', 'summary': 'PRIVATE_SUMMARY_SENTINEL'}
                jobs.append(job)
                message = {'role': 'assistant', 'content': 'Same visible text.',
                           'tool_calls': [{'function': {'name': 'read_document', 'arguments': {'source_id': 'fixture'}}}]}
                # Stop reason is part of the dedup key, as are complete tool args.
                if i == 2:
                    message['tool_calls'][0]['function']['arguments']['source_id'] = 'different'
                body = {'message': message, 'done_reason': 'length' if i == 0 else 'stop'}
                study.write(out / 'calls' / job['job_id'] / 'response.json', {'body': body})
            study.write(out / 'prepared/jobs.json', jobs)
            study.write(out / 'run-end.json', {'calls': 120})
            with patch.object(study, 'OUT', out), patch.object(study, 'verify', return_value={}), \
                 patch.object(study, 'materials', return_value=[('new_challenge', c) for c in cases]):
                study.blind()
            packets = study.read(out / 'scoring/blind-packets.json')
            mapping = study.read(out / 'scoring/private-mapping.json')
            self.assertEqual(len(packets), 4)
            self.assertEqual(sum(map(len, mapping.values())), 120)
            self.assertEqual({j['job_id'] for js in mapping.values() for j in js}, {j['job_id'] for j in jobs})
            for packet in packets:
                self.assertEqual(set(packet), {'id', 'conversation', 'gold', 'output', 'stop', 'tool_requests_executed'})
                self.assertNotIn('PRIVATE_ARM_SENTINEL', json.dumps(packet))
                self.assertNotIn('PRIVATE_SUMMARY_SENTINEL', json.dumps(packet))
                self.assertIs(packet['tool_requests_executed'], False)


if __name__ == '__main__':
    unittest.main(verbosity=2)
