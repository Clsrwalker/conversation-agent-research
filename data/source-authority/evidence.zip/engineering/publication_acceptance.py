"""Local publication acceptance; no model calls. --check-only never rewrites records."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
from urllib.parse import unquote, urlsplit
import zipfile

ROOT = Path(__file__).resolve().parents[5]
STUDY = ROOT / 'output/research/2026-10-23/source-authority'
DIST = ROOT / 'sites/conversation-agent-research/dist'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


class References(HTMLParser):
    def __init__(self):
        super().__init__()
        self.refs, self.stack, self.ids = [], [], set()

    def handle_starttag(self, tag, attributes):
        attrs = dict(attributes)
        if attrs.get('id'): self.ids.add(attrs['id'])
        for key in ('href', 'src'):
            if key in attrs:
                self.refs.append({'attribute': key, 'url': attrs[key], 'contexts': [a for _, a in self.stack]})
        if tag not in {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'}:
            self.stack.append((tag, attrs))

    def handle_endtag(self, tag):
        for index in range(len(self.stack) - 1, -1, -1):
            if self.stack[index][0] == tag:
                self.stack = self.stack[:index]
                break


def parse(path):
    parser = References()
    parser.feed(path.read_text(encoding='utf-8'))
    return parser


def check(expected_manifest_count):
    page = DIST / 'source-authority.html'
    parsed = parse(page)
    local = []
    for item in parsed.refs:
        url = urlsplit(item['url'])
        if url.scheme or url.netloc:
            continue
        target = (DIST / unquote(url.path).lstrip('/')).resolve() if url.path else page
        assert target.is_relative_to(DIST.resolve()) and target.is_file(), item['url']
        if url.fragment and target.suffix == '.html':
            assert unquote(url.fragment) in parse(target).ids, item['url']
        local.append(item['url'])

    index_path = DIST / 'index.html'
    home = parse(index_path)
    entrypoints = [r for r in home.refs if r['url'] == 'source-authority.html']
    assert len(entrypoints) == 2
    for section in ('recent-progress-rows', 'recent-study-list'):
        assert sum(any(section in a.get('class', '').split() for a in r['contexts']) for r in entrypoints) == 1, section
    home_text = index_path.read_text(encoding='utf-8')
    assert home_text.count('Updated 23 Oct 2026') == 2

    combined = read(DIST / 'data/research-record.json')
    js = (DIST / 'data.js').read_text(encoding='utf-8').strip()
    prefix = 'window.RESEARCH_DATA = '
    assert js.startswith(prefix) and js.endswith(';')
    assert json.loads(js[len(prefix):-1]) == combined
    results = read(DIST / 'data/source-authority/results.json')
    validation = read(DIST / 'data/source-authority-validation.json')
    study_entries = [x for x in combined['research_studies'] if x['id'] == results['id']]
    validation_entries = [x for x in combined['engineering_validations'] if x['id'] == validation['id']]
    assert len(study_entries) == len(validation_entries) == 1
    study_entry, validation_entry = study_entries[0], validation_entries[0]
    assert combined['website_record_date'] == '2026-10-23'
    assert study_entry['date'] == results['date'] == '2026-10-23'
    assert study_entry['new_model_runs'] == results['calls'] == 120
    assert study_entry['status'] == results['status'] == 'completed_scored'
    assert study_entry['tool_requests_executed'] is False and study_entry['delivered_success'] is None
    assert study_entry['record'] == 'source-authority/results.json' and study_entry['page'] == 'source-authority.html'
    assert study_entry['evidence'] == 'source-authority/evidence.zip'
    assert validation_entry['record'] == 'source-authority-validation.json'
    assert validation_entry['date'] == validation['date'] == '2026-10-23'
    assert validation_entry['status'] == validation['status']

    with zipfile.ZipFile(DIST / 'data/source-authority/evidence.zip') as archive:
        assert archive.testzip() is None, 'ZIP CRC failure'
        members = archive.namelist()
        assert len(members) == len(set(members)), 'Duplicate ZIP members'
        manifest = json.loads(archive.read('public-export.json'))['files']
        assert len(manifest) == expected_manifest_count, (len(manifest), expected_manifest_count)
        assert len({r['path'] for r in manifest}) == len(manifest)
        for item in manifest:
            source = (STUDY / item['path']).resolve()
            assert source.is_relative_to(STUDY.resolve()) and source.is_file(), item['path']
            assert sha(source.read_bytes()) == item['source_sha256'], item['path']
            assert sha(archive.read(item['path'])) == item['public_sha256'], item['path']
        assert 'analysis/INDEPENDENT-AUDIT.json' in members
        assert 'scoring/ADJUDICATION.md' in members

    return [
        {'name': 'New page local href/src targets', 'status': 'passed',
         'local_reference_occurrences': len(local), 'distinct_local_targets': len(set(local)),
         'fragment_targets_checked': True},
        {'name': 'Two homepage entries and current masthead/footer dates', 'status': 'passed',
         'entrypoints': ['index.html recent-progress-rows', 'index.html recent-study-list'],
         'updated_date_occurrences': 2, 'date': '2026-10-23'},
        {'name': 'Combined research-record.json and data.js', 'status': 'passed',
         'parsed_objects_equal': True, 'study_entries': 1, 'validation_entries': 1,
         'study_calls': 120, 'website_record_date': '2026-10-23'},
        {'name': 'Evidence ZIP CRC and export manifest', 'status': 'passed',
         'crc_errors': 0, 'duplicate_members': 0, 'manifest_entries': len(manifest),
         'source_and_public_hashes_verified': len(manifest)}
    ]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-only', action='store_true')
    parser.add_argument('--expected-manifest-count', type=int, default=408)
    args = parser.parse_args()
    checks = check(args.expected_manifest_count)
    if not args.check_only:
        path = STUDY / 'engineering/validation.json'
        validation = read(path)
        assert validation['passed_total'] == 28
        validation['publication_checks'] = {
            'date': '2026-10-23', 'timezone': 'America/Halifax',
            'recorded_utc': datetime.now(timezone.utc).isoformat(),
            'status': 'local_artifact_acceptance_passed',
            'scope': 'Local generated website and evidence export only. Hosted deployment is verified by separate root-owned publication receipts.',
            'script': 'engineering/publication_acceptance.py',
            'command': 'experiments/deep_conversation/.venv/Scripts/python.exe -B output/research/2026-10-23/source-authority/engineering/publication_acceptance.py',
            'no_model_calls': True, 'unit_test_total_unchanged': 28, 'checks': checks,
            'browser_observations': {
                'observer': '/root', 'source': 'Root agent reported actual local-browser inspection; this acceptance script does not recreate browser observations.',
                'local_http_status': 200,
                'desktop': {'viewport': {'width': 1280, 'height': 720},
                            'table_client_width': 1064, 'table_scroll_width': 1064,
                            'page_scroll_width': 1265, 'horizontal_page_overflow': False},
                'mobile': {'viewport': {'width': 390, 'height': 844}, 'page_width': 375,
                           'table_wrapper_client_widths': [308, 308, 308],
                           'table_scroll_widths': [680, 680, 680],
                           'behavior': 'Tables scroll horizontally within their wrappers; screenshot text was readable.',
                           'initial_screenshot': 'failed',
                           'recovery': 'Root reread accessibility state, then the second screenshot succeeded.'},
                'navigation': {'back_link_destination': 'index.html#methods', 'heading': 'Studies & tests',
                               'displayed_date': '23 Oct 2026', 'succeeded': True},
                'browser_error_logs': [], 'viewport_reset_after_inspection': True
            },
            'limitations': ['Local page acceptance does not prove hosted publication.',
                           'These checks do not add to the 28 offline software tests or measure model/assistance quality.',
                           'No archive or validation-record hash is stored here, avoiding a hash self-reference.']
        }
        path.write_text(json.dumps(validation, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': 'passed', 'check_only': args.check_only, 'checks': len(checks),
                      'manifest_entries': args.expected_manifest_count, 'model_calls': 0,
                      'validation_written': not args.check_only}))


if __name__ == '__main__':
    main()
