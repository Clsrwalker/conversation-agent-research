"""Check generated website tables/data and record the accompanying narrative review."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[5]
OUT = ROOT / 'output/research/2026-10-23/source-authority'
SITE = ROOT / 'sites/conversation-agent-research'
PUBLIC = SITE / 'dist/data/source-authority'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class Tables(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tables, self.row, self.cell = [], None, None

    def handle_starttag(self, tag, attrs):
        if tag == 'table': self.tables.append([])
        if tag == 'tr': self.row = []
        if tag in ('td', 'th'): self.cell = []

    def handle_data(self, data):
        if self.cell is not None: self.cell.append(data)

    def handle_endtag(self, tag):
        if tag in ('td', 'th'):
            self.row.append(''.join(self.cell).strip())
            self.cell = None
        if tag == 'tr':
            self.tables[-1].append(self.row)
            self.row = None


def scrub(value):
    if isinstance(value, dict):
        return {k.replace(str(ROOT), '').replace('\\', '/').lstrip('/'): scrub(v) for k, v in value.items()}
    if isinstance(value, list): return [scrub(v) for v in value]
    if isinstance(value, str):
        for prefix in (str(ROOT) + '\\', str(ROOT) + '/', ROOT.as_posix() + '/'):
            value = value.replace(prefix, '')
    return value


def run():
    result = read(OUT / 'analysis/results.json')
    interpretation = read(OUT / 'analysis/interpretation.json')
    page_path = SITE / 'dist/source-authority.html'
    page = page_path.read_text(encoding='utf-8')
    parser = Tables()
    parser.feed(page)
    assert len(parser.tables) == 3
    conditions = [('baseline', 'none', 'Ordinary actor · no summary'),
                  ('baseline', 'correct', 'Ordinary actor · correct summary'),
                  ('baseline', 'incorrect', 'Ordinary actor · incorrect summary'),
                  ('source_authority', 'correct', 'Source authority · correct summary'),
                  ('source_authority', 'incorrect', 'Source authority · incorrect summary')]
    def count(g, field):
        c = g[field]
        return f"{c['yes']}/12" + (f" + {c['uncertain']} uncertain" if c['uncertain'] else '')
    for table, split in zip(parser.tables[:2], ('seen_regression', 'new_challenge')):
        assert table[0] == ['Condition', 'Scope errors', 'Excluding pure re-approval errors',
                            'Factual errors', 'Calls with tool requests', 'Total tokens']
        expected = []
        for arm, summary, title in conditions:
            g = next(g for g in result['groups'] if (g['split'], g['guidance'], g['summary']) == (split, arm, summary))
            expected.append([title, count(g, 'scope_error'), count(g, 'scope_error_excluding_reconfirmation'),
                             count(g, 'factual_error'), f"{g['tool_request_outputs']}/12", f"{g['input_tokens']+g['output_tokens']:,}"])
        assert table[1:] == expected
    assert 'Only pure re-approval errors are excluded in the sensitivity column; coexisting errors remain.' in page
    assert 'Its 3/36 action-scope result is not directly comparable with the current main scope metric.' in page
    assert 'They do not measure intention recognition or assistance quality.' in page
    assert 'No tools execute here' in page

    for rel in ('results.json', 'interpretation.json'):
        assert read(PUBLIC / rel) == scrub(read(OUT / 'analysis' / rel))
    assert read(SITE / 'dist/data/source-authority-validation.json') == scrub(read(OUT / 'engineering/validation.json'))
    for rel, source in [('rows.csv', OUT / 'analysis/rows.csv'), ('PROTOCOL.md', OUT / 'PROTOCOL.md'),
                        ('SCORING.md', OUT / 'SCORING.md'), ('RESULTS.md', OUT / 'RESULTS.md')]:
        assert (PUBLIC / rel).read_text(encoding='utf-8') == scrub(source.read_text(encoding='utf-8'))

    checked_bundle_files = 0
    with zipfile.ZipFile(PUBLIC / 'evidence.zip') as archive:
        manifest = json.loads(archive.read('public-export.json'))['files']
        for entry in manifest:
            if entry['path'] == 'analysis/INDEPENDENT-AUDIT.json':
                continue  # Parent rebuilds the archive after this report changes.
            assert sha(OUT / entry['path']) == entry['source_sha256'], entry['path']
            assert hashlib.sha256(archive.read(entry['path'])).hexdigest() == entry['public_sha256'], entry['path']
            checked_bundle_files += 1
        assert 'analysis/INDEPENDENT-AUDIT.json' in archive.namelist()
        assert 'scoring/ADJUDICATION.md' in archive.namelist()

    baseline = [r for r in result['rows'] if r['guidance'] == 'baseline' and r['summary'] != 'none']
    candidate = [r for r in result['rows'] if r['guidance'] == 'source_authority']
    assert len(baseline) == len(candidate) == 48
    base_cost = sum(r['input_tokens'] + r['output_tokens'] for r in baseline)
    cand_cost = sum(r['input_tokens'] + r['output_tokens'] for r in candidate)
    assert (base_cost, cand_cost) == (178156, 194227)
    for c in candidate:
        b = next(r for r in baseline if (r['case_id'], r['summary']) == (c['case_id'], c['summary']))
        assert c['input_tokens'] - b['input_tokens'] == 331
    final_logs = [('engineering/source-authority-tests-rerun.txt', 10),
                  ('engineering/preflight/runner-tests.txt', 13), ('engineering/preflight/scoring-tests.txt', 5)]
    for path, n in final_logs:
        text = (OUT / path).read_text(encoding='utf-8-sig')
        assert f'Ran {n} tests' in text and text.strip().endswith('OK'), path

    audit_path = OUT / 'analysis/INDEPENDENT-AUDIT.json'
    audit = read(audit_path)
    audit['status'] = 'passed_record_accounting_and_local_site_content_review'
    audit['audit_utc'] = datetime.now(timezone.utc).isoformat()
    audit['checks'] += [
        {'name': 'Narrative and recorded failure/uncertainty review', 'status': 'passed', 'detail':
         'Read RESULTS.md and interpretation.json against computed groups and paired outcomes. Independently read all 10 primary yes/uncertain outputs and their final raw turns as a targeted semantic spot-check; no labels were changed. Confirmed 331 extra input tokens per matched call, 178156 vs 194227 total tokens, two factual uncertainties, and 28 final offline checks. No claim of full semantic rescoring.'},
        {'name': 'Generated local HTML numerical tables and metric wording', 'status': 'passed', 'detail':
         'Parsed both five-row result tables and compared every displayed count, uncertainty, tool-call-output denominator and token total. Verified pure-reconfirmation sensitivity wording, old-rubric noncomparability, single-decision scope and no-delivery limitations.'},
        {'name': 'Public JSON, CSV, reports and evidence manifest', 'status': 'passed', 'detail':
         {'json_and_text_exports_match_source': True, 'bundle_manifest_entries_verified': checked_bundle_files,
          'self_audit_bundle_copy': 'Present; intentionally excluded from source-hash comparison because this final audit update requires the parent to rebuild the bundle.'}}
    ]
    audit['interpretation_review'] = {'status': 'passed', 'decision_supported': 'retain_experimental_do_not_promote',
        'scope': 'Recorded findings and limitations are supported by this diagnostic. Publication, browser rendering, and future research outcomes are outside this audit.'}
    audit['publication_validation'] = {'status': 'not_performed_by_this_auditor',
        'remaining': 'Parent must rebuild the evidence bundle to include this final audit and verify publication separately.'}
    for path in (OUT / 'RESULTS.md', OUT / 'analysis/interpretation.json', SITE / 'build_source_authority.py',
                 page_path, PUBLIC / 'results.json', PUBLIC / 'interpretation.json'):
        audit['evidence_sha256'][path.relative_to(ROOT).as_posix()] = sha(path)
    audit_path.write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': audit['status'], 'checks_passed': len(audit['checks']),
                      'bundle_entries_verified_excluding_self': checked_bundle_files, 'html_result_rows': 10}))


if __name__ == '__main__':
    run()
