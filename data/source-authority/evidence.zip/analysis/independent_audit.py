"""Independent post-run accounting. Does not import or execute the study scorer."""
from __future__ import annotations

import ast
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import random
import statistics

ROOT = Path(__file__).resolve().parents[5]
OUT = ROOT / 'output/research/2026-10-23/source-authority'
FIELDS = ('scope_error', 'scope_error_excluding_reconfirmation', 'unnecessary_reconfirmation', 'factual_error', 'observable_omission')
SEMANTIC = (*FIELDS, 'scope_failure_type')
LABELS = ('no', 'uncertain', 'yes')
TYPES = ('attribution', 'condition', 'contraction', 'expansion', 'none', 'uncertain')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def reviews(path):
    rows = read(path)
    rows = rows.get('reviews') if isinstance(rows, dict) else rows
    assert len({r['id'] for r in rows}) == len(rows)
    return {r['id']: r for r in rows}


def audit():
    checks = []
    def passed(name, detail):
        checks.append({'name': name, 'status': 'passed', 'detail': detail})

    frozen = read(OUT / 'FREEZE.json')
    for group in ('files', 'historical_files'):
        for rel, expected in frozen[group].items():
            assert digest(ROOT / rel) == expected, (group, rel)
    passed('Frozen and historical file integrity', {k: len(frozen[k]) for k in ('files', 'historical_files')})

    jobs = read(OUT / 'prepared/jobs.json')
    job_by_id = {j['job_id']: j for j in jobs}
    assert len(jobs) == len(job_by_id) == 120
    assert read(OUT / 'run-end.json')['calls'] == 120
    old = read(ROOT / 'output/research/2026-10-19/summary-causal-replay/materials/cases.json')['cases']
    new = read(OUT / 'materials/novel-cases.json')['cases']
    cases = {c['case_id']: c for c in old + new}
    gold = {g['case_id']: g for g in read(OUT / 'materials/novel-gold.json')['cases']}
    assert len(old) == len(new) == 12 and len(cases) == 24
    conditions = [('baseline', 'none'), ('baseline', 'correct'), ('baseline', 'incorrect'),
                  ('source_authority', 'correct'), ('source_authority', 'incorrect')]
    expected_order = [f"{c['case_id']}--{a}--{s}" for c in old + new for a, s in conditions]
    random.Random(20261023).shuffle(expected_order)
    assert [j['job_id'] for j in jobs] == expected_order
    assert Counter((j['guidance'], j['summary']) for j in jobs) == Counter({c: 24 for c in conditions})

    source = read(ROOT / 'output/research/2026-10-19/source-recovery-replay/calls/native-21--r1--original/ollama-request.json')
    tree = ast.parse((ROOT / 'experiments/deep_conversation/source_authority.py').read_text(encoding='utf-8'))
    guidance = next(ast.literal_eval(n.value) for n in tree.body if isinstance(n, ast.Assign)
                    and any(isinstance(t, ast.Name) and t.id == 'SOURCE_AUTHORITY_GUIDANCE' for t in n.targets))
    raw = {}
    names = Counter()
    for job in jobs:
        folder = OUT / 'calls' / job['job_id']
        assert digest(OUT / job['request']) == job['request_sha256']
        prepared = read(OUT / job['request'])
        assert prepared == read(folder / 'request.json') == json.loads((folder / 'request-body.bin').read_bytes())
        dispatch = read(folder / 'dispatch.json')
        assert {k: dispatch[k] for k in job} == job
        case = cases[job['case_id']]
        observation = {'conversation': case['raw_turns'], 'provenance': case['model_observation']['provenance'],
                       'pending_jobs': [], 'active_cards': {}}
        system = source['messages'][0]['content'] + ('\n\n' + guidance if job['guidance'] == 'source_authority' else '')
        messages = [{'role': 'system', 'content': system}, {'role': 'user', 'content':
                    'Current conversation observation:\n' + json.dumps(observation, ensure_ascii=False, indent=2)}]
        if job['summary'] != 'none':
            messages.append({'role': 'user', 'content': 'Saved working summary:\n' + case['summaries'][job['summary']]})
        messages.append({'role': 'user', 'content': 'Continue assisting from this observation.'})
        assert prepared['messages'] == messages
        assert prepared['model'] == source['model'] and prepared['tools'] == source['tools']
        assert prepared['options'] == source['options'] and prepared['think'] is False
        response = read(folder / 'response.json')
        assert response['body'] == json.loads((folder / 'response-body.bin').read_bytes())
        assert response['http_status'] == 200 and response['body']['done'] is True and not response['body'].get('error')
        assert not (folder / 'error.json').exists()
        raw[job['job_id']] = response
        names.update(t['function']['name'] for t in response['body']['message'].get('tool_calls') or [])
    assert len(list((OUT / 'calls').glob('*/response.json'))) == 120
    passed('All 120 requests, wire bodies, responses and seeded schedule', {'calls': 120, 'no_summary': 24,
        'provider_failures': 0, 'message_reconstruction': 'Exact whitelist reconstruction; no evaluator fields rendered.'})

    packet_rows = read(OUT / 'scoring/blind-packets.json')
    packets = {p['id']: p for p in packet_rows}
    mapping = read(OUT / 'scoring/private-mapping.json')
    assert len(packet_rows) == len(packets) and set(packets) == set(mapping)
    mapped = []
    for packet_id, members in mapping.items():
        packet = packets[packet_id]
        assert set(packet) == {'id', 'conversation', 'gold', 'output', 'stop', 'tool_requests_executed'}
        assert packet['tool_requests_executed'] is False
        for job in members:
            assert job == job_by_id[job['job_id']]
            case = cases[job['case_id']]
            body = raw[job['job_id']]['body']
            assert packet['conversation'] == case['raw_turns']
            assert packet['gold'] == gold.get(job['case_id'], case.get('evaluation_only'))
            assert packet['output'] == body['message'] and packet['stop'] == body.get('done_reason')
            mapped.append(job['job_id'])
    assert len(mapped) == len(set(mapped)) == 120 and set(mapped) == set(job_by_id)
    passed('Blind packets and every mapped response', {'packets': len(packets), 'mapped_calls': len(mapped)})

    a, b, adjudication = [reviews(OUT / 'scoring' / filename) for filename in
                          ('reviewer-a.json', 'reviewer-b.json', 'adjudication.json')]
    assert set(a) == set(b) == set(packets)
    disagreements = {key for key in packets if any(a[key][f] != b[key][f] for f in SEMANTIC)}
    assert disagreements == {'output-041', 'output-119'} and disagreements <= set(adjudication)
    final = {p: adjudication.get(p, a[p]) for p in packets}
    actual = read(OUT / 'analysis/results.json')
    actual_by_job = {r['job_id']: r for r in actual['rows']}
    assert len(actual['rows']) == len(actual_by_job) == 120
    rows = []
    grouped = defaultdict(list)
    for packet_id, members in mapping.items():
        ann = final[packet_id]
        for job in members:
            response = raw[job['job_id']]
            body, message = response['body'], response['body']['message']
            tool_names = [t['function']['name'] for t in message.get('tool_calls') or []]
            row = dict(job, blind_id=packet_id, **{f: ann[f] for f in SEMANTIC}, reason=ann['reason'],
                       evidence_quotes=ann['evidence_quotes'], tool_requests=len(tool_names), tool_names=tool_names,
                       publish_card_requests=tool_names.count('publish_card'), private_text_present=bool(message.get('content', '').strip()),
                       empty_response=not message.get('content', '').strip() and not message.get('tool_calls'),
                       output_truncated=body.get('done_reason') == 'length', input_tokens=body['prompt_eval_count'],
                       output_tokens=body['eval_count'], wall_seconds=response['wall_seconds'],
                       response_sha256=digest(OUT / 'calls' / job['job_id'] / 'response.json'))
            assert row == actual_by_job[job['job_id']], job['job_id']
            rows.append(row)
            grouped[(job['split'], job['guidance'], job['summary'])].append(row)
    assert len(grouped) == 10
    computed_groups = []
    for (split, arm, summary), members in sorted(grouped.items()):
        g = dict(split=split, guidance=arm, summary=summary, n=len(members))
        assert g['n'] == 12
        for field in FIELDS:
            counts = Counter(r[field] for r in members)
            g[field] = {label: counts[label] for label in LABELS}
        g.update(input_tokens=sum(r['input_tokens'] for r in members), output_tokens=sum(r['output_tokens'] for r in members),
                 median_wall_seconds=statistics.median(r['wall_seconds'] for r in members),
                 tool_request_outputs=sum(r['tool_requests'] > 0 for r in members),
                 private_text_only=sum(r['private_text_present'] and not r['tool_requests'] for r in members),
                 publish_card_request_outputs=sum(r['publish_card_requests'] > 0 for r in members),
                 empty_responses=sum(r['empty_response'] for r in members),
                 scope_failure_types={t: sum(r['scope_failure_type'] == t for r in members) for t in TYPES},
                 truncated_outputs=sum(r['output_truncated'] for r in members))
        computed_groups.append(g)
    assert computed_groups == actual['groups']
    passed('Independent final-label application and all 10 group aggregates', {'rows': 120, 'group_denominator': 12,
        'disagreements': sorted(disagreements), 'adjudicated': sorted(adjudication)})

    lookup = {(r['case_id'], r['guidance'], r['summary']): r for r in rows}
    comparisons = []
    for split in ('seen_regression', 'new_challenge'):
        ids = sorted(r['case_id'] for r in rows if r['split'] == split and r['guidance'] == 'baseline' and r['summary'] == 'none')
        for summary in ('correct', 'incorrect'):
            for reference in ('same_summary', 'no_summary'):
                c = {'split': split, 'candidate_summary': summary, 'reference': reference, 'pairs': len(ids),
                     **{f: [] for f in ('fixed', 'regressed', 'uncertain_pairs', 'both_error', 'both_no_error')}}
                for case_id in ids:
                    pair = (lookup[(case_id, 'baseline', summary if reference == 'same_summary' else 'none')]['scope_error'],
                            lookup[(case_id, 'source_authority', summary)]['scope_error'])
                    bucket = 'uncertain_pairs' if 'uncertain' in pair else {
                        ('yes', 'no'): 'fixed', ('no', 'yes'): 'regressed', ('yes', 'yes'): 'both_error', ('no', 'no'): 'both_no_error'}[pair]
                    c[bucket].append(case_id)
                assert sum(len(c[k]) for k in ('fixed', 'regressed', 'uncertain_pairs', 'both_error', 'both_no_error')) == 12
                comparisons.append(c)
    assert comparisons == actual['paired_comparisons']
    token_total = sum(r['input_tokens'] + r['output_tokens'] for r in rows)
    assert actual['total_tokens'] == token_total == 459736
    assert actual['calls'] == 120 and actual['cases'] == 24 and actual['scenario_families'] == 12
    assert actual['provider_failures'] == 0 and actual['delivered_success'] is None and actual['tool_requests_executed'] is False
    passed('Paired outcomes, uncertainty partitions and token totals', {'comparisons': 8, 'pairs_each': 12, 'total_tokens': token_total})

    with (OUT / 'analysis/rows.csv').open(encoding='utf-8', newline='') as f:
        exported = list(csv.DictReader(f))
    assert len(exported) == 120 and len({r['job_id'] for r in exported}) == 120
    for item in exported:
        original = actual_by_job[item['job_id']]
        assert all(item[key] == str(original[key]) for key in item)
    passed('Downloadable per-call CSV', {'rows': 120, 'all_exported_fields_match': True})

    bounds = [{'split': g['split'], 'guidance': g['guidance'], 'summary': g['summary'], 'n': g['n'],
               'scope_error_lower': g['scope_error']['yes'],
               'scope_error_upper': g['scope_error']['yes'] + g['scope_error']['uncertain'],
               'sensitivity_lower': g['scope_error_excluding_reconfirmation']['yes'],
               'sensitivity_upper': g['scope_error_excluding_reconfirmation']['yes'] + g['scope_error_excluding_reconfirmation']['uncertain']}
              for g in computed_groups]
    evidence = [OUT / 'FREEZE.json', OUT / 'analysis/results.json', OUT / 'analysis/rows.csv',
                OUT / 'scoring/reviewer-a.json', OUT / 'scoring/reviewer-b.json', OUT / 'scoring/adjudication.json',
                ROOT / 'sites/conversation-agent-research/build_source_authority.py']
    report = {'date': '2026-10-23', 'timezone': 'America/Halifax', 'reviewer': '/root/study_preflight',
              'audit_utc': datetime.now(timezone.utc).isoformat(), 'status': 'arithmetic_and_raw_records_verified_report_review_pending',
              'method': 'Independent direct JSON/wire/hash recomputation; the study scorer was neither imported nor executed. No model calls.',
              'checks': checks, 'groups': computed_groups, 'paired_comparisons': comparisons, 'uncertainty_bounds': bounds,
              'total_tokens': token_total, 'native_tool_requests_by_name': dict(names),
              'interpretation_review': {'status': 'pending', 'reason': 'Narrative and generated website must be separately inspected.'},
              'limits': ['This audit checks accounting and fidelity to recorded reviews, not independent semantic rescoring of all 120 outputs.',
                         'Old action-scope labels excluded some optional offers/reconfirmation; current primary scope includes settled-scope reapproval. Cross-study error counts are not directly comparable.',
                         'Uncertainty bounds are counts of unresolved semantic possibilities, not confidence intervals.',
                         'No output is evidence of actual tool execution or delivered assistance.'],
              'evidence_sha256': {p.relative_to(ROOT).as_posix(): digest(p) for p in evidence}}
    path = OUT / 'analysis/INDEPENDENT-AUDIT.json'
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': report['status'], 'checks_passed': len(checks), 'total_tokens': token_total,
                      'uncertain_scope_packets': [key for key, v in final.items() if v['scope_error'] == 'uncertain']}))


if __name__ == '__main__':
    audit()
