"""Independent record consistency audit; no semantic labels or model calls."""
from pathlib import Path
import hashlib
import json
import statistics

ROOT = Path(__file__).resolve().parents[5]
HERE = Path(__file__).resolve().parents[1]

def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()

freeze = read(HERE / 'FREEZE.json')
jobs = read(HERE / 'prepared/jobs.json')
assert len(jobs) == len({j['job_id'] for j in jobs}) == 120
assert read(HERE / 'run-end.json')['calls'] == 120
for group in ('files', 'historical_files'):
    assert all(digest(ROOT / path) == expected for path, expected in freeze[group].items())
by_case, groups, tool_names = {}, {}, {}
for job in jobs:
    folder = HERE / 'calls' / job['job_id']
    request = read(folder / 'request.json')
    response = read(folder / 'response.json')
    assert request == read(HERE / job['request']) == read(folder / 'request-body.bin')
    assert response['body'] == read(folder / 'response-body.bin')
    assert response['http_status'] == 200 and response['body']['done']
    assert not (folder / 'error.json').exists()
    assert request['model'] == response['body']['model'] == freeze['model']['model']
    assert request['stream'] is False and request['think'] is False
    assert request['options'] == {'num_ctx': 16384, 'num_predict': 1000, 'temperature': 0.0}
    assert len(request['tools']) == 16
    by_case.setdefault(job['case_id'], {})[(job['guidance'], job['summary'])] = request
    key = f"{job['split']}/{job['guidance']}/{job['summary']}"
    groups.setdefault(key, []).append(response)
    for call in response['body']['message'].get('tool_calls') or []:
        name = call['function']['name']
        tool_names[name] = tool_names.get(name, 0) + 1
for case_id, requests in by_case.items():
    assert len(requests) == 5
    no_summary = requests[('baseline', 'none')]
    for summary in ('correct', 'incorrect'):
        baseline = requests[('baseline', summary)]
        candidate = requests[('source_authority', summary)]
        assert baseline['messages'][1:] == candidate['messages'][1:]
        assert baseline['messages'][0]['content'] in candidate['messages'][0]['content']
        assert baseline['tools'] == candidate['tools'] == no_summary['tools']
        assert baseline['messages'][0] == no_summary['messages'][0]
        assert baseline['messages'][1] == no_summary['messages'][1]
        assert baseline['messages'][-1] == no_summary['messages'][-1]
assert len(by_case) == 24
costs = {}
for key, rows in groups.items():
    costs[key] = {'n': len(rows),
                  'input_tokens': sum(r['body']['prompt_eval_count'] for r in rows),
                  'output_tokens': sum(r['body']['eval_count'] for r in rows),
                  'wall_seconds_sum': sum(r['wall_seconds'] for r in rows),
                  'median_wall_seconds': statistics.median(r['wall_seconds'] for r in rows),
                  'truncations': sum(r['body']['done_reason'] == 'length' for r in rows),
                  'tool_outputs': sum(bool(r['body']['message'].get('tool_calls')) for r in rows),
                  'empty_outputs': sum(not r['body']['message'].get('content','').strip() and not r['body']['message'].get('tool_calls') for r in rows)}
    assert len(rows) == 12
record = {'date': '2026-10-23', 'timezone': 'America/Halifax', 'status': 'passed',
          'type': 'engineering_record_audit', 'calls': 120, 'cases': 24,
          'gold_leakage_check': 'Actor fields restricted and frozen before inference; see independent PREFLIGHT.json.',
          'request_and_wire_equal': 120, 'response_and_wire_equal': 120,
          'condition_pairs_equal_except_system_guidance': 48,
          'unchanged_frozen_files': len(freeze['files']),
          'unchanged_historical_files': len(freeze['historical_files']),
          'costs': costs, 'tool_requests_by_name': tool_names,
          'provider_failures': 0, 'tool_requests_executed': False,
          'limits': 'Counts and wire consistency do not grade semantics. Request times include cold load/cache effects, not a controlled latency claim.'}
(HERE / 'analysis/execution-audit.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k:v for k,v in record.items() if k not in ('costs',)}, ensure_ascii=False))
