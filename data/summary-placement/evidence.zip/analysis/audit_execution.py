"""Independent raw-record audit of the completed summary-placement batch.

Standard library only; never imports the runner/scorer, calls a model, executes
tools, grades answers or rewrites frozen evidence. Run only after run-end.json
exists. The report is exclusive-create so an earlier audit is not overwritten.
"""
from __future__ import annotations

import ast
from collections import Counter, defaultdict
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import statistics

HERE = Path(__file__).resolve().parents[1]
ROOT = Path(__file__).resolve().parents[5]
PRIOR = ROOT / 'output/research/2026-10-23/source-authority'
OLDER = ROOT / 'output/research/2026-10-19/summary-causal-replay'
SOURCE = ROOT / 'output/research/2026-10-19/source-recovery-replay/calls/native-21--r1--original/ollama-request.json'
SPLITS = {'seen_regression': 'earlier_regression', 'new_challenge': 'previously_authored_challenge'}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(condition, detail):
    if not condition:
        raise ValueError(detail)


def inside(base, relative):
    path = (base / str(relative).replace('\\', '/')).resolve()
    require(path.is_relative_to(base.resolve()), f'Path outside expected root: {relative}')
    return path


def unique(rows, field):
    result = {row[field]: row for row in rows}
    require(len(result) == len(rows), f'Duplicate {field}')
    return result


def timestamp(value):
    result = datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(result.tzinfo is not None, 'Recorded timestamp lacks timezone')
    return result


def guidance_literal(path):
    # Read a literal without executing/importing the source module.
    tree = ast.parse(path.read_text(encoding='utf-8-sig'))
    matches = [node.value for node in tree.body if isinstance(node, ast.Assign)
               and any(isinstance(target, ast.Name) and target.id == 'SOURCE_AUTHORITY_GUIDANCE'
                       for target in node.targets)]
    require(len(matches) == 1, 'Expected one fixed guidance assignment')
    value = ast.literal_eval(matches[0])
    require(isinstance(value, str), 'Guidance is not a literal string')
    return value


def main():
    report_path = HERE / 'analysis/execution-audit.json'
    require(not report_path.exists(), 'Refusing to replace an existing execution audit')
    require((HERE / 'run-end.json').is_file(), 'Batch has no terminal run-end record; do not audit as complete')
    freeze = read(HERE / 'FREEZE.json')
    preflight = read(HERE / 'PREFLIGHT.json')
    jobs = read(HERE / 'prepared/jobs.json')
    jobs_by_id = unique(jobs, 'job_id')
    planned = preflight['design']['total_new_calls']
    require(len(jobs) == freeze['calls'] == planned, 'Planned/frozen/assigned counts differ')
    require(freeze['quality_retry'] is False and freeze['repetitions'] == 1, 'Unexpected retry/repeat design')
    start, end = read(HERE / 'run-start.json'), read(HERE / 'run-end.json')
    require(end['calls'] == len(jobs), 'Terminal completed count differs')
    require(end['unchanged_historical_files'] == len(freeze['historical_files']), 'Terminal protected count differs')
    require(timestamp(start['utc']) <= timestamp(end['utc']), 'Invalid run interval')

    all_frozen = {}
    for group in ('files', 'historical_files'):
        for relative, expected in freeze[group].items():
            normalized = str(relative).replace('\\', '/')
            if normalized in all_frozen:
                require(all_frozen[normalized] == expected, f'Conflicting freeze entries: {normalized}')
            all_frozen[normalized] = expected
            path = inside(ROOT, normalized)
            require(path.is_file() and digest(path) == expected, f'Frozen bytes changed: {relative}')

    prior_jobs = unique(read(PRIOR / 'prepared/jobs.json'), 'job_id')
    old_cases = read(OLDER / 'materials/cases.json')['cases']
    authored = read(PRIOR / 'materials/novel-cases.json')['cases']
    cases = unique([*old_cases, *authored], 'case_id')
    require(len(cases) == preflight['design']['cases'], 'Case count differs from protocol')
    source = read(SOURCE)
    guidance = guidance_literal(ROOT / 'experiments/deep_conversation/source_authority.py')
    base_system = source['messages'][0]['content']
    require(len(source['tools']) == 16, 'Historical captured tools differ')

    folders = {path.name for path in (HERE / 'calls').iterdir() if path.is_dir()}
    require(folders == set(jobs_by_id), 'Missing or extra call folders')
    groups, by_case, tools = defaultdict(list), defaultdict(dict), Counter()
    dispatch_times, response_times = [], []
    unchanged, swapped = 0, 0
    expected_request_keys = {'model', 'messages', 'stream', 'tools', 'think', 'options', 'keep_alive'}

    for job in jobs:
        job_id, case_id = job['job_id'], job['case_id']
        require(case_id in cases, f'Unknown actor case: {job_id}')
        old = prior_jobs[job['prior_job_id']]
        require(all(job[key] == old[key] for key in ('case_id', 'family', 'guidance', 'summary')),
                f'Prior condition metadata changed: {job_id}')
        require(job['split'] == SPLITS[old['split']], f'Wrong provenance mapping: {job_id}')
        prior_path = inside(PRIOR, old['request'])
        require(digest(prior_path) == old['request_sha256'] == job['prior_request_sha256'],
                f'Prior request identity mismatch: {job_id}')
        expected = deepcopy(read(prior_path))
        order = job['order']
        if job['summary'] == 'none':
            require((job['guidance'], order) == ('baseline', 'none'), f'Extra no-summary arm: {job_id}')
            unchanged += 1
        else:
            require(order in {'summary_first', 'summary_last'}, f'Unexpected layout: {job_id}')
            if order == 'summary_first':
                expected['messages'][1:3] = expected['messages'][1:3][::-1]
                swapped += 1
            else:
                unchanged += 1
        require(job_id == old['job_id'] + '--' + order, f'Job identity differs: {job_id}')

        prepared_path = inside(HERE, job['request'])
        require(digest(prepared_path) == job['request_sha256'], f'Prepared request digest differs: {job_id}')
        prepared = read(prepared_path)
        folder = HERE / 'calls' / job_id
        request = read(folder / 'request.json')
        request_wire = read(folder / 'request-body.bin')
        require(request == request_wire == prepared == expected, f'Wire/prepared/allowed-swap mismatch: {job_id}')
        require(set(request) == expected_request_keys, f'Unexpected actor request field: {job_id}')

        # Independently construct the entire permitted actor message content.
        # Gold/probe/evaluation_only fields are not selected into this structure.
        case = cases[case_id]
        observation = {'conversation': case['raw_turns'],
                       'provenance': case['model_observation']['provenance'],
                       'pending_jobs': [], 'active_cards': {}}
        raw_message = {'role': 'user', 'content': 'Current conversation observation:\n' +
                       json.dumps(observation, ensure_ascii=False, indent=2)}
        system_text = base_system + ('\n\n' + guidance if job['guidance'] == 'source_authority' else '')
        require(job['guidance'] in {'baseline', 'source_authority'}, f'Unknown guidance: {job_id}')
        permitted = [{'role': 'system', 'content': system_text}]
        if job['summary'] == 'none':
            permitted.append(raw_message)
        else:
            require(job['summary'] in {'correct', 'incorrect'}, f'Unknown summary: {job_id}')
            summary_message = {'role': 'user', 'content': 'Saved working summary:\n' + case['summaries'][job['summary']]}
            permitted.extend([summary_message, raw_message] if order == 'summary_first'
                             else [raw_message, summary_message])
        permitted.append({'role': 'user', 'content': 'Continue assisting from this observation.'})
        require(request['messages'] == permitted, f'Actor content outside reviewed whitelist: {job_id}')
        require(request['tools'] == source['tools'], f'Tool definitions changed: {job_id}')
        require(request['model'] == freeze['model']['model'] and request['stream'] is False
                and request['think'] is False and request['keep_alive'] == '5m', f'Request settings changed: {job_id}')
        require(request['options'] == {'num_ctx': 16384, 'num_predict': 1000, 'temperature': 0.0},
                f'Decoding settings changed: {job_id}')

        dispatch = read(folder / 'dispatch.json')
        require({key: value for key, value in dispatch.items() if key != 'utc'} == job,
                f'Dispatch metadata mismatch: {job_id}')
        response = read(folder / 'response.json')
        body = response['body']
        require(body == read(folder / 'response-body.bin'), f'Response wire mismatch: {job_id}')
        require(response['http_status'] == 200 and body.get('done') is True and not body.get('error'),
                f'Provider failed or incomplete: {job_id}')
        require(body['model'] == request['model'], f'Response model differs: {job_id}')
        require(not (folder / 'error.json').exists(), f'Error record exists: {job_id}')
        require(isinstance(body.get('message'), dict) and body['message'].get('role') == 'assistant',
                f'Missing assistant response: {job_id}')
        for field in ('prompt_eval_count', 'eval_count'):
            require(type(body.get(field)) is int and body[field] >= 0, f'Missing/invalid token counter: {job_id}/{field}')
        require(isinstance(response.get('wall_seconds'), (int, float)) and response['wall_seconds'] >= 0,
                f'Missing/invalid elapsed time: {job_id}')
        dispatch_times.append(timestamp(dispatch['utc']))
        response_times.append(timestamp(response['utc']))
        require(timestamp(start['utc']) <= dispatch_times[-1] <= response_times[-1] <= timestamp(end['utc']),
                f'Call outside recorded run interval: {job_id}')
        condition = (job['guidance'], job['summary'], order)
        require(condition not in by_case[case_id], f'Duplicate condition: {job_id}')
        by_case[case_id][condition] = request
        groups['/'.join((job['split'], *condition))].append(response)
        for call in body['message'].get('tool_calls') or []:
            tools[call.get('function', {}).get('name', '<missing>')] += 1

    require(dispatch_times == sorted(dispatch_times), 'Dispatches do not follow frozen schedule order')
    require(all(response_times[i] <= dispatch_times[i + 1] for i in range(len(jobs) - 1)),
            'Recorded calls overlap despite serial dispatch contract')
    summarized = {(guidance, summary, order) for guidance in ('baseline', 'source_authority')
                  for summary in ('correct', 'incorrect') for order in ('summary_first', 'summary_last')}
    expected_conditions = summarized | {('baseline', 'none', 'none')}
    require(set(by_case) == set(cases), 'Missing case')
    for case_id, conditions in by_case.items():
        require(set(conditions) == expected_conditions, f'Incomplete per-case matrix: {case_id}')
    require(len(groups) == preflight['design']['groups'], 'Unexpected group count')
    require({len(rows) for rows in groups.values()} == {preflight['design']['cases_per_group']}, 'Unequal group sizes')

    costs = {}
    for group, rows in sorted(groups.items()):
        costs[group] = {'n': len(rows),
                       'input_tokens': sum(row['body']['prompt_eval_count'] for row in rows),
                       'output_tokens': sum(row['body']['eval_count'] for row in rows),
                       'wall_seconds_sum': sum(row['wall_seconds'] for row in rows),
                       'median_wall_seconds': statistics.median(row['wall_seconds'] for row in rows),
                       'stops': dict(Counter(row['body'].get('done_reason', '<missing>') for row in rows)),
                       'tool_request_outputs': sum(bool(row['body']['message'].get('tool_calls')) for row in rows),
                       'empty_outputs': sum(not row['body']['message'].get('content', '').strip()
                                            and not row['body']['message'].get('tool_calls') for row in rows)}
    record = {'schema_version': 'summary-placement-independent-execution-audit-v1',
              'date': preflight['date'], 'date_basis': 'Frozen study date in America/Halifax',
              'audited_at_utc': datetime.now(timezone.utc).isoformat(),
              'timezone': 'America/Halifax', 'status': 'passed', 'kind': 'engineering_record_audit',
              'audit_source_sha256': digest(Path(__file__)), 'freeze_sha256': digest(HERE / 'FREEZE.json'),
              'calls': len(jobs), 'cases': len(cases), 'groups': len(groups),
              'request_and_wire_equal': len(jobs), 'response_and_wire_equal': len(jobs),
              'prior_request_unchanged': unchanged, 'prior_request_only_message_swap': swapped,
              'gold_exclusion': {'checked_calls': len(jobs),
                  'method': 'Exact independent reconstruction of all actor messages from raw_turns, provenance, selected summary, frozen system guidance and final continuation; exact historical tools and top-level request whitelist. Evaluator fields are not selected.'},
              'unchanged_frozen_files': len(freeze['files']),
              'unchanged_protected_files': len(freeze['historical_files']),
              'unique_frozen_paths': len(all_frozen), 'costs': costs,
              'tool_requests_by_name': dict(sorted(tools.items())),
              'provider_failures': 0, 'tool_requests_executed_by_this_audit': 0,
              'model_calls_by_this_audit': 0, 'semantic_quality_assessed': False,
              'limits': ['Checks establish record consistency and the declared input manipulation, not semantic correctness.',
                         'The study exposes tools but does not execute their requests; private prose is not delivered help.',
                         'All states were previously exposed; repeated conditions are not independent conversations.',
                         'Summary-first swaps both summary position and dialogue recency; it is not native compaction.',
                         'Timing includes loading and cache effects; no general speed claim is supported.',
                         'Matching this study freeze does not prove older whole-harness fingerprints match the current workspace.']}
    report_path.parent.mkdir(parents=True, exist_ok=True)
    with report_path.open('x', encoding='utf-8') as stream:
        json.dump(record, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({key: value for key, value in record.items() if key not in {'costs', 'limits'}}))


if __name__ == '__main__':
    main()
