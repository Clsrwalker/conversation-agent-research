"""Independently audit completed placement records, without importing the scorer.

Run only after results.json, both reviews and any adjudication are complete.
This audits provenance and arithmetic, not the semantic validity of AI labels.
Default writes a new INDEPENDENT-AUDIT.json; --check-only never changes it.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from copy import deepcopy
import csv
from datetime import datetime, timezone
import hashlib
from itertools import product
import json
from pathlib import Path
import random
from statistics import median

ROOT = Path(__file__).resolve().parents[5]
OUT = Path(__file__).resolve().parent.parent
PRIOR = ROOT / 'output/research/2026-10-23/source-authority'
OLDER = ROOT / 'output/research/2026-10-19/summary-causal-replay'
FIELDS = ('scope_error', 'scope_error_excluding_reconfirmation',
          'unnecessary_reconfirmation', 'factual_error', 'observable_omission')
CLASSIFICATIONS = (*FIELDS, 'scope_failure_type')
LABELS = ('yes', 'no', 'uncertain')
TYPES = ('expansion', 'contraction', 'condition', 'attribution', 'none', 'uncertain')
STRATA = ('earlier_regression', 'previously_authored_challenge')
ACTORS = ('baseline', 'source_authority')
SUMMARIES = ('correct', 'incorrect')
ORDERS = ('summary_first', 'summary_last')
KEY_FIELDS = ('split', 'guidance', 'summary', 'order')
BUCKETS = ('fixed', 'regressed', 'uncertain_pairs', 'both_error', 'both_no_error')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(condition, description):
    if not condition:
        raise AssertionError(description)


def indexed(items, key, description):
    result = {row[key]: row for row in items}
    require(len(result) == len(items), f'Duplicate {description}')
    return result


def comparison_identity(message):
    """Independent implementation of the frozen, narrowly declared ID policy."""
    result = deepcopy(message)
    native = result.get('tool_calls') or []
    ids = [entry.get('id') for entry in native]
    if all(isinstance(item, str) and item != '' for item in ids) and len(set(ids)) == len(ids):
        for entry in native:
            del entry['id']
    return result


def semantic_key(case, body):
    return json.dumps([case, comparison_identity(body['message']), body.get('done_reason')],
                      sort_keys=True, ensure_ascii=False)


def strings(value):
    if isinstance(value, dict):
        return [text for item in value.values() for text in strings(item)]
    if isinstance(value, list):
        return [text for item in value for text in strings(item)]
    return [str(value)]


def annotations(path, packets, partial=False):
    value = read(path)
    rows = value['reviews'] if isinstance(value, dict) else value
    reviews = indexed(rows, 'id', f'review ID in {path.name}')
    require(set(reviews) <= set(packets), f'Unknown review ID in {path.name}')
    if not partial:
        require(set(reviews) == set(packets), f'Incomplete {path.name}')
    for key, row in reviews.items():
        require(all(row.get(field) in LABELS for field in FIELDS), f'Invalid labels {path.name}/{key}')
        require(row.get('scope_failure_type') in TYPES, f'Invalid subtype {key}')
        require(isinstance(row.get('reason'), str) and bool(row['reason'].strip()), f'No rationale {key}')
        if row['scope_error'] == 'no':
            require(row['scope_failure_type'] == 'none' and row['scope_error_excluding_reconfirmation'] == 'no', f'No-error inconsistency {key}')
        if row['scope_error'] == 'yes':
            require(row['scope_failure_type'] not in ('none', 'uncertain'), f'No definite subtype {key}')
        if row['unnecessary_reconfirmation'] == 'yes' or row['scope_error_excluding_reconfirmation'] == 'yes':
            require(row['scope_error'] == 'yes', f'Primary/sensitivity/reconfirmation inconsistency {key}')
        output = packets[key]['output']
        empty = not output.get('content', '').strip() and not output.get('tool_calls')
        quotes = row.get('evidence_quotes', [])
        require(isinstance(quotes, list), f'Quotes must be a list {key}')
        require(bool(quotes) or empty, f'Missing actual-output quote {key}')
        observed = strings(output)
        require(all(isinstance(q, str) and q and any(q in text for text in observed) for q in quotes), f'Non-exact output quote {key}')
    return reviews


def audit():
    require((OUT / 'analysis/results.json').is_file(), 'Results are not complete; do not audit an active run')
    require(read(OUT / 'run-end.json')['calls'] == 216, 'Missing completed 216-call terminal record')
    require((OUT / 'run-start.json').is_file(), 'Missing run-start record')
    frozen = read(OUT / 'FREEZE.json')
    checks = []

    def passed(name, evidence):
        checks.append({'id': name, 'status': 'passed', 'evidence': evidence})
        print(name + ': passed', flush=True)

    for section in ('files', 'historical_files'):
        for path, expected in frozen[section].items():
            require((ROOT / path).is_file() and digest(ROOT / path) == expected,
                    f'Frozen file differs or is absent: {path}')
    prior_freeze = read(PRIOR / 'FREEZE.json')
    for section in ('files', 'historical_files'):
        for path, expected in prior_freeze[section].items():
            require(digest(ROOT / path) == expected, f'Prior freeze changed: {path}')
    passed('frozen_inputs_and_historical_evidence', {
        'current_input_entries': len(frozen['files']),
        'current_historical_entries': len(frozen['historical_files']),
        'prior_input_entries': len(prior_freeze['files']),
        'prior_historical_entries': len(prior_freeze['historical_files'])})

    old_cases = read(OLDER / 'materials/cases.json')['cases']
    authored_cases = read(PRIOR / 'materials/novel-cases.json')['cases']
    cases = indexed(old_cases + authored_cases, 'case_id', 'case')
    gold = {row['case_id']: row['evaluation_only'] for row in old_cases}
    gold.update(indexed(read(PRIOR / 'materials/novel-gold.json')['cases'], 'case_id', 'gold case'))
    require(len(cases) == len(gold) == 24 and set(cases) == set(gold), 'Gold/case coverage mismatch')
    split_for_case = {row['case_id']: 'earlier_regression' for row in old_cases}
    split_for_case.update({row['case_id']: 'previously_authored_challenge' for row in authored_cases})
    previous_jobs = indexed(read(PRIOR / 'prepared/jobs.json'), 'job_id', 'prior job')
    job_rows = read(OUT / 'prepared/jobs.json')
    jobs = indexed(job_rows, 'job_id', 'current job')
    require(len(jobs) == 216, 'Wrong current job count')
    expected_cells = {(case, actor, summary, order)
                      for case, actor, summary, order in product(cases, ACTORS, SUMMARIES, ORDERS)}
    expected_cells |= {(case, 'baseline', 'none', 'none') for case in cases}
    require({(j['case_id'], j['guidance'], j['summary'], j['order']) for j in job_rows} == expected_cells,
            '216-cell design mismatch')
    bodies, responses, requests = {}, {}, {}
    for job in job_rows:
        key, case = job['job_id'], job['case_id']
        require(job['split'] == split_for_case[case], f'Provenance mismatch {key}')
        require(job['family'] == cases[case]['scenario_id'], f'Family mismatch {key}')
        prior_job = previous_jobs[job['prior_job_id']]
        for name in ('case_id', 'family', 'guidance', 'summary'):
            require(job[name] == prior_job[name], f'Prior condition mismatch {key}/{name}')
        prior_path = PRIOR / prior_job['request']
        prior_request = read(prior_path)
        require(job['prior_request_sha256'] == digest(prior_path), f'Prior input hash mismatch {key}')
        expected_request = deepcopy(prior_request)
        if job['order'] == 'summary_first':
            expected_request['messages'][1], expected_request['messages'][2] = expected_request['messages'][2], expected_request['messages'][1]
        prepared_path = OUT / job['request']
        require(job['request_sha256'] == digest(prepared_path), f'Prepared hash mismatch {key}')
        request = read(prepared_path)
        require(request == expected_request, f'Non-placement request change {key}')
        folder = OUT / 'calls' / key
        require(read(folder / 'request.json') == request, f'Executed input mismatch {key}')
        require(json.loads((folder / 'request-body.bin').read_bytes()) == request, f'Request wire mismatch {key}')
        dispatch = read(folder / 'dispatch.json')
        require(set(dispatch) == set(job) | {'utc'} and all(dispatch[k] == v for k, v in job.items()), f'Dispatch/job mismatch {key}')
        response = read(folder / 'response.json')
        body = response['body']
        require(response['http_status'] == 200 and body.get('done') is True and not body.get('error'), f'Incomplete provider response {key}')
        require(json.loads((folder / 'response-body.bin').read_bytes()) == body, f'Response wire mismatch {key}')
        require(not (folder / 'error.json').exists(), f'Unexpected recorded provider failure {key}')
        require(all(type(body.get(k)) is int and body[k] >= 0 for k in ('prompt_eval_count', 'eval_count')), f'Invalid token counters {key}')
        requests[key], responses[key], bodies[key] = request, response, body
    require({p.name for p in (OUT / 'calls').iterdir() if p.is_dir()} == set(jobs), 'Call directories differ from frozen schedule')
    passed('all_216_raw_wire_records_and_only_declared_message_swap', {'calls': 216, 'cases': 24, 'ordinary_no_summary_calls': 24})

    packets = indexed(read(OUT / 'scoring/blind-packets.json'), 'id', 'blind packet ID')
    mapping = read(OUT / 'scoring/private-mapping.json')
    require(set(mapping) == set(packets), 'Mapping/packet IDs differ')
    shuffled = list(job_rows)
    random.Random(90231026).shuffle(shuffled)
    equivalent, expected_mapping = {}, {}
    for job in shuffled:
        response = bodies[job['job_id']]
        identity = semantic_key(job['case_id'], response)
        if identity not in equivalent:
            blind_id = f'output-{len(equivalent) + 1:03d}'
            equivalent[identity] = blind_id
            expected_mapping[blind_id] = []
            packet = packets[blind_id]
            require(set(packet) == {'id', 'conversation', 'gold', 'output', 'stop', 'tool_requests_executed'}, f'Unexpected/unblinded packet field {blind_id}')
            require(packet['conversation'] == cases[job['case_id']]['raw_turns'], f'Raw conversation mismatch {blind_id}')
            require(packet['gold'] == gold[job['case_id']], f'Gold mismatch {blind_id}')
            require(packet['output'] == response['message'], f'Representative original ID/message lost {blind_id}')
            require(packet['stop'] == response.get('done_reason') and packet['tool_requests_executed'] is False, f'Packet stop/execution mismatch {blind_id}')
        expected_mapping[equivalent[identity]].append(job)
    require(mapping == expected_mapping and len(equivalent) == len(packets), 'Deduplication differs from exact declared case/message/stop equivalence')
    packet_by_job = {j['job_id']: key for key, entries in mapping.items() for j in entries}
    require(len(packet_by_job) == sum(map(len, mapping.values())) == 216, 'Lost or repeated mapped jobs')
    passed('blind_equivalence_classes_and_full_job_mapping', {'unique_packets': len(packets), 'mapped_calls': 216, 'transport_ids_only_ignored_if_valid_unique_strings': True})

    review_a = annotations(OUT / 'scoring/reviewer-a.json', packets)
    review_b = annotations(OUT / 'scoring/reviewer-b.json', packets)
    differences = sorted(key for key in packets if any(review_a[key][name] != review_b[key][name] for name in CLASSIFICATIONS))
    adjudication_path = OUT / 'scoring/adjudication.json'
    adjudication = annotations(adjudication_path, packets, partial=True) if adjudication_path.exists() else {}
    require(set(adjudication) == set(differences), 'Adjudication must exactly cover the six-field disagreements')
    final_labels = {key: adjudication.get(key, review_a[key]) for key in packets}
    passed('review_schema_exact_evidence_and_final_label_selection', {
        'reviewer_a_records': len(review_a), 'reviewer_b_records': len(review_b),
        'disagreements': differences, 'adjudicated': sorted(adjudication),
        'semantic_correctness_established_by_this_schema_check': False})

    rows = {}
    for key, job in jobs.items():
        body, record = bodies[key], responses[key]
        message = body['message']
        tools = message.get('tool_calls') or []
        annotation = final_labels[packet_by_job[key]]
        rows[key] = {**job, 'blind_id': packet_by_job[key],
            **{name: annotation[name] for name in CLASSIFICATIONS},
            'reason': annotation['reason'], 'evidence_quotes': annotation['evidence_quotes'],
            'tool_requests': len(tools),
            'tool_names': [entry.get('function', {}).get('name') for entry in tools],
            'publish_card_requests': sum(entry.get('function', {}).get('name') == 'publish_card' for entry in tools),
            'private_text_present': bool(message.get('content', '').strip()),
            'empty_response': not message.get('content', '').strip() and not tools,
            'output_truncated': body.get('done_reason') == 'length',
            'input_tokens': body['prompt_eval_count'], 'output_tokens': body['eval_count'],
            'wall_seconds': record['wall_seconds'],
            'response_sha256': digest(OUT / 'calls' / key / 'response.json')}
    result = read(OUT / 'analysis/results.json')
    require(indexed(result['rows'], 'job_id', 'scored row') == rows, 'Scored rows differ from independent reconstruction')
    with (OUT / 'analysis/rows.csv').open(newline='', encoding='utf-8-sig') as stream:
        reader = csv.DictReader(stream)
        columns = ['job_id', 'case_id', 'family', 'split', 'guidance', 'summary', 'order', *CLASSIFICATIONS,
                   'tool_requests', 'private_text_present', 'output_truncated', 'input_tokens', 'output_tokens', 'wall_seconds']
        require(reader.fieldnames == columns, 'CSV columns differ from declared export')
        csv_rows = indexed(list(reader), 'job_id', 'CSV job')
    require(set(csv_rows) == set(rows), 'CSV missing/extra rows')
    for key, row in rows.items():
        require(csv_rows[key] == {column: str(row[column]) for column in columns}, f'CSV differs at {key}')
    passed('all_final_labels_behavior_fields_and_216_csv_rows', {'rows': len(rows), 'csv_rows': len(csv_rows)})

    grouped = defaultdict(list)
    for row in rows.values():
        grouped[tuple(row[k] for k in KEY_FIELDS)].append(row)
    group_results = {}
    for key, members in grouped.items():
        require(len(members) == 12, f'Wrong group denominator {key}')
        value = {**dict(zip(KEY_FIELDS, key)), 'n': len(members)}
        for field in FIELDS:
            count = Counter(row[field] for row in members)
            value[field] = {label: count[label] for label in LABELS}
        value.update(
            input_tokens=sum(row['input_tokens'] for row in members),
            output_tokens=sum(row['output_tokens'] for row in members),
            tool_request_outputs=sum(bool(row['tool_requests']) for row in members),
            tool_requests=sum(row['tool_requests'] for row in members),
            publish_card_request_outputs=sum(bool(row['publish_card_requests']) for row in members),
            private_text_only=sum(row['private_text_present'] and row['tool_requests'] == 0 for row in members),
            empty_responses=sum(row['empty_response'] for row in members),
            truncated_outputs=sum(row['output_truncated'] for row in members),
            median_wall_seconds=median(row['wall_seconds'] for row in members),
            scope_failure_types={kind: sum(row['scope_failure_type'] == kind for row in members) for kind in TYPES})
        group_results[key] = value
    supplied_groups = {tuple(row[k] for k in KEY_FIELDS): row for row in result['groups']}
    require(len(supplied_groups) == len(result['groups']) == len(group_results) == 18, 'Wrong or duplicate groups')
    require(supplied_groups == group_results, 'Group statistics differ from independent recomputation')
    passed('all_18_groups_all_fields_and_costs', {'groups': 18, 'denominator_each': 12, 'ternary_metrics': list(FIELDS)})

    lookups = {(row['case_id'], row['guidance'], row['summary'], row['order']): row for row in rows.values()}
    endpoints = []
    for split, metric, summary in product(STRATA, FIELDS[:2], SUMMARIES):
        for actor in ACTORS:
            endpoints.append((split, metric, 'placement', (actor, summary, 'summary_last'), (actor, summary, 'summary_first')))
        for order in ORDERS:
            endpoints.append((split, metric, 'guidance', ('baseline', summary, order), ('source_authority', summary, order)))
        for actor, order in product(ACTORS, ORDERS):
            endpoints.append((split, metric, 'no_summary_reference', ('baseline', 'none', 'none'), (actor, summary, order)))
    comparisons = {}
    category = {('yes', 'no'): 'fixed', ('no', 'yes'): 'regressed', ('yes', 'yes'): 'both_error', ('no', 'no'): 'both_no_error'}
    for split, metric, kind, left, right in endpoints:
        buckets = {name: [] for name in BUCKETS}
        case_ids = sorted(case for case in cases if split_for_case[case] == split)
        for case in case_ids:
            labels = (lookups[(case, *left)][metric], lookups[(case, *right)][metric])
            bucket = 'uncertain_pairs' if 'uncertain' in labels else category[labels]
            buckets[bucket].append(case)
        value = {'split': split, 'metric': metric, 'comparison': kind,
                 'reference': list(left), 'candidate': list(right), 'pairs': len(case_ids), **buckets}
        comparisons[(split, metric, kind, left, right)] = value
    supplied_comparisons = {(row['split'], row['metric'], row['comparison'], tuple(row['reference']), tuple(row['candidate'])): row for row in result['paired_comparisons']}
    require(len(supplied_comparisons) == len(result['paired_comparisons']) == len(comparisons) == 64, 'Wrong or duplicate paired comparisons')
    require(supplied_comparisons == comparisons, 'Paired fixed/regressed/uncertain/tied case lists differ')
    passed('all_64_paired_comparisons_and_shared_no_summary_reference', {'comparisons': 64, 'pairs_each': 12, 'shared_reference_comparisons': 32})

    repeated = {}
    for key, job in jobs.items():
        if job['order'] == 'summary_first':
            continue
        previous_call = PRIOR / 'calls' / job['prior_job_id']
        same_input = read(previous_call / 'request.json') == requests[key]
        old_body = read(previous_call / 'response.json')['body']
        same_output = semantic_key(job['case_id'], old_body) == semantic_key(job['case_id'], bodies[key])
        require(same_input, f'Repeat-input mismatch {key}')
        repeated[key] = {'job_id': key, 'prior_job_id': job['prior_job_id'], 'same_input': same_input,
                         'same_response_ignoring_call_ids': same_output}
    require(len(repeated) == 120, 'Wrong repeat-input denominator')
    require(indexed(result['repeat_input_check'], 'job_id', 'repeat check') == repeated, 'Repeat identity result differs')
    token_totals = {name: sum(row[name] for row in rows.values()) for name in ('input_tokens', 'output_tokens')}
    require(result['total_tokens'] == sum(token_totals.values()), 'Total token sum differs')
    expected_metadata = {'id': 'summary-placement-2026-10-23', 'date': '2026-10-23', 'timezone': 'America/Halifax',
        'type': 'model_component_diagnostic', 'status': 'completed_scored', 'calls': 216, 'scenario_families': 12,
        'cases': 24, 'all_cases_previously_exposed': True, 'repetitions': 1, 'tool_requests_executed': False,
        'delivered_success': None, 'provider_failures': 0, 'unchanged_historical_files': len(frozen['historical_files']),
        'freeze_sha256': digest(OUT / 'FREEZE.json')}
    for key, value in expected_metadata.items():
        require(result[key] == value, f'Result metadata differs: {key}')
    require(result['scoring']['unique_packets'] == len(packets) and result['scoring']['disagreements'] == differences and result['scoring']['adjudicated'] == sorted(adjudication), 'Scoring metadata differs')
    require(result['scoring']['independent_ai_reviewers'] == 2 and result['scoring']['human_review'] is False, 'Invalid review provenance claim')
    passed('tokens_repeat_identity_and_result_metadata', {**token_totals, 'total_tokens': sum(token_totals.values()),
        'repeated_inputs': 120, 'identical_response_excluding_call_ids': sum(row['same_response_ignoring_call_ids'] for row in repeated.values())})

    selected_paths = [OUT / 'FREEZE.json', OUT / 'prepared/jobs.json', OUT / 'scoring/blind-packets.json',
        OUT / 'scoring/private-mapping.json', OUT / 'scoring/reviewer-a.json', OUT / 'scoring/reviewer-b.json',
        OUT / 'analysis/results.json', OUT / 'analysis/rows.csv', Path(__file__)]
    if adjudication_path.exists():
        selected_paths.append(adjudication_path)
    uncertain = [{name: row[name] for name in ('job_id', 'blind_id', 'case_id', *KEY_FIELDS, *CLASSIFICATIONS)}
                 for row in rows.values() if any(row[field] == 'uncertain' for field in FIELDS)]
    return {
        'schema_version': 'summary-placement-independent-audit-v1',
        'date': '2026-10-23', 'timezone': 'America/Halifax',
        'reviewed_utc': datetime.now(timezone.utc).isoformat(),
        'reviewer': '/root/study_preflight', 'reviewer_kind': 'Independent AI agent; not human validation',
        'status': 'passed_record_accounting_pending_semantic_and_publication_review',
        'method': 'Read frozen artifacts directly and independently reconstructed labels, behavior, groups, paired comparisons, CSV and cost using Python standard library only; did not import the scorer or runner. No model calls, tool execution or score changes.',
        'checks': checks,
        'scope': {'calls': 216, 'cases': 24, 'groups': 18, 'paired_comparisons': 64,
                  'unique_packets': len(packets), 'disagreements': differences, **token_totals,
                  'total_tokens': sum(token_totals.values())},
        'uncertain_rows': uncertain,
        'reviewed_file_sha256': {path.relative_to(ROOT).as_posix(): digest(path) for path in selected_paths},
        'not_yet_reviewed': ['Semantic spot review of final labels and adjudication',
                             'RESULTS.md and interpretation narrative',
                             'Final generated HTML and public data',
                             'Hosted deployment, which requires a separate publication receipt'],
        'limitations': ['Passing accounting checks does not validate AI semantic judgments.',
                        'All 24 states are exposed synthetic development material.',
                        'Only one model decision is observed; native tool requests are not executed.',
                        'Layout swaps also change recency and do not reproduce native long-history compaction.',
                        'Inherited primary rubric includes reconfirmation; use the separately annotated sensitivity outcome and do not directly compare primary rates with historical 3/36.']}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-only', action='store_true', help='Verify without writing or changing the independent audit record')
    args = parser.parse_args()
    report = audit()
    if not args.check_only:
        with (OUT / 'analysis/INDEPENDENT-AUDIT.json').open('x', encoding='utf-8') as stream:
            json.dump(report, stream, ensure_ascii=False, indent=2)
            stream.write('\n')
    print(json.dumps({'status': report['status'], 'passed_checks': len(report['checks']), **report['scope']}, ensure_ascii=False), flush=True)
