"""Read-only interface checks against the actual per-call API tool schemas.

No runner/scorer imports, model calls, tool execution or score changes. The local
study venv has no jsonschema package; the deliberately limited checker below
covers type/required/properties/enum/additionalProperties and rejects unsupported
schema keywords instead of silently claiming complete JSON Schema validation.
"""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
ROOT = Path(__file__).resolve().parents[5]
SUPPORTED = {'type', 'required', 'properties', 'enum', 'additionalProperties'}
ANNOTATIONS = {'description', 'title', 'default', '$schema', '$comment', 'examples'}


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def inspect_schema(schema, path='$'):
    require(isinstance(schema, dict), f'Unsupported non-object schema at {path}')
    unknown = set(schema) - SUPPORTED - ANNOTATIONS
    require(not unknown, f'Unsupported validation keywords at {path}: {sorted(unknown)}')
    if 'type' in schema:
        types = schema['type'] if isinstance(schema['type'], list) else [schema['type']]
        require(all(t in {'object', 'array', 'string', 'number', 'integer', 'boolean', 'null'}
                    for t in types), f'Unsupported type declaration at {path}')
    for key, child in schema.get('properties', {}).items():
        inspect_schema(child, path + '.properties.' + key)
    extra = schema.get('additionalProperties', True)
    require(isinstance(extra, (bool, dict)), f'Unsupported additionalProperties at {path}')
    if isinstance(extra, dict):
        inspect_schema(extra, path + '.additionalProperties')


def has_type(value, declared):
    numeric = type(value) in (int, float) and math.isfinite(value)
    return {'object': isinstance(value, dict), 'array': isinstance(value, list),
            'string': isinstance(value, str), 'number': numeric,
            'integer': numeric and (type(value) is int or value.is_integer()),
            'boolean': type(value) is bool, 'null': value is None}[declared]


def same_json(left, right):
    # JSON booleans are not numbers even though Python bool subclasses int.
    if type(left) is bool or type(right) is bool:
        return type(left) is type(right) and left == right
    return left == right


def check(value, schema, path='$'):
    errors, suspicious = [], []
    declared = schema.get('type')
    types = declared if isinstance(declared, list) else [declared]
    if declared is not None and not any(has_type(value, t) for t in types):
        errors.append({'path': path, 'keyword': 'type', 'expected': declared,
                       'actual_python_json_type': type(value).__name__})
        return errors, suspicious
    if 'enum' in schema and not any(same_json(value, item) for item in schema['enum']):
        errors.append({'path': path, 'keyword': 'enum', 'allowed': schema['enum'], 'actual': value})
    if isinstance(value, dict):
        missing = sorted(set(schema.get('required', [])) - set(value))
        if missing:
            errors.append({'path': path, 'keyword': 'required', 'missing': missing})
        properties = schema.get('properties', {})
        for key, child in value.items():
            child_path = path + '.' + key
            if key in properties:
                sub_errors, sub_suspicious = check(child, properties[key], child_path)
                errors.extend(sub_errors)
                suspicious.extend(sub_suspicious)
            elif schema.get('additionalProperties', True) is False:
                errors.append({'path': child_path, 'keyword': 'additionalProperties',
                               'reason': 'Explicit additionalProperties:false forbids this key'})
            elif isinstance(schema.get('additionalProperties'), dict):
                sub_errors, sub_suspicious = check(child, schema['additionalProperties'], child_path)
                errors.extend(sub_errors)
                suspicious.extend(sub_suspicious)
            else:
                suspicious.append({'path': child_path, 'key': key,
                                   'reason': 'Key absent from properties; additionalProperties is not false',
                                   'schema_violation': False})
    return errors, suspicious


def main():
    destination = HERE / 'analysis/interface-audit.json'
    require(not destination.exists(), 'Refusing to replace existing interface audit')
    require((HERE / 'run-end.json').is_file(), 'Completed run required')
    jobs = read(HERE / 'prepared/jobs.json')
    require(len({job['job_id'] for job in jobs}) == len(jobs), 'Duplicate jobs')
    mapping = read(HERE / 'scoring/private-mapping.json')
    anonymous = {}
    for output_id, assigned in mapping.items():
        for job in assigned:
            require(job['job_id'] not in anonymous, 'Duplicate anonymous mapping')
            anonymous[job['job_id']] = output_id
    require(set(anonymous) == {job['job_id'] for job in jobs}, 'Incomplete mapping')
    rows, files, schema_inventory = [], [], {}
    outputs_with_requests = set()
    for job in jobs:
        folder = HERE / 'calls' / job['job_id']
        request_path, response_path = folder / 'request-body.bin', folder / 'response-body.bin'
        request, response = read(request_path), read(response_path)
        require(request == read(folder / 'request.json'), 'Request wire differs: ' + job['job_id'])
        require(response == read(folder / 'response.json')['body'], 'Response wire differs: ' + job['job_id'])
        definitions = request['tools']
        require(all(item['type'] == 'function' for item in definitions), 'Unexpected tool definition kind')
        schemas = {item['function']['name']: item['function']['parameters'] for item in definitions}
        require(len(schemas) == len(definitions) == 16, 'Expected 16 unique tool schemas per request')
        for name, schema in schemas.items():
            inspect_schema(schema)
            require(name not in schema_inventory or schema_inventory[name] == schema,
                    'Different schema under same tool name: ' + name)
            schema_inventory[name] = schema
        calls = response['message'].get('tool_calls') or []
        require(isinstance(calls, list), 'Non-list tool_calls')
        if calls:
            outputs_with_requests.add(job['job_id'])
        files.append({'job_id': job['job_id'], 'request': str(request_path.relative_to(ROOT)).replace('\\', '/'),
                      'request_sha256': sha(request_path),
                      'response': str(response_path.relative_to(ROOT)).replace('\\', '/'),
                      'response_sha256': sha(response_path), 'tool_requests': len(calls)})
        for index, call in enumerate(calls):
            function = call.get('function', {}) if isinstance(call, dict) else {}
            name = function.get('name') if isinstance(function, dict) else None
            arguments = function.get('arguments') if isinstance(function, dict) else None
            envelope_errors, schema_errors, suspicious = [], [], []
            if not isinstance(name, str) or name not in schemas:
                envelope_errors.append({'kind': 'unknown_or_missing_tool_name', 'name': name})
            elif not isinstance(function, dict) or 'arguments' not in function:
                envelope_errors.append({'kind': 'missing_arguments'})
            else:
                # Ollama wire arguments are validated as returned, without coercion
                # or parsing argument strings into a different representation.
                schema_errors, suspicious = check(arguments, schemas[name])
            rows.append({'job_id': job['job_id'], 'output_id': anonymous[job['job_id']],
                         'condition': {key: job[key] for key in ('split', 'guidance', 'summary', 'order')},
                         'tool_call_index_zero_based': index, 'tool_call_id': call.get('id'),
                         'name': name, 'arguments': arguments,
                         'interface_envelope_errors': envelope_errors,
                         'schema_errors': schema_errors, 'suspicious_extra_keys': suspicious})
    failures = [row for row in rows if row['interface_envelope_errors'] or row['schema_errors']]
    extras = [row for row in rows if row['suspicious_extra_keys']]
    counts = Counter(row['name'] for row in rows)
    report = {
        'schema_version': 'summary-placement-tool-interface-audit-v1',
        'date': '2026-10-23', 'timezone': 'America/Halifax',
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'kind': 'read_only_actual_api_interface_diagnostic',
        'status': 'completed_with_schema_violations' if failures else 'completed_no_checked_violations',
        'method': {'engine': 'stdlib finite-schema checker',
                   'jsonschema_installed_in_audit_interpreter': importlib.util.find_spec('jsonschema') is not None,
                   'checks': ['name membership in the exact request tool definitions',
                              'required', 'explicit type', 'enum', 'properties', 'additionalProperties'],
                   'unsupported_schema_keywords': [],
                   'extra_key_policy': 'Absent additionalProperties:false allows extra keys; flag separately, not as schema failure',
                   'no_argument_coercion': True,
                   'actual_request_and_response_wire_matched_saved_json': len(jobs)},
        'counts': {'api_responses': len(jobs), 'schemas_per_request': 16,
                   'unique_schemas': len(schema_inventory), 'tool_requests': len(rows),
                   'outputs_with_tool_requests': len(outputs_with_requests),
                   'tool_requests_by_name': dict(sorted(counts.items())),
                   'requests_with_schema_errors': sum(bool(row['schema_errors']) for row in rows),
                   'requests_with_envelope_errors': sum(bool(row['interface_envelope_errors']) for row in rows),
                   'jobs_with_interface_or_schema_errors': len({row['job_id'] for row in failures}),
                   'requests_with_suspicious_extra_keys': len(extras),
                   'suspicious_extra_keys': sum(len(row['suspicious_extra_keys']) for row in extras),
                   'extra_key_only_requests_without_errors': sum(not row['schema_errors'] and not row['interface_envelope_errors'] for row in extras)},
        'failures': failures, 'suspicious_extra_key_requests': extras,
        'schema_inventory': dict(sorted(schema_inventory.items())),
        'per_tool_request': rows, 'wire_evidence': files,
        'audit_source_sha256': sha(Path(__file__)),
        'input_sha256': {str(path.relative_to(ROOT)).replace('\\', '/'): sha(path)
                        for path in (HERE / 'prepared/jobs.json', HERE / 'scoring/private-mapping.json', HERE / 'FREEZE.json')},
        'actions': {'model_calls': 0, 'tool_requests_executed': 0, 'scoring_changes': 0,
                    'frozen_evidence_changes': 0, 'dependencies_installed': 0},
        'limits': [
            'This is a finite check of actual API output against explicit schemas, not a full JSON Schema implementation or framework parser test.',
            'No tool request was executed. Schema violations do not establish a real parser failure or any action having occurred.',
            'Descriptions, path existence, tool-state prerequisites, semantic suitability and assistance quality are not validated.',
            'An extra key is suspicious only; without an explicit prohibition it is not a JSON Schema validation error.',
            'Schemas omit types for some declared parameters; those values remain unconstrained here.',
            'Existing semantic scoring is unchanged; diagnostic findings are a separate interface boundary.']}
    with destination.open('x', encoding='utf-8', newline='\n') as output:
        json.dump(report, output, ensure_ascii=False, indent=2)
        output.write('\n')
    print(json.dumps({'path': str(destination), 'counts': report['counts'],
                      'failures': failures, 'suspicious_extra_key_requests': extras}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
