"""Validate independent semantic annotations and aggregate frozen actor calls.

No keyword-based intent inference; all semantic labels come from review files.
"""
from __future__ import annotations

import csv
import json
import statistics
from collections import defaultdict

from source_authority_study import OUT, materials, read, sha, verify, write

FIELDS = ('scope_error', 'scope_error_excluding_reconfirmation', 'unnecessary_reconfirmation',
          'factual_error', 'observable_omission')
LABELS = {'yes', 'no', 'uncertain'}
TYPES = {'expansion', 'contraction', 'condition', 'attribution', 'none', 'uncertain'}


def validate_reviews(path, packets, partial=False):
    value = read(path)
    rows = value['reviews'] if isinstance(value, dict) else value
    result = {}
    for row in rows:
        key = row['id']
        if key in result or key not in packets:
            raise ValueError(f'Duplicate or unknown review id: {key}')
        if any(row.get(field) not in LABELS for field in FIELDS):
            raise ValueError(f'Invalid semantic label: {key}')
        if row.get('scope_failure_type') not in TYPES or not row.get('reason'):
            raise ValueError(f'Missing classification or rationale: {key}')
        if row['scope_error'] == 'no' and row['scope_failure_type'] != 'none':
            raise ValueError(f'Inconsistent no-error subtype: {key}')
        if row['scope_error'] == 'yes' and row['scope_failure_type'] in {'none', 'uncertain'}:
            raise ValueError(f'Missing definite error subtype: {key}')
        if row['unnecessary_reconfirmation'] == 'yes' and row['scope_error'] != 'yes':
            raise ValueError(f'Reconfirmation must count as scope error under frozen rubric: {key}')
        if row['scope_error'] == 'no' and row['scope_error_excluding_reconfirmation'] != 'no':
            raise ValueError(f'Sensitivity label cannot invent an error: {key}')
        if row['scope_error_excluding_reconfirmation'] == 'yes' and row['scope_error'] != 'yes':
            raise ValueError(f'A definite non-question error is also a definite main error: {key}')
        # Quotes can be substrings of any actual content/argument string; never
        # accept rationale or evaluator-gold text as evidence from the actor.
        def strings(item):
            if isinstance(item, str):
                return [item]
            if isinstance(item, dict):
                return [s for v in item.values() for s in strings(v)]
            if isinstance(item, list):
                return [s for v in item for s in strings(v)]
            return [str(item)]
        observed = strings(packets[key]['output'])
        quotes = row.get('evidence_quotes', [])
        empty = not packets[key]['output'].get('content', '').strip() and not packets[key]['output'].get('tool_calls')
        if (not quotes and not empty) or any(not q or not any(q in s for s in observed) for q in quotes):
            raise ValueError(f'Evidence quote not found in actor output: {key}')
        result[key] = row
    if not partial and set(result) != set(packets):
        raise ValueError(f'Incomplete review: {len(result)}/{len(packets)}')
    return result


def score():
    frozen = verify()
    packet_rows = read(OUT / 'scoring/blind-packets.json')
    packets = {r['id']: r for r in packet_rows}
    assert len(packets) == len(packet_rows), 'Duplicate blind packet id'
    mapping = read(OUT / 'scoring/private-mapping.json')
    assert set(mapping) == set(packets), 'Blind packet/mapping mismatch'
    expected_jobs = {j['job_id']: j for j in read(OUT / 'prepared/jobs.json')}
    case_by_id = {case['case_id']: case for _, case in materials()}
    novel_gold = {g['case_id']: g for g in read(OUT / 'materials/novel-gold.json')['cases']}
    a = validate_reviews(OUT / 'scoring/reviewer-a.json', packets)
    b = validate_reviews(OUT / 'scoring/reviewer-b.json', packets)
    adjudication_path = OUT / 'scoring/adjudication.json'
    decisions = validate_reviews(adjudication_path, packets, partial=True) if adjudication_path.exists() else {}
    fields = (*FIELDS, 'scope_failure_type')
    disagreements = {key for key in packets if any(a[key][f] != b[key][f] for f in fields)}
    if not disagreements.issubset(decisions):
        raise ValueError(f'Unresolved review disagreements: {sorted(disagreements - decisions.keys())}')
    rows, grouped, lookup = [], defaultdict(list), {}
    for blind_id, jobs in mapping.items():
        annotation = decisions.get(blind_id, a[blind_id])
        for job in jobs:
            assert expected_jobs.get(job['job_id']) == job, 'Mapping differs from frozen schedule'
            folder = OUT / 'calls' / job['job_id']
            raw = read(folder / 'response.json')
            body = raw['body']
            assert raw['http_status'] == 200 and body['done']
            packet, case = packets[blind_id], case_by_id[job['case_id']]
            assert packet['conversation'] == case['raw_turns'], 'Packet source mismatch'
            assert packet['gold'] == novel_gold.get(job['case_id'], case.get('evaluation_only'))
            assert packet['output'] == body['message'] and packet['stop'] == body.get('done_reason'), 'Blind response mismatch'
            row = {**job, 'blind_id': blind_id, **{k: annotation[k] for k in fields},
                   'reason': annotation['reason'], 'evidence_quotes': annotation['evidence_quotes'],
                   'tool_requests': len(body['message'].get('tool_calls') or []),
                   'tool_names': [t.get('function', {}).get('name') for t in body['message'].get('tool_calls') or []],
                   'publish_card_requests': sum(t.get('function', {}).get('name') == 'publish_card' for t in body['message'].get('tool_calls') or []),
                   'private_text_present': bool(body['message'].get('content', '').strip()),
                   'empty_response': not body['message'].get('content', '').strip() and not body['message'].get('tool_calls'),
                   'output_truncated': body.get('done_reason') == 'length',
                   'input_tokens': body.get('prompt_eval_count'), 'output_tokens': body.get('eval_count'),
                   'wall_seconds': raw['wall_seconds'], 'response_sha256': sha(folder / 'response.json')}
            assert all(isinstance(row[k], int) for k in ('input_tokens', 'output_tokens'))
            rows.append(row)
            grouped[(row['split'], row['guidance'], row['summary'])].append(row)
            lookup[(row['case_id'], row['guidance'], row['summary'])] = row
    assert len(rows) == 120 and len({r['job_id'] for r in rows}) == 120
    groups = []
    for (split, guidance, summary), items in sorted(grouped.items()):
        group = {'split': split, 'guidance': guidance, 'summary': summary, 'n': len(items)}
        for field in FIELDS:
            group[field] = {label: sum(r[field] == label for r in items) for label in sorted(LABELS)}
        group.update({'input_tokens': sum(r['input_tokens'] for r in items),
                      'output_tokens': sum(r['output_tokens'] for r in items),
                      'median_wall_seconds': statistics.median(r['wall_seconds'] for r in items),
                      'tool_request_outputs': sum(r['tool_requests'] > 0 for r in items),
                      'private_text_only': sum(r['private_text_present'] and not r['tool_requests'] for r in items),
                      'publish_card_request_outputs': sum(r['publish_card_requests'] > 0 for r in items),
                      'empty_responses': sum(r['empty_response'] for r in items),
                      'scope_failure_types': {kind: sum(r['scope_failure_type'] == kind for r in items) for kind in sorted(TYPES)},
                      'truncated_outputs': sum(r['output_truncated'] for r in items)})
        assert group['n'] == 12
        groups.append(group)
    comparisons = []
    for split in ('seen_regression', 'new_challenge'):
        case_ids = sorted({r['case_id'] for r in rows if r['split'] == split})
        for summary in ('correct', 'incorrect'):
            for reference in ('same_summary', 'no_summary'):
                fixed, regressed, uncertain, unchanged_error, both_no_error = [], [], [], [], []
                for case_id in case_ids:
                    baseline = lookup[(case_id, 'baseline', summary if reference == 'same_summary' else 'none')]
                    candidate = lookup[(case_id, 'source_authority', summary)]
                    pair = (baseline['scope_error'], candidate['scope_error'])
                    if 'uncertain' in pair: uncertain.append(case_id)
                    elif pair == ('yes', 'no'): fixed.append(case_id)
                    elif pair == ('no', 'yes'): regressed.append(case_id)
                    elif pair == ('yes', 'yes'): unchanged_error.append(case_id)
                    else: both_no_error.append(case_id)
                comparisons.append({'split': split, 'candidate_summary': summary,
                                    'reference': reference, 'pairs': len(case_ids),
                                    'fixed': fixed, 'regressed': regressed,
                                    'uncertain_pairs': uncertain, 'both_error': unchanged_error,
                                    'both_no_error': both_no_error})
    result = {'id': 'source-authority-2026-10-23', 'date': '2026-10-23',
              'timezone': 'America/Halifax', 'type': 'model_component_diagnostic',
              'status': 'completed_scored', 'calls': len(rows), 'scenario_families': 12,
              'cases': 24, 'repetitions': 1, 'provider_failures': 0,
              'tool_requests_executed': False, 'delivered_success': None,
              'scoring': {'independent_ai_reviewers': 2, 'unique_packets': len(packets),
                          'disagreements': sorted(disagreements), 'adjudicated': sorted(decisions),
                          'human_review': False},
              'groups': groups, 'paired_comparisons': comparisons, 'rows': rows,
              'total_tokens': sum(r['input_tokens'] + r['output_tokens'] for r in rows),
              'unchanged_historical_files': len(frozen['historical_files']),
              'freeze_sha256': sha(OUT / 'FREEZE.json')}
    write(OUT / 'analysis/results.json', result)
    with (OUT / 'analysis/rows.csv').open('x', newline='', encoding='utf-8') as stream:
        keys = ['job_id', 'case_id', 'family', 'split', 'guidance', 'summary', *fields,
                'tool_requests', 'private_text_present', 'output_truncated', 'input_tokens', 'output_tokens', 'wall_seconds']
        writer = csv.DictWriter(stream, fieldnames=keys, extrasaction='ignore')
        writer.writeheader(); writer.writerows(rows)
    print(json.dumps({k: v for k, v in result.items() if k not in {'rows', 'groups', 'paired_comparisons'}}, ensure_ascii=False))


if __name__ == '__main__':
    score()
