"""A native Deep Agent chooses its own investigation and publication actions.

The outer graph delivers arrived events, enforces runtime budgets and optionally
offers bounded feedback after retrieval failure. It does not impose task/evidence
schemas, a calculation stage, or release approval.
LangGraph checkpoints persist execution state; they are not semantic milestones.
"""
from __future__ import annotations

import json
from typing import NotRequired

from deepagents import (GeneralPurposeSubagentProfile, HarnessProfile,
                        create_deep_agent, register_harness_profile)
from deepagents._models import get_model_identifier, get_model_provider
from langchain_core.messages import AIMessage, HumanMessage
from langgraph.graph import END, START, StateGraph

from agent import (Accounting, COMMON_PROMPT, ConversationState, EventBoundary,
                   RunContext, assert_paired)
from agent_led_tools import make_tools
from providers import make_model
from investigation_progress import InvestigationProgress
from source_authority import SourceAuthority


class AgentLedState(ConversationState):
    # Written with the recovery message in the parent checkpoint. The durable
    # tool ledger can redeliver an issued message if that checkpoint was lost.
    recovery_feedback_seq: NotRequired[int]
    delivery_feedback_seq: NotRequired[int]
    budget_deferred: NotRequired[bool]
    delivery_pending: NotRequired[str]


PROMPT = COMMON_PROMPT + """
Choose how to investigate and when to offer help. There is no fixed sequence of
planning, searching, calculating, checking and publishing. You can read more,
use a tool, answer from sufficient evidence, revise an existing card or stay quiet.
Working notes can be ordinary prose; no special record format is required.

calculate is available for arithmetic when useful. Think about what each input
means: a process's duration starts at that process's start, which may differ
from an earlier process's end. evidence_check is available for another look at a
draft or uncertain interpretation; its advice is optional, not permission to
publish. Both tools are choices, not prerequisites for an answer.

Address the full question, including what the facts mean for the people talking.
An intermediate number alone may not settle their question. Distinguish an
input rating from an output capability, an observed value from a requested
threshold, and a stated fact from an inference. Source text can leave a question
unresolved; explain the useful part and the missing information when appropriate.

To show help, call publish_card with the text; source_ids and card_id are optional.
Include supporting sources when you have them. Reusing a card_id updates that
card. Ordinary final prose remains private and does not display a card. No user
approval is needed for investigation or publication.
"""


DELIVERY_PROMPT = """
To replace a visible card, call publish_card once with its existing card_id.
Do not withdraw and publish the same card in parallel: these are separate
operations and can conflict. A tool receipt says whether an operation actually
took effect. After a conflict, consider the returned current card before choosing
your next action. An optional delivery reminder may show what is currently visible;
it does not mean that another answer is needed or that private notes should be shared.
"""

STATE_UPDATE_PROMPT = """
Keep each still-useful answer available when another part of the discussion changes.
Use publish_card to create a card. To revise an observed card, use edit_card with
local old/new passages, or append_text for genuinely additional help. Unselected
text and its citations are retained. Choose the passages that are actually wrong
or cancelled; do not erase another person's valid answer. You may select the full
card when all of it needs replacement, or withdraw_card when all of it is obsolete.
An edit failure returns the observed card and a concrete correction; no partial
edit was applied. These are editing operations, not a prescribed answer format.
Do not create another card to repeat existing help or evade a failed edit.

The runtime paces the fixed shared budget so later input can still be considered.
Choose useful work within the available calls; combine independent retrievals
when appropriate. Wait when no useful investigation or correction remains. Mere
confirmations of settled arrangements need no visible acknowledgement card.
"""


def waited_this_turn(messages):
    """A wait in a previous observation must not suppress this turn's feedback."""
    for message in reversed(messages):
        if (isinstance(message, HumanMessage) and
                (message.id or '').startswith(('observation-', 'recovery-', 'delivery-'))):
            break
        if isinstance(message, AIMessage) and any(
                call['name'] == 'wait_for_event' for call in message.tool_calls):
            return True
    return False


def build_agent_led_graph(world, settings, checkpointer, *, model=None,
                          review_model=None, extra_middleware=(), interrupt_after=()):
    """Build the event loop while leaving tool choice to the native investigator."""
    model = model if model is not None else make_model(settings)
    review_model = review_model if review_model is not None else model
    single_investigator = HarnessProfile(
        general_purpose_subagent=GeneralPurposeSubagentProfile(enabled=False))
    identifier, provider = get_model_identifier(model), get_model_provider(model)
    if provider and identifier:
        register_harness_profile(f'{provider}:{identifier}', single_investigator)
    if identifier and ':' in identifier:
        register_harness_profile(identifier, single_investigator)

    budget_middleware = []
    if settings.mechanisms.budget_pacing:
        from budget_policy import BudgetPacing
        budget_middleware = [BudgetPacing(world, settings)]

    summary_middleware = []
    backend_options = {}
    if settings.mechanisms.summary_attribution:
        from deepagents.backends import StateBackend
        from summary_attribution import create_attribution_summary_middleware
        backend = StateBackend()
        backend_options['backend'] = backend
        summary_middleware = [create_attribution_summary_middleware(model, backend)]

    investigator = create_deep_agent(
        model=model, tools=make_tools(world, settings, review_model),
        system_prompt=PROMPT + (DELIVERY_PROMPT if settings.mechanisms.delivery_recovery else '')
            + (STATE_UPDATE_PROMPT if settings.mechanisms.state_preserving_updates else ''),
        state_schema=AgentLedState,
        context_schema=RunContext,
        middleware=[EventBoundary(world, settings),
                    *budget_middleware,
                    *summary_middleware,
                    *([InvestigationProgress()] if settings.mechanisms.investigation_progress else []),
                    *([SourceAuthority()] if settings.mechanisms.source_authority else []),
                    *extra_middleware],
        # The parent owns persistence for the native subgraph and its tool loop.
        checkpointer=None,
        **backend_options,
    )

    def observe(state):
        assert_paired(state.get('messages', []))
        if settings.mechanisms.budget_pacing and state.get('delivery_pending'):
            from budget_policy import BudgetPolicy
            key = state['delivery_pending']
            candidate = next(e for e in world.export()['environment_log']
                if e['kind'] == 'answer_delivery_candidate' and e['candidate_key'] == key)
            policy = BudgetPolicy(world, settings)
            while not world.done:
                if world.observation(candidate['packet']['candidate']['event_cursor'])[0]['events']:
                    break  # delivery records supersession, then observe consumes new input
                allowed, budget = policy.review_eligibility(candidate['packet'], record=False)
                if allowed or budget['reason'] not in {'call_allowance_deferred', 'token_allowance_deferred'}:
                    break
                wake = policy.next_available_ms(budget)
                if wake is None:
                    break
                world.record('budget_wait', role='pending_delivery', **budget)
                world.advance_until_or_event(wake)
            return {'stop_reason': '', 'budget_deferred': False}
        if world.done:
            return {'stop_reason': 'window_closed'}
        metrics = world.metrics()
        if (metrics['model_calls'] >= settings.max_calls or
                metrics['token_usage']['total_tokens'] >= settings.max_tokens):
            return {'stop_reason': 'budget_exhausted'}
        if settings.mechanisms.budget_pacing:
            from budget_policy import BudgetPolicy
            policy = BudgetPolicy(world, settings)
            allowed, budget = policy.can_investigate(record=False)
            # Pausing a subgraph is not a terminal budget failure. Advance the
            # event stream until credit is available; never inspect future text.
            while not allowed and not world.done:
                world.record('budget_wait', **budget)
                before = world.now
                wake = policy.next_available_ms(budget)
                if wake is None:
                    return {'stop_reason': budget['reason']}
                world.advance_until_or_event(wake)
                if world.now <= before:
                    return {'stop_reason': 'budget_wait_no_progress'}
                allowed, budget = policy.can_investigate(record=False)
            if world.done:
                return {'stop_reason': 'window_closed', 'budget_deferred': False}
        payload, cursor = world.observation(state.get('event_cursor', -1))
        if settings.mechanisms.budget_pacing and state.get('budget_deferred') and not payload['events']:
            # A boundary may already have injected this input before yielding.
            # Resume that persisted state; do not wait for another human turn.
            return {'stop_reason': '', 'budget_deferred': False}
        if not payload['events'] and not world.done:
            messages = state.get('messages', [])
            final_response = (bool(messages) and isinstance(messages[-1], AIMessage)
                              and not messages[-1].tool_calls)
            last_batch = next((message.tool_calls for message in reversed(messages)
                               if isinstance(message, AIMessage) and message.tool_calls), [])
            explicit_wait = any(call['name'] == 'wait_for_event' for call in last_batch)
            if settings.mechanisms.delivery_recovery:
                explicit_wait = waited_this_turn(messages)
                if final_response and not explicit_wait:
                    delivery = world.delivery_feedback(
                        state.get('delivery_feedback_seq', -1), observation_cursor=cursor,
                        max_calls=settings.max_calls, max_tokens=settings.max_tokens)
                    if delivery is not None:
                        return {'stop_reason': '', 'event_cursor': cursor,
                                'delivery_feedback_seq': delivery['seq'],
                                'messages': [HumanMessage(
                                    content=json.dumps(delivery['feedback'], ensure_ascii=False),
                                    id=f"delivery-{delivery['seq']}")]}
            if settings.mechanisms.failure_recovery and final_response and not explicit_wait:
                recovery = world.recovery_feedback(
                    state.get('recovery_feedback_seq', -1),
                    max_calls=settings.max_calls, max_tokens=settings.max_tokens)
                if recovery is not None:
                    return {'stop_reason': '', 'event_cursor': cursor,
                            'recovery_feedback_seq': recovery['seq'],
                            'messages': [HumanMessage(
                                content=json.dumps(recovery['feedback'], ensure_ascii=False),
                                id=f"recovery-{recovery['seq']}")]}
            world.advance_next()
            payload, cursor = world.observation(state.get('event_cursor', -1))
        if world.done:
            return {'stop_reason': 'window_closed', 'event_cursor': cursor}
        world.record('observation_step', context_revision=payload['context_revision'])
        return {'event_cursor': cursor, 'stop_reason': '', 'messages': [HumanMessage(
            content=json.dumps(payload, ensure_ascii=False), id=f'observation-{cursor}')]}

    def route(state):
        if state.get('stop_reason'):
            return END
        return 'answer_delivery' if state.get('delivery_pending') else 'investigate'

    builder = StateGraph(AgentLedState, context_schema=RunContext)
    builder.add_node('observe', observe)
    builder.add_node('investigate', investigator)
    builder.add_edge(START, 'observe')
    routes = {END: END, 'investigate': 'investigate'}
    if settings.mechanisms.answer_delivery:
        routes['answer_delivery'] = 'answer_delivery'
    builder.add_conditional_edges('observe', route, routes)
    if settings.mechanisms.answer_delivery:
        from answer_delivery import AnswerDelivery
        if settings.mechanisms.state_preserving_updates:
            from budget_state_delivery import BudgetStateDelivery
            delivery = BudgetStateDelivery(world, settings, review_model)
        else:
            delivery = AnswerDelivery(world, settings, review_model)
        builder.add_node('answer_delivery', delivery)
        builder.add_edge('investigate', 'answer_delivery')
        builder.add_edge('answer_delivery', 'observe')
    else:
        builder.add_edge('investigate', 'observe')
    graph = builder.compile(checkpointer=checkpointer, interrupt_after=list(interrupt_after))
    return graph, investigator, Accounting(world, settings)
