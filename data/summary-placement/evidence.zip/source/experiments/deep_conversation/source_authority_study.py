"""Frozen single-decision study of actor-side source authority, local Ollama only.

The captured historical actor tools are exposed but never executed. This runner
does not measure complete assistance or the live LangGraph's compaction path.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import random
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'output/research/2026-10-23/source-authority'
OLD = ROOT / 'output/research/2026-10-19/summary-causal-replay'
SOURCE = ROOT / 'output/research/2026-10-19/source-recovery-replay/calls/native-21--r1--original/ollama-request.json'
MODEL = 'qwen2.5:14b-instruct'
DIGEST = '7cdf5a0187d5c58cc5d369b255592f7841d1c4696d45a8c8a9489440385b22f6'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def utc():
    return datetime.now(timezone.utc).isoformat()


def client():
    return httpx.Client(base_url='http://127.0.0.1:11434', trust_env=False,
                        follow_redirects=False, timeout=180)


def runtime(c):
    from config import Settings
    from local_runtime import local_model_metadata
    metadata = local_model_metadata(Settings(preset='agent-led-recovery'))
    if metadata['digest'] != DIGEST:
        raise ValueError('Local model identity changed')
    return metadata


def materials():
    old = read(OLD / 'materials/cases.json')['cases']
    novel = read(OUT / 'materials/novel-cases.json')['cases']
    return [('seen_regression', c) for c in old] + [('new_challenge', c) for c in novel]


def make_request(case, guidance, summary, source, addition):
    observation = {'conversation': case['raw_turns'],
                   'provenance': case['model_observation']['provenance'],
                   'pending_jobs': [], 'active_cards': {}}
    system = source['messages'][0]['content']
    if guidance == 'source_authority':
        system += '\n\n' + addition
    messages = [{'role': 'system', 'content': system},
                {'role': 'user', 'content': 'Current conversation observation:\n' +
                 json.dumps(observation, ensure_ascii=False, indent=2)}]
    if summary != 'none':
        messages.append({'role': 'user', 'content': 'Saved working summary:\n' +
                         case['summaries'][summary]})
    messages.append({'role': 'user', 'content': 'Continue assisting from this observation.'})
    return {'model': MODEL, 'messages': messages, 'stream': False,
            'tools': source['tools'], 'think': source['think'],
            'options': dict(source['options']), 'keep_alive': '5m'}


def prepare():
    from source_authority import SOURCE_AUTHORITY_GUIDANCE
    if (OUT / 'FREEZE.json').exists() or (OUT / 'prepared').exists():
        raise FileExistsError('Preparation already exists; never replace a frozen batch')
    if read(OUT / 'materials/PREFLIGHT.json').get('approved_for_freeze') is not True:
        raise ValueError('Independent material and runner preflight must approve the freeze')
    source = read(SOURCE)
    assert source['model'] == MODEL and len(source['tools']) == 16
    assert source['options'] == {'num_ctx': 16384, 'num_predict': 1000, 'temperature': 0.0}
    all_cases = materials()
    assert len(all_cases) == 24 and len({c['case_id'] for _, c in all_cases}) == 24
    with client() as c:
        meta = runtime(c)
    jobs = []
    conditions = [('baseline', 'none'), ('baseline', 'correct'),
                  ('baseline', 'incorrect'), ('source_authority', 'correct'),
                  ('source_authority', 'incorrect')]
    for split, case in all_cases:
        assert set(case['summaries']) == {'correct', 'incorrect'}
        for guidance, summary in conditions:
            job_id = f"{case['case_id']}--{guidance}--{summary}"
            request = make_request(case, guidance, summary, source, SOURCE_AUTHORITY_GUIDANCE)
            path = OUT / 'prepared/requests' / f'{job_id}.json'
            write(path, request)
            jobs.append({'job_id': job_id, 'case_id': case['case_id'],
                         'family': case['scenario_id'], 'split': split,
                         'guidance': guidance, 'summary': summary,
                         'request': str(path.relative_to(OUT)), 'request_sha256': sha(path)})
    random.Random(20261023).shuffle(jobs)
    write(OUT / 'prepared/jobs.json', jobs)
    write(OUT / 'prepared/runtime.json', meta)
    dependencies = [Path(__file__), Path(__file__).with_name('source_authority.py'),
                    Path(__file__).with_name('source_authority_score.py'),
                    Path(__file__).with_name('config.py'),
                    Path(__file__).with_name('agent_led.py'),
                    Path(__file__).with_name('run.py'), SOURCE,
                    Path(__file__).with_name('local_runtime.py'),
                    Path(__file__).with_name('providers.py'),
                    OLD / 'materials/cases.json', OUT / 'materials/novel-cases.json',
                    OUT / 'materials/novel-gold.json', OUT / 'SCORING.md', OUT / 'PROTOCOL.md',
                    OUT / 'materials/PREFLIGHT.json']
    dependencies += list((OUT / 'prepared').rglob('*.json'))
    # Protect all historical source-study evidence without freezing unrelated work.
    historical = [OLD, ROOT / 'output/research/2026-10-19/source-recovery-replay',
                  ROOT / 'output/research/2026-10-20/contrastive-decoding-study']
    protected = {str(p.relative_to(ROOT)): sha(p) for d in historical
                 for p in d.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    write(OUT / 'FREEZE.json', {'prepared_utc': utc(), 'calls': len(jobs),
          'model': meta, 'quality_retry': False, 'repetitions': 1,
          'files': {str(p.relative_to(ROOT)): sha(p) for p in dependencies},
          'historical_files': protected})
    print(json.dumps({'prepared': len(jobs), 'historical_files': len(protected)}), flush=True)


def verify():
    frozen = read(OUT / 'FREEZE.json')
    for group in ('files', 'historical_files'):
        bad = [p for p, digest in frozen[group].items() if not (ROOT / p).is_file() or sha(ROOT / p) != digest]
        if bad:
            raise ValueError(f'Frozen files changed: {bad}')
    return frozen


def run():
    frozen = verify()
    jobs = read(OUT / 'prepared/jobs.json')
    with client() as c:
        assert runtime(c) == frozen['model']
        if (OUT / 'run-start.json').exists():
            raise FileExistsError('Batch already started; inspect its live handle or terminal outcomes, never rerun silently')
        write(OUT / 'run-start.json', {'utc': utc(), 'pid': __import__('os').getpid()})
        for i, job in enumerate(jobs, 1):
            folder = OUT / 'calls' / job['job_id']
            request = read(OUT / job['request'])
            write(folder / 'request.json', request)
            write(folder / 'dispatch.json', {'utc': utc(), **job})
            started = time.perf_counter()
            try:
                wire = c.build_request('POST', '/api/chat', json=request)
                with (folder / 'request-body.bin').open('xb') as stream:
                    stream.write(wire.content)
                response = c.send(wire)
                with (folder / 'response-body.bin').open('xb') as stream:
                    stream.write(response.content)
                body = response.json()
                result = {'utc': utc(), 'http_status': response.status_code,
                          'wall_seconds': time.perf_counter() - started, 'body': body}
                write(folder / 'response.json', result)
                if response.status_code != 200 or body.get('error') or not body.get('done'):
                    raise RuntimeError('Provider did not complete the request')
            except Exception as error:
                write(folder / 'error.json', {'utc': utc(), 'type': type(error).__name__, 'message': str(error)})
                raise
            print(json.dumps({'completed': i, 'total': len(jobs), 'job': job['job_id'],
                              'seconds': round(result['wall_seconds'], 2),
                              'stop': body.get('done_reason')}), flush=True)
        assert runtime(c) == frozen['model']
    verify()
    write(OUT / 'run-end.json', {'utc': utc(), 'calls': len(jobs),
                               'unchanged_historical_files': len(frozen['historical_files'])})


def blind():
    verify()
    assert read(OUT / 'run-end.json')['calls'] == 120
    cases = {case['case_id']: case for _, case in materials()}
    gold = read(OUT / 'materials/novel-gold.json')
    gold_cases = gold['cases'] if isinstance(gold, dict) and 'cases' in gold else gold
    if isinstance(gold_cases, list):
        gold_cases = {g['case_id']: g for g in gold_cases}
    packets, mapping, dedup = [], {}, {}
    jobs = list(read(OUT / 'prepared/jobs.json'))
    random.Random(871023).shuffle(jobs)
    for job in jobs:
        case = cases[job['case_id']]
        result = read(OUT / 'calls' / job['job_id'] / 'response.json')['body']
        key = json.dumps([job['case_id'], result['message'], result.get('done_reason')],
                         sort_keys=True, ensure_ascii=False)
        if key in dedup:
            mapping[dedup[key]].append(job)
            continue
        blind_id = f'output-{len(packets)+1:03d}'
        packet = {'id': blind_id, 'conversation': case['raw_turns'],
                  'gold': gold_cases.get(job['case_id'], case.get('evaluation_only')),
                  'output': result['message'], 'stop': result.get('done_reason'),
                  'tool_requests_executed': False}
        assert packet['gold']
        packets.append(packet)
        mapping[blind_id] = [job]
        dedup[key] = blind_id
    write(OUT / 'scoring/blind-packets.json', packets)
    write(OUT / 'scoring/private-mapping.json', mapping)
    # Compact, readable packet bundles are convenient for independent reviewers.
    for start in range(0, len(packets), 20):
        write(OUT / f'scoring/packets-{start+1:03d}-{min(start+20,len(packets)):03d}.json', packets[start:start+20])
    print(json.dumps({'blind_unique_outputs': len(packets), 'mapped_calls': sum(map(len, mapping.values()))}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['prepare', 'verify', 'run', 'blind'])
    args = parser.parse_args()
    {'prepare': prepare, 'verify': verify, 'run': run, 'blind': blind}[args.command]()
