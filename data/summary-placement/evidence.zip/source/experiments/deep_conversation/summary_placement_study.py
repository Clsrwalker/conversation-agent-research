"""Frozen summary-position diagnostic; no tools execute and no old run is reused."""
from __future__ import annotations

import argparse
from copy import deepcopy
import hashlib
import json
import random
import time
from pathlib import Path

from source_authority_study import (ROOT, OUT as PRIOR, client, materials,
                                    read, runtime, sha, utc, write)

OUT = ROOT / 'output/research/2026-10-23/summary-placement'
SPLITS = {'seen_regression': 'earlier_regression',
          'new_challenge': 'previously_authored_challenge'}


def canonical_message(message):
    """Only transport-generated call IDs are irrelevant to semantic identity."""
    result = deepcopy(message)
    calls = result.get('tool_calls') or []
    identifiers = [call.get('id') for call in calls]
    if any(not isinstance(value, str) or not value for value in identifiers):
        return result
    if len(set(identifiers)) != len(identifiers):
        return result
    for call in calls:
        call.pop('id', None)
    return result


def conditions():
    result = []
    for old in read(PRIOR / 'prepared/jobs.json'):
        request = read(PRIOR / old['request'])
        orders = ('none',) if old['summary'] == 'none' else ('summary_first', 'summary_last')
        assert len(request['messages']) == (3 if old['summary'] == 'none' else 4)
        assert request['messages'][1]['content'].startswith('Current conversation observation:\n')
        if old['summary'] != 'none':
            assert request['messages'][2]['content'].startswith('Saved working summary:\n')
        for order in orders:
            current = deepcopy(request)
            if order == 'summary_first':
                current['messages'][1:3] = current['messages'][1:3][::-1]
            job = {k: old[k] for k in ('case_id', 'family', 'guidance', 'summary')}
            job.update(job_id=old['job_id'] + '--' + order, order=order,
                       split=SPLITS[old['split']], prior_job_id=old['job_id'],
                       prior_request_sha256=sha(PRIOR / old['request']))
            result.append((job, current))
    assert len(result) == 216
    assert len({j['job_id'] for j, _ in result}) == 216
    return result


def prepare():
    if (OUT / 'FREEZE.json').exists() or (OUT / 'prepared').exists():
        raise FileExistsError('Never replace frozen preparation')
    assert read(OUT / 'PREFLIGHT.json')['approved_for_freeze'] is True
    prior_freeze = read(PRIOR / 'FREEZE.json')
    protected = {}
    for group in ('files', 'historical_files'):
        for path, digest in prior_freeze[group].items():
            assert sha(ROOT / path) == digest, path
            if path in protected:
                assert protected[path] == digest, path
            protected[path] = digest
    for p in PRIOR.rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts:
            path, digest = str(p.relative_to(ROOT)), sha(p)
            if path in protected:
                assert protected[path] == digest, path
            else:
                protected[path] = digest
    with client() as c:
        metadata = runtime(c)
    assert metadata == read(PRIOR / 'prepared/runtime.json'), 'Prior model/runtime changed'
    jobs = []
    for job, request in conditions():
        path = OUT / 'prepared/requests' / (job['job_id'] + '.json')
        write(path, request)
        jobs.append({**job, 'request': path.relative_to(OUT).as_posix(),
                     'request_sha256': sha(path)})
    random.Random(2026102302).shuffle(jobs)
    write(OUT / 'prepared/jobs.json', jobs)
    write(OUT / 'prepared/runtime.json', metadata)
    dependencies = [Path(__file__), Path(__file__).with_name('summary_placement_score.py'),
        Path(__file__).with_name('source_authority_study.py'),
        Path(__file__).with_name('source_authority_score.py'),
        Path(__file__).with_name('config.py'), Path(__file__).with_name('local_runtime.py'),
        Path(__file__).with_name('providers.py'), OUT / 'PROTOCOL.md', OUT / 'SCORING.md',
        OUT / 'PREFLIGHT.json'] + list((OUT / 'prepared').rglob('*.json'))
    write(OUT / 'FREEZE.json', {'prepared_utc': utc(), 'calls': 216,
        'repetitions': 1, 'quality_retry': False, 'model': metadata,
        'files': {str(p.relative_to(ROOT)): sha(p) for p in dependencies},
        'historical_files': protected})
    print(json.dumps({'prepared': 216, 'protected_files': len(protected)}), flush=True)


def verify():
    frozen = read(OUT / 'FREEZE.json')
    for group in ('files', 'historical_files'):
        bad = [p for p, digest in frozen[group].items()
               if not (ROOT / p).is_file() or sha(ROOT / p) != digest]
        if bad:
            raise ValueError(f'Frozen content changed: {bad}')
    return frozen


def run():
    frozen = verify()
    if (OUT / 'run-start.json').exists():
        raise FileExistsError('Started batch cannot be silently restarted')
    jobs = read(OUT / 'prepared/jobs.json')
    with client() as c:
        assert runtime(c) == frozen['model']
        write(OUT / 'run-start.json', {'utc': utc(), 'pid': __import__('os').getpid()})
        for index, job in enumerate(jobs, 1):
            folder = OUT / 'calls' / job['job_id']
            request = read(OUT / job['request'])
            write(folder / 'request.json', request)
            write(folder / 'dispatch.json', {'utc': utc(), **job})
            started = time.perf_counter()
            try:
                wire = c.build_request('POST', '/api/chat', json=request)
                with (folder / 'request-body.bin').open('xb') as stream:
                    stream.write(wire.content)
                response = c.send(wire)
                with (folder / 'response-body.bin').open('xb') as stream:
                    stream.write(response.content)
                body = response.json()
                write(folder / 'response.json', {'utc': utc(), 'http_status': response.status_code,
                    'wall_seconds': time.perf_counter() - started, 'body': body})
                if response.status_code != 200 or body.get('error') or not body.get('done'):
                    raise RuntimeError('Provider did not complete request')
            except Exception as error:
                write(folder / 'error.json', {'utc': utc(), 'type': type(error).__name__,
                                              'message': str(error)})
                raise
            print(json.dumps({'completed': index, 'total': 216, 'job': job['job_id'],
                              'stop': body.get('done_reason')}), flush=True)
        assert runtime(c) == frozen['model']
    verify()
    write(OUT / 'run-end.json', {'utc': utc(), 'calls': 216,
                                'unchanged_historical_files': len(frozen['historical_files'])})


def gold_by_case():
    old = {case['case_id']: case.get('evaluation_only') for _, case in materials()}
    old.update({case['case_id']: case for case in read(PRIOR / 'materials/novel-gold.json')['cases']})
    return old


def blind():
    verify()
    assert read(OUT / 'run-end.json')['calls'] == 216
    cases = {case['case_id']: case for _, case in materials()}
    gold = gold_by_case()
    packets, mapping, dedup = [], {}, {}
    jobs = list(read(OUT / 'prepared/jobs.json'))
    random.Random(90231026).shuffle(jobs)
    for job in jobs:
        body = read(OUT / 'calls' / job['job_id'] / 'response.json')['body']
        key = json.dumps([job['case_id'], canonical_message(body['message']), body.get('done_reason')],
                         sort_keys=True, ensure_ascii=False)
        if key in dedup:
            mapping[dedup[key]].append(job)
            continue
        blind_id = f'output-{len(packets)+1:03d}'
        packets.append({'id': blind_id, 'conversation': cases[job['case_id']]['raw_turns'],
                        'gold': gold[job['case_id']], 'output': body['message'],
                        'stop': body.get('done_reason'), 'tool_requests_executed': False})
        mapping[blind_id], dedup[key] = [job], blind_id
    write(OUT / 'scoring/blind-packets.json', packets)
    write(OUT / 'scoring/private-mapping.json', mapping)
    for start in range(0, len(packets), 20):
        write(OUT / f'scoring/review-bundle-{start // 20 + 1:02d}.json', packets[start:start+20])
    print(json.dumps({'unique_packets': len(packets), 'calls': 216}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['prepare', 'verify', 'run', 'blind'])
    args = parser.parse_args()
    {'prepare': prepare, 'verify': verify, 'run': run, 'blind': blind}[args.command]()
