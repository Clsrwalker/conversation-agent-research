"""Aggregate blinded scope annotations for the frozen position control."""
from __future__ import annotations

from collections import defaultdict
import csv
import json
import statistics

from source_authority_score import FIELDS, LABELS, TYPES, validate_reviews
from summary_placement_study import (OUT, PRIOR, canonical_message, gold_by_case,
                                      materials, read, sha, verify, write)


def paired(lookup, case_ids, left, right, field):
    buckets = {key: [] for key in ('fixed', 'regressed', 'uncertain_pairs', 'both_error', 'both_no_error')}
    for case in case_ids:
        a, b = lookup[(case, *left)][field], lookup[(case, *right)][field]
        if 'uncertain' in (a, b): key = 'uncertain_pairs'
        elif (a, b) == ('yes', 'no'): key = 'fixed'
        elif (a, b) == ('no', 'yes'): key = 'regressed'
        elif (a, b) == ('yes', 'yes'): key = 'both_error'
        else: key = 'both_no_error'
        buckets[key].append(case)
    return {'metric': field, 'reference': list(left), 'candidate': list(right),
            'pairs': len(case_ids), **buckets}


def score():
    frozen = verify()
    assert read(OUT / 'run-end.json')['calls'] == 216
    packet_rows = read(OUT / 'scoring/blind-packets.json')
    packets = {row['id']: row for row in packet_rows}
    assert len(packets) == len(packet_rows)
    mapping = read(OUT / 'scoring/private-mapping.json')
    assert set(mapping) == set(packets)
    jobs = {job['job_id']: job for job in read(OUT / 'prepared/jobs.json')}
    assert len(jobs) == 216
    cases = {case['case_id']: case for _, case in materials()}
    gold = gold_by_case()
    a = validate_reviews(OUT / 'scoring/reviewer-a.json', packets)
    b = validate_reviews(OUT / 'scoring/reviewer-b.json', packets)
    fields = (*FIELDS, 'scope_failure_type')
    disagreements = {key for key in packets if any(a[key][f] != b[key][f] for f in fields)}
    path = OUT / 'scoring/adjudication.json'
    decisions = validate_reviews(path, packets, partial=True) if path.exists() else {}
    assert set(decisions) == disagreements, 'Adjudicate exactly the disagreements'
    rows, grouped, lookup, replay_identity = [], defaultdict(list), {}, []
    for blind_id, mapped_jobs in mapping.items():
        annotation = decisions.get(blind_id, a[blind_id])
        for job in mapped_jobs:
            assert jobs.get(job['job_id']) == job
            folder = OUT / 'calls' / job['job_id']
            response = read(folder / 'response.json')
            body = response['body']
            assert response['http_status'] == 200 and body['done'] and not body.get('error')
            packet = packets[blind_id]
            assert packet['conversation'] == cases[job['case_id']]['raw_turns']
            assert packet['gold'] == gold[job['case_id']]
            assert canonical_message(packet['output']) == canonical_message(body['message'])
            assert packet['stop'] == body.get('done_reason')
            assert read(folder / 'request.json') == read(OUT / job['request'])
            assert json.loads((folder / 'request-body.bin').read_bytes()) == read(folder / 'request.json')
            assert json.loads((folder / 'response-body.bin').read_bytes()) == body
            tools = body['message'].get('tool_calls') or []
            row = {**job, 'blind_id': blind_id, **{field: annotation[field] for field in fields},
                   'reason': annotation['reason'], 'evidence_quotes': annotation['evidence_quotes'],
                   'tool_requests': len(tools),
                   'tool_names': [t.get('function', {}).get('name') for t in tools],
                   'publish_card_requests': sum(t.get('function', {}).get('name') == 'publish_card' for t in tools),
                   'private_text_present': bool(body['message'].get('content', '').strip()),
                   'empty_response': not body['message'].get('content', '').strip() and not tools,
                   'output_truncated': body.get('done_reason') == 'length',
                   'input_tokens': body.get('prompt_eval_count'), 'output_tokens': body.get('eval_count'),
                   'wall_seconds': response['wall_seconds'], 'response_sha256': sha(folder / 'response.json')}
            assert all(type(row[k]) is int for k in ('input_tokens', 'output_tokens'))
            rows.append(row)
            grouped[(row['split'], row['guidance'], row['summary'], row['order'])].append(row)
            lookup[(row['case_id'], row['guidance'], row['summary'], row['order'])] = row
            if row['order'] != 'summary_first':
                old_folder = PRIOR / 'calls' / row['prior_job_id']
                old = read(old_folder / 'response.json')['body']
                assert read(old_folder / 'request.json') == read(folder / 'request.json')
                replay_identity.append({'job_id': row['job_id'], 'prior_job_id': row['prior_job_id'],
                    'same_input': True, 'same_response_ignoring_call_ids':
                    canonical_message(old['message']) == canonical_message(body['message'])
                    and old.get('done_reason') == body.get('done_reason')})
    assert len(rows) == len({r['job_id'] for r in rows}) == len(lookup) == 216
    assert len(replay_identity) == 120
    groups = []
    for (split, guidance, summary, order), items in sorted(grouped.items()):
        group = dict(split=split, guidance=guidance, summary=summary, order=order, n=len(items))
        assert len(items) == 12
        for field in FIELDS:
            group[field] = {label: sum(r[field] == label for r in items) for label in sorted(LABELS)}
        group.update(input_tokens=sum(r['input_tokens'] for r in items),
            output_tokens=sum(r['output_tokens'] for r in items),
            tool_request_outputs=sum(r['tool_requests'] > 0 for r in items),
            tool_requests=sum(r['tool_requests'] for r in items),
            publish_card_request_outputs=sum(r['publish_card_requests'] > 0 for r in items),
            private_text_only=sum(r['private_text_present'] and not r['tool_requests'] for r in items),
            empty_responses=sum(r['empty_response'] for r in items),
            truncated_outputs=sum(r['output_truncated'] for r in items),
            median_wall_seconds=statistics.median(r['wall_seconds'] for r in items),
            scope_failure_types={kind: sum(r['scope_failure_type'] == kind for r in items) for kind in sorted(TYPES)})
        groups.append(group)
    assert len(groups) == 18
    comparisons = []
    for split in sorted({r['split'] for r in rows}):
        case_ids = sorted({r['case_id'] for r in rows if r['split'] == split})
        for metric in ('scope_error', 'scope_error_excluding_reconfirmation'):
            for summary in ('correct', 'incorrect'):
                for guidance in ('baseline', 'source_authority'):
                    comparisons.append({'split': split, 'comparison': 'placement',
                        **paired(lookup, case_ids, (guidance, summary, 'summary_last'),
                                 (guidance, summary, 'summary_first'), metric)})
                for order in ('summary_first', 'summary_last'):
                    comparisons.append({'split': split, 'comparison': 'guidance',
                        **paired(lookup, case_ids, ('baseline', summary, order),
                                 ('source_authority', summary, order), metric)})
                for guidance in ('baseline', 'source_authority'):
                    for order in ('summary_first', 'summary_last'):
                        comparisons.append({'split': split, 'comparison': 'no_summary_reference',
                            **paired(lookup, case_ids, ('baseline', 'none', 'none'),
                                     (guidance, summary, order), metric)})
    result = {'id': 'summary-placement-2026-10-23', 'date': '2026-10-23',
        'timezone': 'America/Halifax', 'type': 'model_component_diagnostic',
        'status': 'completed_scored', 'calls': 216, 'scenario_families': 12,
        'cases': 24, 'all_cases_previously_exposed': True, 'repetitions': 1,
        'tool_requests_executed': False, 'delivered_success': None, 'provider_failures': 0,
        'scoring': {'independent_ai_reviewers': 2, 'unique_packets': len(packets),
            'disagreements': sorted(disagreements), 'adjudicated': sorted(decisions),
            'deduplication': 'Same case, complete message and stop, ignoring only native tool call IDs.',
            'human_review': False},
        'groups': groups, 'paired_comparisons': comparisons, 'rows': rows,
        'repeat_input_check': replay_identity,
        'total_tokens': sum(r['input_tokens'] + r['output_tokens'] for r in rows),
        'unchanged_historical_files': len(frozen['historical_files']),
        'freeze_sha256': sha(OUT / 'FREEZE.json')}
    write(OUT / 'analysis/results.json', result)
    with (OUT / 'analysis/rows.csv').open('x', newline='', encoding='utf-8') as stream:
        keys = ['job_id', 'case_id', 'family', 'split', 'guidance', 'summary', 'order', *fields,
                'tool_requests', 'private_text_present', 'output_truncated',
                'input_tokens', 'output_tokens', 'wall_seconds']
        writer = csv.DictWriter(stream, fieldnames=keys, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({k: v for k, v in result.items()
                      if k not in {'rows', 'groups', 'paired_comparisons', 'repeat_input_check'}}))


if __name__ == '__main__':
    score()
