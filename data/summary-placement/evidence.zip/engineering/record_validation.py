"""Record existing offline evidence and copy hash-verified source bytes.

Standard library only. Does not import a study/scorer, execute tests, contact a
model, or modify existing records. The copied sources are a manifest-listed
source bundle, not a complete environment or a guarantee of historical replay.
"""
from __future__ import annotations

import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parents[1]
ROOT = Path(__file__).resolve().parents[5]


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def digest_bytes(value):
    return hashlib.sha256(value).hexdigest()


def key(path):
    return str(path).replace('\\', '/')


def inside(base, relative):
    path = (base / key(relative)).resolve()
    if not path.is_relative_to(base.resolve()):
        raise ValueError(f'Path escapes expected root: {relative}')
    return path


def log_text(path):
    raw = path.read_bytes()
    return raw.decode('utf-16' if raw.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8-sig')


def write_new(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def main():
    destination = HERE / 'engineering/validation.json'
    bundle = HERE / 'frozen-source'
    if destination.exists():
        raise FileExistsError('Existing validation must not be replaced')
    preflight = read(HERE / 'PREFLIGHT.json')
    freeze = read(HERE / 'FREEZE.json')
    if preflight.get('approved_for_freeze') is not True:
        raise ValueError('Preflight did not approve freezing')
    frozen = {}
    groups = {}
    for group in ('files', 'historical_files'):
        for path, expected in freeze[group].items():
            normalized = key(path)
            if normalized in frozen and frozen[normalized] != expected:
                raise ValueError(f'Conflicting frozen digests: {normalized}')
            frozen[normalized] = expected
            groups.setdefault(normalized, []).append(group)
    if digest_bytes((HERE / 'PREFLIGHT.json').read_bytes()) != frozen[key((HERE / 'PREFLIGHT.json').relative_to(ROOT))]:
        raise ValueError('Preflight differs from the frozen review')

    reviewed = []
    for path, expected in preflight['reviewed_file_sha256'].items():
        normalized = key(path)
        actual = digest_bytes(inside(ROOT, normalized).read_bytes())
        if actual != expected:
            raise ValueError(f'Reviewed bytes changed: {normalized}')
        if normalized in frozen and frozen[normalized] != expected:
            raise ValueError(f'Reviewed and frozen bytes differ: {normalized}')
        reviewed.append({'path': normalized, 'sha256': actual,
                         'freeze_groups': groups.get(normalized, []),
                         'reviewed_at_preflight': True})

    evidence = preflight['engineering_validation']
    source = inside(HERE, evidence['test_source'])
    tree = ast.parse(source.read_text(encoding='utf-8-sig'))
    tests = [f'{cls.name}.{node.name}' for cls in tree.body if isinstance(cls, ast.ClassDef)
             for node in cls.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
             and node.name.startswith('test_')]
    if len(tests) != len(set(tests)) or len(tests) != evidence['unique_test_methods']:
        raise ValueError('Unique test-method count does not match reviewed evidence')
    final_log = log_text(inside(HERE, evidence['final_log']))
    final_rows = re.findall(r'^(test_\w+)\s+\([^\n]+\)\s+\.\.\.\s+(ok|FAIL|ERROR)\s*$', final_log, re.M)
    if len(final_rows) != len(tests) or {name for name, _ in final_rows} != {name.split('.', 1)[1] for name in tests}:
        raise ValueError('Final log does not enumerate the reviewed unique tests')
    if any(status != 'ok' for _, status in final_rows) or not re.search(r'^OK\s*$', final_log, re.M):
        raise ValueError('Final test log is not all passed')
    attempts = []
    for attempt in evidence['attempts']:
        path = inside(HERE, attempt['log'])
        text = log_text(path)
        total = re.search(r'Ran (\d+) tests? in ([\d.]+)s', text)
        failures = re.search(r'FAILED \(([^)]+)\)', text)
        counts = dict((name, int(number)) for name, number in
                      re.findall(r'(failures|errors)=(\d+)', failures.group(1) if failures else ''))
        if total is None or int(total.group(1)) != attempt['tests']:
            raise ValueError(f'Attempt count differs: {attempt["log"]}')
        if counts.get('failures', 0) != attempt['failed']:
            raise ValueError(f'Attempt failure count differs: {attempt["log"]}')
        attempts.append({**attempt, 'log_sha256': digest_bytes(path.read_bytes()),
                         'elapsed_seconds_from_log': float(total.group(2)),
                         'errors_from_log': counts.get('errors', 0)})

    # Verify every source before copying any. These are explicitly listed active
    # source dependencies, not an inferred transitive dependency closure.
    sources = []
    for path, expected in sorted(frozen.items()):
        if not path.startswith('experiments/') or not path.endswith('.py'):
            continue
        raw = inside(ROOT, path).read_bytes()
        if digest_bytes(raw) != expected:
            raise ValueError(f'Source no longer matches frozen digest: {path}')
        target = inside(bundle, path)
        if target.exists() and target.read_bytes() != raw:
            raise ValueError(f'Existing source copy differs: {target}')
        sources.append((path, expected, raw, target))
    source_manifest = []
    for path, expected, raw, target in sources:
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            with target.open('xb') as stream:
                stream.write(raw)
        if digest_bytes(target.read_bytes()) != expected:
            raise ValueError(f'Copied source hash mismatch: {path}')
        source_manifest.append({'original': path, 'copy': target.relative_to(HERE).as_posix(),
                                'sha256': expected, 'freeze_groups': groups[path]})
    source_manifest_path = bundle / 'MANIFEST.json'
    source_record = {'freeze_sha256': digest_bytes((HERE / 'FREEZE.json').read_bytes()),
                     'sources': source_manifest,
                     'scope': 'Manifest-listed current Python sources only; not a full runtime, dependency closure, or historical replay environment.'}
    if source_manifest_path.exists():
        if read(source_manifest_path) != source_record:
            raise ValueError('Existing source manifest differs')
    else:
        write_new(source_manifest_path, source_record)

    contract = HERE / 'EVENT-CONTRACT-AUDIT.md'
    record = {
        'id': 'summary-placement-engineering-2026-10-23',
        'type': 'engineering_validation',
        'schema_version': 'summary-placement-engineering-validation-v1',
        'date': preflight['date'], 'date_basis': 'Frozen engineering preflight date in America/Halifax',
        'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
        'timezone': 'America/Halifax', 'kind': 'existing_offline_engineering_evidence',
        'status': 'passed', 'preflight': 'PREFLIGHT.json',
        'preflight_sha256': digest_bytes((HERE / 'PREFLIGHT.json').read_bytes()),
        'freeze_sha256': digest_bytes((HERE / 'FREEZE.json').read_bytes()),
        'freeze_counts': {group: len(freeze[group]) for group in ('files', 'historical_files')},
        'unique_test_methods': len(tests), 'test_methods': sorted(tests),
        'final_passed': len(final_rows), 'final_failed': 0, 'final_errors': 0,
        'original_command': evidence['command'], 'attempts': attempts,
        'resolved_issue': preflight['resolved_issue'], 'tested_and_reviewed_files': reviewed,
        'source_bundle': {'manifest': 'frozen-source/MANIFEST.json', 'source_count': len(source_manifest)},
        'event_contract_audit': {
            'path': 'EVENT-CONTRACT-AUDIT.md', 'sha256': digest_bytes(contract.read_bytes()),
            'classification': 'Research-component event contract gap; not integrated into current production actor or Lab.',
            'historical_replay_limit': 'The older source-recovery full harness fingerprint does not match current config.py, run.py and agent_led.py; matching the two recovery component hashes is not whole-study reproducibility.'},
        'model_calls_by_this_recorder': 0, 'tests_rerun_by_this_recorder': 0,
        'recorder_execution_note': 'Initial recorder invocation reached verified source copying but could not format a timezone because this Python environment lacks tzdata. No validation.json was written. The recorder now preserves the frozen Halifax study date and records its own creation time separately in UTC; this is not another test-suite attempt.',
        'quality_claim': False,
        'limits': [
            'Thirteen unique offline tests; repeated attempts do not increase the test count.',
            'Initial failures and the isolated digest-overwrite reproduction remain in the record.',
            'This recorder validates reviewed files, logs and copied sources; the independent execution audit separately checks every frozen/protected file and all real request/response records.',
            'Passing contracts does not establish intention understanding, assistance quality, native compaction equivalence or production benefit.',
            'Source copies preserve frozen bytes but do not include a complete runtime or prove historical end-to-end replay.'],
    }
    write_new(destination, record)
    print(json.dumps({'validation': destination.relative_to(ROOT).as_posix(),
                      'unique_tests': len(tests), 'source_copies': len(source_manifest),
                      'freeze_counts': record['freeze_counts']}))


if __name__ == '__main__':
    main()
