"""Check generated site links, rendered counts, shared records and export hashes."""
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlsplit
import hashlib
import json
import re
import zipfile

STUDY = Path(__file__).resolve().parents[1]
ROOT = Path(__file__).resolve().parents[5]
SITE = ROOT / 'sites/conversation-agent-research/dist'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


class Page(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links, self.ids, self.rows = [], set(), {}
        self.split, self.row, self.cell = None, None, None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if attrs.get('id'):
            self.ids.add(attrs['id'])
        for name in ('href', 'src'):
            if name in attrs:
                self.links.append(attrs[name])
        if tag == 'section' and 'data-split' in attrs:
            self.split = attrs['data-split']
        if tag == 'tr' and 'data-guidance' in attrs:
            self.row = (self.split, attrs['data-guidance'], attrs['data-summary'])
            self.rows[self.row] = []
        if tag == 'td' and self.row:
            self.cell = ''

    def handle_data(self, text):
        if self.cell is not None:
            self.cell += text

    def handle_endtag(self, tag):
        if tag == 'td' and self.cell is not None:
            self.rows[self.row].append(self.cell.strip())
            self.cell = None
        if tag == 'tr':
            self.row = None


def parse(path):
    page = Page()
    page.feed(path.read_text(encoding='utf-8'))
    return page


def main():
    page = parse(SITE / 'summary-placement.html')
    linked = set()
    for link in page.links:
        parts = urlsplit(link)
        if parts.scheme or parts.netloc:
            continue
        target = (SITE / unquote(parts.path or 'summary-placement.html')).resolve()
        assert target.is_relative_to(SITE.resolve()) and target.is_file(), link
        if parts.fragment:
            assert unquote(parts.fragment) in parse(target).ids, link
        linked.add(link)
    results = read(STUDY / 'analysis/results.json')
    assert read(SITE / 'data/summary-placement/results.json') == results
    report_root = SITE / 'data/summary-placement'
    report_links = re.findall(r'\]\(([^)]+)\)', (report_root / 'RESULTS.md').read_text(encoding='utf-8'))
    for link in report_links:
        parts = urlsplit(link)
        if not parts.scheme and not parts.netloc:
            target = (report_root / unquote(parts.path)).resolve()
            assert target.is_relative_to(report_root.resolve()) and target.is_file(), link
    assert len(page.rows) == 8
    groups = {(g['split'], g['guidance'], g['summary'], g['order']): g for g in results['groups']}
    checked_cells = 0
    for key, cells in page.rows.items():
        expected = []
        for order in ('summary_last', 'summary_first'):
            group = groups[(*key, order)]
            for field in ('scope_error', 'scope_error_excluding_reconfirmation'):
                counts = group[field]
                expected.append(f"{counts['yes']}/{group['n']}" +
                    (f" + {counts['uncertain']} uncertain" if counts['uncertain'] else ''))
        assert cells == expected, (key, cells, expected)
        checked_cells += len(cells)
    index = parse(SITE / 'index.html')
    assert index.links.count('summary-placement.html') == 2
    assert index.links.count('source-authority.html') == 2
    assert 'summary-placement.html' in parse(SITE / 'source-authority.html').links
    combined = read(SITE / 'data/research-record.json')
    js = (SITE / 'data.js').read_text(encoding='utf-8')
    assert js.startswith('window.RESEARCH_DATA = ') and js.rstrip().endswith(';')
    assert json.loads(js[len('window.RESEARCH_DATA = '):].rstrip().removesuffix(';')) == combined
    entries = [s for s in combined['research_studies'] if s['id'] == results['id']]
    assert len(entries) == 1 and entries[0]['new_model_runs'] == 216
    validation = read(SITE / 'data/summary-placement-validation.json')
    assert validation['final_passed'] == 13 and validation['type'] == 'engineering_validation'
    assert len([v for v in combined['engineering_validations'] if v['id'] == validation['id']]) == 1
    with zipfile.ZipFile(SITE / 'data/summary-placement/evidence.zip') as archive:
        assert archive.testzip() is None
        assert len(archive.namelist()) == len(set(archive.namelist()))
        manifest = json.loads(archive.read('public-export.json'))
        assert manifest == read(SITE / 'data/summary-placement/public-export.json')
        for item in manifest['files']:
            source = (ROOT / item['source_path']).resolve()
            assert source.is_relative_to(ROOT.resolve())
            assert sha(source.read_bytes()) == item['source_sha256'], item['path']
            assert sha(archive.read(item['path'])) == item['public_sha256'], item['path']
        names = archive.namelist()
        assert sum(n.startswith('calls/') and n.endswith('/request.json') for n in names) == 216
        assert sum(n.startswith('calls/') and n.endswith('/response.json') for n in names) == 216
        assert any(n.endswith('summary_placement_study.py') for n in names)
    print(json.dumps({'status': 'passed', 'local_links': len(linked), 'rendered_count_cells': checked_cells,
        'report_evidence_links': len(report_links),
        'html_rows': len(page.rows), 'evidence_manifest_entries': len(manifest['files']),
        'json_and_javascript_identical': True, 'calls': 216, 'model_calls_by_check': 0}))


if __name__ == '__main__':
    main()
