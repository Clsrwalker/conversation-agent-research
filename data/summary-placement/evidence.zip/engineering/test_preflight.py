"""Offline contracts for the placement diagnostic; fixtures never call a model.

Run with the project's Python and -B.  These tests validate transport, freezing
and arithmetic, not whether a model understands a participant's intention.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from contextlib import ExitStack, redirect_stdout
from copy import deepcopy
import io
import json
from pathlib import Path
import random
import socket
import sys
import tempfile
import unittest
from unittest.mock import patch

import httpx

ROOT = Path(__file__).resolve().parents[5]
sys.path.insert(0, str(ROOT / 'experiments/deep_conversation'))
import source_authority_study as previous
import summary_placement_study as study
import summary_placement_score as score


class FakeClient:
    def __init__(self, responses=()):
        self.responses, self.sent = iter(responses), []

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass

    def build_request(self, method, path, json):
        return httpx.Request(method, 'http://127.0.0.1:11434' + path, json=json)

    def send(self, request):
        self.sent.append(request)
        response = next(self.responses)
        if isinstance(response, Exception):
            raise response
        return response


def replace_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')


class PlacementContracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.conditions = study.conditions()
        cls.cases = {c['case_id']: c for _, c in study.materials()}
        cls.gold = study.gold_by_case()

    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.stack.enter_context(patch.object(socket.socket, 'connect', side_effect=AssertionError('Offline fixture attempted network')))
        self.quiet = self.stack.enter_context(redirect_stdout(io.StringIO()))
        self.root = Path(self.stack.enter_context(tempfile.TemporaryDirectory(dir=Path(__file__).parent)))

    def patch(self, module, name, value):
        return self.stack.enter_context(patch.object(module, name, value))

    def test_real_matrix_has_216_new_cells_18_groups_and_one_shared_none(self):
        self.assertEqual(len(self.conditions), 216)
        groups = Counter((j['split'], j['guidance'], j['summary'], j['order']) for j, _ in self.conditions)
        self.assertEqual(len(groups), 18)
        self.assertEqual(set(groups.values()), {12})
        by_case = defaultdict(list)
        for job, request in self.conditions:
            by_case[job['case_id']].append(job)
            old_path = study.PRIOR / next(j['request'] for j in study.read(study.PRIOR / 'prepared/jobs.json') if j['job_id'] == job['prior_job_id'])
            old = study.read(old_path)
            self.assertEqual(study.sha(old_path), job['prior_request_sha256'])
            expected = deepcopy(old)
            if job['order'] == 'summary_first':
                expected['messages'][1:3] = expected['messages'][1:3][::-1]
            self.assertEqual(request, expected)
            self.assertEqual(request['messages'][-1], {'role': 'user', 'content': 'Continue assisting from this observation.'})
            self.assertEqual(len(request['tools']), 16)
            self.assertEqual(request['options'], {'num_ctx': 16384, 'num_predict': 1000, 'temperature': 0.0})
            self.assertIs(request['think'], False)
        self.assertEqual(set(by_case), set(self.cases))
        for jobs in by_case.values():
            self.assertEqual(len(jobs), 9)
            self.assertEqual(Counter(j['order'] for j in jobs), {'none': 1, 'summary_first': 4, 'summary_last': 4})
            none = next(j for j in jobs if j['summary'] == 'none')
            self.assertEqual((none['guidance'], none['order']), ('baseline', 'none'))

    def test_gold_and_actor_observations_exactly_inherit_24_previously_reviewed_states(self):
        original = {c['case_id']: c['evaluation_only'] for c in previous.read(previous.OLD / 'materials/cases.json')['cases']}
        authored = {c['case_id']: c for c in previous.read(previous.OUT / 'materials/novel-gold.json')['cases']}
        self.assertEqual(len(original), 12)
        self.assertEqual(len(authored), 12)
        self.assertFalse(set(original) & set(authored))
        self.assertEqual(self.gold, {**original, **authored})
        self.assertEqual(set(self.gold), set(self.cases))
        for job, request in self.conditions:
            case = self.cases[job['case_id']]
            message = next(m for m in request['messages'] if m['content'].startswith('Current conversation observation:\n'))
            observation = json.loads(message['content'].split('\n', 1)[1])
            self.assertEqual(observation, {'conversation': case['raw_turns'], 'provenance': case['model_observation']['provenance'], 'pending_jobs': [], 'active_cards': {}})
            self.assertNotIn('evaluation_only', observation)
            self.assertNotIn('gold', observation)

    def test_semantic_rubric_and_all_original_frozen_hashes_remain_unchanged(self):
        old = (study.PRIOR / 'SCORING.md').read_text(encoding='utf-8')
        new = (study.OUT / 'SCORING.md').read_text(encoding='utf-8')
        def semantic(text):
            return text.split('## Required review record', 1)[1].split('## Aggregation and uncertainty', 1)[0]
        self.assertEqual(semantic(new), semantic(old))
        frozen = previous.verify()
        self.assertEqual(len(frozen['files']), 137)
        self.assertEqual(len(frozen['historical_files']), 4475)

    def test_canonical_identity_ignores_only_valid_unique_call_ids(self):
        message = {'role': 'assistant', 'content': 'Exact prose', 'tool_calls': [
            {'id': 'a', 'index': 0, 'function': {'name': 'search', 'arguments': {'query': 'x', 'n': 2}}},
            {'id': 'b', 'index': 1, 'function': {'name': 'read_document', 'arguments': {'source_id': 'y'}}}]}
        changed = deepcopy(message)
        changed['tool_calls'][0]['id'], changed['tool_calls'][1]['id'] = 'new-a', 'new-b'
        self.assertEqual(study.canonical_message(message), study.canonical_message(changed))
        self.assertEqual(message['tool_calls'][0]['id'], 'a')
        for value in ('', None, 4, 'b'):
            bad = deepcopy(message)
            bad['tool_calls'][0]['id'] = value
            self.assertEqual(study.canonical_message(bad), bad)
        bad = deepcopy(message)
        del bad['tool_calls'][0]['id']
        self.assertEqual(study.canonical_message(bad), bad)
        variants = []
        for field, value in [('content', 'Exact prose '), ('role', 'user')]:
            variant = deepcopy(message)
            variant[field] = value
            variants.append(variant)
        variant = deepcopy(message)
        variant['tool_calls'].reverse()
        variants.append(variant)
        for field, value in [('index', 3), ('function', {'name': 'search', 'arguments': {'query': 'x ', 'n': 2}})]:
            variant = deepcopy(message)
            variant['tool_calls'][0][field] = value
            variants.append(variant)
        for variant in variants:
            self.assertNotEqual(study.canonical_message(message), study.canonical_message(variant))

    def prepare_fixture(self):
        out, prior = self.root / 'new', self.root / 'prior'
        source = self.root / 'src'
        source.mkdir()
        for name in ('summary_placement_study.py', 'summary_placement_score.py', 'source_authority_study.py', 'source_authority_score.py', 'config.py', 'local_runtime.py', 'providers.py'):
            (source / name).write_text('fixture source ' + name)
        study.write(out / 'PREFLIGHT.json', {'approved_for_freeze': True})
        (out / 'PROTOCOL.md').write_text('fixture protocol')
        (out / 'SCORING.md').write_text('fixture rubric')
        study.write(prior / 'prepared/runtime.json', {'fixture': True})
        protected = prior / 'protected.txt'
        protected.write_text('original prior material')
        study.write(prior / 'FREEZE.json', {'files': {str(protected.relative_to(self.root)): study.sha(protected)}, 'historical_files': {}})
        (prior / 'postrun.txt').write_text('previous results preserved too')
        self.patch(study, 'ROOT', self.root)
        self.patch(study, 'OUT', out)
        self.patch(study, 'PRIOR', prior)
        self.patch(study, '__file__', str(source / 'summary_placement_study.py'))
        self.patch(study, 'conditions', lambda: deepcopy(self.conditions))
        client = FakeClient()
        self.patch(study, 'client', lambda: client)
        self.patch(study, 'runtime', lambda _: {'fixture': True})
        return out, prior, protected

    def test_prepare_requires_approval_and_refuses_existing_preparation(self):
        out, _, _ = self.prepare_fixture()
        replace_json(out / 'PREFLIGHT.json', {'approved_for_freeze': False})
        with self.assertRaises(AssertionError):
            study.prepare()
        self.assertFalse((out / 'prepared').exists())
        replace_json(out / 'PREFLIGHT.json', {'approved_for_freeze': True})
        (out / 'prepared').mkdir()
        with self.assertRaises(FileExistsError):
            study.prepare()

    def test_prepare_materializes_all_requests_deterministically_and_protects_prior_results(self):
        out, prior, _ = self.prepare_fixture()
        study.prepare()
        jobs = study.read(out / 'prepared/jobs.json')
        expected = [j['job_id'] for j, _ in self.conditions]
        random.Random(2026102302).shuffle(expected)
        self.assertEqual([j['job_id'] for j in jobs], expected)
        frozen = study.verify()
        self.assertEqual(frozen['calls'], 216)
        self.assertFalse(frozen['quality_retry'])
        for job in jobs:
            self.assertEqual(job['request_sha256'], study.sha(out / job['request']))
        self.assertIn(str((prior / 'postrun.txt').relative_to(self.root)), frozen['historical_files'])
        self.assertIn(str((prior / 'FREEZE.json').relative_to(self.root)), frozen['historical_files'])
        (prior / 'postrun.txt').write_text('changed after new freeze')
        with self.assertRaises(ValueError):
            study.verify()

    def test_prepare_cannot_replace_prior_frozen_digest_with_current_tampered_hash(self):
        out, _, protected = self.prepare_fixture()
        protected.write_text('tampered previous frozen material')
        with self.assertRaises((AssertionError, ValueError)):
            study.prepare()
        self.assertFalse((out / 'prepared').exists(), 'Historical integrity must be checked before new materialization')
        self.assertFalse((out / 'FREEZE.json').exists())

    def test_verify_rejects_missing_current_and_modified_historical_inputs(self):
        out = self.root / 'new'
        current, old = self.root / 'current.txt', self.root / 'old.txt'
        current.write_text('current')
        old.write_text('history')
        study.write(out / 'FREEZE.json', {'files': {'current.txt': study.sha(current)}, 'historical_files': {'old.txt': study.sha(old)}})
        self.patch(study, 'ROOT', self.root)
        self.patch(study, 'OUT', out)
        study.verify()
        current.unlink()
        with self.assertRaises(ValueError):
            study.verify()
        current.write_text('current')
        old.write_text('different')
        with self.assertRaises(ValueError):
            study.verify()

    def run_fixture(self, responses, started=False):
        out = self.root / 'new'
        jobs = []
        for i in range(216):
            job = {'job_id': f'fixture-{i}', 'request': f'prepared/requests/{i}.json'}
            jobs.append(job)
            study.write(out / job['request'], {'model': 'fixture', 'messages': [{'role': 'user', 'content': str(i)}]})
        study.write(out / 'prepared/jobs.json', jobs)
        if started:
            study.write(out / 'run-start.json', {'fixture': True})
        fake = FakeClient(responses)
        frozen = {'model': {'fixture': True}, 'historical_files': {'prior': 'digest'}}
        self.patch(study, 'OUT', out)
        self.patch(study, 'client', lambda: fake)
        self.patch(study, 'runtime', lambda _: frozen['model'])
        self.patch(study, 'verify', lambda: frozen)
        return out, fake

    def test_all_216_calls_dispatch_fresh_and_preserve_wire_without_tool_execution(self):
        body = {'done': True, 'done_reason': 'stop', 'message': {'role': 'assistant', 'content': '', 'tool_calls': [{'id': 'fixture-id', 'function': {'name': 'publish_card', 'arguments': {'text': 'fixture'}}}]}}
        out, fake = self.run_fixture([httpx.Response(200, json=body) for _ in range(216)])
        study.run()
        self.assertEqual(len(fake.sent), 216)
        self.assertEqual(study.read(out / 'run-end.json')['calls'], 216)
        for i, wire in enumerate(fake.sent):
            folder = out / 'calls' / f'fixture-{i}'
            self.assertEqual((folder / 'request-body.bin').read_bytes(), wire.content)
            self.assertEqual(json.loads((folder / 'response-body.bin').read_bytes()), body)
            self.assertFalse((folder / 'error.json').exists())
        self.assertEqual(len(list((out / 'calls').glob('*'))), 216)

    def test_provider_failure_is_retained_and_stops_without_retry(self):
        out, fake = self.run_fixture([httpx.Response(503, json={'error': 'fixture unavailable'})])
        with self.assertRaises(RuntimeError):
            study.run()
        self.assertEqual(len(fake.sent), 1)
        self.assertEqual(study.read(out / 'calls/fixture-0/response.json')['http_status'], 503)
        self.assertTrue((out / 'calls/fixture-0/response-body.bin').is_file())
        self.assertTrue((out / 'calls/fixture-0/error.json').is_file())
        self.assertFalse((out / 'calls/fixture-1').exists())
        self.assertFalse((out / 'run-end.json').exists())

    def test_started_batch_cannot_be_silently_dispatched_again(self):
        out, fake = self.run_fixture([], started=True)
        with self.assertRaises(FileExistsError):
            study.run()
        self.assertEqual(fake.sent, [])
        self.assertFalse((out / 'calls').exists())

    def scoring_fixture(self):
        out, prior = self.root / 'new', self.root / 'prior'
        jobs, expected = [], {}
        case_indices = {case: index for index, case in enumerate(sorted(self.cases))}
        for index, (job, request) in enumerate(self.conditions):
            job = {**job, 'request': f"prepared/requests/{job['job_id']}.json"}
            study.write(out / job['request'], request)
            job['request_sha256'] = study.sha(out / job['request'])
            jobs.append(job)
            category = 0 if job['summary'] == 'none' else (case_indices[job['case_id']] + (job['guidance'] == 'source_authority') + 2 * (job['summary'] == 'incorrect') + (job['order'] == 'summary_first')) % 4
            text = f'Synthetic fixture category {category}'
            message = {'role': 'assistant', 'content': text, 'tool_calls': [{'id': f'call-{index}', 'index': 0, 'function': {'name': 'publish_card' if category == 0 else 'search', 'arguments': {'text': text}}}]}
            body = {'done': True, 'done_reason': 'stop', 'message': message, 'prompt_eval_count': 100 + index, 'eval_count': 10 + category}
            folder = out / 'calls' / job['job_id']
            study.write(folder / 'request.json', request)
            (folder / 'request-body.bin').write_bytes(json.dumps(request).encode())
            study.write(folder / 'response.json', {'http_status': 200, 'wall_seconds': (index + 1) / 10, 'body': body})
            (folder / 'response-body.bin').write_bytes(json.dumps(body).encode())
            if job['order'] != 'summary_first':
                old = prior / 'calls' / job['prior_job_id']
                study.write(old / 'request.json', request)
                prior_body = deepcopy(body)
                prior_body['message']['tool_calls'][0]['id'] = 'prior-id'
                study.write(old / 'response.json', {'body': prior_body})
            expected[job['job_id']] = {'category': category, 'input_tokens': 100 + index, 'output_tokens': 10 + category}
        study.write(out / 'prepared/jobs.json', jobs)
        study.write(out / 'run-end.json', {'calls': 216})
        study.write(out / 'FREEZE.json', {'fixture': True})
        self.patch(study, 'OUT', out)
        self.patch(study, 'verify', lambda: {'historical_files': {}})
        self.patch(score, 'OUT', out)
        self.patch(score, 'PRIOR', prior)
        self.patch(score, 'verify', lambda: {'historical_files': {}})
        study.blind()
        packets = study.read(out / 'scoring/blind-packets.json')
        reviews = []
        for packet in packets:
            text = packet['output']['content']
            category = int(text.rsplit(' ', 1)[1])
            reviews.append({'id': packet['id'], 'scope_error': ('no', 'yes', 'yes', 'uncertain')[category],
                'scope_error_excluding_reconfirmation': ('no', 'yes', 'no', 'uncertain')[category],
                'scope_failure_type': ('none', 'expansion', 'contraction', 'uncertain')[category],
                'unnecessary_reconfirmation': 'yes' if category == 2 else 'no', 'observable_omission': 'no', 'factual_error': 'no',
                'reason': 'Synthetic predeclared fixture category; not a model assessment.', 'evidence_quotes': [text]})
        study.write(out / 'scoring/reviewer-a.json', reviews)
        study.write(out / 'scoring/reviewer-b.json', reviews)
        return out, jobs, packets, expected

    def test_blinding_and_full_scoring_preserve_216_denominators_tokens_and_all_paired_buckets(self):
        out, jobs, packets, expected = self.scoring_fixture()
        mapping = study.read(out / 'scoring/private-mapping.json')
        self.assertEqual(len(packets), 96)
        self.assertEqual(sum(map(len, mapping.values())), 216)
        self.assertEqual({j['job_id'] for js in mapping.values() for j in js}, set(expected))
        for packet in packets:
            self.assertEqual(set(packet), {'id', 'conversation', 'gold', 'output', 'stop', 'tool_requests_executed'})
            self.assertTrue(packet['output']['tool_calls'][0]['id'].startswith('call-'))
            self.assertFalse(packet['tool_requests_executed'])
            self.assertEqual(len({j['case_id'] for j in mapping[packet['id']]}), 1)
        score.score()
        result = study.read(out / 'analysis/results.json')
        self.assertEqual(result['calls'], 216)
        self.assertEqual(len(result['groups']), 18)
        self.assertEqual(len(result['paired_comparisons']), 64)
        self.assertEqual(len(result['repeat_input_check']), 120)
        self.assertTrue(all(r['same_input'] and r['same_response_ignoring_call_ids'] for r in result['repeat_input_check']))
        self.assertEqual(result['total_tokens'], sum(x['input_tokens'] + x['output_tokens'] for x in expected.values()))
        independent_rows = {}
        for row in result['rows']:
            item = expected[row['job_id']]
            self.assertEqual(row['scope_error'], ('no', 'yes', 'yes', 'uncertain')[item['category']])
            self.assertEqual(row['scope_error_excluding_reconfirmation'], ('no', 'yes', 'no', 'uncertain')[item['category']])
            self.assertEqual(row['tool_requests'], 1)
            self.assertEqual(row['input_tokens'], item['input_tokens'])
            independent_rows[(row['case_id'], row['guidance'], row['summary'], row['order'])] = row
        for group in result['groups']:
            members = [r for r in result['rows'] if all(r[k] == group[k] for k in ('split', 'guidance', 'summary', 'order'))]
            self.assertEqual(len(members), 12)
            for field in score.FIELDS:
                self.assertEqual(group[field], {label: sum(r[field] == label for r in members) for label in ('yes', 'no', 'uncertain')})
            for token in ('input_tokens', 'output_tokens'):
                self.assertEqual(group[token], sum(r[token] for r in members))
        for comparison in result['paired_comparisons']:
            cases = sorted({j['case_id'] for j in jobs if j['split'] == comparison['split']})
            buckets = {key: [] for key in ('fixed', 'regressed', 'uncertain_pairs', 'both_error', 'both_no_error')}
            for case in cases:
                left = independent_rows[(case, *comparison['reference'])][comparison['metric']]
                right = independent_rows[(case, *comparison['candidate'])][comparison['metric']]
                key = 'uncertain_pairs' if 'uncertain' in (left, right) else {('yes', 'no'): 'fixed', ('no', 'yes'): 'regressed', ('yes', 'yes'): 'both_error', ('no', 'no'): 'both_no_error'}[(left, right)]
                buckets[key].append(case)
            self.assertEqual(comparison['pairs'], 12)
            for key, cases in buckets.items():
                self.assertEqual(comparison[key], cases)
            if comparison['comparison'] == 'no_summary_reference':
                self.assertEqual(comparison['reference'], ['baseline', 'none', 'none'])

    def test_scoring_rejects_mapping_packet_wire_and_unadjudicated_label_corruption(self):
        out, _, packets, _ = self.scoring_fixture()
        mapping_path = out / 'scoring/private-mapping.json'
        mapping = study.read(mapping_path)
        key = packets[0]['id']
        bad = deepcopy(mapping)
        bad[key][0]['guidance'] = 'tampered'
        replace_json(mapping_path, bad)
        with self.assertRaises(AssertionError):
            score.score()
        replace_json(mapping_path, mapping)
        packet_path = out / 'scoring/blind-packets.json'
        bad_packets = deepcopy(packets)
        bad_packets[0]['gold'] = {'tampered': True}
        replace_json(packet_path, bad_packets)
        with self.assertRaises(AssertionError):
            score.score()
        replace_json(packet_path, packets)
        wire = out / 'calls' / mapping[key][0]['job_id'] / 'request-body.bin'
        saved = wire.read_bytes()
        wire.write_bytes(b'{"tampered": true}')
        with self.assertRaises(AssertionError):
            score.score()
        wire.write_bytes(saved)
        reviews_path = out / 'scoring/reviewer-b.json'
        reviews = study.read(reviews_path)
        reviews[0]['factual_error'] = 'uncertain'
        replace_json(reviews_path, reviews)
        with self.assertRaises(AssertionError):
            score.score()
        self.assertFalse((out / 'analysis/results.json').exists())


if __name__ == '__main__':
    unittest.main(verbosity=2)
