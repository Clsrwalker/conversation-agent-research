"""Append observed publication checks without changing research scores."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json

OUT = Path(__file__).resolve().parents[1]
ROOT = OUT.parents[3]
path = OUT / 'engineering/validation.json'
record = json.loads(path.read_text(encoding='utf-8'))
record['publication_preflight'] = {
    'status': 'passed', 'date': '2026-10-23', 'timezone': 'America/Halifax',
    'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
    'builds': ['build_summary_placement.py', 'build_source_authority.py', 'build_overview.py', 'build_data.py'],
    'check_script': 'engineering/check_publication.py',
    'checks': ['All 16 new-page local links and target fragments resolve.',
               'Standalone report relative evidence links resolve to exported files.',
               'All 32 displayed scope metric cells equal the corresponding scored groups.',
               'Homepage contains both new study links and retains both source-authority links.',
               'Prior study links to follow-up while preserving its scores.',
               'Combined JSON and JavaScript records agree and contain one study and one validation entry.',
               'Evidence ZIP has unique members, passes CRC, and matches all local source and public export hashes.',
               'Evidence contains all 216 request JSON and 216 response JSON files and frozen source.'],
    'browser': {
        'environment': 'Local in-app browser at http://127.0.0.1:8777; not a production deployment check',
        'http_status': 200,
        'page': 'summary-placement.html',
        'viewport_observations': [
            {'width': 1280, 'height': 720, 'document_scroll_width': 1265,
             'table_client_width': 1065, 'table_scroll_width': 1065,
             'observed': 'Heading, metrics, both-order table columns and uncertain counts display without overlap.'},
            {'width': 390, 'height': 844, 'document_scroll_width': 375,
             'table_client_width': 308, 'table_scroll_width': 680,
             'observed': 'Long result tables are contained in overflow-x:auto areas; page has no horizontal overflow. Paragraphs and download actions fit the viewport.'}],
        'study_index': 'New 216-call entry is visible under index.html#methods.',
        'captured_console_errors_or_warnings': 0,
        'viewport_override_reset': True,
        'limits': ['No automated accessibility conformance claim.', 'Download records were verified on disk; no browser download completion test.', 'No model calls were triggered by site validation.']},
    'deployment': 'Recorded separately after publication; this preflight does not claim hosted success.'
}
record['interface_diagnostic'] = {
    'record': 'analysis/interface-audit.json', 'calls': 216, 'native_tool_requests': 243,
    'explicit_schema_violations': 1, 'calls_with_undeclared_keys': 3,
    'overlap': 'One of the three extra-key calls is also the single required-field failure.',
    'tools_executed': False,
    'limit': 'Limited validation of supplied schema keywords; not an executed parser test or assistance-quality score.'
}
record['score_accounting'] = {
    'record': 'analysis/INDEPENDENT-AUDIT.json', 'independent_checks_passed': 8,
    'scored_calls': 216, 'groups': 18, 'paired_comparisons': 64,
    'human_review': False, 'semantic_quality_proven': False
}
record['publication_preflight']['source_sha256'] = {
    name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
    for name in ['sites/conversation-agent-research/build_summary_placement.py',
                 'sites/conversation-agent-research/build_source_authority.py',
                 'sites/conversation-agent-research/build_overview.py',
                 'sites/conversation-agent-research/build_data.py',
                 'output/research/2026-10-23/summary-placement/engineering/check_publication.py']
}
path.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'validation': 'updated', 'unique_offline_tests': record['unique_test_methods'], 'model_calls': 0}))
