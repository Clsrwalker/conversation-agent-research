"""Durable causal Replay environment and conservative model-call accounting.

Only the existing Replay environment is reused; its provider and model loop are
never run. Tool idempotency is transactional for this simulated environment only.
It does not establish exactly-once effects for an external API. A reserved model
request with an unknown network outcome remains counted and is never retried by
this module; its actual token usage and financial cost may be unknown. The token
budget checks reported usage before each call, not an upper bound on future
provider output. Virtual model latency is a diagnostic, not measured latency.
"""
from __future__ import annotations

import copy
import importlib.util
import json
import math
from pathlib import Path
import sqlite3
import sys
from collections import Counter
from contextlib import contextmanager
from threading import RLock
from typing import Any


def _load_replay():
    # A unique module name avoids colliding with the new experiment's runner.
    source = Path(__file__).resolve().parents[1] / "conversation_harness" / "runner.py"
    spec = importlib.util.spec_from_file_location("_deep_conversation_replay", source)
    module = importlib.util.module_from_spec(spec)
    old_path, old_bytecode = list(sys.path), sys.dont_write_bytecode
    try:
        sys.path.insert(0, str(source.parent))
        sys.dont_write_bytecode = True
        spec.loader.exec_module(module)
    finally:
        sys.path[:] = old_path
        sys.dont_write_bytecode = old_bytecode
    return module.Replay


Replay = _load_replay()


class BudgetExceeded(RuntimeError):
    """A new model call would exceed the persisted call or known-token budget."""


class ModelCallAlreadyReserved(RuntimeError):
    """The call ID is already reserved; an unknown request must not be resent."""


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


class WorldStore:
    """SQLite-backed Replay with atomic simulated tools and model-call ledgers.

    ``close_at_ms`` is the observation deadline; ``close()`` closes the connection.
    ``snapshot``/``export`` are privileged diagnostic views and must not be sent
    to the model. Only ``observation`` and ``history`` provide causal model input.
    """

    def __init__(self, path: Path, case: dict | None = None, corpus: list | None = None,
                 model_latency_ms: int = 250):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = RLock()
        self._closed = False
        self._conn = sqlite3.connect(str(self.path), timeout=30, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA busy_timeout=30000")
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=FULL")
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS world_state (
                singleton INTEGER PRIMARY KEY CHECK (singleton=1), snapshot_json TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS tool_calls (
                call_id TEXT PRIMARY KEY, name TEXT NOT NULL, args_json TEXT NOT NULL,
                result_json TEXT NOT NULL, at_ms INTEGER NOT NULL, seq INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS model_calls (
                ordinal INTEGER PRIMARY KEY AUTOINCREMENT, call_id TEXT UNIQUE NOT NULL,
                role TEXT NOT NULL, request_json TEXT, outcome TEXT NOT NULL,
                started_at_ms INTEGER NOT NULL, finished_at_ms INTEGER,
                usage_json TEXT, input_tokens INTEGER NOT NULL DEFAULT 0,
                output_tokens INTEGER NOT NULL DEFAULT 0, total_tokens INTEGER NOT NULL DEFAULT 0,
                wall_ms REAL NOT NULL DEFAULT 0, max_calls INTEGER NOT NULL,
                max_tokens INTEGER NOT NULL
            );
        """)
        try:
            with self._lock:
                self._conn.execute("BEGIN IMMEDIATE")
                row = self._conn.execute("SELECT snapshot_json FROM world_state WHERE singleton=1").fetchone()
                if row is None:
                    if case is None or corpus is None:
                        raise ValueError("A new WorldStore requires both case and corpus")
                    if not isinstance(model_latency_ms, int) or model_latency_ms < 0:
                        raise ValueError("model_latency_ms must be a nonnegative integer")
                    replay = Replay(copy.deepcopy(case), copy.deepcopy(corpus),
                                    model_latency_ms=model_latency_ms, log_path=None, baseline="B0")
                    self._conn.execute("INSERT INTO world_state VALUES (1, ?)", (_json(replay.__dict__),))
                else:
                    saved = json.loads(row["snapshot_json"])
                    if case is not None and _json(case) != _json(saved["case"]):
                        raise ValueError("Existing WorldStore belongs to a different case")
                    if corpus is not None:
                        allowed = set(saved["case"]["corpus_ids"])
                        relevant = {doc["id"]: doc for doc in corpus if doc["id"] in allowed}
                        if _json(relevant) != _json(saved["corpus"]):
                            raise ValueError("Existing WorldStore has a different corpus")
                self._conn.commit()
        except BaseException:
            self._conn.rollback()
            self._conn.close()
            self._closed = True
            raise

    def _check_open(self):
        if self._closed:
            raise RuntimeError("WorldStore is closed")

    def _load(self):
        self._check_open()
        row = self._conn.execute("SELECT snapshot_json FROM world_state WHERE singleton=1").fetchone()
        replay = Replay.__new__(Replay)
        replay.__dict__.update(json.loads(row["snapshot_json"]))
        replay.log_path = None
        return replay

    @contextmanager
    def _transaction(self):
        with self._lock:
            self._check_open()
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                replay = self._load()
                yield replay
                self._preserve_arrived_full_sources(replay)
                self._conn.execute("UPDATE world_state SET snapshot_json=? WHERE singleton=1",
                                   (_json(replay.__dict__),))
                self._conn.commit()
            except BaseException:
                self._conn.rollback()
                raise

    @staticmethod
    def _preserve_arrived_full_sources(replay):
        """Repeated search results cannot downgrade already arrived full reads.

        Also repairs snapshots made by older Replay versions that replaced full
        reads with later snippets. Reconstruct only from causal arrival records,
        never by reading the hidden corpus or unfinished/cancelled jobs.
        """
        for entry in replay.log:
            if entry["kind"] != "environment_event":
                continue
            event = entry["event"]
            if event.get("kind") != "job_result" or event.get("operation") != "read":
                continue
            result = event.get("result", {})
            source_id = result.get("source_id")
            if source_id is not None and "text" in result:
                replay.delivered[source_id] = {"level": "full", **copy.deepcopy(result)}

    def snapshot(self) -> dict:
        with self._lock:
            return copy.deepcopy(self._load().__dict__)

    def register_source_catalog(self, source_ids: list[str]) -> list[dict]:
        """Make supplied IDs readable in direct mode without revealing contents.

        Research replay never calls this adapter operation. Catalog entries are
        metadata only, not arrived passages or evidence; ordinary asynchronous
        reads still retrieve their bodies. Re-registration is idempotent.
        """
        if (not isinstance(source_ids, list) or
                any(not isinstance(value, str) or not value for value in source_ids)):
            raise ValueError('Catalog IDs must be nonempty strings.')
        with self._transaction() as replay:
            if replay.case.get('input_mode') != 'direct_request':
                raise ValueError('Source catalogs are available only for direct requests.')
            catalog = []
            for source_id in dict.fromkeys(source_ids):
                source = replay.corpus.get(source_id)
                if (source_id not in replay.case.get('corpus_ids', []) or not source or
                        source.get('available_at_ms', 0) > 0 or
                        source.get('provenance') != 'User-provided local Run Lab input'):
                    raise ValueError('Catalog source is not an initially supplied document.')
                catalog.append({'source_id': source_id, 'title': source['title']})
            new_entries = []
            for item in catalog:
                if item['source_id'] not in replay.delivered:
                    replay.delivered[item['source_id']] = {'level': 'catalog', **item}
                    new_entries.append(item)
            if new_entries:
                replay.record('source_catalog_registered', sources=new_entries)
            return copy.deepcopy(catalog)

    @property
    def now(self):
        return self.snapshot()["now"]

    @property
    def close_at_ms(self):
        return self.snapshot()["close"]

    @property
    def done(self):
        state = self.snapshot()
        return state["now"] >= state["close"]

    @staticmethod
    def _arrivals(replay):
        return [entry for entry in replay.log if entry["kind"] == "environment_event"]

    def observation(self, after_seq: int) -> tuple[dict, int]:
        if not isinstance(after_seq, int):
            raise TypeError("Observation cursor must be an integer")
        with self._lock:
            replay = self._load()
            arrivals = self._arrivals(replay)
            events = [{**copy.deepcopy(item["event"]), "seq": item["seq"], "at_ms": item["at_ms"]}
                      for item in arrivals if item["seq"] > after_seq]
            payload = {
                "at_ms": replay.now, "events": events, "notes": copy.deepcopy(replay.notes),
                "active_cards": copy.deepcopy(replay.cards),
                "pending_jobs": [{"job_id": job_id, "operation": job["operation"], "due_ms": job["due_ms"]}
                                 for job_id, job in replay.jobs.items() if job["status"] == "pending"],
                "context_revision": sum(item["event"].get("kind") != "job_result" for item in arrivals),
            }
            return payload, max((item["seq"] for item in replay.log), default=-1)

    def history(self) -> list:
        with self._lock:
            return [{**copy.deepcopy(item["event"]), "seq": item["seq"], "at_ms": item["at_ms"]}
                    for item in self._arrivals(self._load()) if item["event"].get("kind") != "job_result"]

    def advance_next(self):
        with self._transaction() as replay:
            replay.advance(replay.next_time())
            return replay.now

    def recovery_feedback(self, after_seq: int, *, max_calls: int, max_tokens: int):
        """Offer one optional continuation after a failed retrieval and idle exit.

        This describes execution facts, not whether the user's question requires
        an answer. It neither retries a tool nor approves or rejects a card.
        Persist issuance separately from the graph's delivery acknowledgement:
        replaying an interrupted observe node returns the same feedback event.
        """
        if type(after_seq) is not int:
            raise TypeError('Recovery cursor must be an integer')
        with self._transaction() as replay:
            calls, tokens = self._conn.execute(
                'SELECT COUNT(*), COALESCE(SUM(total_tokens),0) FROM model_calls').fetchone()
            if replay.now >= replay.close or calls >= max_calls or tokens >= max_tokens:
                return None
            if any(job['status'] == 'pending' for job in replay.jobs.values()):
                return None
            failures = [entry for entry in replay.log
                        if entry['kind'] == 'tool_result'
                        and (entry['name'], entry['result'].get('error_code')) in {
                            ('read_document', 'source_not_available'),
                            ('search', 'empty_search_query')}
                        and entry['result'].get('job_started') is False
                        and entry['result'].get('retryable') is True]
            if not failures:
                return None
            failure = failures[-1]
            later = [entry for entry in replay.log if entry['seq'] > failure['seq']]
            # New evidence or conversation is already an opportunity to decide
            # again. Do not revive the old failure after processing that input.
            if any(entry['kind'] == 'environment_event' for entry in later):
                return None
            for entry in later:
                if entry['kind'] != 'tool_result':
                    continue
                name, result = entry['name'], entry['result']
                if ((name == 'wait' and 'error' not in result)
                        or (name in {'search', 'read_document'} and result.get('status') == 'pending')
                        or (name == 'publish_card' and result.get('status') in {'displayed', 'unchanged'})
                        or (name == 'withdraw_card' and result.get('status') == 'withdrawn')):
                    return None
            revision = sum(item['event'].get('kind') != 'job_result'
                           for item in self._arrivals(replay))
            previous = next((entry for entry in reversed(replay.log)
                             if entry['kind'] == 'recovery_feedback'
                             and entry['context_revision'] == revision), None)
            if previous is not None:
                return copy.deepcopy(previous) if previous['seq'] > after_seq else None
            feedback = {
                'kind': 'retrieval_recovery',
                'message': ('The retrieval attempt below did not start a job, and no source job is pending. '
                            'There is no result from this attempt to wait for. You can change the search '
                            'or use an available source ID. If help is no longer useful, you can still '
                            'wait or stop. This is an optional recovery opportunity, not a required step.'),
                'failed_attempt': {'tool': failure['name'], 'arguments': failure['args'],
                                   'result': copy.deepcopy(failure['result'])},
            }
            replay.record('recovery_feedback', context_revision=revision,
                          failed_call_id=failure['call_id'], feedback=feedback)
            return copy.deepcopy(replay.log[-1])

    def record(self, kind, **values):
        with self._transaction() as replay:
            replay.record(kind, **values)
            return copy.deepcopy(replay.log[-1])

    @staticmethod
    def _validate_tool_identity(row, name, encoded_args):
        if row["name"] != name or row["args_json"] != encoded_args:
            raise ValueError("Tool call ID reused for a different operation or arguments")

    def lookup_tool(self, call_id, name, args):
        with self._lock:
            self._check_open()
            row = self._conn.execute("SELECT * FROM tool_calls WHERE call_id=?", (call_id,)).fetchone()
            if row is None:
                return None
            self._validate_tool_identity(row, name, _json(args))
            return json.loads(row["result_json"])

    def apply(self, call_id, name, args, result_override=None, *,
              card_commit=False, unchanged_card=None, expected_observation_cursor=None,
              card_withdraw=False) -> dict:
        if not isinstance(call_id, str) or not call_id:
            raise ValueError("Tool call_id must be a nonempty string")
        if card_commit and (name != 'publish_card' or result_override is not None):
            raise ValueError('Card commit options require a real publish_card operation')
        if card_withdraw and (card_commit or name != 'withdraw_card' or result_override is not None):
            raise ValueError('Card withdrawal options require a real withdraw_card operation')
        guarded_card = card_commit or card_withdraw
        if unchanged_card is not None and not guarded_card:
            raise ValueError('unchanged_card requires a guarded card operation')
        if expected_observation_cursor is not None and (
                not guarded_card or type(expected_observation_cursor) is not int):
            raise ValueError('An observation cursor requires a guarded card operation and must be an integer')
        encoded_args = _json(args)
        with self._transaction() as replay:
            prior = self._conn.execute("SELECT * FROM tool_calls WHERE call_id=?", (call_id,)).fetchone()
            if prior is not None:
                self._validate_tool_identity(prior, name, encoded_args)
                return json.loads(prior["result_json"])
            current = replay.cards.get(args.get('card_id')) if guarded_card else None
            if (expected_observation_cursor is not None and any(
                    item['seq'] > expected_observation_cursor for item in self._arrivals(replay))):
                result = {'status': 'new_observations',
                          'reason': 'New conversation or source evidence has arrived; read it before deciding whether this card still applies.'}
            elif guarded_card and current != unchanged_card:
                # The comparison and persisted outcome share the tool transaction.
                # A concurrent replacement cannot be mistaken for our old card.
                # In this mode None explicitly means the card must not exist.
                result = {'status': 'conflict', 'card_id': args['card_id']}
                if expected_observation_cursor is not None:
                    result['current_card'] = copy.deepcopy(current)
                    result['reason'] = 'The card changed since you observed it. Consider this snapshot before deciding whether to update or withdraw it.'
            elif (card_commit and unchanged_card is not None and replay.now < replay.close and
                  current['text'] == args['text'] and current['source_ids'] == args['source_ids']):
                result = {'status': 'unchanged', 'card_id': args['card_id'],
                          'retained_card': copy.deepcopy(current)}
            else:
                result = copy.deepcopy(result_override) if result_override is not None else replay.act(name, copy.deepcopy(args))
            if card_commit and result.get('status') in {'displayed', 'unchanged'}:
                result['committed_card'] = copy.deepcopy(replay.cards[result['card_id']])
            if not isinstance(result, dict):
                raise TypeError("Tool results must be dictionaries")
            replay.record("tool_result", name=name, call_id=call_id, args=args, result=result)
            self._conn.execute("INSERT INTO tool_calls VALUES (?, ?, ?, ?, ?, ?)",
                               (call_id, name, encoded_args, _json(result), replay.now, replay.log[-1]["seq"]))
            return copy.deepcopy(result)

    def reserve_call(self, call_id, role, max_calls, max_tokens, request=None):
        if not isinstance(call_id, str) or not call_id:
            raise ValueError("Model call_id must be a nonempty string")
        if not isinstance(role, str) or not role:
            raise ValueError("Model role must be a nonempty string")
        if not isinstance(max_calls, int) or not isinstance(max_tokens, int) or min(max_calls, max_tokens) < 0:
            raise ValueError("Budgets must be nonnegative integers")
        with self._transaction() as replay:
            if self._conn.execute("SELECT 1 FROM model_calls WHERE call_id=?", (call_id,)).fetchone():
                raise ModelCallAlreadyReserved(f"Model call {call_id!r} is already reserved; do not resend")
            calls, tokens = self._conn.execute("SELECT COUNT(*), COALESCE(SUM(total_tokens),0) FROM model_calls").fetchone()
            if calls >= max_calls:
                raise BudgetExceeded(f"Model call budget exhausted ({calls}/{max_calls})")
            if tokens >= max_tokens:
                raise BudgetExceeded(f"Known token budget exhausted ({tokens}/{max_tokens}); unknown usage may add cost")
            self._conn.execute("""INSERT INTO model_calls
                (call_id, role, request_json, outcome, started_at_ms, max_calls, max_tokens)
                VALUES (?, ?, ?, 'pending', ?, ?, ?)""",
                (call_id, role, None if request is None else _json(request), replay.now, max_calls, max_tokens))
            replay.record("model_call_reserved", call_id=call_id, role=role, max_calls=max_calls, max_tokens=max_tokens)

    def finish_call(self, call_id, usage: dict, wall_ms: float, outcome="completed"):
        if not isinstance(usage, dict):
            raise TypeError("usage must be a dictionary")
        # Accept both provider Responses usage and LangChain AIMessage usage names.
        normalized = {
            "input_tokens": usage.get("input_tokens", usage.get("prompt_tokens", 0)) or 0,
            "output_tokens": usage.get("output_tokens", usage.get("completion_tokens", 0)) or 0,
        }
        normalized["total_tokens"] = usage.get("total_tokens", sum(normalized.values())) or 0
        if any(not isinstance(value, int) or value < 0 for value in normalized.values()):
            raise ValueError("Token usage must be nonnegative integer counts")
        if normalized["total_tokens"] < normalized["input_tokens"] + normalized["output_tokens"]:
            raise ValueError("Total token usage cannot be less than input plus output")
        if not isinstance(wall_ms, (int, float)) or not math.isfinite(wall_ms) or wall_ms < 0:
            raise ValueError("wall_ms must be nonnegative and finite")
        if not isinstance(outcome, str) or not outcome or outcome == "pending":
            raise ValueError("finish_call requires a non-pending outcome")
        with self._transaction() as replay:
            row = self._conn.execute("SELECT * FROM model_calls WHERE call_id=?", (call_id,)).fetchone()
            if row is None:
                raise KeyError(f"Unknown model call {call_id!r}")
            if row["outcome"] != "pending":
                if row["outcome"] == outcome and row["usage_json"] == _json(usage) and row["wall_ms"] == wall_ms:
                    return
                raise ValueError("Model call was already finished with a different result")
            if outcome == "completed":
                replay.advance(replay.now + replay.model_latency_ms)
            self._conn.execute("""UPDATE model_calls SET outcome=?, finished_at_ms=?, usage_json=?,
                input_tokens=?, output_tokens=?, total_tokens=?, wall_ms=? WHERE call_id=?""",
                (outcome, replay.now, _json(usage), normalized["input_tokens"], normalized["output_tokens"],
                 normalized["total_tokens"], float(wall_ms), call_id))
            replay.record("model_call_finished", call_id=call_id, role=row["role"], outcome=outcome,
                          usage=normalized, wall_ms=float(wall_ms))

    @staticmethod
    def _metrics(rows):
        return {
            "model_calls": len(rows),
            "token_usage": {key: sum(row[key] for row in rows)
                            for key in ("input_tokens", "output_tokens", "total_tokens")},
            "api_wall_ms": round(sum(row["wall_ms"] for row in rows), 3),
            "pending_or_failed_calls": sum(row["outcome"] != "completed" for row in rows),
            "role_counts": dict(Counter(row["role"] for row in rows)),
        }

    def metrics(self) -> dict:
        with self._lock:
            self._check_open()
            return self._metrics(self._conn.execute("SELECT * FROM model_calls ORDER BY ordinal").fetchall())

    def export(self) -> dict:
        with self._lock:
            self._check_open()
            # One read transaction keeps all three views mutually consistent.
            self._conn.execute("BEGIN")
            try:
                replay = self._load()
                rows = self._conn.execute("SELECT * FROM model_calls ORDER BY ordinal").fetchall()
                models = []
                for row in rows:
                    value = dict(row)
                    value["request"] = json.loads(value.pop("request_json")) if value["request_json"] is not None else None
                    value.pop("request_json", None)
                    value["usage"] = json.loads(value.pop("usage_json")) if value["usage_json"] is not None else None
                    value.pop("usage_json", None)
                    models.append(value)
                tool_rows = self._conn.execute("SELECT * FROM tool_calls ORDER BY seq").fetchall()
                tools = [{"call_id": row["call_id"], "name": row["name"], "args": json.loads(row["args_json"]),
                          "result": json.loads(row["result_json"]), "at_ms": row["at_ms"], "seq": row["seq"]}
                         for row in tool_rows]
                return {"environment_log": copy.deepcopy(replay.log), "model_calls": models,
                        "tool_calls": tools, "metrics": self._metrics(rows)}
            finally:
                self._conn.rollback()

    def close(self):
        with self._lock:
            if not self._closed:
                self._conn.close()
                self._closed = True

