"""No model generation: real selected graphs under the labelled plumbing model."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from lab import make_fixture, PROFILE, HARNESSES
from lab_worker import BASELINE, FIXED, HERE, ObservedGraph, run_job, verify_baseline


class WorkerTests(unittest.TestCase):
    def test_observer_keeps_invocation_and_original_callbacks(self):
        class Graph:
            name = 'original'
            def invoke(self, value, config, **kwargs):
                return value, config, kwargs
        original = {'callbacks': ['accounting'], 'configurable': {'thread_id': 'same'}}
        proxy = ObservedGraph(Graph(), ['output', 'runtime'])
        value, config, kwargs = proxy.invoke({'messages': []}, original, durability='sync')
        self.assertEqual(original['callbacks'], ['accounting'])
        self.assertEqual(config['callbacks'], ['accounting', 'output', 'runtime'])
        self.assertEqual(kwargs, {'durability': 'sync'})
        self.assertEqual(proxy.name, 'original')
        self.assertEqual(value, {'messages': []})

    def test_profiles_cannot_drift_or_accept_arbitrary_source(self):
        self.assertEqual(FIXED, PROFILE)
        for job in [{'harness': '../bad'}, {'harness': 'native', 'preset': 'native', 'settings': {}}]:
            with self.assertRaises(ValueError):
                run_job(job, scripted=True)

    def test_baseline_checksum_detects_edit(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / 'run.py').write_text('changed')
            (root / 'checksums.json').write_text(json.dumps({'files_sha256': {'run.py': 'wrong'}}))
            with self.assertRaisesRegex(ValueError, 'integrity'):
                verify_baseline(root)

    def test_caught_runner_failure_propagates_exit_code(self):
        runner = SimpleNamespace(Settings=lambda **kwargs: kwargs, build_graph=lambda: None,
                                 main=lambda: 1)
        spec = SimpleNamespace(loader=SimpleNamespace(exec_module=lambda module: None))
        with tempfile.TemporaryDirectory() as temp, patch('lab_worker.importlib.util.spec_from_file_location', return_value=spec), patch('lab_worker.importlib.util.module_from_spec', return_value=runner):
            job = dict(id='failure', harness='native', preset='native', settings=FIXED,
                       output=str(Path(temp) / 'run'), dataset=temp, case_id='failure')
            before = list(sys.path)
            try:
                self.assertEqual(run_job(job, scripted=True), 1)
            finally:
                sys.path[:] = before

    def test_selected_graphs_and_preserved_baseline(self):
        before = verify_baseline()
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            for harness in HARNESSES:
                with self.subTest(harness=harness['id']):
                    folder = root / harness['id']
                    dataset = root / (harness['id'] + '-dataset')
                    case_id = make_fixture(dataset, 'diagnostic', 'Find the offline note.',
                                           [{'title': 'offline', 'text': 'Offline integration fixture only.'}],
                                           input_mode=harness['input_mode'])
                    job = dict(id='diagnostic', harness=harness['id'], preset=harness['preset'],
                               input_mode=harness['input_mode'],
                               settings=FIXED, dataset=str(dataset), case_id=case_id, output=str(folder))
                    path = root / (harness['id'] + '.json')
                    path.write_text(json.dumps(job), encoding='utf-8')
                    process = subprocess.run([sys.executable, '-B', str(HERE / 'lab_worker.py'),
                                              '--job', str(path), '--scripted'], capture_output=True,
                                             text=True, encoding='utf-8', timeout=90)
                    self.assertEqual(process.returncode, 0, process.stderr[-4000:])
                    provenance = json.loads((folder / 'lab_provenance.json').read_text())
                    manifest = json.loads((folder / 'manifest.json').read_text())
                    summary = json.loads((folder / 'summary.json').read_text())
                    self.assertTrue(provenance['scripted_diagnostic'])
                    self.assertFalse(provenance['quality_evaluated'])
                    self.assertEqual(manifest['provider'], 'scripted')
                    self.assertEqual(manifest['settings']['preset'], harness['preset'])
                    self.assertEqual(summary['status'], 'completed')
                    self.assertTrue((folder / 'monitor_events.jsonl').exists())
                    self.assertTrue((folder / 'assistant_output.jsonl').exists())
                    self.assertTrue((folder / 'graph.json').exists())
                    expected = before if harness['id'] == 'frozen-baseline' else None
                    self.assertEqual(provenance['baseline_checksums_sha256'], expected)
                    if expected:
                        from lab_worker import sha
                        key = 'experiments/deep_conversation/run.py'
                        self.assertEqual(manifest['fingerprint']['source_sha256'][key],
                                         sha(BASELINE / 'source' / key))
        self.assertEqual(verify_baseline(), before)


if __name__ == '__main__':
    unittest.main()
