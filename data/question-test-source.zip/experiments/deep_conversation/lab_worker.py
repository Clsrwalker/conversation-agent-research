"""Run a Lab job using its selected source, with observational callbacks only.

The frozen runner is imported from its intact snapshot in a fresh process. This
wrapper changes neither prompts nor tools nor graph transitions for those
research presets. Direct-help is a separately recorded task adapter with its
own prompt and response-delivery node; it is not a new research baseline.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
BASELINE = HERE / 'baselines' / '2026-10-07-agent-led-recovery-v1'
HARNESS_SOURCES = {
    'frozen-baseline': (BASELINE / 'source/experiments/deep_conversation', 'agent-led-recovery'),
    'progress': (HERE, 'agent-led-progress'),
    'native': (HERE, 'native'),
    'agent-led': (HERE, 'agent-led'),
    'direct-help': (HERE, 'agent-led'),
}
FIXED = dict(provider='ollama', model='qwen2.5:14b-instruct', context_window=16384,
             temperature=0, max_calls=24, max_tokens=120000, max_output_tokens=1200,
             request_timeout=180, model_latency_ms=250, reasoning_effort='none',
             local_base_url='http://127.0.0.1:11434')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def verify_baseline(folder=BASELINE):
    checksums = read(folder / 'checksums.json')
    for relative, expected in checksums['files_sha256'].items():
        path = (folder / relative).resolve()
        if not path.is_relative_to(folder.resolve()) or sha(path) != expected:
            raise ValueError('Frozen baseline integrity check failed.')
    return sha(folder / 'checksums.json')


class ObservedGraph:
    """Delegate all graph operations; add observers only at invoke."""
    def __init__(self, graph, callbacks):
        self.graph, self.callbacks = graph, callbacks

    def __getattr__(self, name):
        return getattr(self.graph, name)

    def invoke(self, value, config=None, **kwargs):
        observed = dict(config or {})
        observed['callbacks'] = [*(observed.get('callbacks') or []), *self.callbacks]
        return self.graph.invoke(value, observed, **kwargs)


def run_job(job, *, scripted=False):
    if job.get('harness') not in HARNESS_SOURCES:
        raise ValueError('Unknown Lab harness.')
    source, preset = HARNESS_SOURCES[job['harness']]
    if job.get('preset') != preset or job.get('settings') != FIXED:
        raise ValueError('Lab preset or fixed model profile does not match.')
    direct = job['harness'] == 'direct-help'
    provided_sources = []
    if direct:
        case = next((case for case in read(Path(job['dataset']) / 'cases.json')
                     if case.get('case_id') == job['case_id']), None)
        if job.get('input_mode') != 'direct_request' or not case or case.get('input_mode') != 'direct_request':
            raise ValueError('Direct-help requires a direct-request fixture and job.')
        provided_sources = [
            {'source_id': doc['id'], 'title': doc['title']}
            for doc in read(Path(job['dataset']) / 'corpus.json')
            if doc['id'] in case.get('corpus_ids', []) and doc.get('available_at_ms', 0) <= 0
            and doc.get('provenance') == 'User-provided local Run Lab input']
    baseline_checksum = verify_baseline() if job['harness'] == 'frozen-baseline' else None
    output = Path(job['output']).resolve()
    if output.exists():
        raise ValueError('Lab output must be a new directory.')
    # Fresh-process use is deliberate: generic module names belong to the selected
    # source, including its own world, agent, config and sibling shared runner.
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(source))
    spec = importlib.util.spec_from_file_location('selected_lab_runner', source / 'run.py')
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    if direct:
        from direct_request import build_direct_request_graph
        original_sources = runner.source_files

        def direct_sources():
            return {**original_sources(), **{
                str((HERE / name).relative_to(runner.ROOT)).replace('\\', '/'): HERE / name
                for name in ['direct_request.py', 'lab_worker.py']}}

        runner.source_files = direct_sources
        runner.execution_design = lambda settings: 'direct_request_optional_tools_and_response_delivery'
        runner.build_graph = lambda *args, **kwargs: build_direct_request_graph(
            *args, **kwargs, response_path=output / 'direct_response.json',
            provided_sources=provided_sources)
    settings = runner.Settings(preset=preset, **{k: v for k, v in FIXED.items() if k != 'temperature'})
    expected = job.get('expected_local_model')
    if not scripted:
        if not expected or runner.local_model_metadata(settings) != expected:
            raise ValueError('The local model or runtime changed after Lab preflight.')
        # The runner preflights again just before creating the manifest. Check
        # that exact metadata as well, rather than trusting the earlier read.
        preflight = runner.local_model_metadata

        def pinned_preflight(config):
            actual = preflight(config)
            if actual != expected:
                raise ValueError('The local model or runtime changed after Lab preflight.')
            return actual

        runner.local_model_metadata = pinned_preflight
    # Load external observers by absolute file path: no frozen file is modified.
    from lab_output import LocalModelOutputCallback
    from monitor_runtime import RuntimeMonitor
    stream = None
    external_monitor = None
    build_graph = runner.build_graph

    def observed_build(*args, **kwargs):
        nonlocal external_monitor, stream
        graph, native, accounting = build_graph(*args, **kwargs)
        manifest = read(output / 'manifest.json')
        stream = LocalModelOutputCallback(output)
        callbacks = [stream]
        if baseline_checksum:
            external_monitor = RuntimeMonitor(output, metadata={
                'provider': manifest['provider'],
                'model': runner.SmokeModel.model_fields['model_name'].default if scripted else manifest['settings']['model'],
                'preset': preset, 'case_id': job['case_id'], 'thread_id': manifest['thread_id'],
                'execution_mode': 'scripted_graph' if scripted else 'model_graph',
            })
            external_monitor.export_graph(graph, native, fingerprint=manifest['fingerprint'])
            callbacks.append(external_monitor)
        provenance = {
            'schema_version': 1, 'created_at': datetime.now(timezone.utc).isoformat(),
            'job_id': job['id'], 'harness': job['harness'], 'preset': preset,
            'input_mode': 'direct_request' if direct else 'human_human_transcript',
            'source': BASELINE.name if baseline_checksum else 'current',
            'baseline_checksums_sha256': baseline_checksum,
            'source_fingerprint': manifest['fingerprint'],
            'observer_sha256': {name: sha(HERE / name) for name in
                               ['lab_worker.py', 'lab_output.py', 'monitor_runtime.py']},
            'actual_local_model': manifest.get('local_model'),
            'dataset_sha256': manifest['dataset_sha256'],
            'model_profile': FIXED,
            'scripted_diagnostic': scripted, 'quality_evaluated': False,
            'observation': 'Provider-returned text and callback events; no hidden reasoning requested.',
            'comparison_scope': 'Selected harness code under the recorded local runtime; new user input is not a replay of frozen study results.',
        }
        if direct:
            provenance['task_adapter'] = {
                'id': 'direct-help-v2', 'sha256': sha(HERE / 'direct_request.py'),
                'changes': ['Direct user-request prompt', 'Role-aware input',
                            'Provided-document ID/title inventory without body injection',
                            'Explicit ordinary-prose response delivery',
                            'One bounded continuation after empty model output'],
                'tools_omitted': ['publish_card', 'withdraw_card', 'evidence_check'],
                'delivery_is_quality_score': False,
                'limitations': ['No live web retrieval', 'No semantic answer-quality gate',
                                'Not a frozen-baseline comparison'],
            }
        (output / 'lab_provenance.json').write_text(json.dumps(provenance, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        return ObservedGraph(graph, callbacks), native, accounting

    runner.build_graph = observed_build
    argv = ['run.py', '--preset', preset, '--provider', 'scripted' if scripted else 'ollama',
            '--dataset', str(job['dataset']), '--case', job['case_id'], '--output', str(output)]
    for key, value in FIXED.items():
        if key not in {'provider', 'temperature'}:
            argv.extend(['--' + key.replace('_', '-'), str(value)])
    old_argv = sys.argv
    sys.argv = argv
    try:
        return runner.main()
    finally:
        sys.argv = old_argv
        if stream:
            stream.finish()
        if external_monitor:
            try:
                summary = read(output / 'summary.json')
                status = summary.get('status', 'error')
            except (OSError, ValueError):
                status = 'error'
            external_monitor.finish(status)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--job', required=True, type=Path)
    parser.add_argument('--scripted', action='store_true', help='Offline integration diagnostic only; never offered by the browser server.')
    args = parser.parse_args()
    return run_job(read(args.job), scripted=args.scripted)


if __name__ == '__main__':
    sys.exit(main())
