"""Group completed data-contract checks separately from the planned LoRA study."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]


def read(name):
    return json.loads((HERE / name).read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    data = read('data/validation.json')
    plan = read('plan.json')
    inventory = read('data-audit/inventory.json')
    assert data['status'] == 'passed'
    assert (data['examples_checked'], data['sft_pairs_checked'], data['families']) == (24, 24, 12)
    assert data['source_hashes_before'] == data['source_hashes_after']
    for name, expected in data['source_hashes_after'].items():
        assert sha(ROOT / name) == expected, name
    for name, expected in data['artifact_hashes'].items():
        assert sha(HERE / 'data' / name) == expected, name
    assert data['new_real_model_calls'] == data['training_runs'] == inventory['new_real_model_calls'] == inventory['training_runs'] == 0
    assert sum(plan['training_mix'].values()) == plan['training_examples_target']
    assert all(plan['family_targets'][name] * plan['decisions_per_family_target'] == count for name, count in
               [('train', 800), ('development', 200), ('heldout', 400)])
    e2e = plan['planned_end_to_end']
    assert e2e['heldout_families'] * e2e['arms'] * e2e['inference_repeats'] == e2e['trajectories']
    assert e2e['trajectories'] * e2e['stages'] * e2e['calls_per_stage'] == e2e['model_call_ceiling']
    summary = {'id': 'tracker-lora-plan', 'date': plan['date'], 'timezone': plan['timezone'],
        'kind': 'prospective_protocol_with_completed_data_contract_checks',
        'status': 'data_contract_checked_training_not_started',
        'actual': {key: data[key] for key in ('examples_checked', 'families', 'languages', 'sft_pairs_checked',
            'no_change_examples', 'target_operations', 'preserved_records_checked', 'corruption_cases',
            'runtime_rejected_corruptions', 'authored_oracle_only_corruptions', 'new_real_model_calls', 'training_runs')},
        'planned_only': {key: plan[key] for key in ('training_examples_target', 'development_examples_target',
            'heldout_examples_target', 'family_targets', 'planned_end_to_end', 'comparison')},
        'measured_omission_reduction': None,
        'semantic_labels': 'Agent-authored; independent model review in REVIEW.json; human adjudication pending.',
        'illustrative_data_usage': 'Development only; never a claimed unseen benchmark or automatically training-approved.',
        'unresolved_owner_examples': 'Two examples use an uncertain owner-label convention, not unique settled gold.',
        'input_shortcut_repair': 'Semantic category was removed from runtime patch IDs after review; attempt 1 preserved, attempt 2 revalidated.',
        'runtime_changes': 'None. previous_error and bounded recovery remain proposed interfaces.',
        'training_readiness': '16 GB GPU observed; exact training stack, checkpoint, memory fit and adapter deployment unverified.',
        'sources': ['plan.json', 'data/validation.json', 'data/validation_attempt_history.json', 'data-audit/inventory.json', 'REVIEW.json']}
    validation = {'id': 'tracker-lora-data-validation', 'type': 'engineering_validation',
        'date': plan['date'], 'timezone': plan['timezone'], 'status': 'passed_with_scope_limits',
        'tested_revision': {'source_sha256': data['source_hashes_after'], 'data_artifact_sha256': data['artifact_hashes']},
        'checks': [
            {'name': '24 example state replay and 24 SFT prompt/completion pairs', 'status': 'passed', 'record': 'data/validation.json'},
            {'name': '40 unchanged records and 6 semantic no-change examples', 'status': 'passed', 'record': 'data/validation.json'},
            {'name': 'Three invalid patches rejected atomically', 'status': 'passed', 'record': 'data/validation.json'},
            {'name': 'One omitted requirement accepted by runtime but detected by authored expected-state oracle', 'status': 'boundary_confirmed_not_quality_pass', 'record': 'data/validation.json'},
            {'name': 'Semantic labels removed from runtime patch IDs', 'status': 'corrected_and_rechecked', 'record': 'data/validation_attempt_history.json'},
            {'name': 'Source identity, current artifact hashes and proposed budget arithmetic', 'status': 'passed', 'record': 'SUMMARY.json'}],
        'inventory': 'Read-only source and package inventory; no training compatibility claim.',
        'new_real_model_calls': 0, 'training_runs': 0,
        'label_review': 'Independent model review in REVIEW.json; unresolved owner convention and human review remain open.',
        'limitations': [
            '24 agent-authored short examples are illustrative development data, not collected train/dev/test sets.',
            'Expected-state agreement and schema acceptance do not prove user-intent correctness or LoRA quality.',
            'Family separation policy is specified; no unseen split has been constructed or evaluated.',
            'Recovery error input is not yet wired into the current runtime.',
            'No adapter, training-fit test, semantic evaluation runner or end-to-end LoRA comparison has run.',
            'Original no-LoRA study and diagnostics remain unchanged.'],
        'study_status': plan['status'], 'protocol': 'PROTOCOL.md'}
    for name, value in [('SUMMARY.json', summary), ('validation.json', validation)]:
        (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': summary['status'], 'actual_examples': 24, 'planned_training_examples': 800,
                      'new_real_model_calls': 0, 'training_runs': 0, 'validation': validation['status']}))


if __name__ == '__main__':
    main()
