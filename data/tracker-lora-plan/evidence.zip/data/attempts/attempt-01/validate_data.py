"""Replay illustrative labels with the real store; no model/network/training."""
from __future__ import annotations
from collections import Counter
import copy
import hashlib
import json
from pathlib import Path
import sys
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
ROOT = next(p for p in HERE.parents if (p / 'experiments/deep_conversation/intention_state.py').exists())
sys.path.insert(0, str(ROOT / 'experiments/deep_conversation'))
from intention_state import IntentStore, IntentValidationError

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def check(condition, message):
    if not condition: raise AssertionError(message)

def prepare(ex):
    store = IntentStore(':memory:')
    raw = ex['input']['conversation']
    for patch in ex['metadata']['setup_patches']:
        store.observe([event for event in raw if event['seq'] <= patch['through_seq']])
        store.commit_patch(**patch)
    store.observe(raw)
    return store

def apply_target(store, ex, target=None):
    proposal = ex['target'] if target is None else target
    check(isinstance(proposal, dict) and set(proposal) == {'operations'}, 'Target must have exactly operations')
    return store.commit_patch(**ex['metadata']['target_commit_identity'], operations=proposal['operations'])

def validate_example(ex):
    check(set(ex['input']) == ({'conversation', 'intention_state', 'tool_receipts', 'previous_error'} if ex['metadata']['candidate_runtime_error_input'] else {'conversation', 'intention_state', 'tool_receipts'}), 'Unexpected input fields')
    check(ex['metadata']['split'] == 'illustrative_development_only', 'Example must remain development only')
    check(ex['metadata']['semantic_review_status'] == 'independent semantic and human review pending', 'Review status cannot overclaim')
    store = prepare(ex)
    try:
        before = store.snapshot()
        check(before == ex['input']['intention_state'], 'Current state replay mismatch')
        check(store.events() == ex['input']['conversation'], 'Input must be all and only arrived raw conversation')
        source_ids = {event['seq'] for event in store.events()}
        for op in ex['target']['operations']:
            check(set(op['source_seqs']) <= source_ids, 'Target cites an unarrived source')
        recovery = ex['input'].get('previous_error')
        if recovery:
            try:
                store.commit_patch('deliberate-rejected-attempt', before['version'], before['observed_event_seq'], recovery['proposal']['operations'])
                raise AssertionError('Repair example did not reproduce its original rejection')
            except IntentValidationError as error:
                check(type(error).__name__ == recovery['error_type'] and str(error) == recovery['message'], 'Repair error mismatch')
                check(store.snapshot() == before, 'Rejected repair precursor was not atomic')
        after = apply_target(store, ex)
        check(after == ex['metadata']['expected_post_state'], 'Full expected state mismatch')
        projection = [{k: value[k] for k in ('intent_id', 'owner', 'text', 'status')} for value in after['intents']]
        check(projection == sorted(ex['metadata']['atomic_requirement_annotations'], key=lambda x: x['intent_id']), 'Authored requirements mismatch')
        before_by_id = {x['intent_id']: x for x in before['intents']}
        after_by_id = {x['intent_id']: x for x in after['intents']}
        for identifier in ex['metadata']['preserve_unchanged_ids']:
            check(before_by_id[identifier] == after_by_id[identifier], f'Unchanged intention modified: {identifier}')
        if not ex['target']['operations']:
            check(before['intents'] == after['intents'], 'Empty operations changed intentions')
            check(after['version'] == before['version'] + 1 and after['processed_event_seq'] == before['observed_event_seq'], 'No-change cursor/version semantics violated')
        return {'example_id': ex['example_id'], 'status': 'passed', 'operations': len(ex['target']['operations']), 'preserved_ids': len(ex['metadata']['preserve_unchanged_ids']), 'repair_error_reproduced': bool(recovery)}
    finally:
        store.close()

def corruptions(examples):
    byid = {x['example_id']: x for x in examples}
    cases = []
    ex = byid['add-constraint-en']
    bad = copy.deepcopy(ex['target']); bad['operations'][0]['source_seqs'] = [999]
    cases.append(('future-source', ex, bad, 'runtime_structure'))
    ex = byid['combined-operations-en']
    bad = copy.deepcopy(ex['target']); bad['operations'].append(copy.deepcopy(bad['operations'][0]))
    cases.append(('duplicate-target-after-valid-operations', ex, bad, 'runtime_structure_and_atomicity'))
    ex = byid['reopen-en']
    bad = {'operations': [{'op': 'update', 'intent_id': 'sync', 'status': 'active', 'source_seqs': [9]}]}
    cases.append(('withdrawn-update-without-reopen', ex, bad, 'runtime_transition'))
    ex = byid['add-constraint-en']
    cases.append(('omitted-required-add', ex, {'operations': []}, 'authored_expected_state_oracle_only'))
    results = []
    for name, ex, target, layer in cases:
        store = prepare(ex)
        before = store.snapshot()
        runtime_rejected = False
        caught = None
        try:
            try:
                after = apply_target(store, ex, target)
                check(after == ex['metadata']['expected_post_state'], 'Authored expected state mismatch: omitted required intention')
            except IntentValidationError as error:
                runtime_rejected = True
                caught = {'type': type(error).__name__, 'message': str(error)}
                check(before == store.snapshot(), 'Rejected corruption was not atomic')
            except AssertionError as error:
                if layer != 'authored_expected_state_oracle_only': raise
                caught = {'type': type(error).__name__, 'message': str(error)}
            check(caught is not None, f'Corruption was not caught: {name}')
            results.append({'name': name, 'status': 'expected_corruption_detected', 'layer': layer,
                            'runtime_rejected': runtime_rejected,
                            'rollback_verified': runtime_rejected, 'error': caught,
                            'interpretation': 'The real store accepts an empty patch; only an external authored target detects this semantic omission.' if not runtime_rejected else 'Runtime rejects this structurally invalid patch and preserves the entire pre-state.'})
        finally:
            store.close()
    return results

def main():
    sourcepaths = [ROOT / 'experiments/deep_conversation/intention_state.py', ROOT / 'experiments/deep_conversation/intent_roles.py']
    beforehash = {str(p.relative_to(ROOT)).replace('\\', '/'): digest(p) for p in sourcepaths}
    examples = [json.loads(line) for line in (HERE / 'examples.jsonl').read_text(encoding='utf-8').splitlines() if line]
    check(len(examples) == 24, 'Expected 24 illustrative examples')
    check(len({x['example_id'] for x in examples}) == 24, 'Duplicate example identifiers')
    languages = Counter(x['metadata']['language'] for x in examples)
    check(languages == {'zh': 12, 'en': 12}, 'Language balance mismatch')
    families = Counter(x['metadata']['family_id'] for x in examples)
    check(len(families) == 12 and set(families.values()) == {2}, 'Family grouping mismatch')
    results = [validate_example(ex) for ex in examples]
    sft = [json.loads(line) for line in (HERE / 'sft_examples.jsonl').read_text(encoding='utf-8').splitlines() if line]
    check(len(sft) == len(examples), 'SFT line count mismatch')
    prompt = (HERE / 'system_prompt.txt').read_text(encoding='utf-8')
    for record, ex in zip(sft, examples):
        check(set(record) == {'prompt', 'completion'}, 'SFT contains nontraining fields')
        check(record['prompt'] == [{'role': 'system', 'content': prompt}, {'role': 'user', 'content': json.dumps(ex['input'], ensure_ascii=False, sort_keys=True)}], 'SFT input mismatch or metadata leakage')
        check(record['completion'] == [{'role': 'assistant', 'content': json.dumps(ex['target'], ensure_ascii=False, sort_keys=True)}], 'SFT target mismatch')
    negatives = corruptions(examples)
    afterhash = {str(p.relative_to(ROOT)).replace('\\', '/'): digest(p) for p in sourcepaths}
    check(beforehash == afterhash, 'Implementation changed during verification')
    result = {'schema_version': 1, 'id': 'tracker-lora-illustrative-data-validation-2026-10-24',
        'type': 'engineering_validation', 'date': '2026-10-24', 'timezone': 'America/Halifax',
        'created_at_utc': datetime.now(timezone.utc).isoformat(), 'status': 'passed',
        'scope': 'Offline structure, causal source availability, replay, authored-target consistency, and corruption detection; not semantic quality or LoRA benefit.',
        'examples_checked': len(examples), 'families': len(families), 'languages': dict(languages),
        'sft_pairs_checked': len(sft), 'sft_metadata_excluded': True,
        'no_change_examples': sum(not x['target']['operations'] for x in examples),
        'recovery_examples_with_candidate_input': sum(x['metadata']['candidate_runtime_error_input'] for x in examples),
        'target_operations': sum(len(x['target']['operations']) for x in examples),
        'preserved_records_checked': sum(x['preserved_ids'] for x in results),
        'corruption_cases': len(negatives), 'runtime_rejected_corruptions': sum(x['runtime_rejected'] for x in negatives),
        'authored_oracle_only_corruptions': sum(not x['runtime_rejected'] for x in negatives),
        'new_real_model_calls': 0, 'training_runs': 0, 'downloads': 0,
        'semantic_review_status': 'independent semantic and human review pending',
        'current_runtime_supports_previous_error_input': False,
        'examples': results, 'corruptions': negatives,
        'source_hashes_before': beforehash, 'source_hashes_after': afterhash,
        'artifact_hashes': {p.name: digest(p) for p in (HERE / 'examples.jsonl', HERE / 'sft_examples.jsonl', HERE / 'sft_manifest.json', HERE / 'build_examples.py', HERE / 'validate_data.py', HERE / 'system_prompt.txt')},
        'attempts': {'validation_execution': 1, 'unexpected_failed_validation_attempts': 0, 'intended_rejection_precursors': 2,
                     'preparatory_missing_directory_inventory': 'An initial rg inventory returned path-not-found before this new output directory was created; no validation had run.'},
        'limitations': ['Labels and requirement wording are agent-authored; independent semantic/human review is pending.',
                        'Paired bilingual siblings are not independent tests; all 24 are exposed illustrative development examples.',
                        '24 short examples are not a collected training dataset, sample-size justification, or held-out benchmark.',
                        'Structural replay cannot show that an intention represents the user correctly.',
                        'Recovery examples use a proposed previous_error field not supplied by the current IntentRoleSession.',
                        'Unresolved ownership is represented in an uncertain text label because the current schema has no owner-resolution field.',
                        'No adapters were trained, loaded, or evaluated; reduction in intention omission remains untested.']}
    (HERE / 'validation.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: result[k] for k in ('status', 'examples_checked', 'families', 'languages', 'no_change_examples', 'recovery_examples_with_candidate_input', 'target_operations', 'preserved_records_checked', 'corruption_cases', 'runtime_rejected_corruptions', 'authored_oracle_only_corruptions', 'new_real_model_calls', 'training_runs')}, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
