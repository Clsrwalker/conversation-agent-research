"""Author a small fictional development pack; this is not a training run."""
from __future__ import annotations
import ast
import copy
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = next(p for p in HERE.parents if (p / 'experiments/deep_conversation/intention_state.py').exists())
sys.path.insert(0, str(ROOT / 'experiments/deep_conversation'))
from intention_state import IntentStore, IntentValidationError

def event(seq, who, text, role='user'):
    return {'seq': seq, 'speaker': who, 'text': text, 'role': role}

def add(key, owner, text, seq, status='active'):
    return {'op': 'add', 'intent_id': key, 'owner': owner, 'text': text, 'source_seqs': [seq], 'status': status}

def update(key, text, seq, **extra):
    return {'op': 'update', 'intent_id': key, 'text': text, 'source_seqs': [seq], **extra}

def transition(op, key, seq):
    return {'op': op, 'intent_id': key, 'source_seqs': [seq]}

def atom(key, owner, text, status='active'):
    return {'intent_id': key, 'owner': owner, 'text': text, 'status': status}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def make_spec(lang, family, history, setup, target, expected, preserved, note, rejected=None):
    return {'example_id': f'{family}-{lang}', 'family_id': family, 'language': lang,
            'conversation': history, 'setup': setup, 'target': {'operations': target},
            'requirements': expected, 'preserved_ids': preserved, 'annotation_note': note,
            'rejected': rejected}

def specs():
    result = []
    for lang in ('zh', 'en'):
        zh = lang == 'zh'
        own = '林' if zh else 'Mira'
        other = '周' if zh else 'Owen'
        def t(c, e): return c if zh else e
        def e(n, text, who=own, role='user'): return event(n, who, text, role)
        task = t('选择一个笔记工具', 'Choose a note-taking tool')
        offline = t('必须能离线使用', 'Must work offline')
        free = t('必须免费', 'Must be free')
        desktop = t('使用桌面端', 'Use a desktop app')
        mobile = t('使用移动端', 'Use a mobile app')
        result.append(make_spec(lang, 'add-constraint',
            [e(1, t('帮我选择一个笔记工具。', 'Help me choose a note-taking tool.')),
             e(4, t('另外，必须能离线使用。', 'Also, it must work offline.'))],
            [(1, [add('task', own, task, 1)])], [add('offline', own, offline, 4)],
            [atom('task', own, task), atom('offline', own, offline)], ['task'],
            'Add the newly required property without replacing the existing goal.'))
        result.append(make_spec(lang, 'local-update',
            [e(1, t('找一个免费的桌面端笔记工具。', 'Find a free desktop note-taking tool.')),
             e(4, t('换成移动端，免费要求保持。', 'Switch to mobile; keep the free requirement.'))],
            [(1, [add('task', own, task, 1), add('cost', own, free, 1), add('platform', own, desktop, 1)])],
            [update('platform', mobile, 4)],
            [atom('task', own, task), atom('cost', own, free), atom('platform', own, mobile)], ['task', 'cost'],
            'Only platform changes; zero price and the original goal remain active.'))
        sync = t('需要云同步', 'Require cloud synchronization')
        result.append(make_spec(lang, 'withdraw',
            [e(1, t('找一个能离线用、带云同步的笔记工具。', 'Find a note-taking tool with offline use and cloud sync.')),
             e(4, t('云同步先取消，离线仍然必须支持。', 'Cancel cloud sync for now; offline use is still required.'))],
            [(1, [add('task', own, task, 1), add('offline', own, offline, 1), add('sync', own, sync, 1)])],
            [transition('withdraw', 'sync', 4)],
            [atom('task', own, task), atom('offline', own, offline), atom('sync', own, sync, 'withdrawn')], ['task', 'offline'],
            'Withdrawal retains the sync record and history; it does not delete unrelated needs.'))
        for family in ('reopen', 'validation-repair'):
            history = [e(1, t('工具需要云同步，也必须免费。', 'The tool needs cloud sync and must be free.')),
                       e(4, t('先取消云同步。', 'Cancel cloud sync for now.')),
                       e(9, t('还是恢复云同步吧，免费要求不变。', 'Restore cloud sync after all; the free requirement stays.'))]
            setup = [(1, [add('sync', own, sync, 1), add('cost', own, free, 1)]),
                     (4, [transition('withdraw', 'sync', 4)])]
            target_key, target_text, stable_key, stable_text = 'sync', sync, 'cost', free
            if family == 'validation-repair':
                target_key = 'csv-export'
                target_text = t('导出结果为CSV文件', 'Export results as a CSV file')
                stable_key = 'language'
                stable_text = t('报告使用中文', 'Write the report in English')
                history = [e(1, t('报告用中文，结果还要导出为CSV文件。', 'Write the report in English and export results as a CSV file.')),
                           e(4, t('CSV导出先取消。', 'Cancel the CSV export for now.')),
                           e(9, t('恢复CSV导出，报告语言保持中文。', 'Restore the CSV export; keep the report in English.'))]
                setup = [(1, [add(target_key, own, target_text, 1), add(stable_key, own, stable_text, 1)]),
                         (4, [transition('withdraw', target_key, 4)])]
            bad = {'operations': [update(target_key, target_text, 9)]} if family == 'validation-repair' else None
            result.append(make_spec(lang, family, history, setup,
                [transition('reopen', target_key, 9)], [atom(target_key, own, target_text), atom(stable_key, own, stable_text)], [stable_key],
                ('Repair a rejected update by explicit reopen, using the unchanged current state. '
                 'previous_error is a proposed input field absent from the current runtime.' if bad else
                 'Restore the same stable ID rather than adding a duplicate or updating a withdrawn record.'), bad))
        result.append(make_spec(lang, 'no-change',
            [e(1, t('工具必须免费并且可以离线。', 'The tool must be free and work offline.')),
             e(4, t('明白了，谢谢。', 'Understood, thanks.'))],
            [(1, [add('cost', own, free, 1), add('offline', own, offline, 1)])], [],
            [atom('cost', own, free), atom('offline', own, offline)], ['cost', 'offline'],
            'Acknowledgement is not a changed request; empty operations still advances the processed cursor.'))
        result.append(make_spec(lang, 'unaccepted-proposal',
            [e(1, t('工具必须免费并且可以离线。', 'The tool must be free and work offline.')),
             e(4, t('我建议改成付费的在线服务。', 'I suggest switching to a paid online service.'), 'assistant', 'assistant')],
            [(1, [add('cost', own, free, 1), add('offline', own, offline, 1)])], [],
            [atom('cost', own, free), atom('offline', own, offline)], ['cost', 'offline'],
            'An assistant proposal is not user acceptance; do not revise either active constraint.'))
        result.append(make_spec(lang, 'quoted-third-party',
            [e(1, t('工具必须免费并且可以离线。', 'The tool must be free and work offline.')),
             e(4, t('同事说：“预算放宽，用在线的吧。”这只是他的建议，我的要求没改。',
                    'My colleague said, "Raise the budget and use an online tool." That is only his suggestion; my requirements have not changed.'))],
            [(1, [add('cost', own, free, 1), add('offline', own, offline, 1)])], [],
            [atom('cost', own, free), atom('offline', own, offline)], ['cost', 'offline'],
            'Quoted third-party instructions plus explicit non-adoption produce no operations.'))
        uncertain = t('可能需要团队的字幕支持；需求是否确定及归属待澄清',
                      'Possible team caption support; whether it is required and who owns it need clarification')
        team = t('团队（待确认）', 'team (unconfirmed)')
        result.append(make_spec(lang, 'owner-ambiguity',
            [e(1, t('帮我选一个免费的笔记工具。', 'Help me choose a free note-taking tool.')),
             e(4, t('我们可能还要字幕，不过是谁需要、是不是必须，我现在不确定。',
                    'We might also need captions, but I am not sure who needs them or whether they are required.'))],
            [(1, [add('task', own, task, 1), add('cost', own, free, 1)])],
            [add('caption-candidate', team, uncertain, 4, 'uncertain')],
            [atom('task', own, task), atom('cost', own, free), atom('caption-candidate', team, uncertain, 'uncertain')], ['task', 'cost'],
            'Candidate convention: preserve the uncertainty explicitly, with an unresolved-owner label; do not invent an individual owner. The current store has no dedicated owner-resolution field.'))
        ownlimit = t('每月预算不超过18元', 'Monthly budget at most 18 credits')
        newlimit = t('每月预算不超过24元', 'Monthly budget at most 24 credits')
        otherlimit = t('每月预算不超过9元', 'Monthly budget at most 9 credits')
        result.append(make_spec(lang, 'multiple-owners',
            [e(1, t('我的预算每月最多18元。', 'My monthly budget is at most 18 credits.')),
             e(3, t('我的预算每月最多9元，而且必须离线。', 'My monthly budget is at most 9 credits, and I need offline use.'), other),
             e(6, t('只把我的预算提高到每月24元，别改周的要求。', 'Raise only my monthly budget to 24 credits; do not change Owen\'s requirements.'))],
            [(3, [add('first-budget', own, ownlimit, 1), add('second-budget', other, otherlimit, 3), add('second-offline', other, offline, 3)])],
            [update('first-budget', newlimit, 6)],
            [atom('first-budget', own, newlimit), atom('second-budget', other, otherlimit), atom('second-offline', other, offline)], ['second-budget', 'second-offline'],
            'One speaker changes only that speaker\'s budget; the other owner\'s budget and offline constraint survive.'))
        result.append(make_spec(lang, 'combined-operations',
            [e(1, t('我要免费的桌面笔记工具，还需要云同步。', 'I want a free desktop note-taking tool with cloud sync.')),
             e(5, t('换成移动端，取消云同步，另外要离线；免费要求保留。',
                    'Switch to mobile, cancel cloud sync, and add offline use; keep it free.'))],
            [(1, [add('task', own, task, 1), add('cost', own, free, 1), add('platform', own, desktop, 1), add('sync', own, sync, 1)])],
            [update('platform', mobile, 5), transition('withdraw', 'sync', 5), add('offline', own, offline, 5)],
            [atom('task', own, task), atom('cost', own, free), atom('platform', own, mobile), atom('sync', own, sync, 'withdrawn'), atom('offline', own, offline)], ['task', 'cost'],
            'Apply three changes atomically, touching each ID once, and preserve the independent price constraint.'))
        budget = t('每月预算不超过12元', 'Monthly budget at most 12 credits')
        wrong = t('每月预算不超过120元', 'Monthly budget at most 120 credits')
        result.append(make_spec(lang, 'stale-state-correction',
            [e(1, t('预算每月最多12元，必须能离线用。', 'Budget at most 12 credits per month; offline use is required.')),
             e(4, t('提醒一下，预算一直是12元，不是120元；离线要求不变。',
                    'Reminder: the budget has always been 12 credits, not 120; offline use still matters.'))],
            [(1, [add('budget', own, wrong, 1), add('offline', own, offline, 1)])],
            [update('budget', budget, 4)],
            [atom('budget', own, budget), atom('offline', own, offline)], ['offline'],
            'The prior patch is deliberately semantically wrong but structurally valid. Correct the advisory state from original words; this is not a user budget change.'))
    return result

def materialize(spec):
    with IntentStore(':memory:') as store:
        setup = []
        for index, (through, operations) in enumerate(spec['setup']):
            store.observe([e for e in spec['conversation'] if e['seq'] <= through])
            patch = {'patch_id': f'setup-{index}',
                     'expected_version': store.snapshot()['version'], 'through_seq': through,
                     'operations': operations}
            store.commit_patch(**patch)
            setup.append(patch)
        store.observe(spec['conversation'])
        current = store.snapshot()
        packet = {'conversation': spec['conversation'], 'intention_state': current, 'tool_receipts': []}
        if spec['rejected'] is not None:
            try:
                store.commit_patch('attempt-0', current['version'], current['observed_event_seq'], spec['rejected']['operations'])
                raise AssertionError('Expected rejection did not occur')
            except IntentValidationError as error:
                assert current == store.snapshot()
                packet['previous_error'] = {'proposal': spec['rejected'], 'error_type': type(error).__name__, 'message': str(error)}
        commit = {'patch_id': 'decision-0', 'expected_version': current['version'],
                  'through_seq': current['observed_event_seq'], 'operations': spec['target']['operations']}
        post = store.commit_patch(**commit)
        projection = [{key: value[key] for key in ('intent_id', 'owner', 'text', 'status')} for value in post['intents']]
        assert projection == sorted(spec['requirements'], key=lambda x: x['intent_id'])
        return {'schema_version': 1, 'example_id': spec['example_id'],
                'input': packet, 'target': spec['target'],
                'metadata': {'family_id': spec['family_id'], 'language': spec['language'],
                    'role': 'intention_tracker', 'split': 'illustrative_development_only',
                    'authorship': 'agent-authored fictional scenarios',
                    'semantic_review_status': 'independent semantic and human review pending',
                    'sibling_group_policy': 'Keep every family_id together in any future split; these examples are already exposed development material.',
                    'candidate_runtime_error_input': spec['rejected'] is not None,
                    'current_runtime_supplies_previous_error': False,
                    'setup_patches': setup, 'target_commit_identity': {k: v for k, v in commit.items() if k != 'operations'},
                    'atomic_requirement_annotations': spec['requirements'],
                    'expected_post_state': post, 'preserve_unchanged_ids': spec['preserved_ids'],
                    'annotation_note': spec['annotation_note']}}

def main():
    source = ROOT / 'experiments/deep_conversation/intent_roles.py'
    constants = {}
    for node in ast.parse(source.read_text(encoding='utf-8')).body:
        if isinstance(node, ast.Assign):
            for name in node.targets:
                if isinstance(name, ast.Name) and name.id in {'BASE_PROMPT', 'TRACKER_PROMPT'}:
                    constants[name.id] = ast.literal_eval(node.value)
    prompt = constants['BASE_PROMPT'] + '\n' + constants['TRACKER_PROMPT']
    (HERE / 'system_prompt.txt').write_text(prompt, encoding='utf-8')
    data = [materialize(s) for s in specs()]
    assert len(data) == 24
    (HERE / 'examples.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False, sort_keys=True) + '\n' for x in data), encoding='utf-8')
    # No metadata, expected snapshots or requirement annotations enter this export.
    sft = [{'prompt': [{'role': 'system', 'content': prompt},
                       {'role': 'user', 'content': json.dumps(x['input'], ensure_ascii=False, sort_keys=True)}],
            'completion': [{'role': 'assistant', 'content': json.dumps(x['target'], ensure_ascii=False, sort_keys=True)}]} for x in data]
    (HERE / 'sft_examples.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False, sort_keys=True) + '\n' for x in sft), encoding='utf-8')
    (HERE / 'sft_manifest.json').write_text(json.dumps({'usage': 'illustrative development only; not training-approved',
        'split': 'all_development_no_heldout', 'semantic_review': 'pending',
        'line_mapping': [{'line': index + 1, 'example_id': x['example_id'], 'family_id': x['metadata']['family_id'],
                          'candidate_runtime_error_input': x['metadata']['candidate_runtime_error_input']} for index, x in enumerate(data)],
        'files_sha256': {p.name: sha(p) for p in (HERE / 'examples.jsonl', HERE / 'sft_examples.jsonl', HERE / 'system_prompt.txt')}}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'examples_written': len(data), 'families': len(set(x['metadata']['family_id'] for x in data)), 'real_model_calls': 0, 'training_runs': 0}))

if __name__ == '__main__':
    main()
