# Intention tracker LoRA: illustrative data contract

Date: 2026-10-24 (America/Halifax). These 24 original fictional examples are an **illustrative development pack**, not a collected training corpus, held-out evaluation set, or evidence of LoRA effectiveness. There are 12 Chinese and 12 English examples. Each bilingual pair shares a `family_id`; related paraphrases and counterfactuals must remain in the same split in a future dataset. These exposed examples must never become a claimed blind test set.

The 12 families cover adding a constraint, local modification, withdrawal, reopening, acknowledgement/no change, unaccepted assistant proposal, quoted third-party speech, uncertain ownership, multiple owners, combined changes, correction of a wrong prior state, and repair after a rejected transition. All wording and labels are agent-authored. Independent semantic and human review are pending. A successful engineering check does not certify the labels.

## Files and schema

- `examples.jsonl`: one record per tracking decision. Only `input` and `target` may be used to construct a training pair; the complete metadata must never enter the model input.
- `sft_examples.jsonl`: separate illustrative prompt/completion export containing only the exact model input and operations target. It includes no example metadata, expected post-state or requirement annotations. This export is **not training-approved**.
- `sft_manifest.json`: separate line-to-example/family mapping, candidate recovery flags and hashes. Do not concatenate this manifest into model input; all lines remain development-only.
- `system_prompt.txt`: exact current `BASE_PROMPT + TRACKER_PROMPT`, extracted from the source. It is a reference contract, not a tuned prompt.
- `build_examples.py`: human-readable scenario definitions and reproducible materialization with the actual `IntentStore`.
- `validate_data.py`: offline replay of all setup and target patches, preservation checks, and four controlled corruptions.
- `validation.json` and `stdout.txt`: the executed engineering result and console output.
- `validation_attempt_history.json` and `attempts/attempt-01/`: the earlier successful structural check, its original hashes/scripts/output, the later-discovered input-shortcut risk, and the reason for the second validation. The first version used example-derived patch IDs; the corrected export uses neutral runtime IDs.

Each record has:

| Field | Meaning |
|---|---|
| `example_id` | Unique development example ID. |
| `input.conversation` | All and only authenticated arrived conversation events, including the newest message; original speaker, role, sequence and wording remain intact. |
| `input.intention_state` | Actual durable snapshot produced by replaying prior observations and patches, then observing the newest event. Includes stable IDs, histories and cursors. |
| `input.tool_receipts` | Empty in this seed pack. No work results or answer facts are supplied. |
| `input.previous_error` | Only the two repair examples: actual rejected proposal and actual runtime error. This is a **candidate input extension**; the current runtime does not supply it. |
| `target` | Exactly `{"operations": [...]}`. No rationale, future event, factual answer, patch ID, version or cursor. |
| `metadata.setup_patches` | Reproduction-only prior history; excluded from model input. A stale-state example deliberately contains a semantically wrong but structurally valid prior patch. |
| `metadata.expected_post_state` | Full reproduced target snapshot, kept outside model input. |
| `metadata.atomic_requirement_annotations` | Separately authored owner/text/status requirement labels for a future scorer. These are draft annotations, not independently adjudicated gold. |
| `metadata.preserve_unchanged_ids` | Existing records that must remain byte-equivalent as JSON values, including history. |
| `metadata.family_id`, `language`, `split` | Grouping and provenance; every example is `illustrative_development_only`. |

Uncertain ownership currently has no dedicated schema field. The two ambiguity examples use a clearly unresolved owner label with `status: uncertain`; this is a proposed annotation convention that needs review before dataset production. The whole pack is development-only, so no held-out split or independent generalization is claimed to have been tested here.

## What the executed validator establishes

It imports the real `IntentStore`, rebuilds the pre-state from observed events and valid prior patches, checks exact input snapshots, reproduces the two intentional rejection precursors, applies target JSON, compares full expected snapshots and separately authored requirement projections, and verifies untouched records. Empty operations must leave intention records intact while advancing version and the processed cursor.

All prior patch IDs are neutral `setup-N` identities, the target is `decision-0`, and rejected attempts use `attempt-0`. Example IDs and family names remain metadata only. The validator explicitly checks that bookkeeping identities do not reveal authored labels. The initial validation lacked this check and is preserved under `attempts/attempt-01/`; passing it did not establish the absence of input shortcuts.

Four corrupted proposals test distinct boundaries: a future source reference, duplicate operations on one ID after earlier valid operations, updating a withdrawn record without reopening, and omitting a required addition. The first three must be rejected atomically by the actual runtime. The fourth is **accepted structurally** and caught only by the illustrative authored expected-state oracle. Runtime validation is not a semantic omission detector.

The implementation source hashes are recorded before and after verification. No frozen implementation or old evaluation fixture is changed. No model is called, no adapter is trained, and nothing is downloaded.

Run from the repository root:

```powershell
& .\experiments\deep_conversation\.venv\Scripts\python.exe -B output/research/2026-10-24/tracker-lora-plan/data/build_examples.py
& .\experiments\deep_conversation\.venv\Scripts\python.exe -B output/research/2026-10-24/tracker-lora-plan/data/validate_data.py
```

## Before this could become training data

Collect sufficiently varied, consented or original fictional conversation histories; include long distraction spans, implicit changes, partial language, negative/no-change cases and realistic prior tracker errors. Separately annotate every still-valid atomic requirement, owner, status, supporting source and allowed patch; resolve disagreements without exposing held-out cases to model selection. Partition by source conversation, scenario template and semantic family before augmentation or translation. Tune on development data and report unseen families, owners and language combinations separately. Prefer reasonable alternative equivalent patches over requiring an arbitrary exact natural-language wording.

Use the same raw conversation, state contract, frozen base model, inference budget and data split for no-LoRA and tracker-LoRA comparisons. The primary claim must come from held-out retained-requirement recall plus false additions, mistaken withdrawals/owner changes, valid-transition rate and downstream task outcomes—not this script passing.
