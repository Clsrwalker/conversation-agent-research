"""Read-only source/environment inventory; writes only the sibling audit JSON.

No model inference, installation, downloading, training or dataset relabeling.
"""
from pathlib import Path
import collections
import hashlib
import importlib.metadata
import json
import os
import subprocess
import sys
import urllib.request
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[5]
OUT = Path(__file__).resolve().parent
def read(rel):
    return json.loads((ROOT / rel).read_text(encoding="utf-8-sig"))
def evidence(rel):
    p = ROOT / rel
    return {"path": rel, "sha256": hashlib.sha256(p.read_bytes()).hexdigest(), "bytes": p.stat().st_size}
def run(args):
    p = subprocess.run(args, capture_output=True, text=True, encoding="utf-8", errors="replace")
    return {"command": args, "exit_code": p.returncode, "stdout": p.stdout.strip(), "stderr": p.stderr.strip()}

study = "output/research/2026-10-23/intent-role-separation/"
fixtures = read(study + "fixtures/cases.json")
manifests = {p: read(study + p + "/manifest.json") for p in ["development", "evaluation"]}
pilot = {}
for phase, key in [("evaluation", "cases"), ("development", "dev_cases")]:
    cases = fixtures[key]
    m = manifests[phase]
    pilot[phase] = {
        "authored_case_count": len(cases),
        "family_id_count": len({c.get("family_id", c["case_id"]) for c in cases}),
        "unique_authored_stage_prefixes": sum(len(c["stages"]) for c in cases),
        "authored_human_event_count": sum(len(c["replay"]["events"]) for c in cases),
        "trajectory_assignments": len(m["assignments"]),
        "conditions": sorted({a["condition"] for a in m["assignments"]}),
        "repetitions": m["repetitions"],
        "calls_per_stage": m["calls_per_stage"],
        "planned_executed_calls_from_assignment_structure": sum(len(next(c for c in cases if c["case_id"] == a["case_id"])["stages"]) * m["calls_per_stage"] for a in m["assignments"]),
        "cases": [{"case_id": c["case_id"], "family_id": c.get("family_id", c["case_id"]), "stage_count": len(c["stages"]), "tags": c.get("tags", [])} for c in cases],
        "new_tracker_lora_split_eligibility": "exposed regression/development only; not a new held-out set",
    }

paths = [
    "intent-coverage-v1/public-cases.json", "intention-diagnostic-v1/cases.json",
    "meeting-intention-v1/cases.json", "meeting-factorial-v1/cases.json",
    "goal-directed-v1/benchmark.json", "investigation-progress-v1/dev/cases.json",
    "investigation-progress-v1/heldout/cases.json", "discovery/cases.json",
    "holdout/cases.json", "orchestration-holdout-v1/cases.json",
]
older = []
for tail in paths:
    rel = "experiments/deep_conversation/benchmarks/" + tail
    obj = read(rel)
    cases = obj if isinstance(obj, list) else obj.get("cases", [])
    row = {**evidence(rel), "top_level_keys": list(obj) if isinstance(obj, dict) else None,
           "case_count": len(cases), "new_tracker_lora_split_eligibility": "existing exposed project material; reserve as regression, not fresh held-out"}
    if cases:
        row["case_record_keys"] = list(cases[0])
        for k in ["family_id", "pair_id", "family", "category"]:
            vals = [c[k] for c in cases if k in c]
            if vals:
                row[k + "_counts"] = dict(collections.Counter(str(v) for v in vals))
        row["event_count_if_replay_schema"] = sum(len(c.get("events", [])) for c in cases)
    older.append(row)

datasets = "output/research/2026-10-06/datasets/"
downloads = read(datasets + "download_manifest.json")
download_check = []
for f in downloads["files"]:
    rel = datasets + f["file"].replace("\\", "/")
    p = ROOT / rel
    row = {"path": rel, "exists": p.exists(), "repository": f["repository"], "revision": f["revision"]}
    if p.exists():
        row.update(evidence(rel))
        row["matches_recorded_sha256"] = row["sha256"] == f["sha256"]
        if p.suffix == ".jsonl":
            row["nonempty_rows"] = sum(bool(line.strip()) for line in p.open(encoding="utf-8"))
    download_check.append(row)

package_code = "import importlib.metadata,json,sys; names=['torch','transformers','peft','accelerate','bitsandbytes','trl','datasets','safetensors']; out={};\nfor n in names:\n try: out[n]=importlib.metadata.version(n)\n except importlib.metadata.PackageNotFoundError: out[n]=None\nprint(json.dumps({'python':sys.version,'executable':sys.executable,'packages':out}))"
runtime = {
    "gpu_query": run(["nvidia-smi", "--query-gpu=name,memory.total,memory.free,driver_version", "--format=csv,noheader"]),
    "python_environments": [run([str(ROOT / "experiments/deep_conversation/.venv/Scripts/python.exe"), "-B", "-c", package_code]), run(["python", "-B", "-c", package_code])],
    "archived_pilot_model": manifests["evaluation"]["local_model"],
    "cache_scopes_checked": [],
    "readiness_status": "not established: package presence and GPU metadata do not establish training fit or adapter deployment compatibility",
}
windows_python = Path.home() / "AppData/Local/Programs/Python/Python313/python.exe"
if windows_python.exists():
    runtime["python_environments"].append(run([str(windows_python), "-B", "-c", package_code]))
for rel in [".cache/huggingface/hub", ".cache/huggingface/transformers"]:
    p = Path.home() / rel
    runtime["cache_scopes_checked"].append({"scope": "user_home/" + rel, "exists": p.exists(), "immediate_directory_names": sorted(x.name for x in p.iterdir() if x.is_dir()) if p.exists() else [], "scope_limit": "Known cache only, not exhaustive filesystem search"})
try:
    request = urllib.request.Request("http://127.0.0.1:11434/api/show", data=json.dumps({"model": "qwen2.5:14b-instruct"}).encode(), headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(request, timeout=10) as response:
        data = json.load(response)
    runtime["ollama_show_read_only"] = {"endpoint": "http://127.0.0.1:11434/api/show", "request_model": "qwen2.5:14b-instruct", "details": data.get("details"), "capabilities": data.get("capabilities"), "status": "available", "model_inference": False}
except Exception as e:
    runtime["ollama_show_read_only"] = {"status": "unavailable", "exception": str(e), "model_inference": False}

diag = read("output/research/2026-10-23/intent-role-diagnostics/SUMMARY.json")
coverage_gold = read("experiments/deep_conversation/benchmarks/intent-coverage-v1/gold.json")
prior_public_audit = read(datasets + "public_data_audit.json")
refs = [study + "fixtures/cases.json", study + "evaluation/manifest.json", study + "development/manifest.json", "output/research/2026-10-23/intent-role-diagnostics/SUMMARY.json", "output/research/2026-10-23/intent-role-diagnostics/REPORT.md", "experiments/deep_conversation/INTENTION_ROLES.md", "experiments/deep_conversation/intention_state.py", "experiments/deep_conversation/intent_roles.py", datasets + "download_manifest.json", datasets + "public_data_audit.json", datasets + "discussllm/development/manifest.json"]
report_refs = ["experiments/deep_conversation/benchmarks/intent-coverage-v1/DATASET.md", "experiments/deep_conversation/benchmarks/intention-diagnostic-v1/README.md", "experiments/deep_conversation/benchmarks/meeting-intention-v1/README.md", "experiments/deep_conversation/benchmarks/meeting-factorial-v1/README.md", "experiments/deep_conversation/benchmarks/goal-directed-v1/README.md", "experiments/deep_conversation/benchmarks/goal-directed-v1/sources.json", datasets + "When2Speak/README.md", datasets + "discussllm/README.md"]
out = {
    "id": "tracker-lora-data-and-readiness-inventory",
    "date": "2026-10-24", "timezone": "America/Halifax",
    "created_at_utc": datetime.now(timezone.utc).isoformat(),
    "kind": "read_only_inventory_not_training_or_quality_experiment",
    "new_real_model_calls": 0, "training_runs": 0, "downloads": 0, "installations": 0,
    "personal_raw_data_accessed": False, "personal_raw_data_training_permission_obtained": False,
    "human_annotations_obtained": False,
    "scope_of_personal_data_statement": "No user-private conversation or personal training data was accessed. Existing public dataset files were read for hashes and row counts.",
    "pilot": pilot,
    "original_tracker_traces": {k: diag[k] for k in ["original_tracker_proposals_replayed", "original_tracker_proposals_accepted", "original_tracker_proposals_rejected", "original_trajectories", "original_captured_model_calls_reconciled", "original_final_failures"]},
    "original_trace_label_limit": "44 accepted proposals passed state-store structural rules; this is not semantic gold. All 69 proposals need independent prefix-based semantic labeling before possible training reuse. Retries are correlated; split by originating family/conversation.",
    "known_gold_issue": "Workshop price is in earlier stage gold before explicitly requested in stage 3; do not turn that early gold into a training requirement. Preserve old scoring; author revised labels separately.",
    "older_project_datasets": older,
    "intent_coverage_labels": {"cases": len(coverage_gold), "required_needs": sum(len(x["required_needs"]) for x in coverage_gold), "need_count_distribution": dict(collections.Counter(len(x["required_needs"]) for x in coverage_gold)), "label_origin": "Existing AI-authored and AI-reviewed diagnostic; no human labels obtained in this audit", "evidence": evidence("experiments/deep_conversation/benchmarks/intent-coverage-v1/gold.json")},
    "downloaded_candidate_sources": download_check,
    "public_data_previous_audit": {"path": datasets + "public_data_audit.json", "limit": "Read-only prior audit reused. Existing SPEAK/SILENT or intervention-location labels are not tracker state-transition targets; license and task fit need review before training."},
    "public_data_leakage_evidence": {"ami_train_test_meeting_id_overlap": prior_public_audit["ami"]["overlaps"]["train_test"]["meeting_ids"], "ami_test_rows_from_train_meetings": prior_public_audit["ami"]["test_rows_from_train_meetings"], "ami_test_rows_with_exact_train_context_and_target": prior_public_audit["ami"]["test_rows_with_train_context_and_target"], "interpretation": "Published row splits do not imply unseen-meeting splits. Exact-input overlap and meeting overlap are separate issues; split by source conversation/meeting for tracker evaluation."},
    "runtime": runtime,
    "evidence": [evidence(r) for r in refs],
    "report_supporting_documents": [evidence(r) for r in report_refs],
    "commands": ["python -B output/research/2026-10-24/tracker-lora-plan/data-audit/inventory_sources.py", "nvidia-smi --query-gpu=name,memory.total,memory.free,driver_version --format=csv,noheader", "Python importlib.metadata reads in project .venv and default python; no training packages imported", "POST localhost Ollama /api/show metadata only; no /api/generate or /api/chat"],
    "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "execution_notes": ["First execution reached output assembly but failed because this Python lacks tzdata for ZoneInfo('UTC'). Replaced that timestamp-only dependency with datetime.timezone.utc and reran. No dataset or model state changed.", "One exploratory PowerShell read named a nonexistent analysis/report.md, and an rg path wildcard was unsupported; actual diagnosis REPORT.md and direct file paths were used instead."],
    "limitations": ["Counts are inventory, not training sufficiency or independent sample-size claims.", "Existing named holdout folders are historically evaluated project material; no fresh held-out claim is made.", "Cache and package inventory is scoped; software or base weights may exist outside checked locations.", "No fresh public data downloaded, no model loaded, no training fit benchmark performed."]
}
(OUT / "inventory.json").write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"output": str((OUT / "inventory.json").relative_to(ROOT)), "pilot": pilot, "runtime": runtime, "older": older, "download_checks": download_check}, ensure_ascii=False, indent=2))
