# Tracker LoRA data and local readiness inventory

2026-10-24 · America/Halifax · Read-only inventory, not a training run or quality experiment.

The project has useful regression examples and failure traces, but it does not yet have a verified, family-separated training/evaluation corpus of tracker state transitions. The previous role pilot did not train or load any LoRA. Counts and hashes below are recorded in [inventory.json](inventory.json); [inventory_sources.py](inventory_sources.py) reproduces the read-only inspection.

## What is already available

| Existing material | Actual authored scope | Useful role in this project |
|---|---:|---|
| 2026-10-23 role pilot evaluation fixtures | 8 family IDs, 24 stage prefixes, 26 human events | Exposed regression suite: replacement, withdrawal, restoration, no-change, unsupported assistant proposal, combination change, multiple owners and obsolete evidence |
| Role pilot development fixture | 1 family, 3 stage prefixes, 3 events | Exposed development example |
| `intent-coverage-v1` | 24 snippets in 12 contrast pairs; 28 required needs; 4 zero-need snippets | Seed examples for recognition and unsupported additions; current labels do not describe executable state patches |
| `intention-diagnostic-v1` | 6 cases, 27 events | Retention, person attribution, cancellation and settled/no-intervention examples |
| `meeting-intention-v1` | 3 meetings, 27 events | Longer retention, partial cancellation and ownership examples |
| `meeting-factorial-v1` | 4 meetings, 36 events | Change, partial resolution and a fully settled meeting |
| `goal-directed-v1` | 6 task families × 4 variants = 24 cases | Correction, refusal, pause, consent and tool-receipt examples; actor/private/evaluator fields must be separated |
| Other older project case sets | Discovery 6; original holdout 6; orchestration holdout 6; investigation-progress dev 2 / historical heldout 10 | Secondary regression material; file/family names are not evidence of freshness for a new study |

The role pilot's **48 evaluation trajectories / 864 model calls** and **3 development trajectories / 54 calls** repeat these authored cases. They are not 918 independent training examples. The recorded **69 tracker proposals** include **44 structurally accepted and 25 rejected** proposals across 16 tracked evaluation trajectories. Acceptance by the state store is not semantic correctness. Repeated invalid proposals often share the same input and must not inflate effective training size.

Existing material is visible to this research team and has informed diagnosis. Keep the named examples and close paraphrases in a declared regression/development pool. Build a fresh test pool by source conversation and authoring family before generating paraphrases or training. Same-family, same-template, contrast-pair, translation and turn-prefix derivatives must stay in one split. These small authored pools do not establish independent samples of real users.

## Label problems and missing annotations

The workshop fixture's early gold mentions a price requirement before the user explicitly requests price in stage 3. Do not copy that early evaluator wording into tracker training. The final-stage price omission is supported by an explicit request, but earlier labels need separate, versioned prefix-only review. Preserve the frozen previous scores.

The current state-store contract allows `add`, `update`, `withdraw`, `reopen`, `active`/`uncertain`, arrived-conversation source references and at most one operation per intent per patch. It has no separate structured constraint inventory or work-invalidation field. Current fixture `stage_gold` contains evaluator answer content as well as intent descriptions. Converting it directly to a training target would mix user intention with answers obtained from tools and could expose future information.

Before a trace becomes a supervised example, add reviewed labels for:

- A conversation prefix, its actual speakers/source authority and the latest arrived message; no future turn or evaluator answer.
- The valid pre-state, stable intent identity, beneficiary/owner and explicitly retained constraints.
- The correct state patch **and** resulting semantic state; no-change is a valid empty patch. Keep alternative equivalent patches acceptable.
- Exact supporting source spans, unsupported topics not to adopt, and ambiguous cases requiring uncertainty/clarification.
- If using corrupted pre-state or a rejected proposal, a separately labeled repair target and actual validation error. Do not teach a silent rejection loop.
- Downstream invalidation labels, if that contract is added, kept separate from current schema rather than pretended to be implemented already.

A useful new example set must cover missed additions, changed conditions, partial withdrawal, explicit reopening, irrelevant chatter, reported/quoted/practice requests, unaccepted assistant suggestions, multiple owners, simultaneous changes, ambiguities and old tool information arriving after a change. The last category needs newly exercised arrivals: in the previous pilot all six old reads were cancelled before delivery.

No human annotation, expert review, or permission to train on the user's private conversations was obtained in this audit. No private conversation data was accessed. Existing public files were read only for metadata, hashes and row counts. New synthetic labels should be marked synthetic and independently reviewed; model-generated labels are not human ground truth.

## Public-source candidates already recorded locally

All seven files in the existing 2026-10-06 download manifest still match their recorded SHA-256 hashes. This verifies local file identity, not training suitability or label correctness.

| Source | What is locally recorded | Tracker limitation / split constraint |
|---|---|---|
| AMI-derived `ishiki-labs/multi-party-dialogue` | 11,270 train / 1,408 val / 1,410 test rows; existing audit finds 21 meeting IDs shared between train and test | Predicts human next-speaker behavior, not intention state. All 1,410 test rows come from training meetings; use meeting-level splits for new tracker labels. One exact context/target train-test collision is separately recorded. |
| DiscussLLM | Downloaded archive; prior parser records 88,718 synthetic discussions (75,411 / 13,307), with format exclusions; existing development export is 42 prefixes from 10 discussions | Intervention positions/categories are not state-update labels. Relabel prefixes from source conversations; do not expose scenario answers or future intervention text. Keep each entire discussion in one split. |
| When2Speak | Only the 21,788-row token validation file is downloaded in this manifest | SPEAK/SILENT timing labels are not intent patches. A published validation split should not silently become both training material and a test. |
| Taskmaster-1 / MetaLWOz provenance in `goal-directed-v1` | Prior authoring record inspected 699 automotive and 495 phone-plan source records; selected 3 per domain; full corpus not retained there | Human role-play offers correction patterns, not tracker gold or natural customer outcomes. Taskmaster attribution and MetaLWOz research/redistribution restrictions remain relevant before reuse. |

The known Hugging Face cache also has dataset-named directories for DailyDialog, MeetingBank and DEBATE_LLM. Their file completeness, licenses and tracker-label fit were not audited, so they are not counted as ready training data. No public-source labels should be treated as tracker ground truth merely because many rows are available.

## Local model and training readiness

The frozen pilot and current read-only Ollama metadata identify **`qwen2.5:14b-instruct`, 14.8B, GGUF Q4_K_M**. The archived digest is `7cdf5a0187d5c58cc5d369b255592f7841d1c4696d45a8c8a9489440385b22f6`; the archived model file is 8,988,124,069 bytes. The current metadata check did not run inference and did not independently rehash the model blobs.

Fresh `nvidia-smi` reports **NVIDIA GeForce RTX 4080 SUPER, 16,376 MiB total**. Free memory is a transient snapshot, not a training-budget promise. No training-fit or sequence-length benchmark has been performed.

| Python environment checked | Training-package metadata |
|---|---|
| Project `.venv` (Python 3.12.14) | `torch`, `transformers`, `peft`, `accelerate`, `bitsandbytes`, `trl`, `datasets`, `safetensors` absent |
| Bundled runtime Python 3.12.14 | Same eight packages absent |
| Explicit system Python 3.13.1 | `torch 2.12.0+cu130`, `transformers 5.14.1`, `accelerate 1.14.0`, `bitsandbytes 0.50.0`, `datasets 5.0.0`, `safetensors 0.8.0`; `peft` and `trl` absent |

Only installed-distribution metadata was read; package import, CUDA interoperability and training compatibility were not tested. Known Hugging Face model cache locations did not contain a model-named base-weight directory; this is a scoped cache check, not proof that weights exist nowhere on the machine. The current inference package alone does not establish a verified training/export/deployment path for a compatible adapter.

Preserving the user's “same base, different job LoRAs” direction requires pinning the trainable base revision/tokenizer, adapter configuration and inference representation before comparison. The old quantized pilot can remain a historical reference. It cannot serve as the sole causal no-LoRA control if the new experiment also changes inference engine, weight precision, prompt/template or context budget. Re-run the no-LoRA control on the same new stack, then attach only the tracker LoRA for the first experiment. Other role adapters can follow once the tracker contribution is measured.

No installation, download, model inference or training happened. Readiness remains **unverified**. The first script attempt failed at UTC timestamp construction because the environment lacks `tzdata`; replacing only that timestamp dependency with `datetime.timezone.utc` allowed the inventory to complete. Exploratory missing-path/wildcard reads are recorded in the JSON and did not affect source data.
