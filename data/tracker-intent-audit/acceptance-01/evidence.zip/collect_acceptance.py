"""Fixed 12-input acceptance: same frozen base/adapter, one normal + one audit call.

No training, sampling search, retries, data expansion, or automatic model swap.
Raw calls and outcomes stay private; public reporting uses reviewed aggregates.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.metadata
import json
import os
import sys
import time
import traceback

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
sys.path.insert(0,str(HERE))
sys.path.insert(0,str(HERE.parent/'repair_v2'))
from train_tracker import MODEL_ID, REVISION, MODEL_PATH, BASE_RECEIPT, quantized_base, prepare_frozen_base, measured_memory, sha
from collect_three_arm import adapter_artifacts, exclusive_collector
from pipeline import legacy, track_then_audit, TRACKER_PROMPT
import audit

if not __debug__:
    raise RuntimeError('Acceptance safety gates require Python assertions; do not use -O/-OO.')

STUDY = ROOT/'output/research/2026-10-27/tracker-intent-audit'
ADAPTER_RUN = ROOT/'output/research/2026-10-24/tracker-lora-repair-v2/training/formal-01'

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def write(path,value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')

def durable(path,value):
    with Path(path).open('a',encoding='utf-8',newline='\n') as stream:
        stream.write(legacy.encode(value)+'\n')
        stream.flush(); os.fsync(stream.fileno())

def emit(event,**values):
    print(json.dumps({'event':event,**values},ensure_ascii=False),flush=True)

def active_adapter(model):
    layers = [m for m in model.modules() if hasattr(m,'lora_A')]
    assert layers and list(model.active_adapters) == ['tracker_lora_v2']
    assert all(set(m.lora_A)=={'tracker_lora_v2'} and list(m.active_adapters)==['tracker_lora_v2'] and not m.disable_adapters for m in layers)
    assert not any(p.requires_grad for p in model.parameters()) and not model.training
    return {'name':'tracker_lora_v2','layers':len(layers),'enabled':True,'trainable_parameters':0}

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    out=args.output
    assert not out.exists(), 'Choose a fresh run folder; no output retries or overwrite.'
    out.mkdir(parents=True)
    started=time.perf_counter()
    result={'status':'setup','date':'2026-10-27','timezone':'America/Halifax','assigned_inputs':12,
            'maximum_assigned_calls':24,'new_training_runs':0,'retries':0,'pid':os.getpid()}
    write(out/'result.json',result)
    try:
        import torch
        from transformers import AutoTokenizer
        from peft import PeftModel
        with exclusive_collector(out/'collector.lock'):
            source_path=STUDY/'data/acceptance.records.jsonl'
            rows=legacy.jsonl(source_path)
            assert len(rows)==12 and len({r['case_id'] for r in rows})==12
            assert sum(r['condition']=='faulty' for r in rows)==6
            assert sum(r['condition']=='clean' for r in rows)==6
            manifest=read(STUDY/'data/manifest.json')
            preflight=read(STUDY/'data/preflight.json')
            assert preflight['status']=='passed'
            assert manifest['rows']==12 and manifest['model_calls_budget']==24
            for name,item in manifest['files'].items():
                path=STUDY/'data'/name
                assert path.stat().st_size==item['bytes'] and sha(path)==item['sha256'],name
            for rel,value in manifest['source_hashes'].items():
                assert sha(ROOT/rel)==value,rel
            review=read(STUDY/'review/preflight-review.json')
            assert review['status']=='passed','Independent implementation/data review is required.'
            for rel,value in review['source_hashes'].items():
                assert sha(ROOT/rel)==value,rel
            adapter=adapter_artifacts(ADAPTER_RUN)
            frozen=read(ROOT/'output/research/2026-10-24/tracker-lora-repair-v2/evaluation/protocol-lock.json')
            for item in frozen['files'].values():
                assert sha(item['path'])==item['sha256'],item['path']
            receipt=read(BASE_RECEIPT)
            assert receipt['model_id']==MODEL_ID and receipt['revision']==REVISION
            emit('verifying_frozen_base_files',files=len(receipt['files']))
            for item in receipt['files']:
                path=MODEL_PATH/item['rfilename']
                assert path.stat().st_size==item['actual_bytes'] and sha(path)==item['actual_sha256'],item['rfilename']
            source_paths=[HERE/'audit.py',HERE/'audit_prompt.txt',HERE/'pipeline.py',Path(__file__),
                          HERE/'build_acceptance.py',source_path,STUDY/'data/manifest.json',STUDY/'data/acceptance-plan.json',
                          STUDY/'data/preflight.json',STUDY/'review/preflight-review.json',TRACKER_PROMPT,HERE.parent/'evaluate_tracker.py',
                          HERE.parent/'repair_v2/train_tracker.py',HERE.parent/'repair_v2/collect_three_arm.py',
                          ROOT/'experiments/deep_conversation/intention_state.py']
            config={'kind':'bounded_engineering_acceptance_not_heldout_research','date':'2026-10-27','timezone':'America/Halifax',
                    'base_id':MODEL_ID,'base_revision':REVISION,'adapter':adapter,'maximum_assigned_calls':24,
                    'case_order':[r['case_id'] for r in rows],'stages':['normal','audit'],
                    'max_prompt_tokens':2048,'max_new_tokens':{'normal':512,'audit':1024},
                    'seed':20261024,'do_sample':False,'num_beams':1,'repetition_penalty':1.0,'cache_implementation':'dynamic',
                    'quantization':'frozen NF4 double quantization / bfloat16 compute; frozen loader unchanged',
                    'call_budget_note':'Treatment adds one audit call. This is not an equal-compute mechanism comparison.',
                    'source_hashes':{p.relative_to(ROOT).as_posix():sha(p) for p in source_paths},
                    'base_files_verified':len(receipt['files']),'base_receipt_sha256':sha(BASE_RECEIPT),
                    'versions':{name:importlib.metadata.version(name) for name in ['torch','transformers','peft','bitsandbytes','accelerate']}}
            write(out/'config.json',config)
            cfg_hash=sha(out/'config.json')
            tokenizer=AutoTokenizer.from_pretrained(str(MODEL_PATH),local_files_only=True,trust_remote_code=False)
            lengths=[]
            for row in rows:
                normal_messages=[{'role':'system','content':TRACKER_PROMPT.read_text(encoding='utf-8').strip()},
                                 {'role':'user','content':legacy.encode(row['input'])}]
                with legacy.restore_store(row['input']) as st:
                    audit_messages=audit.messages(audit.build_request(st))
                lengths.append({'case_id':row['case_id'],'normal':len(tokenizer.apply_chat_template(normal_messages,tokenize=True,add_generation_prompt=True,return_dict=False)),
                                'audit_before_normal':len(tokenizer.apply_chat_template(audit_messages,tokenize=True,add_generation_prompt=True,return_dict=False))})
            write(out/'token-preflight.json',{'status':'passed' if all(max(x['normal'],x['audit_before_normal'])<=2048 for x in lengths) else 'failed','lengths':lengths,'truncation':False})
            assert all(max(x['normal'],x['audit_before_normal'])<=2048 for x in lengths),'Prompt bound exceeded before inference.'
            emit('loading_fixed_base_and_adapter',inputs=12,max_calls=24)
            model=prepare_frozen_base(quantized_base())
            model=PeftModel.from_pretrained(model,str(ADAPTER_RUN/'adapter'),adapter_name='tracker_lora_v2',is_trainable=False)
            model.requires_grad_(False); model.eval()
            if model.is_gradient_checkpointing: model.gradient_checkpointing_disable()
            active_adapter(model)
            ordinal=0
            for index,row in enumerate(rows):
                def generate(messages,stage):
                    nonlocal ordinal
                    ordinal+=1
                    assert ordinal<=24
                    tokens=tokenizer.apply_chat_template(messages,tokenize=True,add_generation_prompt=True,return_dict=False)
                    event={'ordinal':ordinal,'case_id':row['case_id'],'stage':stage,'config_sha256':cfg_hash,
                           'input_messages_sha256':legacy.digest(messages),'input_token_ids_sha256':legacy.digest(tokens),
                           'input_tokens':len(tokens),'started_at_utc':datetime.now(timezone.utc).isoformat()}
                    durable(out/'attempts.jsonl',{'event':'started',**event})
                    started_call=time.perf_counter()
                    record={**event,'messages':messages,'status':'failed'}
                    try:
                        assert len(tokens)<=2048,'Audit input exceeds frozen context bound; no truncation.'
                        record['actual_adapter_state']=active_adapter(model)
                        torch.manual_seed(20261024); torch.cuda.manual_seed_all(20261024)
                        inputs=torch.tensor([tokens],device='cuda',dtype=torch.long)
                        with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
                            output=model.generate(input_ids=inputs,attention_mask=torch.ones_like(inputs),do_sample=False,
                                repetition_penalty=1.0,num_beams=1,max_new_tokens=config['max_new_tokens'][stage],use_cache=True,
                                cache_implementation='dynamic',logits_to_keep=1,pad_token_id=tokenizer.eos_token_id)
                        generated=output[0,len(tokens):].tolist()
                        record.update(status='completed',output_text=tokenizer.decode(generated,skip_special_tokens=True),
                                      output_tokens=len(generated),hit_token_cap=len(generated)>=config['max_new_tokens'][stage])
                        del output,inputs
                    except Exception as error:
                        record['error']={'type':type(error).__name__,'message':str(error)}
                        raise
                    finally:
                        record['elapsed_seconds']=time.perf_counter()-started_call
                        record['finished_at_utc']=datetime.now(timezone.utc).isoformat()
                        durable(out/'PRIVATE-calls.jsonl',record)
                        durable(out/'attempts.jsonl',{'event':'ended','ordinal':ordinal,'status':record['status'],'record_sha256':legacy.digest(record)})
                        emit('call_recorded',case=row['case_id'],stage=stage,status=record['status'],calls=ordinal,
                             seconds=round(record['elapsed_seconds'],2),output_tokens=record.get('output_tokens'))
                    return record['output_text']
                with legacy.restore_store(row['input']) as store:
                    outcome=track_then_audit(store,lambda m:generate(m,'normal'),lambda m:generate(m,'audit'),
                                            row['case_id'],tool_receipts=row['input']['tool_receipts'])
                durable(out/'PRIVATE-outcomes.jsonl',{'case_id':row['case_id'],'index':index,'result':outcome})
            assert ordinal==24
            assert adapter_artifacts(ADAPTER_RUN)==adapter
            for rel,value in config['source_hashes'].items(): assert sha(ROOT/rel)==value,rel
            calls=legacy.jsonl(out/'PRIVATE-calls.jsonl')
            assert len(calls)==24 and [r['ordinal'] for r in calls]==list(range(1,25))
            assert [(r['case_id'],r['stage']) for r in calls]==[(row['case_id'],stage) for row in rows for stage in ('normal','audit')]
            result.update(status='completed',calls=ordinal,completed_calls=sum(r['status']=='completed' for r in calls),
                          outcomes=12,config_sha256=cfg_hash,post_run_adapter_hashes_unchanged=True,
                          outputs_sha256=sha(out/'PRIVATE-calls.jsonl'),outcomes_sha256=sha(out/'PRIVATE-outcomes.jsonl'),
                          actual_adapter_state=active_adapter(model),memory=measured_memory(),quality_scored=False)
    except Exception as error:
        result.update(status='failed',error={'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()},
                      durable_calls=len(legacy.jsonl(out/'PRIVATE-calls.jsonl')) if (out/'PRIVATE-calls.jsonl').exists() else 0)
        raise
    finally:
        result['elapsed_seconds']=time.perf_counter()-started
        result['finished_at_utc']=datetime.now(timezone.utc).isoformat()
        write(out/'result.json',result)
        emit('collection_finished',status=result['status'],elapsed_seconds=round(result['elapsed_seconds'],2))

if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    main()
