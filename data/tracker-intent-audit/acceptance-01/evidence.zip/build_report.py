"""Assemble one bounded acceptance report from immutable calls and review."""
from pathlib import Path
import json
import hashlib

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def main():
    auto=read(HERE/'analysis/automatic-metrics.json')
    run=read(HERE/'collection-02/result.json')
    review=read(HERE/'review/post-run-review.json')
    assert run['status']=='completed' and review['status']=='passed'
    assert auto['calls']==24 and auto['audit_statuses']=={'rejected':12}
    assert auto['faulty_baseline_correct']==auto['faulty_audit_correct']==0
    assert auto['clean_baseline_correct']==auto['clean_audit_correct']==5
    assert auto['clean_damaged']==auto['metadata_changed_fields']==0
    assert auto['all_ids_and_text_preserved']
    s=review['summary']
    for key in ('faulty_baseline_correct','faulty_audit_correct','clean_damaged'):
        assert s[key]==auto[key],key
    assert not review['acceptance_passed']
    assert s['new_other_owner_status_errors']==s['source_error_changes']==s['unresolved_audits']==0
    normal=auto['costs']['normal']; audit=auto['costs']['audit']
    metrics={'actual_model_calls':24,'baseline_calls':12,'audit_calls':12,
       'faulty_baseline_correct':0,'faulty_audit_correct':0,'faulty_inputs':6,
       'clean_baseline_correct':5,'clean_audit_correct':5,'clean_inputs':6,'clean_damaged':0,
       'new_other_owner_status_errors':s['new_other_owner_status_errors'],
       'source_error_changes':s['source_error_changes'],'unresolved_audits':s['unresolved_audits'],
       'rejected_audits':12,'malformed_json_audits':11,'verdict_value_conflict_audits':1,
       'committed_audits':0,'failed_calls':24-normal['completed']-audit['completed'],
       'input_tokens':normal['input_tokens']+audit['input_tokens'],
       'output_tokens':normal['output_tokens']+audit['output_tokens'],
       'elapsed_seconds':run['elapsed_seconds'],'costs':auto['costs']}
    report={'id':'tracker-intent-audit-acceptance','status':'completed','kind':'bounded_engineering_acceptance',
       'date':'2026-10-27','timezone':'America/Halifax','acceptance_passed':False,'training_runs':0,
       'title':'意图核查已实现，但本轮能力验收失败',
       'lead':'固定当前底座与 LoRA，完成 12 个输入、24 次生成。12 份核查报告全部被执行层拒绝；6 个故障目标从核查前 0 个正确到核查后仍为 0 个，未获得修复收益。',
       'problem':'已有意图的归属错误、错误撤销和不确定状态被错误激活，可能被后续普通跟踪保留下来。',
       'baseline':'使用现有 v2 LoRA 完成一次普通跟踪，保存实际状态作为配对基线。正确前态也可能被本次普通跟踪破坏。',
       'change':'在同一 IntentStore 上增加一次独立核查，读取原始对话及所有已有记录（包括撤销项），逐字段报告保留、更正或证据不足。Harness 校验覆盖、引用与版本，合法结果才原子提交；不改文本或 ID。',
       'comparison_conditions':'底座 Qwen/Qwen2.5-14B-Instruct，revision cf98f3b3bbb457ad9e2bb7baf9a0125b6b88caa8；固定现有 tracker v2 formal-01 LoRA，同一次加载、同一个适配器，两阶段均冻结权重。6 个中英文故障前态加 6 个配对正确前态，来自 6 个前缀、5 个场景家庭；贪心生成，无重试、无提示词搜索、无新增训练。核查额外消耗一次调用，不是等算力对照。',
       'rows':auto['rows'],'metrics':metrics,'engineering':{'tests_passed':18,'tests_total':18},
       'failures':[
         '11 份报告不是合法 JSON；另 1 份虽能解析，但 owner 的 change 判定给出了未变化的值，违反字段契约。12 份均被拒绝，0 份提交。',
         '6 个故障目标均未修复。核查没有新增误改，原因是所有报告均未执行，不能解读成核查判断可靠。',
         '6 个正确前态中，普通跟踪先把英文不确定需求 i4 误激活并改写为另一任务，还遗漏了对应新增项；核查未修复。目标字段整体仅 5/6 保持正确，核查新增损伤则是 0/6。',
         '本轮输出协议失败已经足以阻断功能；部分拒绝报告还提出了错误状态或归属。没有通过自动补标点、忽略矛盾或二次生成来替换原始结果。',
         '首次 collection-01 启动误用了没有 PyTorch 的通用测试环境，0 次模型调用；collection-02 使用既有推理环境完成。未安装新依赖，未更改冻结来源。'],
       'limitations':[
         '这是已暴露合成案例上的小规模工程验收，标签与语义复核均由模型产生或检查，没有新增独立人工金标准。',
         '12 个输入不是 12 个独立场景，也不是新测试集上的泛化结果；本轮不估计统计显著性。',
         '表中正确仅指目标归属与状态，完整文本含义和证据充分性另行复核；语义复核不把未执行的提议当作修复。',
         '核查不能补回整个缺失的意图，也不能修复被普通步骤改坏的文本；证据不足和不支持的组合修改会保留记录并返回未决项。',
         '0 个执行后证据错误、0 个新增误改均以 0 个已执行核查修改为前提，不能据此计算可信的修改准确率。',
         '验收不通过，原型未接入默认聊天或工作执行流程；本轮在冻结范围内结束，不扩样本、不重训、不换底座。',
         '当前证据定位了输出协议与接入失败，不能确定其内部成因，也不能证明整个意图核查方向无效。'],
       'index_text':'固定模型与 LoRA：18 项工程测试通过；12 份模型核查均被拒绝，故障修复 0/6，能力验收失败。',
       'scope_stop':'All 24 assigned calls retained. No output-dependent retries, prompt edits, extra model arms or enlarged acceptance.',
       'provenance':{str(p.relative_to(ROOT)):sha(p) for p in [HERE/'analysis/automatic-metrics.json',HERE/'review/post-run-review.json',HERE/'collection-02/result.json',HERE/'collection-02/config.json',HERE/'data/acceptance-plan.json']}}
    write(HERE/'analysis/acceptance-summary.json',report)
    pipeline_log=HERE/'engineering/pipeline-tests-01.log'
    assert 'Ran 4 tests' in pipeline_log.read_text(encoding='utf-8') and '\nOK' in pipeline_log.read_text(encoding='utf-8')
    assert read(HERE/'engineering/core-validation-01.json')['tests_passed']==14
    engineering={'id':'tracker-intent-audit-engineering','type':'engineering_validation',
       'status':'implementation_passed_acceptance_failed','date':'2026-10-27','timezone':'America/Halifax',
       'tested_run':'collection-02','tests_passed':18,'tests_total':18,'capability_acceptance_passed':False,
       'checks':[
         {'name':'Core and real-store integration','status':'passed','result':'14 core + 4 pipeline unit tests; scripted callbacks, not model quality. First functional test runs passed.'},
         {'name':'Frozen data and independent source review','status':'passed','result':'12 restored inputs, all-record audit inputs without labels, 18 legacy dependency hashes preserved; preflight-review.json binds 58 source records.'},
         {'name':'Model startup recovery','status':'recovered','result':'collection-01 failed before inference (missing torch); existing tracker venv used for collection-02, no package installation.'},
         {'name':'Bounded real-model collection','status':'completed','result':'24/24 generations completed, no truncation or retries; fixed base files and adapter hashes verified.'},
         {'name':'Desired owner/status repair acceptance','status':'failed','result':'12/12 audit reports rejected; faulty target metadata correct 0/6 before and after. No audit operations executed.'},
         {'name':'Independent raw-dialogue review','status':'completed','record':'post-run-review.json','result':'Unblinded AI source review; does not convert malformed or incorrect reports into successful results.'}],
       'source_hashes':read(HERE/'collection-02/config.json')['source_hashes'],
       'pipeline_test_log_sha256':sha(pipeline_log),'core_validation_sha256':sha(HERE/'engineering/core-validation-01.json'),
       'new_model_calls':24,'new_training_runs':0,
       'limits':['Only existing-record metadata audit is implemented.','Unit tests establish software behavior, not assistance quality.','Website checks and deployment are recorded separately after publication preparation.']}
    write(HERE/'engineering/validation.json',engineering)
    print(json.dumps({'status':'report_assembled','acceptance_passed':False,'report_sha256':sha(HERE/'analysis/acceptance-summary.json')}))
if __name__=='__main__': main()
