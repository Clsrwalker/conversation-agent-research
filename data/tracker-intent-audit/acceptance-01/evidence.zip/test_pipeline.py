"""Integration contracts using scripted callbacks, not model quality tests."""
from pathlib import Path
import json
import importlib
import sys
import unittest

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from pipeline import legacy,track_then_audit
from intention_state import IntentStore

def report(owner='Alice'):
    return json.dumps({'checks':[{'intent_id':'i1','owner':{'verdict':'change','value':owner,'source_seqs':[0]},
                                 'status':{'verdict':'keep','value':'active','source_seqs':[0]}}]})

class PipelineContractTests(unittest.TestCase):
    def test_reusable_package_import(self):
        sys.path.insert(0,str(HERE.parents[3]))
        module=importlib.import_module('experiments.deep_conversation.tracker_lora.intent_audit.pipeline')
        self.assertTrue(callable(module.track_then_audit))

    def store(self):
        st=IntentStore(':memory:')
        self.addCleanup(st.close)
        st.observe([{'seq':0,'role':'user','speaker':'Alice','text':'My map must keep a fixed scale.'}])
        st.commit_patch('seed',0,0,[{'op':'add','intent_id':'i1','owner':'Bob','text':'Keep a fixed scale.','status':'active','source_seqs':[0]}])
        return st

    def test_real_normal_to_audit_chain_has_exact_inputs_and_one_call_each(self):
        st=self.store(); initial=st.snapshot(); seen=[]
        def normal(messages):
            seen.append(('normal',messages))
            self.assertEqual(json.loads(messages[1]['content']),{'conversation':st.events(),'intention_state':initial,'tool_receipts':[]})
            return '{"operations":[]}'
        def audited(messages):
            seen.append(('audit',messages)); payload=json.loads(messages[1]['content'])
            self.assertEqual(set(payload),{'conversation','intention_state','required_intent_ids','through_seq'})
            self.assertEqual(payload['required_intent_ids'],['i1'])
            self.assertNotIn('history',payload['intention_state'][0])
            self.assertEqual(st.snapshot()['version'],2)
            return report()
        result=track_then_audit(st,normal,audited,'example')
        self.assertEqual([x[0] for x in seen],['normal','audit'])
        self.assertEqual(result['baseline']['post_state']['intents'][0]['owner'],'Bob')
        self.assertEqual(result['post_state']['intents'][0]['owner'],'Alice')
        self.assertEqual(result['post_state']['intents'][0]['text'],initial['intents'][0]['text'])
        self.assertEqual(result['post_state']['version'],3)

    def test_invalid_normal_output_preserved_and_one_audit_still_runs(self):
        st=self.store(); calls=[]
        def audited(messages): calls.append(1); return report()
        result=track_then_audit(st,lambda m:'bad json',audited,'invalid')
        self.assertFalse(result['baseline']['committed'])
        self.assertEqual(calls,[1])
        self.assertEqual(result['post_state']['intents'][0]['owner'],'Alice')

    def test_new_arrival_during_generation_rejects_stale_patch_without_extra_call(self):
        st=self.store(); audits=[]
        def normal(messages):
            st.observe([{'seq':1,'role':'user','speaker':'Alice','text':'Keep the map title too.'}])
            return '{"operations":[]}'
        result=track_then_audit(st,normal,lambda m:audits.append(m),'stale')
        self.assertEqual(result['baseline']['status'],'stale_input')
        self.assertEqual(result['audit']['status'],'not_run_stale_input')
        self.assertEqual(audits,[])
        self.assertEqual(st.snapshot()['observed_event_seq'],1)
        self.assertEqual(st.snapshot()['version'],1)

if __name__=='__main__':
    unittest.main()
