"""Freeze the reviewed, bounded engineering acceptance without private transcripts."""
from pathlib import Path
from datetime import datetime,timezone
import json
import hashlib
import re

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
FEATURE=ROOT/'experiments/deep_conversation/tracker_lora/intent_audit'
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def relative(v):
    if isinstance(v,dict): return {k:relative(x) for k,x in v.items()}
    if isinstance(v,list): return [relative(x) for x in v]
    if isinstance(v,str):
        for prefix in (str(ROOT),ROOT.as_posix()):
            v=v.replace(prefix+'\\','').replace(prefix+'/','')
        # Source tracebacks keep line/error information; local interpreter paths
        # outside this workspace are not part of the public provenance contract.
        v=re.sub(r'[A-Za-z]:[\\/][^\n\r\"]*?(?=\", line|\n|$)','[local environment path]',v)
    return v
def main():
    report=read(HERE/'analysis/acceptance-summary.json')
    review=read(HERE/'review/post-run-review.json')
    final=read(HERE/'review/final-report-review.json')
    assert review['status']=='passed' and final['status']=='passed'
    assert final['reviewed_report_sha256']==sha(HERE/'analysis/acceptance-summary.json')
    assert report['status']=='completed' and report['kind']=='bounded_engineering_acceptance'
    assert report['metrics']['actual_model_calls']==24 and report['training_runs']==0
    paths={
      'acceptance-summary.json':HERE/'analysis/acceptance-summary.json',
      'automatic-metrics.json':HERE/'analysis/automatic-metrics.json',
      'post-run-review.json':HERE/'review/post-run-review.json',
      'final-report-review.json':HERE/'review/final-report-review.json',
      'preflight-review.json':HERE/'review/preflight-review.json',
      'acceptance-plan.json':HERE/'data/acceptance-plan.json',
      'data-manifest.json':HERE/'data/manifest.json',
      'data-preflight.json':HERE/'data/preflight.json',
      'selection.json':HERE/'data/selection.json',
      'prior-bundles.json':HERE/'analysis/prior-bundles.json',
      'engineering-validation.json':HERE/'engineering/validation.json',
      'core-validation.json':HERE/'engineering/core-validation-01.json',
      'startup-recovery.json':HERE/'engineering/startup-recovery.json',
      'startup-failure.json':HERE/'collection-01/result.json',
      'collection-result.json':HERE/'collection-02/result.json',
      'collection-config.json':HERE/'collection-02/config.json',
      'token-preflight.json':HERE/'collection-02/token-preflight.json',
      'core-tests.txt':HERE/'engineering/core-tests-01.log',
      'pipeline-tests.txt':HERE/'engineering/pipeline-tests-01.log',
      'compute_metrics.py':HERE/'compute_metrics.py',
      'build_report.py':HERE/'build_report.py',
      'export_publication.py':Path(__file__),
      **{name:FEATURE/name for name in ('audit.py','audit_prompt.txt','pipeline.py','collect_acceptance.py','build_acceptance.py','test_audit.py','test_pipeline.py','README.md','USAGE.md')},
    }
    dest=HERE/'publication/acceptance-01'
    assert not dest.exists(),'Never overwrite the frozen evidence package.'
    payloads={}; bindings={}
    for name,p in paths.items():
        data=p.read_bytes(); transformation='none'
        if p.suffix=='.json' and name!='acceptance-summary.json':
            data=(json.dumps(relative(read(p)),ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')
            transformation='JSON formatting and local path redaction only; hashes retain exact source provenance.'
        if name.endswith('.txt') and p.suffix=='.log':
            data=data.decode('utf-8-sig').encode('utf-8')
            transformation='UTF-8 encoding; execution content unchanged.'
        assert not re.search(rb'(?<![A-Za-z0-9])[A-Za-z]:[\\/]+',data),name
        assert '\ufffd' not in data.decode('utf-8'),name
        assert not name.startswith('PRIVATE-')
        if name.endswith('.json'):
            def check(v):
                if isinstance(v,dict):
                    assert not set(v)&{'output_text','messages','per_assignment','blind_id'},name
                    for child in v.values(): check(child)
                elif isinstance(v,list):
                    for child in v: check(child)
            check(json.loads(data))
        payloads[name]=data
        bindings[name]={'source_path':p.relative_to(ROOT).as_posix(),'source_sha256':sha(p),
          'export_sha256':hashlib.sha256(data).hexdigest(),'transformation':transformation}
    summary={**report,'independent_final_audit':'passed',
      'reviewed_interpretation_source_sha256':sha(HERE/'analysis/acceptance-summary.json'),
      'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'source_and_export_files':bindings}
    dest.mkdir(parents=True)
    for name,data in payloads.items(): (dest/name).write_bytes(data)
    write(dest/'summary.json',summary)
    print(json.dumps({'status':'frozen','files':len(payloads)+1,'acceptance_passed':report['acceptance_passed'],'summary_sha256':sha(dest/'summary.json')}))
if __name__=='__main__': main()
