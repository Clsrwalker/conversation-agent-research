"""Structural/transition tests only; no model and no semantic quality score."""
import copy
import json
from pathlib import Path
import sys
import unittest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parents[1]))
from audit import AuditValidationError, apply_report, build_request, messages, run_audit
from intention_state import IntentStore


class InjectedRuntimeFailureStore(IntentStore):
    """Force a real atomic runtime rejection after a legal first operation."""
    def commit_patch(self, patch_id, expected_version, through_seq, operations):
        if patch_id.startswith('intent-audit:'):
            operations = copy.deepcopy(operations) + [
                {'op': 'update', 'intent_id': 'not-stored', 'owner': 'Nobody', 'source_seqs': [0]}]
        return super().commit_patch(patch_id, expected_version, through_seq, operations)


class AuditTests(unittest.TestCase):
    def make_store(self, *, wrong_owner=False, withdrawn=False, wrong_uncertainty=False, cls=IntentStore):
        st = cls(':memory:')
        self.addCleanup(st.close)
        st.observe([
            {'seq': 0, 'speaker': 'Alice', 'role': 'user', 'text': 'I need my map.'},
            {'seq': 1, 'speaker': 'Bob', 'role': 'user', 'text': 'I need my chart.'},
            {'seq': 2, 'speaker': 'assistant', 'role': 'assistant', 'text': 'Would you like a grid too?'},
            {'seq': 3, 'speaker': 'Alice', 'role': 'user', 'text': 'Maybe, I have not decided about a grid.'},
            {'seq': 4, 'speaker': 'Alice', 'role': 'user', 'text': 'Understood.'},
        ])
        st.commit_patch('initial', 0, 4, [
            {'op': 'add', 'intent_id': 'i1', 'owner': 'Alice', 'text': 'Alice needs her map.', 'status': 'active', 'source_seqs': [0]},
            {'op': 'add', 'intent_id': 'i2', 'owner': 'Alice', 'text': 'Alice may need a grid; undecided.', 'status': 'active' if wrong_uncertainty else 'uncertain', 'source_seqs': [2, 3]},
            {'op': 'add', 'intent_id': 'i3', 'owner': 'Alice' if wrong_owner else 'Bob', 'text': 'Bob needs his chart.', 'status': 'active', 'source_seqs': [1]},
        ])
        if withdrawn:
            st.commit_patch('seeded-wrong-withdrawal', 1, 4,
                            [{'op': 'withdraw', 'intent_id': 'i1', 'source_seqs': [4]}])
        return st

    def report(self, st):
        sources = {'i1': [0], 'i2': [2, 3], 'i3': [1]}
        return {'checks': [
            {'intent_id': item['intent_id'], **{
                field: {'verdict': 'keep', 'value': item[field], 'source_seqs': sources[item['intent_id']]}
                for field in ('owner', 'status')}} for item in st.snapshot()['intents']]}

    def change(self, report, identifier, field, value, sources):
        next(check for check in report['checks'] if check['intent_id'] == identifier)[field] = {
            'verdict': 'change', 'value': value, 'source_seqs': sources}

    def reject(self, st, request, raw):
        before = st.snapshot()
        result = apply_report(st, request, raw, 'rejected-case')
        self.assertEqual(result['status'], 'rejected')
        self.assertFalse(result['committed'])
        self.assertIsNotNone(result['error'])
        self.assertEqual(st.snapshot(), before)
        return result

    def test_three_supported_repairs_atomic_and_text_preserved(self):
        st = self.make_store(wrong_owner=True, withdrawn=True, wrong_uncertainty=True)
        request = build_request(st)
        report = self.report(st)
        self.change(report, 'i1', 'status', 'active', [0])
        self.change(report, 'i2', 'status', 'uncertain', [2, 3])
        self.change(report, 'i3', 'owner', 'Bob', [1])
        result = apply_report(st, request, json.dumps(report), 'three-repairs')
        self.assertEqual(result['status'], 'applied')
        self.assertTrue(result['committed'] and result['coverage_complete'])
        self.assertEqual(result['semantic_correctness'], 'not_judged')
        self.assertEqual(len(result['operations']), 3)
        self.assertEqual(result['post_state']['version'], request['expected_version'] + 1)
        final = {x['intent_id']: x for x in result['post_state']['intents']}
        self.assertEqual((final['i1']['status'], final['i2']['status'], final['i3']['owner']),
                         ('active', 'uncertain', 'Bob'))
        self.assertEqual({x['intent_id']: x['text'] for x in request['snapshot']['intents']},
                         {key: value['text'] for key, value in final.items()})
        self.assertEqual({op['op'] for op in result['operations']}, {'update', 'reopen'})

    def test_keep_all_preserves_records_but_acknowledges_version(self):
        st = self.make_store()
        request = build_request(st)
        result = apply_report(st, request, json.dumps(self.report(st)), 'keep')
        self.assertEqual(result['status'], 'no_change')
        self.assertEqual(result['operations'], [])
        self.assertEqual(result['post_state']['intents'], request['snapshot']['intents'])
        self.assertEqual(result['post_state']['version'], request['expected_version'] + 1)

    def test_insufficient_holds_entire_record_and_allows_other_repair(self):
        st = self.make_store(wrong_owner=True)
        request = build_request(st)
        report = self.report(st)
        report['checks'][0]['owner'] = {'verdict': 'insufficient', 'value': None, 'source_seqs': []}
        self.change(report, 'i1', 'status', 'uncertain', [0])
        self.change(report, 'i3', 'owner', 'Bob', [1])
        result = apply_report(st, request, json.dumps(report), 'partial')
        self.assertEqual(result['status'], 'partial_unresolved')
        self.assertEqual([op['intent_id'] for op in result['operations']], ['i3'])
        self.assertEqual(result['unresolved'][0]['intent_id'], 'i1')
        self.assertEqual(result['post_state']['intents'][0], request['snapshot']['intents'][0])

    def test_rejects_missing_duplicate_unknown_coverage(self):
        st = self.make_store()
        request = build_request(st)
        for mode in ('missing', 'duplicate', 'unknown'):
            with self.subTest(mode=mode):
                report = self.report(st)
                if mode == 'missing':
                    report['checks'].pop()
                elif mode == 'duplicate':
                    report['checks'].append(copy.deepcopy(report['checks'][0]))
                else:
                    report['checks'][0]['intent_id'] = 'unknown'
                self.reject(st, request, json.dumps(report))

    def test_rejects_unsafe_sources(self):
        st = self.make_store()
        request = build_request(st)
        for source in ([True], [-1], [5], [0, 0], [3, 0], [2], []):
            with self.subTest(source=source):
                report = self.report(st)
                report['checks'][0]['owner']['source_seqs'] = source
                self.reject(st, request, json.dumps(report))

    def test_rejects_json_and_schema_errors_without_partial_apply(self):
        st = self.make_store(wrong_owner=True)
        request = build_request(st)
        valid = self.report(st)
        self.change(valid, 'i3', 'owner', 'Bob', [1])
        raw = json.dumps(valid)
        variants = ['```json\n'+raw+'\n```', '{"checks":[],"checks":[]}',
                    '{"checks":NaN}', '{"checks":1e999}', '[]', '{"operations":[]}']
        for bad in variants:
            with self.subTest(raw=bad):
                self.reject(st, request, bad)
        for place in ('root', 'record', 'field'):
            report = copy.deepcopy(valid)
            if place == 'root':
                report['operations'] = []
            elif place == 'record':
                report['checks'][0]['text'] = 'A hidden text rewrite.'
            else:
                report['checks'][0]['owner']['reason'] = 'extra'
            self.reject(st, request, json.dumps(report))

    def test_rejects_verdict_value_conflicts(self):
        st = self.make_store()
        request = build_request(st)
        for verdict, value in [('keep', 'Bob'), ('change', 'Alice'), ('insufficient', 'Alice')]:
            with self.subTest(verdict=verdict):
                report = self.report(st)
                report['checks'][0]['owner'].update(verdict=verdict, value=value)
                self.reject(st, request, json.dumps(report))

    def test_unsupported_owner_plus_reopen_is_held_whole(self):
        st = self.make_store(withdrawn=True)
        request = build_request(st)
        report = self.report(st)
        self.change(report, 'i1', 'owner', 'Bob', [0])
        self.change(report, 'i1', 'status', 'active', [0])
        result = apply_report(st, request, json.dumps(report), 'compound')
        self.assertEqual(result['status'], 'partial_unresolved')
        self.assertEqual(result['operations'], [])
        self.assertEqual(result['post_state']['intents'], request['snapshot']['intents'])
        self.assertEqual(result['unresolved'][0]['reason'], 'combined_owner_and_withdrawal_transition_unsupported')

    def test_owner_change_while_retaining_withdrawn_is_held(self):
        st = self.make_store(withdrawn=True)
        request = build_request(st)
        report = self.report(st)
        self.change(report, 'i1', 'owner', 'Bob', [0])
        result = apply_report(st, request, json.dumps(report), 'withdrawn-owner')
        self.assertEqual(result['status'], 'partial_unresolved')
        self.assertEqual(result['post_state']['intents'], request['snapshot']['intents'])

    def test_ambiguous_owner_change_is_deferred(self):
        st = self.make_store()
        request = build_request(st)
        report = self.report(st)
        self.change(report, 'i1', 'owner', '__unresolved__', [0])
        self.change(report, 'i1', 'status', 'uncertain', [0])
        result = apply_report(st, request, json.dumps(report), 'ambiguous')
        self.assertEqual(result['status'], 'partial_unresolved')
        self.assertEqual(result['operations'], [])

    def test_stale_version_and_observation_are_rejected(self):
        for change in ('version', 'observation'):
            with self.subTest(change=change):
                st = self.make_store()
                request = build_request(st)
                report = json.dumps(self.report(st))
                if change == 'version':
                    st.commit_patch('other-update', st.snapshot()['version'], 4, [])
                else:
                    st.observe([{'seq': 5, 'speaker': 'Alice', 'text': 'A new message.'}])
                result = self.reject(st, request, report)
                self.assertEqual(result['error']['type'], 'IntentConflictError')

    def test_real_runtime_rejection_rolls_back_prior_legal_operation(self):
        st = self.make_store(wrong_owner=True, cls=InjectedRuntimeFailureStore)
        request = build_request(st)
        report = self.report(st)
        self.change(report, 'i3', 'owner', 'Bob', [1])
        result = self.reject(st, request, json.dumps(report))
        self.assertTrue(result['coverage_complete'])
        self.assertEqual(st.snapshot(), request['snapshot'])

    def test_messages_are_annotation_free_and_include_withdrawn(self):
        st = self.make_store(withdrawn=True)
        request = build_request(st)
        payload = json.loads(messages(request)[1]['content'])
        self.assertEqual(set(payload), {'conversation', 'intention_state', 'required_intent_ids', 'through_seq'})
        self.assertEqual(payload['required_intent_ids'], ['i1', 'i2', 'i3'])
        self.assertEqual(payload['intention_state'][0]['status'], 'withdrawn')
        self.assertTrue(all(set(x) == {'intent_id', 'text', 'owner', 'status'} for x in payload['intention_state']))
        self.assertEqual(payload['conversation'], st.events())
        self.assertEqual(request['snapshot'], st.snapshot())
        with self.assertRaises(AuditValidationError):
            build_request(st, max_intents=2)
        with self.assertRaises(AuditValidationError):
            build_request(st, max_events=4)

    def test_run_audit_calls_generator_once_and_never_retries(self):
        st = self.make_store()
        calls = []
        def bad_generator(msgs):
            calls.append(msgs)
            return 'not JSON'
        before = st.snapshot()
        result = run_audit(st, bad_generator, 'one-call')
        self.assertEqual(result['status'], 'rejected')
        self.assertEqual(len(calls), 1)
        self.assertEqual(st.snapshot(), before)
        def raising_generator(msgs):
            calls.append(msgs)
            raise RuntimeError('synthetic generation error')
        result = run_audit(st, raising_generator, 'failed-call')
        self.assertEqual(len(calls), 2)
        self.assertEqual(result['error']['stage'], 'capture_or_generation')
        self.assertEqual(st.snapshot(), before)


if __name__ == '__main__':
    unittest.main(verbosity=2)
