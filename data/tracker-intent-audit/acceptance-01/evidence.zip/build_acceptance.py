"""Freeze 12 exposed engineering acceptance inputs without looking at model outputs.

Faulty examples are the first eligible frozen-test row per focus and language.
Their clean pairs are rebuilt from the original authored history, not edited
snapshots. References/selection metadata remain outside every model input.
"""
from __future__ import annotations

import argparse
from collections import Counter
import copy
from datetime import date, datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = next(p for p in Path(__file__).resolve().parents
            if (p/'experiments/deep_conversation/intention_state.py').exists())
OLD_CODE = ROOT/'experiments/deep_conversation/tracker_lora'
STUDY = ROOT/'output/research/2026-10-24/tracker-lora-repair-v2'
DEFAULT_OUTPUT = ROOT/'output/research/2026-10-27/tracker-intent-audit/data'
sys.path.insert(0, str(OLD_CODE))
import build_dataset as legacy
from evaluate_tracker import restore_store

spec = importlib.util.spec_from_file_location('frozen_repair_compiler', OLD_CODE/'repair_v2/build_dataset.py')
repair = importlib.util.module_from_spec(spec)
spec.loader.exec_module(repair)


def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))


def encode(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(encode(value).encode('utf-8')).hexdigest()


def write(p, value):
    assert not p.exists(), f'Preserve frozen output: {p.name}'
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')


def no_sft(row):
    return {k:v for k,v in row.items() if k != 'sft'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--date', required=True)
    parser.add_argument('--output', type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    date.fromisoformat(args.date)
    out = args.output
    assert not out.exists() or not any(out.iterdir()), 'Output must be new or empty.'
    out.mkdir(parents=True, exist_ok=True)

    lock_path = STUDY/'evaluation/protocol-lock.json'
    lock = read(lock_path)
    bindings = {lock_path.relative_to(ROOT).as_posix():sha(lock_path),
                Path(__file__).resolve().relative_to(ROOT).as_posix():sha(Path(__file__))}
    for item in lock['files'].values():
        p = Path(item['path'])
        assert sha(p) == item['sha256'], p.name
        bindings[p.relative_to(ROOT).as_posix()] = item['sha256']
    manifest = read(STUDY/'data/compiled/manifest.json')
    source_paths = []
    for relative, expected in manifest['source_files'].items():
        p = STUDY/relative
        assert sha(p) == expected, relative
        source_paths.append(p)
        bindings[p.relative_to(ROOT).as_posix()] = expected
    records_path = STUDY/'data/compiled/test.records.jsonl'
    assert sha(records_path) == manifest['files']['test.records.jsonl']['sha256']
    source_lines = records_path.read_bytes().splitlines(keepends=True)
    assert len(source_lines) == 200 and all(line.endswith(b'\n') for line in source_lines)
    source_rows = [json.loads(line) for line in source_lines]
    prompt_path = STUDY/'annotation/system_prompt.txt'
    prompt = prompt_path.read_text(encoding='utf-8').strip()

    families = {}
    for p in sorted((STUDY/'data/source').glob('*.jsonl')):
        for line in p.read_text(encoding='utf-8-sig').splitlines():
            if line.strip():
                family = json.loads(line)
                assert family['family_id'] not in families
                entry = manifest['family_sources'][family['family_id']]
                assert p.relative_to(STUDY).as_posix() == entry['path']
                assert digest(family) == entry['family_sha256']
                families[family['family_id']] = family

    selected = []
    for kind, focus in [('owner','owner'), ('wrong_withdrawn','wrong_withdrawn'), ('status','uncertain_status')]:
        for language in ('zh','en'):
            eligible = []
            for index,row in enumerate(source_rows):
                fault = row.get('prior_fault_annotation',{})
                if fault.get('fault_kind') != kind or row['language'] != language:
                    continue
                target = next(x for x in row['expected_semantic_state'] if x['intent_id'] == fault['intent_id'])
                if kind == 'status' and not (target['status'] == 'uncertain' and fault['wrong_value'] == 'active'):
                    continue
                eligible.append((index,row))
            assert eligible, (kind,language)
            index,row = eligible[0]
            selected.append((focus,language,index,row))
    assert len(selected) == 6 and len({row['example_id'] for _,_,_,row in selected}) == 6

    rows, pairs, preflight_rows = [], [], []
    exact_fault_lines = []
    for focus,language,index,faulty in selected:
        family = families[faulty['family_id']]
        ordinary = next(r for r in legacy.materialize(family,prompt) if r['example_id'] == faulty['example_id'])
        regenerated = no_sft(repair.fault_row(family,ordinary,copy.deepcopy(faulty['prior_fault_annotation']),prompt))
        assert regenerated == faulty
        # Preserve the original platform line ending as well as canonical bytes.
        newline = b'\r\n' if source_lines[index].endswith(b'\r\n') else b'\n'
        assert encode(regenerated).encode('utf-8')+newline == source_lines[index]
        clean = no_sft(ordinary)
        assert clean['input']['conversation'] == faulty['input']['conversation']
        assert clean['expected_semantic_state'] == faulty['expected_semantic_state']
        assert clean['input']['intention_state'] != faulty['input']['intention_state']
        target_id = faulty['prior_fault_annotation']['intent_id']
        assert target_id in clean['preserve_ids'], 'Current raw turn must not revise the designated prior target.'
        correct_prior = {i['intent_id']:{k:i[k] for k in ('owner','text','status')}
                         for i in clean['input']['intention_state']['intents']}
        expected_target = next(i for i in clean['expected_semantic_state'] if i['intent_id'] == target_id)
        pair_id = focus+'-'+language
        pair = {'pair_id':pair_id,'focus':focus,'language':language,'source_row_index':index,
                'source_example_id':faulty['example_id'],'source_family_id':faulty['family_id'],
                'focal_intent_id':target_id,'expected_focal_metadata':{k:expected_target[k] for k in ('owner','status')},
                'source_faulty_line_sha256':hashlib.sha256(source_lines[index]).hexdigest(),
                'original_faulty_record_sha256':digest(faulty), 'clean_record_sha256':digest(clean),
                'conversation_sha256':digest(clean['input']['conversation']),
                'clean_control_method':'Original family materialized through public IntentStore operations; no metadata/history hand edits.'}
        pairs.append(pair)
        exact_fault_lines.append(source_lines[index])
        for condition,original in [('faulty',faulty),('clean',clean)]:
            row = copy.deepcopy(original)
            assert set(row['input']) == {'conversation','intention_state','tool_receipts'}
            row.update(case_id=pair_id+'-'+condition,pair_id=pair_id,condition=condition,focus=focus,
                       source_row_index=index,focal_intent_id=target_id,
                       expected_focal_metadata={k:expected_target[k] for k in ('owner','status')},
                       correct_prior_fields=copy.deepcopy(correct_prior),
                       source_original_record_sha256=digest(original),
                       acceptance_kind='exposed_engineering_regression_not_heldout')
            with restore_store(row['input']) as store:
                assert store.snapshot() == row['input']['intention_state']
                assert store.events() == row['input']['conversation']
                after = store.commit_patch('acceptance-reference-control',store.snapshot()['version'],
                    store.snapshot()['observed_event_seq'],row['target']['operations'])
                assert legacy.project(after) == row['expected_semantic_state']
            assert all(e['seq'] <= row['input']['intention_state']['observed_event_seq']
                       for e in row['input']['conversation'])
            rows.append(row)
            preflight_rows.append({'case_id':row['case_id'],'input_sha256':digest(row['input']),
                'original_input_identical':row['input'] == original['input'],
                'public_store_restore_exact':True,'annotated_patch_matches_reference_projection':True,
                'current_intents':len(row['input']['intention_state']['intents']),
                'arrived_events':len(row['input']['conversation'])})

    assert len(rows) == 12 and len({r['case_id'] for r in rows}) == 12
    assert len({encode(r['input']) for r in rows}) == 12
    assert Counter(r['condition'] for r in rows) == {'faulty':6,'clean':6}
    assert Counter(r['language'] for r in rows) == {'zh':6,'en':6}
    # No rows from the known ordinary-reference amendment are selected.
    amended_examples = {'fresh-test-005-5','fresh-test-017-5'}
    assert not {r['example_id'] for r in rows} & amended_examples
    payloads = {
        'acceptance.records.jsonl': ''.join(encode(r)+'\n' for r in rows).encode('utf-8'),
        'inputs.jsonl': ''.join(encode(r['input'])+'\n' for r in rows).encode('utf-8'),
        'source-faulty.records.jsonl': b''.join(exact_fault_lines),
    }
    for name,content in payloads.items():
        (out/name).write_bytes(content)
    write(out/'selection.json',{'rule':'First matching row in the frozen 200-row test order, separately for each category and language. Selection never reads generated model outputs.',
        'pairs':pairs,'unique_prefixes':6,'unique_families':len({r['family_id'] for r in rows}),
        'dependency_note':'The Chinese owner and uncertain-status selections are different prefixes from the same family; pairs and repeated prefixes are not independent trials.'})
    plan = {'id':'tracker-intent-audit-small-acceptance','type':'engineering_acceptance_plan',
        'date':args.date,'timezone':'America/Halifax','status':'frozen_before_acceptance_inference',
        'purpose':'Check whether one explicit owner/status audit after normal tracking repairs the known focal failures without damaging correct states.',
        'scope':{'inputs':12,'faulty':6,'matched_clean':6,'prefix_pairs':6,'families':5,
                 'focus_categories':['owner','wrong_withdrawn','uncertain_status'],'languages':['zh','en'],
                 'normal_tracker_calls':12,'maximum_audit_calls':12,'maximum_total_model_calls':24,
                 'training_runs':0,'base_model_changes':0,'adapter_weight_changes':0},
        'input_contract':'The normal tracker receives only each row.input. Audit receives arrived raw dialogue and ALL existing post-tracker intents, including withdrawn; never focal IDs, fault kind, references, expected metadata, preserve_ids, scenario labels, or review notes.',
        'procedure':['Freeze these cases and the implementation/prompt before inference.',
                     'For each input, generate and apply one normal-tracker proposal using the fixed current v2 LoRA.',
                     'Run at most one audit with the same loaded base and adapter over every existing post-tracker record; retain the normal result as the paired baseline.',
                     'Preserve failures, truncations and rejected audits; no output-dependent sample selection, prompt tuning, retry or additional model arm.',
                     'Review raw source meaning and changed-field citations separately from structural coverage.'],
        'primary_outcome':'Focal existing stable-ID owner and status both correct against the predeclared reference after the normal step and after audit; score meaning/text separately so metadata correctness is not called full intent correctness.',
        'secondary_outcomes':['Changes from baseline-correct to wrong owner/status on every audited record, not only the focal record.',
                              'Fault target corrections, remaining errors, clean-target damage and newly unsupported changes.',
                              'Strict report coverage, accepted/rejected/unresolved results and changes supported by sufficient cited arrived user evidence.',
                              'Audit preserves text and record IDs exactly; absent or newly misidentified baseline intents require explicit manual matching or an unscorable flag, never arbitrary ID matching.',
                              'Normal plus audit calls/tokens/time; audit consumes additional compute, so no matched-budget superiority claim.'],
        'desired_acceptance':{'faulty_targets_correct_after_audit':6,'faulty_target_denominator':6,
                               'clean_focal_targets_damaged_by_audit':0,'clean_target_denominator':6,
                               'new_owner_or_status_errors_elsewhere':0,
                               'changed_fields_supported_by_sufficient_raw_evidence':True,
                               'all_completed_audit_reports_structurally_complete':True,
                               'text_and_ids_preserved_by_audit':True},
        'interpretation_rule':'A functional audit requires valid behavior, not just completed calls. Meeting the desired checks is acceptance on these exposed cases; a repair benefit additionally requires observed baseline-to-audit corrections with no offsetting damage. Do not claim held-out generalization, causal mechanism, statistical superiority, or production reliability.',
        'stop_rule':'One frozen implementation and one bounded acceptance collection. If the focal capability does not work or causes regressions, report it and stop this scope; do not add prompt sweeps, new models, retraining or a larger evaluation.',
        'limitations':['Previously exposed synthetic examples and model-authored/model-reviewed reference labels.',
                       'Five families with six prefixes and matched priors; 12 inputs are not 12 independent scenarios.',
                       'No real rollout, end-to-end task success, ASR, or user study is tested.',
                       'Correct-prior controls are original family histories; they can still require ordinary updates from the latest turn.']}
    write(out/'acceptance-plan.json',plan)
    write(out/'preflight.json',{'status':'passed','date':args.date,'timezone':'America/Halifax',
        'checked_at_utc':datetime.now(timezone.utc).isoformat(),'frozen_protocol_dependencies_verified':len(lock['files']),
        'manifest_source_files_verified':len(source_paths),'exact_regenerated_faulty_rows':6,
        'clean_controls_regenerated_from_original_histories':6,'input_restores_checked':12,
        'annotated_reference_controls_checked':12,'all_pairs_same_arrived_conversation':True,
        'no_selected_reference_overlay_corrections':True,'checks':preflight_rows,
        'new_model_calls':0,'training_runs':0,
        'limits':['Preflight establishes executable reference transitions and exact provenance, not new semantic gold or model quality.']})
    for relative,expected in bindings.items():
        assert sha(ROOT/relative) == expected, relative
    files = {p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.iterdir()) if p.is_file()}
    manifest_out = {'id':'tracker-intent-audit-acceptance-data','status':'frozen_before_acceptance_inference',
        'date':args.date,'timezone':'America/Halifax','frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'kind':'bounded_exposed_engineering_acceptance','rows':12,'pairs':6,'families':5,
        'conditions':dict(Counter(r['condition'] for r in rows)),
        'languages':dict(Counter(r['language'] for r in rows)),
        'model_calls_budget':24,'new_model_calls_during_data_build':0,
        'source_hashes':bindings,'files':files,'source_artifacts_modified':False,
        'reference_quality':'Existing frozen model-authored/model-reviewed synthetic references; not human gold.',
        'publication_note':'Inputs and references are fictional authored material. No new model outputs or private blind-ID joins are present.'}
    write(out/'manifest.json',manifest_out)
    print(json.dumps({'status':'frozen','rows':12,'pairs':6,'families':5,'maximum_model_calls':24,
                      'manifest_sha256':sha(out/'manifest.json')},ensure_ascii=False))


if __name__ == '__main__':
    main()
