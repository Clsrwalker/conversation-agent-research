# Using the bounded tracker audit

The reusable entry point runs one normal tracker update and then one audit on
the same `IntentStore`. Supply the same frozen model/adapter generation callback
for both stages:

```python
from experiments.deep_conversation.tracker_lora.intent_audit.pipeline import track_then_audit

result = track_then_audit(
    store,
    tracker_generate=generate,
    audit_generate=generate,
    run_id="unique-turn-id",
)
```

`generate(messages)` returns the model's raw string. It must not be a wrapper
that silently switches adapters, retries, or adds reference answers. The bundled
`collect_acceptance.py` demonstrates loading the pinned Qwen2.5-14B base and
existing tracker v2 adapter once, with frozen parameters and explicit call logs.

Read both `result["baseline"]` and `result["audit"]`. A rejected normal proposal
can leave existing records available for audit. A concurrent change during the
normal step returns `stale_input` and skips the audit; the caller must schedule a
fresh normal update on the new input rather than applying an old answer.

An audit result of `applied`, `no_change`, or `partial_unresolved` means the report
passed structural checks and an atomic patch committed. None means the model's
interpretation has been proved correct. `unresolved` explains held records;
`rejected` includes a structural/generation error. The feature does not resolve
insufficient evidence by inventing an owner or treating uncertainty as active.

The first version supports at most 12 existing intentions and 40 arrived events,
without truncation. It audits owner/status, preserves text/IDs, and cannot add a
missing intention or perform an unsupported combined owner/reopen transition.
The inference runner additionally enforces its 2048-token prompt limit.

The one bounded acceptance command is:

```text
experiments/deep_conversation/tracker_lora/.venv/Scripts/python.exe -B -u experiments/deep_conversation/tracker_lora/intent_audit/collect_acceptance.py --output output/research/2026-10-27/tracker-intent-audit/collection-02
```

The runner requires the frozen data manifest and independent preflight review.
It refuses an existing output directory. Do not launch another run to replace an
unfavorable result. The 12 exposed inputs are engineering regression cases, not
a new held-out benchmark or evidence of production reliability.

`collection-01` preserves a startup failure from using the general test venv,
which has no PyTorch. It made zero model calls. `collection-02` uses the existing
tracker inference venv, with unchanged frozen model, prompt, source and inputs.
