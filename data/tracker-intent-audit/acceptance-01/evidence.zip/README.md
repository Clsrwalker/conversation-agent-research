# Bounded intention evidence audit

This additive feature keeps the existing base, tracker LoRA and `IntentStore`
unchanged. After the normal tracker has proposed its update, capture the store
and run one audit call using the **same frozen adapter**. There is no training,
adapter switching, hidden retry, automatic semantic oracle or reference-label
lookup in this module.

`build_request(store, max_intents=12, max_events=40)` captures the full current
snapshot, version/cursor, every current intent ID (including withdrawn records)
and all arrived events. It fails rather than truncating above a cap.
`messages(request)` exposes all raw dialogue and the current ID/text/owner/status
projection, with the exact required ID list. Old state histories and execution
receipts are not evidence supplied to this audit model; they remain in the store.
`apply_report(store, request, raw, audit_id)` validates and atomically commits the
compiled patch. `run_audit(store, generate, audit_id)` combines these steps with
one `generate(messages) -> raw_text` callback and no retry.

The model returns a `checks` list covering every ID exactly once. Each record
contains owner and status verdicts: `keep`, `change`, or `insufficient`, plus a
value and field-specific `source_seqs`. Keep/change require an arrived user
source; source references are structural provenance, not proof of meaning.
The harness rejects malformed JSON, duplicate keys, missing/duplicate coverage,
unknown IDs/fields, future/boolean/duplicate/unsorted source indices, assistant-only
keep/change evidence, contradictory verdict/value pairs and stale snapshots.

Only owner/status changes compile to `update`, `withdraw`, or `reopen`.
Text and IDs cannot change and no record is added/deleted. Insufficient evidence
holds the entire affected record. Compound owner changes with a withdrawal or
reopen are deferred because the existing store permits only one operation per ID
and reopen cannot revise owner/text. Changing owner to `__unresolved__` is also
deferred; unresolved ownership cannot be promoted to active. Other fully supported
records can still commit atomically in the same patch.

Results include `status` (`applied`, `no_change`, `partial_unresolved`, or
`rejected`), `committed`, `coverage_complete`, `operations`, `checks`,
`unresolved`, `post_state`, and `error`. `semantic_correctness` always says
`not_judged`. Accepted no-change/held-only reports advance the store version via
the normal empty-patch convention; malformed or stale reports do not mutate it.

This is an audit of **existing** records. It does not recover missing/new intents,
repair arbitrary text qualifiers, assess completed work or establish generalization.
The small acceptance run must report both repair and new-error outcomes, extra
calls/tokens/latency and invalid reports. Structural coverage alone is not success.
