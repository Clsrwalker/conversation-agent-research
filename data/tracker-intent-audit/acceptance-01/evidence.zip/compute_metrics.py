"""Read-only bounded acceptance arithmetic; semantic review is separate."""
from pathlib import Path
from collections import Counter
import json
import hashlib

HERE=Path(__file__).resolve().parent
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def rows(p): return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def main():
    run=HERE/'collection-02'
    result=read(run/'result.json')
    assert result['status']=='completed' and result['calls']==24 and result['outcomes']==12
    data=rows(HERE/'data/acceptance.records.jsonl')
    outcomes=rows(run/'PRIVATE-outcomes.jsonl')
    calls=rows(run/'PRIVATE-calls.jsonl')
    assert sha(run/'PRIVATE-outcomes.jsonl')==result['outcomes_sha256']
    assert sha(run/'PRIVATE-calls.jsonl')==result['outputs_sha256']
    assert len(data)==len(outcomes)==12 and len(calls)==24
    assert [r['case_id'] for r in data]==[r['case_id'] for r in outcomes]
    facts=[]
    for row,item in zip(data,outcomes):
        r=item['result']; baseline=r['baseline']; audit=r['audit']
        b={i['intent_id']:i for i in baseline['post_state']['intents']}
        a={i['intent_id']:i for i in r['post_state']['intents']}
        focal=row['focal_intent_id']; expected=row['expected_focal_metadata']
        def correct(state):
            return focal in state and all(state[focal][k]==v for k,v in expected.items())
        bc,ac=correct(b),correct(a)
        changed=[{'intent_id':i,'field':k,'before':b[i][k],'after':a[i][k]}
                 for i in b.keys()&a.keys() for k in ('owner','status') if b[i][k]!=a[i][k]]
        facts.append({'case_id':row['case_id'],'focus':row['focus'],'condition':row['condition'],
          'focal_intent_id':focal,'baseline_focal_metadata_correct':bc,'audit_focal_metadata_correct':ac,
          'focal_corrected':not bc and ac,'focal_damaged':bc and not ac,
          'baseline_status':baseline['status'],'audit_status':audit['status'],
          'audit_committed':audit['committed'],'audit_coverage_complete':audit['coverage_complete'],
          'unresolved_records':len(audit['unresolved']),'baseline_records':len(b),'post_audit_records':len(a),
          'ids_preserved':b.keys()==a.keys(),
          'text_preserved':b.keys()==a.keys() and all(b[i]['text']==a[i]['text'] for i in b),
          'changed_fields':changed,'audit_error':audit['error']})
    faulty=[r for r in facts if r['condition']=='faulty']; clean=[r for r in facts if r['condition']=='clean']
    categories=[]
    for focus,label in [('owner','归属'),('wrong_withdrawn','误撤销恢复'),('uncertain_status','不确定状态')]:
        f=[r for r in faulty if r['focus']==focus]; c=[r for r in clean if r['focus']==focus]
        categories.append({'focus':focus,'label':label,'inputs':len(f),
           'baseline_correct':sum(r['baseline_focal_metadata_correct'] for r in f),
           'audit_correct':sum(r['audit_focal_metadata_correct'] for r in f),
           'clean_inputs':len(c),'clean_damaged':sum(r['focal_damaged'] for r in c)})
    costs={}
    for stage in ('normal','audit'):
        group=[r for r in calls if r['stage']==stage]
        costs[stage]={'calls':len(group),'completed':sum(r['status']=='completed' for r in group),
          'input_tokens':sum(r['input_tokens'] for r in group),
          'output_tokens':sum(r.get('output_tokens',0) for r in group),
          'hit_token_cap':sum(r.get('hit_token_cap',False) for r in group),
          'elapsed_seconds':round(sum(r['elapsed_seconds'] for r in group),3)}
    summary={'kind':'automated_arithmetic_not_semantic_adjudication','date':'2026-10-27','timezone':'America/Halifax',
       'sources':{str(p.relative_to(HERE)):sha(p) for p in [HERE/'data/acceptance.records.jsonl',run/'result.json',run/'config.json',run/'PRIVATE-calls.jsonl',run/'PRIVATE-outcomes.jsonl']},
       'inputs':12,'faulty_inputs':6,'clean_inputs':6,'calls':24,
       'faulty_baseline_correct':sum(r['baseline_focal_metadata_correct'] for r in faulty),
       'faulty_audit_correct':sum(r['audit_focal_metadata_correct'] for r in faulty),
       'faulty_corrected':sum(r['focal_corrected'] for r in faulty),
       'clean_baseline_correct':sum(r['baseline_focal_metadata_correct'] for r in clean),
       'clean_audit_correct':sum(r['audit_focal_metadata_correct'] for r in clean),
       'clean_damaged':sum(r['focal_damaged'] for r in clean),
       'audit_statuses':dict(Counter(r['audit_status'] for r in facts)),
       'baseline_statuses':dict(Counter(r['baseline_status'] for r in facts)),
       'coverage_complete':sum(r['audit_coverage_complete'] for r in facts),
       'audit_committed':sum(r['audit_committed'] for r in facts),
       'all_ids_and_text_preserved':all(r['ids_preserved'] and r['text_preserved'] for r in facts),
       'metadata_changed_fields':sum(len(r['changed_fields']) for r in facts),
       'costs':costs,'rows':categories,'cases':facts,
       'semantic_review_required':['field evidence sufficiency','all-record metadata regressions','focal text completeness','identity matching']}
    write(HERE/'analysis/automatic-metrics.json',summary)
    print(json.dumps({k:v for k,v in summary.items() if k not in ('cases','sources')},ensure_ascii=True))
if __name__=='__main__': main()
