# Investigation progress: authored diagnostic scenarios

This collection contains two development scenarios and ten held-out scenarios. All conversations, organizations, products and documents are fictional. It is a new controlled diagnostic set, not an external benchmark. The author had inspected earlier harness results and knew their failure families; the author was not blind to those findings. No evaluated model has run on this collection at freeze time.

## Runtime and annotation separation

Run `dev/` or `heldout/` as separate dataset directories. Each contains `cases.json` and `corpus.json` in the existing Replay format. `gold.json` is a private grading file for review_packets.py. The root `rubric.json` collects those same semantic annotations. Neither rubric, this protocol, design labels, the complete future dialogue nor the undelivered corpus may enter acting-model input. The runner may verify annotation hashes without parsing their contents. Root `corpus.json` is an authoring inventory, not permission to give one case access to the other cases' sources.

Keep held-out content and reference conclusions out of mechanism development. Freeze model configuration, prompts, code, interventions, budgets and repeat counts in a separate execution protocol before opening test outcomes. Once a test outcome guides a change, it becomes development evidence; do not keep claiming it is an untouched test. Preserve these files and create a new version if an execution defect requires fixture changes.

## Timing

Every case is evaluated at 45,000 simulated milliseconds. The environment does not close when the model produces a final message, and the final active card is still evaluated if the agent exhausts its budget. Search and read delays are fixed per case and identical between comparison arms. A feasibility check confirms that an old read can span a scope change and that a search can return after people have resolved a need. These are possible schedules, not prescribed model trajectories. Model execution and virtual-clock time are recorded separately. This collection does not measure live ASR latency.

The `asr_final` event name is reused as the existing text-replay transport. The text was authored directly and was not transcribed from recordings. There are no partial-recognition events or claims of speech-recognition robustness in this collection.

## What is evaluated

The ten held-out scenarios include seven opportunities requiring useful help and three controls requiring no unnecessary visible action. They cover a sufficient excerpt, information available only beyond an initial excerpt, terminology that can motivate a different query, a useful documentation gap, delayed evidence, a changed question, and no-action cases. One no-action case includes an unrelated mention after the current issue is already settled.

Score supported current-scope help and appropriate silence separately. No tool sequence is compulsory. A strong initial query can avoid a later reformulation; a decisive source can make further reading unnecessary; a specific uncertainty answer can be complete help. Searching, reading, waiting, ending a turn and cancelling work are choices, not rubric stages. The rubric judges visible meaning and factual support, not exact wording or a mandatory source count.

Calls, tokens, repeated retrieval, evidence changes, intermediate errors and stale publications are secondary observations. A repeat is not automatically waste, and fewer calls do not by themselves prove better help. A serious unsupported claim relevant to the decision prevents primary success even when part of the answer is correct. Ratings should be blinded to configuration; state whether reviewers are humans or AI.

The proposed main comparison is ten held-out scenarios, two configurations and two repeats, for forty runs. Repeats do not turn ten authored scenarios into forty independent cases. Freeze the actual execution plan separately. This set cannot establish generalization, statistical significance or benefit in real conversations.

This directory is the dev split.
