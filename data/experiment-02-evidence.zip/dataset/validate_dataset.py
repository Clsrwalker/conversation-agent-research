"""Validate authored fixtures offline; never invoke an acting model or API."""
from __future__ import annotations
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def validate():
    runner = HERE.parents[2] / 'conversation_harness' / 'runner.py'
    spec = importlib.util.spec_from_file_location('dataset_replay_validation', runner)
    module = importlib.util.module_from_spec(spec)
    sys.path.insert(0, str(runner.parent))
    try:
        spec.loader.exec_module(module)
    finally:
        sys.path.pop(0)
    corpus = read(HERE / 'corpus.json')
    rubric = read(HERE / 'rubric.json')
    assert len(corpus) == len({source['id'] for source in corpus}) == 23
    assert len(rubric['cases']) == len({case['case_id'] for case in rubric['cases']}) == 12
    seen_cases, seen_sources = set(), set()
    counts, retrievable = {}, 0
    for split in ('dev', 'heldout'):
        cases, documents = read(HERE / split / 'cases.json'), read(HERE / split / 'corpus.json')
        gold = read(HERE / split / 'gold.json')
        ids = {case['case_id'] for case in cases}
        sources = {doc['id']: doc for doc in documents}
        assert not ids & seen_cases and not set(sources) & seen_sources
        seen_cases |= ids
        seen_sources |= set(sources)
        assert ids == {case['case_id'] for case in gold['cases']}
        assert gold['cases'] == [case for case in rubric['cases'] if case['split'] == split]
        assert documents == [source for source in corpus if source['id'] in sources]
        for document in documents:
            assert set(document) == {'id', 'title', 'kind', 'available_at_ms', 'text'}
            assert re.fullmatch('[a-z0-9-]+', document['id'])
            assert document['kind'] == 'document' and document['available_at_ms'] == 0
        for case in cases:
            assert set(case) == {'case_id', 'corpus_ids', 'close_at_ms', 'tool_latency_ms', 'events'}
            assert re.fullmatch('[a-z0-9-]+', case['case_id'])
            assert case['close_at_ms'] == 45000
            assert set(case['corpus_ids']) <= set(sources)
            assert 1 <= len(case['corpus_ids']) <= 4
            assert set(case['tool_latency_ms']) == {'search', 'read'}
            assert all(type(value) is int and value > 0 for value in case['tool_latency_ms'].values())
            times = [event['at_ms'] for event in case['events']]
            assert times == sorted(times) and times[0] == 0 and max(times) < 45000
            assert len({event['segment_id'] for event in case['events']}) == len(case['events'])
            for event in case['events']:
                assert set(event) == {'kind', 'at_ms', 'speaker', 'segment_id', 'text'}
                assert event['kind'] == 'asr_final'
            for source_id in case['corpus_ids']:
                replay = module.Replay(case, documents)
                receipt = replay.act('search', {'query': sources[source_id]['title']})
                replay.advance(receipt['due_ms'])
                assert source_id in replay.delivered, 'A title query must be able to find its document.'
                read_receipt = replay.act('read_document', {'source_id': source_id})
                replay.advance(read_receipt['due_ms'])
                assert replay.delivered[source_id]['level'] == 'full'
                assert replay.now < case['close_at_ms']
                retrievable += 1
        counts[split] = {
            'scenarios': len(cases), 'sources': len(documents),
            'required_help': sum(case['opportunity_type'] == 'required_help' for case in gold['cases']),
            'silence_controls': sum(case['opportunity_type'] == 'silence_control' for case in gold['cases']),
        }
    assert counts['dev']['scenarios'] == 2
    assert counts['heldout']['scenarios'] == 10
    assert counts['heldout']['required_help'] == 7 and counts['heldout']['silence_controls'] == 3
    assert seen_sources == {source['id'] for source in corpus}

    # These are feasibility checks of the deterministic Replay, not model paths.
    tests = read(HERE / 'heldout' / 'cases.json')
    annotations = {case['case_id']: case for case in rubric['cases']}
    delayed_change, delayed_resolution = 0, 0
    for case in tests:
        annotation = annotations[case['case_id']]['stale_and_revision']
        if annotation['change_at_ms'] is not None:
            replay = module.Replay(case, corpus)
            source = next(doc for doc in corpus if doc['id'] == case['corpus_ids'][0])
            receipt = replay.act('search', {'query': source['title']})
            replay.advance(receipt['due_ms'])
            started = replay.now
            receipt = replay.act('read_document', {'source_id': source['id']})
            assert started < annotation['change_at_ms'] < receipt['due_ms'] < 45000
            replay.advance(receipt['due_ms'])
            assert any(event['kind'] == 'environment_event'
                       and event['at_ms'] == annotation['change_at_ms'] for event in replay.log)
            delayed_change += 1
        if annotation['resolved_at_ms'] is not None:
            replay = module.Replay(case, corpus)
            receipt = replay.act('search', {'query': case['events'][0]['text']})
            assert annotation['resolved_at_ms'] < receipt['due_ms'] < 45000
            delayed_resolution += 1
    assert delayed_change == delayed_resolution == 1
    checked_hashes = 0
    for split in ('dev', 'heldout'):
        freeze_file = HERE / split / 'freeze.json'
        if freeze_file.exists():
            for name, expected in read(freeze_file)['files_sha256'].items():
                assert Path(name).name == name
                assert hashlib.sha256((HERE / split / name).read_bytes()).hexdigest() == expected
                checked_hashes += 1
    if (HERE / 'freeze.json').exists():
        for name, expected in read(HERE / 'freeze.json')['files_sha256'].items():
            assert hashlib.sha256((HERE / name).read_bytes()).hexdigest() == expected
            checked_hashes += 1
    return {'schema_version': 1, 'passed': True, 'splits': counts,
            'unique_scenarios': len(seen_cases), 'unique_sources': len(seen_sources),
            'source_search_and_read_checks': retrievable,
            'read_can_span_scope_change': delayed_change == 1,
            'search_can_return_after_human_resolution': delayed_resolution == 1,
            'fixed_evaluation_horizon_ms': 45000,
            'runtime_cases_have_no_grading_fields': True,
            'runtime_events_have_no_action_labels': True,
            'actor_runs': 0, 'external_api_calls': 0, 'freeze_hashes_checked': checked_hashes}


if __name__ == '__main__':
    print(json.dumps(validate(), indent=2))
