"""Offline plumbing model. Its fixed behavior is not a research baseline."""
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage, ToolMessage
from langchain_core.outputs import ChatGeneration, ChatResult


class SmokeModel(BaseChatModel):
    model_name: str = 'local:offline-plumbing-only'

    @property
    def _llm_type(self):
        return 'offline-plumbing-only'

    def bind_tools(self, tools, **kwargs):
        return self

    def get_num_tokens_from_messages(self, messages, tools=None):
        return sum(max(1, len(str(m.content)) // 4) for m in messages)

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        count = sum(isinstance(m, AIMessage) for m in messages)
        searched = any(isinstance(m, ToolMessage) and m.name == 'search' for m in messages)
        name, args = ('wait_for_event', {}) if searched else ('search', {'query': 'offline'})
        result = AIMessage(content='', tool_calls=[{
            'name': name, 'args': args, 'id': f'smoke-{count}', 'type': 'tool_call'}],
            usage_metadata={'input_tokens': self.get_num_tokens_from_messages(messages),
                            'output_tokens': 10,
                            'total_tokens': self.get_num_tokens_from_messages(messages) + 10})
        return ChatResult(generations=[ChatGeneration(message=result)])
