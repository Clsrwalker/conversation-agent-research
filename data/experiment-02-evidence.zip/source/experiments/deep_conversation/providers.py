"""Explicit model backends; local runs never fall back to a hosted provider."""
from __future__ import annotations

import ipaddress
import math
import os
import re
from urllib.parse import urlsplit, urlunsplit

from config import Settings


def validate_local_settings(settings: Settings) -> str:
    """Validate local-only configuration and return the normalized server URL.

    This performs no network calls. Runtime preflight must additionally verify
    the installed model's metadata: aliases can otherwise hide cloud models.
    """
    if settings.provider != 'ollama':
        raise ValueError('Local model validation requires provider=ollama')
    try:
        url = urlsplit(settings.local_base_url)
        host, port = url.hostname, url.port
    except (TypeError, ValueError) as error:
        raise ValueError('Invalid local Ollama URL') from error
    if (url.scheme not in {'http', 'https'} or not host or
            url.username is not None or url.password is not None or
            url.path not in {'', '/'} or url.query or url.fragment):
        raise ValueError('Ollama requires a loopback server root URL without credentials')
    if host == 'localhost':
        host = '127.0.0.1'
    try:
        address = ipaddress.ip_address(host)
    except ValueError as error:
        raise ValueError('Ollama URL must use localhost or a loopback IP address') from error
    if not address.is_loopback:
        raise ValueError('Ollama URL must use a loopback address')
    if port is not None and port <= 0:
        raise ValueError('Ollama URL needs a positive port')
    model = settings.model
    if not isinstance(model, str) or not model or model != model.strip() or any(c.isspace() for c in model):
        raise ValueError('A nonempty local Ollama model name is required')
    if '://' in model or re.search(r'(^|[-_./:])cloud($|[-_./:])', model, re.IGNORECASE):
        raise ValueError('Cloud model names are not allowed for local Ollama runs')
    if not isinstance(settings.context_window, int) or settings.context_window <= 0:
        raise ValueError('context_window must be a positive integer')
    if not 0 < settings.max_output_tokens < settings.context_window:
        raise ValueError('max_output_tokens must be positive and smaller than context_window')
    if not math.isfinite(settings.request_timeout) or settings.request_timeout <= 0:
        raise ValueError('request_timeout must be a positive finite number')
    if settings.reasoning_effort != 'none':
        raise ValueError('Local experiment runs require reasoning_effort=none')
    authority = f'[{host}]' if address.version == 6 else host
    if port is not None:
        authority += f':{port}'
    return urlunsplit((url.scheme, authority, '', '', ''))


def openai_model(settings: Settings):
    """Keep the paid Responses backend available only through explicit selection."""
    if settings.provider != 'openai':
        raise ValueError('The hosted model requires provider=openai')
    if not os.environ.get('OPENAI_API_KEY'):
        raise RuntimeError('OPENAI_API_KEY is not set')
    from langchain_openai import ChatOpenAI

    return ChatOpenAI(model=settings.model, base_url='https://api.openai.com/v1',
                      use_responses_api=True, store=False,
                      reasoning={'effort': settings.reasoning_effort},
                      max_tokens=settings.max_output_tokens, max_retries=0, timeout=60,
                      model_kwargs={'parallel_tool_calls': False})


def make_model(settings: Settings):
    if settings.provider == 'openai':
        return openai_model(settings)
    if settings.provider != 'ollama':
        raise ValueError('Use ollama/openai, or inject the scripted test model')
    base_url = validate_local_settings(settings)
    # Import lazily so injected protocol models never need a local server or
    # provider package. Neither construction nor failed calls trigger a pull.
    from langchain_ollama import ChatOllama

    return ChatOllama(
        model=settings.model, base_url=base_url, validate_model_on_init=False,
        reasoning=False, temperature=0, num_ctx=settings.context_window,
        num_predict=settings.max_output_tokens,
        profile={'max_input_tokens': settings.context_window,
                 'max_output_tokens': settings.max_output_tokens,
                 'tool_calling': True},
        # Ignore external proxy variables and never follow a redirect off-host.
        client_kwargs={'timeout': settings.request_timeout,
                       'trust_env': False, 'follow_redirects': False},
    )
