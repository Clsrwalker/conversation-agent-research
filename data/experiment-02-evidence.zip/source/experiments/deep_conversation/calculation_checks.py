"""Bounded arithmetic over quoted, arrived inputs; never executes model code.

The checks establish that a literal occurs in its quoted source and that the
selected arithmetic is correct. They do NOT establish that the model selected
the right event, quantity, units, operation, or meaning. A real source can still
be irrelevant to the requested conclusion. Consumers must preserve this limit.
"""
from __future__ import annotations

from decimal import Decimal, DecimalException, Inexact, localcontext
import re
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError


MAX_CALCULATIONS = 8
_DECIMAL_VALUE = re.compile(r'[+-]?(?:0|[1-9]\d{0,11})(?:\.\d{1,6})?\Z')
_SOURCE_NUMBER = re.compile(
    r'(?<![\w.,:+-])[+-]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?'
    r'(?![\w,:+\-]|\.\d)')
_CLOCK_VALUE = re.compile(r'(?:[01]\d|2[0-3]):[0-5]\d\Z')
_SOURCE_CLOCK = re.compile(r'(?<![\w:])(?:[01]\d|2[0-3]):[0-5]\d(?![\w:]|\.\d|\s*[aApP][mM]\b)')
_CALC_PLACEHOLDER = re.compile(r'(?<!\{)\{\{calc([1-9]\d*)\}\}(?!\})')
_MALFORMED_PLACEHOLDER = re.compile(r'\{+\s*calc|\bcalc\d+\s*\}\}', re.IGNORECASE)


class CalculationOperand(BaseModel):
    model_config = ConfigDict(extra='forbid')
    ref: str = Field(min_length=1, max_length=64, description='An arrived passage ID.')
    quote: str = Field(min_length=1, max_length=1200,
                       description='Exact source clause containing this input, with its event and units.')
    value: str = Field(min_length=1, max_length=24,
                       description='Decimal literal or 24-hour HH:MM literally present in the quoted source; no inferred inputs.')


class CalculationSpec(BaseModel):
    model_config = ConfigDict(extra='forbid')
    operation: Literal['add', 'subtract', 'multiply', 'divide',
                       'time_add_minutes', 'time_difference_minutes']
    left: CalculationOperand
    right: CalculationOperand
    end_day_offset: Literal[0, 1] = Field(default=0,
        description='Only for time_difference_minutes: 1 explicitly means right clock is the following day; otherwise 0. The program never assumes midnight rollover.')


CALCULATION_INSTRUCTIONS = """For numeric or clock arithmetic, submit calculations.
Each operation has two source-bound operands {ref, quote, value}. Use add,
subtract, multiply, divide for decimals; time_add_minutes for HH:MM plus a
nonnegative whole number of minutes; time_difference_minutes for minutes from
left HH:MM to right HH:MM. Set end_day_offset=1 only when the latter endpoint is
explicitly on the following day, otherwise 0. Include the words identifying the
quantity/event and units in each exact quote. Do not supply a calculated result:
the program computes it. Values must literally occur in their quoted passages.
An empty list is appropriate when no arithmetic is needed. These checks cannot
establish that the chosen operands or operation have the correct meaning.
Write {{calc1}}, {{calc2}}, etc. in the answer or derivation for results of the
first, second, etc. calculation. The program substitutes computed values; do not
manually copy a computed value into the prose. A clock result includes any day
rollover; a rounded decimal is explicitly marked approximate.
"""


class CalculationCheckError(ValueError):
    """A short, actionable calculation-contract error."""


def _decimal(value: str) -> Decimal:
    if not _DECIMAL_VALUE.fullmatch(value):
        raise CalculationCheckError('number must be a finite plain decimal with at most 12 integer and 6 fractional digits')
    number = Decimal(value)
    if not number.is_finite():
        raise CalculationCheckError('number must be finite')
    return number


def _clock(value: str) -> int:
    if not _CLOCK_VALUE.fullmatch(value):
        raise CalculationCheckError('clock must be a valid 24-hour HH:MM')
    hour, minute = value.split(':')
    return int(hour) * 60 + int(minute)


def _operand(operand: CalculationOperand, passages: dict, *, clock: bool):
    passage = passages.get(operand.ref)
    if not isinstance(passage, dict) or not isinstance(passage.get('text'), str):
        raise CalculationCheckError(f'unknown arrived passage: {operand.ref}')
    if not operand.quote.strip() or operand.quote not in passage['text']:
        raise CalculationCheckError(f'quote is not an exact nonempty passage substring: {operand.ref}')
    if clock:
        value = _clock(operand.value)
        if operand.value not in _SOURCE_CLOCK.findall(operand.quote):
            raise CalculationCheckError(f'clock input {operand.value} does not occur as a 24-hour clock in its quote')
        return value
    value = _decimal(operand.value)
    observed = []
    # The Unicode minus sign cannot silently turn a negative source value into
    # a positive operand. Other textual units and qualifiers stay semantic.
    for token in _SOURCE_NUMBER.findall(operand.quote.replace('\u2212', '-')):
        try:
            observed.append(_decimal(token.replace(',', '')))
        except CalculationCheckError:
            continue
    if value not in observed:
        raise CalculationCheckError(f'numeric input {operand.value} does not occur as a complete number in its quote')
    return value


def _canonical_decimal(value: Decimal) -> str:
    # Never serialize binary floats, exponential notation, or a negative zero.
    if value == 0:
        return '0'
    return format(value, 'f').rstrip('0').rstrip('.') if '.' in format(value, 'f') else format(value, 'f')


def _evaluate(spec: CalculationSpec, passages: dict) -> dict:
    operation = spec.operation
    clock_operation = operation.startswith('time_')
    left = _operand(spec.left, passages, clock=clock_operation)
    right = _operand(spec.right, passages, clock=operation == 'time_difference_minutes')
    if operation != 'time_difference_minutes' and spec.end_day_offset != 0:
        raise CalculationCheckError('end_day_offset is only allowed for time_difference_minutes')
    if operation == 'time_add_minutes':
        if right != right.to_integral_value() or not 0 <= right <= 10080:
            raise CalculationCheckError('time_add_minutes requires whole minutes between 0 and 10080')
        absolute = left + int(right)
        day_offset, minute_of_day = divmod(absolute, 1440)
        hour, minute = divmod(minute_of_day, 60)
        return {'value': f'{hour:02}:{minute:02}', 'unit': 'clock',
                'day_offset': day_offset, 'exact': True}
    if operation == 'time_difference_minutes':
        difference = right + spec.end_day_offset * 1440 - left
        if difference < 0:
            raise CalculationCheckError('negative same-day time difference; specify end_day_offset=1 only if the source establishes the following day')
        return {'value': str(difference), 'unit': 'minutes', 'day_offset': spec.end_day_offset,
                'exact': True}
    with localcontext() as context:
        context.prec = 40
        context.clear_flags()
        if operation == 'add':
            result = left + right
        elif operation == 'subtract':
            result = left - right
        elif operation == 'multiply':
            result = left * right
        else:
            if right == 0:
                raise CalculationCheckError('division by zero')
            result = left / right
        # Rounded repeating quotients must never masquerade as exact values.
        exact = not context.flags[Inexact]
        return {'value': _canonical_decimal(result), 'unit': 'number',
                'day_offset': 0, 'exact': exact}


def evaluate_calculations(calculations: list, passages: dict) -> dict:
    """Return JSON-safe verified results and indexed diagnostics, without raising.

    ``ok`` is false for any invalid member. A caller must not authorize an answer
    using the successful subset when other requested calculations failed.
    Results retain original operands for audit; every result is program-owned.
    No matching between the results and free-form conclusion prose is claimed.
    """
    if not isinstance(calculations, list) or len(calculations) > MAX_CALCULATIONS:
        return {'ok': False, 'results': [], 'diagnostics': [
            {'index': None, 'error': f'calculations must be a list of at most {MAX_CALCULATIONS} items'}]}
    if not isinstance(passages, dict):
        return {'ok': False, 'results': [], 'diagnostics': [
            {'index': None, 'error': 'passages must be an arrived passage catalog'}]}
    results, diagnostics = [], []
    for index, raw in enumerate(calculations):
        try:
            spec = CalculationSpec.model_validate(raw)
            result = _evaluate(spec, passages)
            display = result['value']
            if result['unit'] == 'clock' and result['day_offset']:
                days = result['day_offset']
                display += f' (+{days} {"day" if days == 1 else "days"})'
            if not result['exact']:
                display = 'approximately ' + display
            results.append({'index': index, 'operation': spec.operation,
                            'left': spec.left.model_dump(), 'right': spec.right.model_dump(),
                            'end_day_offset': spec.end_day_offset,
                            'result': result, 'result_display': display})
        except ValidationError as error:
            fields = '; '.join('.'.join(str(part) for part in row['loc']) + ': ' + row['msg']
                               for row in error.errors(include_input=False)[:4])
            diagnostics.append({'index': index, 'error': fields})
        except (CalculationCheckError, DecimalException) as error:
            diagnostics.append({'index': index, 'error': str(error)})
    return {'ok': not diagnostics, 'results': results, 'diagnostics': diagnostics}


def render_calculations(text: str, evaluated: dict) -> str:
    """Replace exact {{calcN}} tokens with program values or reject bad tokens.

    This is literal substitution, not a format-string or expression engine.
    Other braces are preserved. It does not detect an unsupported arithmetic
    claim the model writes without a token, or choose which facts need arithmetic.
    """
    if not isinstance(text, str) or len(text) > 20000:
        raise CalculationCheckError('calculation text must be a string of at most 20000 characters')
    if not isinstance(evaluated, dict) or evaluated.get('ok') is not True:
        raise CalculationCheckError('cannot render invalid calculations')
    displays = {str(item['index'] + 1): item['result_display'] for item in evaluated['results']}

    def substitute(match):
        key = match.group(1)
        if key not in displays:
            raise CalculationCheckError('unknown calculation placeholder: ' + match.group(0)[:64])
        return displays[key]

    rendered = _CALC_PLACEHOLDER.sub(substitute, text)
    if _MALFORMED_PLACEHOLDER.search(rendered):
        raise CalculationCheckError('malformed or unclosed calculation placeholder; use exact {{calcN}} syntax')
    return rendered
