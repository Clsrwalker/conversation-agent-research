"""Read-only local Ollama preflight; no generation, pulls or cloud fallback."""
from __future__ import annotations

import json
from urllib.error import HTTPError, URLError
from urllib.request import ProxyHandler, Request, build_opener

from config import Settings
from providers import validate_local_settings


def local_model_metadata(settings: Settings):
    base_url = validate_local_settings(settings)
    # A corporate/system proxy must not receive local model traffic.
    opener = build_opener(ProxyHandler({}))

    def request(path, data=None):
        payload = json.dumps(data).encode('utf-8') if data is not None else None
        req = Request(base_url + path, data=payload,
                      headers={'Content-Type': 'application/json'})
        try:
            with opener.open(req, timeout=10) as response:
                return json.load(response)
        except (HTTPError, URLError, TimeoutError) as error:
            raise RuntimeError('Local Ollama is unavailable or the model is missing. '
                               'Start Ollama and run: ollama pull ' + settings.model) from error

    listed = request('/api/tags')['models']
    canonical = settings.model if ':' in settings.model.rsplit('/', 1)[-1] else settings.model + ':latest'
    match = next((m for m in listed if m.get('name') == canonical or m.get('model') == canonical), None)
    if match is None:
        raise RuntimeError('Model is not installed locally. Run: ollama pull ' + settings.model)
    shown = request('/api/show', {'model': settings.model})
    if any(value.get(key) for value in [match, shown] for key in ['remote_host', 'remote_model']):
        raise ValueError('This model routes to a remote service; use downloaded local weights.')
    capabilities = shown.get('capabilities', [])
    if 'tools' not in capabilities:
        raise ValueError('The selected local model does not advertise tool calling support.')
    info = shown.get('model_info', {})
    limits = [v for k, v in info.items() if k.endswith('.context_length') and isinstance(v, int)]
    if limits and settings.context_window > max(limits):
        raise ValueError('Configured context window exceeds this model\'s context limit.')
    return {'model': match.get('name', canonical), 'digest': match['digest'],
            'size_bytes': match.get('size'), 'details': shown.get('details', {}),
            'capabilities': capabilities, 'ollama_version': request('/api/version')['version'],
            'context_window': settings.context_window, 'endpoint': base_url,
            'inference_location': 'local', 'paid_api_fallback': False}
