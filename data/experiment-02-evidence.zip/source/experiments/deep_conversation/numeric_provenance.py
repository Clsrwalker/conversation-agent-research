"""Check literal provenance in answer templates without judging their meaning.

A number must occur as a complete literal in the selected exact source quote
or explicitly bound task utterance, or use a verified calculation placeholder. This cannot prove
that a source concerns the correct event, that its units fit the question, or
that the model selected the correct arithmetic. It does not detect quantities
written entirely in words or digits embedded in names such as C20.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
import re

from calculation_checks import CalculationCheckError, render_calculations


_TIME = re.compile(
    r'(?<![\w:])\d{1,3}:\d{2}(?::\d{2})?(?:\s*[aApP][mM]\b)?(?![\w:]|\.\d)')
_NUMBER = re.compile(
    r'(?<![\w.,:+\-\u2212])[+\-\u2212]?(?:(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?|\.\d+)'
    r'(?:\s*(?:%|percent\b))?(?![\w,:+\-\u2212]|\.\d)', re.IGNORECASE)
_PLACEHOLDER = re.compile(r'(?<!\{)\{\{calc[1-9]\d*\}\}(?!\})')


class NumericProvenanceError(ValueError):
    def __init__(self, diagnostics):
        self.diagnostics = diagnostics
        super().__init__('; '.join(
            f'{row["field"]}: {row["literal"]!r} {row["reason"]}' for row in diagnostics))


@dataclass(frozen=True)
class _Literal:
    start: int
    end: int
    text: str
    key: tuple


def _literals(text):
    """Keep clocks distinct from numbers and percentages distinct from counts."""
    clocks = []
    for match in _TIME.finditer(text):
        raw = match.group()
        canonical = re.sub(r'\s+', '', raw).lower()
        # Normalize a one-digit clock hour without turning a bare 9 into 09:00.
        if re.fullmatch(r'\d:\d{2}', canonical):
            canonical = '0' + canonical
        clocks.append(_Literal(match.start(), match.end(), raw, ('clock', canonical)))
    literals = list(clocks)
    for match in _NUMBER.finditer(text):
        if any(match.start() < clock.end and match.end() > clock.start for clock in clocks):
            continue
        raw = match.group()
        if len(raw) > 80:
            raise ValueError('numeric literal exceeds 80 characters')
        percent = bool(re.search(r'(?:%|percent)\s*$', raw, re.IGNORECASE))
        numeric = re.sub(r'\s*(?:%|percent)\s*$', '', raw, flags=re.IGNORECASE)
        numeric = numeric.replace(',', '').replace('\u2212', '-')
        literals.append(_Literal(match.start(), match.end(), raw,
                                 ('percent' if percent else 'number', Decimal(numeric))))
    return sorted(literals, key=lambda literal: literal.start)


def _quoted_literals(grounding, catalog, field):
    """Prevent a short quote cutting 120 into 12, -5 into 5, or 5% into 5."""
    ref, quote = grounding.get('ref'), grounding.get('quote')
    passage = catalog.get(ref)
    if (not isinstance(passage, dict) or not isinstance(passage.get('text'), str)
            or not isinstance(quote, str) or not quote.strip()
            or quote not in passage['text']):
        raise NumericProvenanceError([{'field': field, 'literal': str(ref),
            'reason': 'does not identify an exact nonempty quote from an arrived passage; supply its actual grounding'}])
    try:
        quoted = _literals(quote)
        complete = {(item.start, item.end, item.key) for item in _literals(passage['text'])}
    except ValueError as error:
        raise NumericProvenanceError([{'field': field, 'literal': quote[:80], 'reason': str(error)}]) from error
    offset = passage['text'].find(quote)
    while offset != -1:
        if all((offset + item.start, offset + item.end, item.key) in complete for item in quoted):
            return quoted
        offset = passage['text'].find(quote, offset + 1)
    raise NumericProvenanceError([{'field': field, 'literal': quote,
        'reason': 'cuts through a numeric literal, sign, clock or percent unit; quote the complete original literal'}])


def validate_numeric_provenance(parsed_template, catalog, computed_results, *, context_refs=()):
    """Validate pre-render templates; return None or raise indexed diagnostics.

    ``computed_results`` is the complete result of evaluate_calculations.
    Each finding uses ONLY its own quoted groundings. The displayed answer,
    derivation and missing-premise text may use the union of those verified
    groundings and verified calculation-operand quotes, not arbitrary numbers
    elsewhere in the passage catalog.
    Raw computed values receive no permission from calculation results: use
    {{calcN}}. A value independently present in a quote remains an observed
    literal; this mechanical check cannot distinguish its intended semantics.
    Optional context_refs explicitly identify arrived utterances already bound
    to the current task. Their full literals may be reused as parameters across
    slots, but requirements are never thereby proved satisfied. No unlisted
    utterance or document receives this context permission.
    """
    if not isinstance(parsed_template, dict) or not isinstance(catalog, dict):
        raise NumericProvenanceError([{'field': 'answer_contract', 'literal': '',
            'reason': 'requires a parsed template and an arrived passage catalog'}])
    if not isinstance(computed_results, dict) or computed_results.get('ok') is not True:
        raise NumericProvenanceError([{'field': 'calculations', 'literal': '',
            'reason': 'must pass calculation validation before numerical provenance is checked'}])

    context_observed = set()
    if not isinstance(context_refs, (tuple, list, set, frozenset)):
        raise NumericProvenanceError([{'field': 'context_refs', 'literal': str(context_refs),
            'reason': 'must be an explicit collection of current-task utterance references'}])
    for index, ref in enumerate(context_refs):
        passage = catalog.get(ref) if isinstance(ref, str) else None
        if not isinstance(passage, dict) or passage.get('kind') != 'utterance' or not isinstance(passage.get('text'), str):
            raise NumericProvenanceError([{'field': f'context_refs[{index}]', 'literal': str(ref),
                'reason': 'must name an arrived utterance explicitly bound to the current task; document sources cannot bypass quote grounding'}])
        try:
            context_observed.update(item.key for item in _literals(passage['text']))
        except ValueError as error:
            raise NumericProvenanceError([{'field': f'context_refs[{index}]', 'literal': str(ref),
                'reason': str(error)}]) from error

    # A calculated value also must not be based on a quote cut from the middle
    # of a different source number; successful arithmetic alone cannot fix that.
    calculation_observed = set()
    for result in computed_results['results']:
        for side in ('left', 'right'):
            quoted = _quoted_literals(result[side], catalog, f'calculations[{result["index"]}].{side}')
            calculation_observed.update(item.key for item in quoted)

    all_observed, slot_observed = calculation_observed | context_observed, {}
    for slot, finding in parsed_template['slots'].items():
        observed = set(context_observed)
        for index, grounding in enumerate(finding['groundings']):
            quoted = _quoted_literals(grounding, catalog, f'slots.{slot}.groundings[{index}]')
            observed.update(item.key for item in quoted)
        slot_observed[slot] = observed
        all_observed.update(observed)

    diagnostics = []

    def check(text, allowed, field):
        try:
            # Validate exact placeholders without granting their rendered values
            # to free-form text elsewhere in the same or another field.
            render_calculations(text, computed_results)
            literal_text = _PLACEHOLDER.sub(lambda match: ' ' * len(match.group()), text)
            literals = _literals(literal_text)
        except (CalculationCheckError, ValueError) as error:
            diagnostics.append({'field': field, 'literal': '', 'reason': str(error)})
            return
        for literal in literals:
            if literal.key not in allowed:
                diagnostics.append({'field': field, 'literal': literal.text,
                    'reason': 'has no complete literal in the selected source groundings; add the applicable exact grounding or use a source-bound {{calcN}} calculation'})

    for slot, finding in parsed_template['slots'].items():
        check(finding['finding'], slot_observed[slot], f'slots.{slot}.finding')
    readiness = parsed_template['answer_readiness']
    for name in ('answer', 'derivation'):
        check(readiness[name], all_observed, 'answer_readiness.' + name)
    # These premises become the visible limitations paragraph in the contract.
    for index, premise in enumerate(readiness.get('missing_premises', [])):
        check(premise['premise'], all_observed, f'answer_readiness.missing_premises[{index}].premise')
    if diagnostics:
        raise NumericProvenanceError(diagnostics)
