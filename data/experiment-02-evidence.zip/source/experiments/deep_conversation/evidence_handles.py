"""Program-owned handles for exact evidence and calculation inputs.

Public API:
* ``build_catalog(passages)`` consumes ``stage_acceptance.passage_catalog`` output
  and returns JSON-safe ``evidence`` and ``quantities`` dictionaries.
* ``resolve_evidence(ids, catalog)`` returns fresh ``{ref, quote}`` groundings.
* ``resolve_calculation(operation, left_id, right_id, end_day_offset, catalog)``
  returns a checked ``CalculationSpec`` dictionary, without a model-written value.

Rebuild the catalog from the CURRENT passages for every proposal. A handle binds
the reference, entire passage (including metadata), exact span and row contents;
editing any part of its passage invalidates its old handles. An old catalog is a
snapshot, not a live freshness check. Callers must never accept model-made catalogs.

Evidence quotes preserve complete sentences/lines, including negation. Quantities
retain those quotes; they do not establish facts, applicable units, events, or the
right operation. Those semantic decisions still belong to the evidence guard.
Percentages stay in evidence but have no quantity handle: the calculator has no
percentage operand type, so silently turning a percentage into a count is unsafe.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import re

from calculation_checks import (
    _CLOCK_VALUE, _DECIMAL_VALUE, _SOURCE_CLOCK, _SOURCE_NUMBER,
    evaluate_calculations,
)
from numeric_provenance import _NUMBER, _TIME


__all__ = ['EvidenceHandleError', 'build_catalog', 'resolve_evidence',
           'resolve_calculation']

# Keep decimal points, clock colons, commas and semicolons inside their sentence.
# Numeric spans also protect e.g. "5\npercent" against splitting its unit away.
_SENTENCE_END = re.compile(r'(?:[。！？!?]+|\.(?!\d))["\'”’）)\]]*|[\r\n]+')
_PERCENT_SUFFIX = re.compile(r'\s*(?:[%％‰‱]|percent(?:age)?\b)', re.IGNORECASE)


class EvidenceHandleError(ValueError):
    """An invalid catalog, unknown/stale handle, or unsupported calculation."""


def _digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def _handle(prefix, row):
    return prefix + _digest(row)[:20]


def _insert(section, prefix, row):
    handle = _handle(prefix, row)
    if handle in section and section[handle] != row:
        raise EvidenceHandleError('handle digest collision; cannot build an unambiguous catalog')
    section[handle] = row
    return handle


def _literal_spans(text):
    """Reuse provenance token boundaries without weakening calculator syntax."""
    clocks = list(_TIME.finditer(text))
    spans = [(match, 'clock') for match in clocks]
    spans.extend((match, 'number') for match in _NUMBER.finditer(text)
                 if not any(match.start() < clock.end() and match.end() > clock.start()
                            for clock in clocks))
    return sorted(spans, key=lambda item: item[0].start())


def _sentences(text, literals):
    start = 0
    for match in _SENTENCE_END.finditer(text):
        end = match.end()
        if any(token.start() < end < token.end() for token, _ in literals):
            continue
        left, right = start, end
        while left < right and text[left].isspace():
            left += 1
        while right > left and text[right - 1].isspace():
            right -= 1
        if left < right:
            yield left, right
        start = end
    left, right = start, len(text)
    while left < right and text[left].isspace():
        left += 1
    while right > left and text[right - 1].isspace():
        right -= 1
    if left < right:
        yield left, right


def _value(token, kind, text):
    raw = token.group()
    if kind == 'clock':
        return raw if _CLOCK_VALUE.fullmatch(raw) and _SOURCE_CLOCK.fullmatch(raw) else None
    # Tokenization includes ASCII %/percent. Check other explicit percent symbols
    # too, without trying to infer any textual unit or quantity's meaning.
    if re.search(r'(?:%|percent)\s*$', raw, re.IGNORECASE):
        return None
    if _PERCENT_SUFFIX.match(text, token.end()):
        return None
    if token.start() and text[token.start() - 1] in '%％‰‱':
        return None
    normalized = raw.replace('\u2212', '-').replace(',', '')
    if (_DECIMAL_VALUE.fullmatch(normalized)
            and _SOURCE_NUMBER.fullmatch(raw.replace('\u2212', '-'))):
        return normalized
    return None


def build_catalog(passages):
    """Build fresh, deterministic handles from arrived passage dictionaries.

    Every row includes ``source_meta`` (a deep copy of all non-text passage
    fields), ``passage_digest``, and character offsets ``start``/``end`` into the
    original passage. Quantity offsets locate ``literal``; their ``quote`` is the
    containing evidence sentence. ``value`` is the calculator-compatible literal
    (commas removed and Unicode minus normalized), never an inferred quantity.
    Only exact 24-hour HH:MM and bounded plain decimals supported by the current
    calculator are exposed. Unsupported literals remain visible in evidence.
    Sentences longer than its 1200-character operand limit get evidence handles
    but no quantity handles; they are never truncated to drop context.
    """
    if not isinstance(passages, dict):
        raise EvidenceHandleError('passages must be an arrived passage catalog')
    evidence, quantities = {}, {}
    for ref, passage in passages.items():
        if (not isinstance(ref, str) or not ref or not isinstance(passage, dict)
                or not isinstance(passage.get('text'), str)):
            raise EvidenceHandleError('each passage requires a nonempty ref and text string')
        try:
            passage_digest = _digest(passage)
        except (TypeError, ValueError) as error:
            raise EvidenceHandleError('passages must contain finite JSON-safe metadata') from error
        text = passage['text']
        metadata = {key: deepcopy(value) for key, value in passage.items() if key != 'text'}
        literals = _literal_spans(text)
        for start, end in _sentences(text, literals):
            row = {'ref': ref, 'quote': text[start:end], 'start': start, 'end': end,
                   'passage_digest': passage_digest, 'source_meta': deepcopy(metadata)}
            evidence_id = _insert(evidence, 'ev_', row)
            if len(row['quote']) > 1200 or len(ref) > 64:
                continue
            for token, kind in literals:
                if token.start() < start or token.end() > end:
                    continue
                value = _value(token, kind, text)
                if value is None:
                    continue
                quantity = {**deepcopy(row), 'start': token.start(), 'end': token.end(),
                            'evidence_id': evidence_id, 'literal': token.group(),
                            'value': value, 'kind': kind}
                _insert(quantities, 'qty_', quantity)
    return {'evidence': evidence, 'quantities': quantities}


def _lookup(handle, catalog, section, prefix):
    if (not isinstance(catalog, dict) or not isinstance(catalog.get('evidence'), dict)
            or not isinstance(catalog.get('quantities'), dict)):
        raise EvidenceHandleError('catalog must be the current program-built handle catalog')
    if not isinstance(handle, str) or handle not in catalog[section]:
        raise EvidenceHandleError(f'unknown or stale {section} handle: {handle!r}')
    row = catalog[section][handle]
    try:
        valid = isinstance(row, dict) and _handle(prefix, row) == handle
    except (TypeError, ValueError):
        valid = False
    if not valid:
        raise EvidenceHandleError(f'modified or stale {section} handle: {handle!r}')
    return row


def resolve_evidence(ids, catalog):
    """Resolve selected evidence IDs in order, or reject the entire selection.

    No substring matching, aliases, best-effort dropping, or model-supplied quotes
    are accepted. Duplicate IDs are rejected. Returned objects share no mutable
    state with the catalog or the caller's original passages.
    """
    if not isinstance(ids, (list, tuple)):
        raise EvidenceHandleError('evidence IDs must be a list or tuple')
    rows, seen = [], set()
    for handle in ids:
        row = _lookup(handle, catalog, 'evidence', 'ev_')
        if handle in seen:
            raise EvidenceHandleError(f'duplicate evidence handle: {handle}')
        seen.add(handle)
        rows.append({'ref': row['ref'], 'quote': row['quote']})
    # Validate even an empty selection's catalog.
    if not isinstance(catalog, dict) or any(not isinstance(catalog.get(key), dict)
                                            for key in ('evidence', 'quantities')):
        raise EvidenceHandleError('catalog must be the current program-built handle catalog')
    return rows


def resolve_calculation(operation, left_id, right_id, end_day_offset, catalog):
    """Resolve two quantity IDs and return an executable CalculationSpec dict.

    Valid operations/offsets and arithmetic bounds are checked by the existing
    calculator. ``end_day_offset`` must explicitly be integer 0 or 1; its factual
    justification, like the event/unit/operation choice, remains a guard judgment.
    No clock/number coercion or percentage-as-number fallback is performed.
    """
    if type(end_day_offset) is not int or end_day_offset not in (0, 1):
        raise EvidenceHandleError('end_day_offset must be integer 0 or 1')
    kinds = {'add': ('number', 'number'), 'subtract': ('number', 'number'),
             'multiply': ('number', 'number'), 'divide': ('number', 'number'),
             'time_add_minutes': ('clock', 'number'),
             'time_difference_minutes': ('clock', 'clock')}
    if not isinstance(operation, str) or operation not in kinds:
        raise EvidenceHandleError(f'unsupported calculation operation: {operation!r}')
    operands, passages = [], {}
    for handle, expected_kind in zip((left_id, right_id), kinds[operation]):
        quantity = _lookup(handle, catalog, 'quantities', 'qty_')
        evidence = _lookup(quantity['evidence_id'], catalog, 'evidence', 'ev_')
        if (quantity['kind'] != expected_kind
                or any(quantity[key] != evidence[key]
                       for key in ('ref', 'quote', 'passage_digest', 'source_meta'))
                or not evidence['start'] <= quantity['start'] < quantity['end'] <= evidence['end']
                or evidence['quote'][quantity['start'] - evidence['start']:
                                     quantity['end'] - evidence['start']] != quantity['literal']):
            raise EvidenceHandleError(f'quantity handle has incompatible kind or evidence: {handle}')
        operands.append({key: quantity[key] for key in ('ref', 'quote', 'value')})
        # Full quotes are sufficient for the existing exact-substring validator.
        # Joining is internal validation only; no new passage escapes this API.
        passages.setdefault(quantity['ref'], {'text': ''})['text'] += quantity['quote'] + '\n'
    spec = {'operation': operation, 'left': operands[0], 'right': operands[1],
            'end_day_offset': end_day_offset}
    evaluated = evaluate_calculations([spec], passages)
    if not evaluated['ok']:
        raise EvidenceHandleError('; '.join(row['error'] for row in evaluated['diagnostics']))
    return deepcopy(spec)
