"""Run/reopen a native Deep Agents experiment with persisted environment and graph."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import shutil
import sys
import uuid

from langgraph.checkpoint.sqlite import SqliteSaver

from agent import RunContext, build_graph
from config import PRESETS, Settings
from local_runtime import local_model_metadata
from monitor_runtime import RuntimeMonitor
from smoke_model import SmokeModel
from world import WorldStore

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DATASET = ROOT / 'output/research/2026-10-06/pilot-followup'
PACKAGES = ['deepagents', 'langchain', 'langchain-core', 'langchain-openai',
            'langchain-ollama', 'ollama', 'langgraph', 'langgraph-checkpoint-sqlite', 'openai', 'pydantic']


def execution_design(settings):
    if settings.mechanisms.investigation_progress:
        return 'agent_led_visible_investigation_progress'
    if settings.mechanisms.failure_recovery:
        return 'agent_led_bounded_failure_recovery'
    if settings.mechanisms.agent_led:
        return 'agent_led_optional_tools'
    if settings.mechanisms.evidence_interface:
        return 'selected_evidence_interface'
    if settings.mechanisms.answer_contract:
        return 'canonical_answer_contract'
    if settings.mechanisms.stage_acceptance:
        return 'stage_acceptance'
    return 'staged_v4' if settings.mechanisms.orchestration else 'native_loop'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write(path, data):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def source_files():
    own = [HERE / name for name in ['agent.py', 'config.py', 'world.py', 'run.py',
                                  'orchestration.py', 'stage_acceptance.py', 'conclusion_review.py', 'answer_contract.py',
                                  'calculation_checks.py', 'numeric_provenance.py', 'evidence_handles.py',
                                  'calculation_plan.py', 'selected_answer.py', 'agent_led.py', 'agent_led_tools.py',
                                  'providers.py', 'local_runtime.py', 'monitor_runtime.py', 'investigation_progress.py',
                                  'smoke_model.py', 'requirements.lock.txt']]
    reused = [HERE.parent / 'conversation_harness' / name for name in ['runner.py', 'state_baseline.py']]
    return {str(p.relative_to(ROOT)).replace('\\', '/'): p for p in [*own, *reused]}


def fingerprint():
    return {'source_sha256': {key: sha(path) for key, path in source_files().items()},
            'packages': {name: version(name) for name in PACKAGES}}


def add_model_arguments(parser):
    parser.add_argument('--provider', choices=['ollama', 'openai', 'scripted'], default='ollama')
    parser.add_argument('--model', help='Defaults to qwen2.5:14b-instruct locally; gpt-5.6-terra only with --provider openai.')
    parser.add_argument('--reasoning-effort', default='none')
    parser.add_argument('--local-base-url', default='http://127.0.0.1:11434')
    parser.add_argument('--context-window', type=int, default=16384)
    parser.add_argument('--request-timeout', type=float, default=180)


def model_arguments(args):
    return dict(provider=args.provider,
                model=args.model or ('gpt-5.6-terra' if args.provider == 'openai' else Settings().model),
                reasoning_effort=args.reasoning_effort, local_base_url=args.local_base_url,
                context_window=args.context_window, request_timeout=args.request_timeout)


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--preset', choices=list(PRESETS), default='native')
    add_model_arguments(parser)
    parser.add_argument('--case', default='late-scope-change')
    parser.add_argument('--dataset', type=Path, default=DATASET)
    parser.add_argument('--max-calls', type=int, default=24)
    parser.add_argument('--max-tokens', type=int, default=100000)
    parser.add_argument('--max-output-tokens', type=int, default=1000)
    parser.add_argument('--model-latency-ms', type=int, default=250)
    parser.add_argument('--pause-after', choices=['observe', 'frame_task', 'task_acceptance', 'reconcile_cards',
                                                 'investigate', 'plan_evidence', 'collect_planned_evidence',
                                                 'evidence_acceptance', 'materialize_sources',
                                                'compose_candidate', 'validate_candidate', 'commit'])
    parser.add_argument('--resume', type=Path,
                        help='Reopen this run using its saved settings; other settings are ignored.')
    parser.add_argument('--output', type=Path, help='A new, empty run directory.')
    return parser.parse_args(argv)


def main():
    args = parse_args()
    resumed = args.resume is not None
    if resumed:
        folder = args.resume.resolve()
        manifest = read(folder / 'manifest.json')
        if manifest['fingerprint'] != fingerprint():
            raise ValueError('Source or dependency versions changed; resume must use the frozen implementation.')
        provider = manifest['provider']
        settings = Settings(**{**{k: v for k, v in manifest['settings'].items() if k != 'mechanisms'},
                               'provider': provider})
        if provider == 'ollama' and local_model_metadata(settings) != manifest.get('local_model'):
            raise ValueError('Local model or runtime changed; resume must use the recorded model digest and runtime.')
        world = WorldStore(folder / 'world.sqlite')
        if provider != 'scripted' and world.metrics()['pending_or_failed_calls']:
            world.close()
            raise RuntimeError('This run contains failed or unfinished model calls. Automatic resume is disabled because their outcome may be unknown; preserve this run for inspection.')
    else:
        settings = Settings(preset=args.preset, **model_arguments(args),
                            max_calls=args.max_calls, max_tokens=args.max_tokens,
                            max_output_tokens=args.max_output_tokens, model_latency_ms=args.model_latency_ms)
        if args.provider == 'scripted' and settings.mechanisms.orchestration:
            raise ValueError('The legacy scripted model does not implement staged JSON outputs. Use test_orchestration.py for offline orchestration checks.')
        if min(settings.max_calls, settings.max_tokens, settings.max_output_tokens) <= 0:
            raise ValueError('Budgets must be positive')
        local_model = local_model_metadata(settings) if args.provider == 'ollama' else None
        cases = read(args.dataset / 'cases.json')
        case = next((c for c in cases if c['case_id'] == args.case), None)
        if case is None:
            raise ValueError('Unknown case: ' + args.case)
        corpus = read(args.dataset / 'corpus.json')
        stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
        folder = args.output or HERE / 'runs' / f'{stamp}-{args.provider}-{settings.preset}-{args.case}'
        folder = folder.resolve()
        folder.mkdir(parents=True, exist_ok=False)
        provider = args.provider
        manifest = {'created_at': datetime.now(timezone.utc).isoformat(), 'provider': provider,
                    'local_model': local_model,
                    'thread_id': str(uuid.uuid4()), 'case_id': args.case, 'settings': settings.to_dict(),
                    'fingerprint': fingerprint(), 'dataset': str(args.dataset.resolve()),
                    'dataset_sha256': {name: sha(args.dataset / name) for name in ['cases.json', 'corpus.json']},
                    'implementation': 'create_deep_agent nested in LangGraph; single investigator profile',
                    'execution_design': execution_design(settings),
                    'checkpoint_durability': 'sync' if settings.mechanisms.stage_acceptance or settings.mechanisms.agent_led else 'async',
                    'scripted_is_quality_evidence': False,
                    'token_budget': 'Known usage checked before each request; a final request can overshoot. Unknown usage is reported.',
                    'time': 'Simulated model/tool/event time; API wall time is reported separately.'}
        write(folder / 'manifest.json', manifest)
        write(folder / 'fixture.json', {'case': case, 'corpus': corpus})
        for key, path in source_files().items():
            dest = folder / 'source' / key
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, dest)
        world = WorldStore(folder / 'world.sqlite', case, corpus, settings.model_latency_ms)
    failure = None
    monitor = RuntimeMonitor(folder, resumed=resumed, metadata={
        'provider': provider, 'model': SmokeModel.model_fields['model_name'].default if provider == 'scripted' else settings.model,
        'preset': settings.preset, 'case_id': manifest['case_id'],
        'thread_id': manifest['thread_id'],
        'execution_mode': 'scripted_graph' if provider == 'scripted' else 'model_graph',
    })
    try:
        with SqliteSaver.from_conn_string(str(folder / 'checkpoints.sqlite')) as saver:
            model = SmokeModel() if provider == 'scripted' else None
            graph, native, accounting = build_graph(world, settings, saver, model=model,
                interrupt_after=[args.pause_after] if args.pause_after else [])
            monitor.export_graph(graph, native, fingerprint=manifest['fingerprint'])
            config = {'configurable': {'thread_id': manifest['thread_id']},
                      'callbacks': [accounting, monitor], 'recursion_limit': settings.recursion_limit}
            previous = graph.get_state(config)
            try:
                if not resumed or previous.next:
                    graph.invoke(None if resumed else {'messages': [], 'event_cursor': -1},
                                 config=config, context=RunContext(),
                                 durability='sync' if settings.mechanisms.stage_acceptance or settings.mechanisms.agent_led else 'async')
                elif not previous.values:
                    # Creation can fail before the first graph checkpoint.
                    graph.invoke({'messages': [], 'event_cursor': -1}, config=config, context=RunContext(),
                                 durability='sync' if settings.mechanisms.stage_acceptance or settings.mechanisms.agent_led else 'async')
            except Exception as error:
                failure = type(error).__name__
                # Provider error bodies may contain request details; export only their class.
                world.record('run_error', error_type=failure)
            state = graph.get_state(config)
            if not failure and state.values.get('stop_reason') == 'invalid_task_frame':
                failure = 'InvalidTaskFrame'
                world.record('run_error', error_type=failure)
            exported = world.export()
            for key in ['environment_log', 'model_calls', 'tool_calls']:
                write(folder / f'{key}.json', exported[key])
            snapshot = world.snapshot()
            result = {'status': 'error' if failure else 'paused' if state.next else 'completed',
                      'error_type': failure, 'stop_reason': state.values.get('stop_reason'),
                      'next_nodes': list(state.next), 'provider': provider, 'preset': settings.preset,
                       'execution_design': execution_design(settings),
                       'checkpoint_durability': 'sync' if settings.mechanisms.stage_acceptance or settings.mechanisms.agent_led else 'async',
                      'simulated_at_ms': world.now, 'close_at_ms': world.close_at_ms,
                      **exported['metrics'],
                      'known_token_budget_overshoot': max(0, exported['metrics']['token_usage']['total_tokens'] - settings.max_tokens),
                      'model_usage_missing': sum(not call['usage'] for call in exported['model_calls']),
                      'domain_tool_counts': dict(Counter(t['name'] for t in exported['tool_calls'])),
                      'cards': snapshot['cards'], 'notes': snapshot['notes'],
                      'outer_graph_nodes': sorted(graph.get_graph().nodes),
                      'native_graph_nodes': sorted(native.get_graph().nodes),
                      'checkpoints': len(list(saver.list({'configurable': {'thread_id': manifest['thread_id']}}))),
                      'checkpoint_id': state.config.get('configurable', {}).get('checkpoint_id'),
                      'message_count': len(state.values.get('messages', [])),
                      'quality_score': None}
            if settings.mechanisms.orchestration:
                result['orchestration_state'] = {
                    key: value for key, value in state.values.items()
                    if key not in {'messages', 'files', 'todos'}
                }
        write(folder / 'summary.json', result)
        monitor.finish(result['status'], **{key: result[key] for key in [
            'stop_reason', 'error_type', 'next_nodes', 'model_calls', 'token_usage', 'simulated_at_ms']})
        print(json.dumps({'run': str(folder), **result}, ensure_ascii=False, indent=2))
    except BaseException as error:
        monitor.finish('error', error_type=type(error).__name__)
        raise
    finally:
        monitor.finish('error', error_type='RunDidNotFinish')
        world.close()
    return 1 if failure else 0


if __name__ == '__main__':
    sys.exit(main())
