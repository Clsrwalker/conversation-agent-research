"""Best-effort, metadata-only observation of a real LangGraph execution.

This callback never changes graph state, tool inputs, budgets or decisions. It
writes only monitor files, not the world ledger or graph checkpoint. Failure to
write telemetry must not turn a successful agent run into a failed run.
"""
from __future__ import annotations

from datetime import datetime, timezone
from functools import wraps
import json
import os
from pathlib import Path
from threading import Event, RLock, Thread
import time
import uuid

from langchain_core.callbacks import BaseCallbackHandler


SCHEMA_VERSION = 1
TERMINAL_STATUSES = {'paused', 'completed', 'error'}


def _now():
    return datetime.now(timezone.utc).isoformat()


def _nonfatal(method):
    @wraps(method)
    def wrapped(self, *args, **kwargs):
        try:
            return method(self, *args, **kwargs)
        except Exception as error:
            with self._lock:
                self._telemetry_errors += 1
                self._last_telemetry_error = type(error).__name__
            return None
    return wrapped


def _name(serialized=None, explicit=None):
    if explicit:
        return str(explicit)
    if isinstance(serialized, dict):
        if serialized.get('name'):
            return str(serialized['name'])
        if isinstance(serialized.get('id'), list) and serialized['id']:
            return str(serialized['id'][-1])
    return None


class RuntimeMonitor(BaseCallbackHandler):
    """Persist actual callbacks and wall-clock liveness, without model content."""

    raise_error = False
    run_inline = True

    def __init__(self, folder, *, metadata=None, resumed=False, heartbeat_seconds=1.0):
        self.folder = Path(folder)
        self._lock = RLock()
        self._stop = Event()
        self._thread = None
        self._telemetry_errors = 0
        self._last_telemetry_error = None
        self._chains = {}
        self._models = {}
        self._tools = {}
        self._seq = 0
        self._finished = False
        self._status = 'running'
        self._terminal = {}
        self._session_id = str(uuid.uuid4())
        self._started_at = self._session_started_at = _now()
        self._last_event_at = None
        self._resume_count = 0
        # Do not accept arbitrary model requests or private settings as metadata.
        self._metadata = {key: value for key, value in (metadata or {}).items()
                          if key in {'provider', 'model', 'preset', 'case_id',
                                     'execution_mode', 'thread_id'}}
        self._heartbeat_seconds = max(0.01, float(heartbeat_seconds))
        self._initialize(resumed)
        self._start_heartbeat()

    @_nonfatal
    def _initialize(self, resumed):
        with self._lock:
            self.folder.mkdir(parents=True, exist_ok=True)
            event_path = self.folder / 'monitor_events.jsonl'
            if event_path.exists():
                with event_path.open(encoding='utf-8') as stream:
                    for line in stream:
                        try:
                            self._seq = max(self._seq, int(json.loads(line).get('seq', 0)))
                        except (ValueError, TypeError, json.JSONDecodeError):
                            continue
                # Preserve a possibly interrupted final line; start the next
                # event on its own line rather than corrupting the new event.
                if event_path.stat().st_size:
                    with event_path.open('rb') as stream:
                        stream.seek(-1, os.SEEK_END)
                        needs_newline = stream.read(1) != b'\n'
                    if needs_newline:
                        with event_path.open('a', encoding='utf-8') as stream:
                            stream.write('\n')
            status_path = self.folder / 'runtime_status.json'
            if resumed and status_path.exists():
                try:
                    old = json.loads(status_path.read_text(encoding='utf-8'))
                    self._started_at = old.get('started_at', self._started_at)
                    self._resume_count = int(old.get('resume_count', 0)) + 1
                except (ValueError, TypeError, json.JSONDecodeError):
                    pass
            self._emit('session_started', data={'resumed': bool(resumed)})

    @_nonfatal
    def _start_heartbeat(self):
        self._thread = Thread(target=self._heartbeat, name='agent-runtime-monitor', daemon=True)
        self._thread.start()

    def _heartbeat(self):
        while not self._stop.wait(self._heartbeat_seconds):
            self._flush_status()

    def _atomic_json(self, name, value):
        temporary = self.folder / f'.{name}.{self._session_id}.tmp'
        try:
            with temporary.open('w', encoding='utf-8', newline='\n') as stream:
                json.dump(value, stream, ensure_ascii=False, indent=2)
                stream.write('\n')
                stream.flush()
            os.replace(temporary, self.folder / name)
        finally:
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass

    @_nonfatal
    def _flush_status(self):
        with self._lock:
            now = _now()
            value = {
                'schema_version': SCHEMA_VERSION, 'status': self._status,
                'pid': os.getpid(), 'session_id': self._session_id,
                'started_at': self._started_at, 'session_started_at': self._session_started_at,
                'updated_at': now, 'heartbeat_at': now, 'last_event_at': self._last_event_at,
                'heartbeat_interval_seconds': self._heartbeat_seconds,
                'resume_count': self._resume_count, 'last_event_seq': self._seq,
                'active_nodes': [self._public(value) for value in self._chains.values()
                                 if value['is_node']],
                'active_models': [self._public(value) for value in self._models.values()],
                'active_tools': [self._public(value) for value in self._tools.values()],
                'telemetry_errors': self._telemetry_errors,
                'last_telemetry_error': self._last_telemetry_error,
                **self._metadata, **self._terminal,
            }
            self._atomic_json('runtime_status.json', value)

    @staticmethod
    def _public(value):
        return {key: val for key, val in value.items()
                if key not in {'monotonic_start', 'is_node'}}

    def _emit(self, event, entry=None, data=None):
        self._seq += 1
        timestamp = self._last_event_at = _now()
        record = {
            'schema_version': SCHEMA_VERSION, 'seq': self._seq,
            'timestamp': timestamp, 'session_id': self._session_id, 'event': event,
            'run_id': None, 'parent_run_id': None, 'name': None, 'node': None,
            'graph_namespace': None, **(self._public(entry) if entry else {}),
            'data': data or {},
        }
        try:
            with (self.folder / 'monitor_events.jsonl').open('a', encoding='utf-8', newline='\n') as stream:
                stream.write(json.dumps(record, ensure_ascii=False) + '\n')
        except Exception as error:
            self._telemetry_errors += 1
            self._last_telemetry_error = type(error).__name__
        self._flush_status()

    @staticmethod
    def _entry(run_id, parent_run_id, name, metadata=None, *, is_node=False):
        metadata = metadata or {}
        return {
            'run_id': str(run_id),
            'parent_run_id': str(parent_run_id) if parent_run_id is not None else None,
            'name': name,
            'node': metadata.get('langgraph_node'),
            'graph_namespace': metadata.get('langgraph_checkpoint_ns', metadata.get('checkpoint_ns')),
            'graph_step': metadata.get('langgraph_step'),
            'started_at': _now(), 'monotonic_start': time.perf_counter(), 'is_node': is_node,
        }

    @_nonfatal
    def export_graph(self, graph, investigator, *, fingerprint):
        """Export the graphs actually compiled for this run, not a drawn template."""
        with self._lock:
            value = {
                'schema_version': SCHEMA_VERSION, 'recorded': True,
                'exported_at': _now(),
                'export_source': 'compiled_graph.get_graph().to_json',
                'execution_mode': self._metadata.get('execution_mode'),
                'source_fingerprint': fingerprint,
                'outer': graph.get_graph().to_json(),
                'investigator': investigator.get_graph().to_json(),
                'note': 'Recorded compiled structure. Visited nodes are established by callback events, not this export.',
            }
            self._atomic_json('graph.json', value)
            self._emit('graph_exported', data={'recorded': True})

    @_nonfatal
    def on_chain_start(self, serialized, inputs, *, run_id, parent_run_id=None,
                       metadata=None, **kwargs):
        with self._lock:
            name = _name(serialized, kwargs.get('name'))
            node = (metadata or {}).get('langgraph_node')
            # Nested Runnable wrappers can inherit a node's metadata. Only a
            # callback whose actual name matches that metadata is called a node.
            is_node = bool(node and name == node)
            entry = self._entry(run_id, parent_run_id, name, metadata, is_node=is_node)
            self._chains[str(run_id)] = entry
            self._emit('node_start' if is_node else 'chain_start', entry)

    def _end(self, table, prefix, run_id, error=None, data=None):
        entry = table.pop(str(run_id), None)
        if entry is None:
            entry = self._entry(run_id, None, None)
            extra = {'matching_start_recorded': False}
        else:
            extra = {'matching_start_recorded': True,
                     'duration_ms': round(1000 * (time.perf_counter() - entry['monotonic_start']), 3)}
        if prefix == 'chain' and entry.get('is_node'):
            prefix = 'node'
        if error is not None:
            extra['error_type'] = type(error).__name__
        self._emit(prefix + ('_error' if error is not None else '_end'), entry,
                   {**extra, **(data or {})})

    @_nonfatal
    def on_chain_end(self, outputs, *, run_id, **kwargs):
        with self._lock:
            self._end(self._chains, 'chain', run_id)

    @_nonfatal
    def on_chain_error(self, error, *, run_id, **kwargs):
        with self._lock:
            self._end(self._chains, 'chain', run_id, error)

    @_nonfatal
    def on_chat_model_start(self, serialized, messages, *, run_id,
                            parent_run_id=None, metadata=None, **kwargs):
        with self._lock:
            entry = self._entry(run_id, parent_run_id, _name(serialized, kwargs.get('name')), metadata)
            self._models[str(run_id)] = entry
            self._emit('model_start', entry,
                       {'harness_role': (metadata or {}).get('harness_role', 'investigator')})

    def on_llm_start(self, serialized, prompts, *, run_id, **kwargs):
        self.on_chat_model_start(serialized, None, run_id=run_id, **kwargs)

    @_nonfatal
    def on_llm_end(self, response, *, run_id, **kwargs):
        with self._lock:
            usage = {'input_tokens': 0, 'output_tokens': 0, 'total_tokens': 0}
            usage_present = False
            tool_count = 0
            for batch in response.generations:
                for generation in batch:
                    message = getattr(generation, 'message', None)
                    data = getattr(message, 'usage_metadata', None) or {}
                    usage_present = usage_present or bool(data)
                    for key in usage:
                        usage[key] += int(data.get(key, 0) or 0)
                    tool_count += len(getattr(message, 'tool_calls', None) or [])
            self._end(self._models, 'model', run_id,
                      data={'usage': usage if usage_present else None, 'tool_call_count': tool_count})

    @_nonfatal
    def on_llm_error(self, error, *, run_id, **kwargs):
        with self._lock:
            self._end(self._models, 'model', run_id, error)

    @_nonfatal
    def on_tool_start(self, serialized, input_str, *, run_id,
                      parent_run_id=None, metadata=None, **kwargs):
        with self._lock:
            entry = self._entry(run_id, parent_run_id, _name(serialized, kwargs.get('name')), metadata)
            self._tools[str(run_id)] = entry
            self._emit('tool_start', entry)

    @_nonfatal
    def on_tool_end(self, output, *, run_id, **kwargs):
        with self._lock:
            # A tool may return a message or a JSON string. Extract only status
            # markers; do not copy retrieved text, advice, notes or card content.
            result = getattr(output, 'content', output)
            if isinstance(result, str):
                try:
                    result = json.loads(result)
                except (TypeError, json.JSONDecodeError):
                    result = None
            data = {key: result[key] for key in ('status', 'error_code', 'job_started', 'retryable')
                    if isinstance(result, dict) and key in result}
            self._end(self._tools, 'tool', run_id, data=data)

    @_nonfatal
    def on_tool_error(self, error, *, run_id, **kwargs):
        with self._lock:
            self._end(self._tools, 'tool', run_id, error)

    @_nonfatal
    def finish(self, status, **details):
        # Stop the heartbeat even if a final write cannot be made.
        self._stop.set()
        if self._thread is not None and self._thread.ident is not None:
            self._thread.join(timeout=2)
        self._finish(status, details)

    @_nonfatal
    def _finish(self, status, details):
        with self._lock:
            if self._finished:
                return
            self._finished = True
            self._status = status if status in TERMINAL_STATUSES else 'error'
            self._terminal = {key: value for key, value in details.items()
                              if key in {'stop_reason', 'error_type', 'next_nodes',
                                         'model_calls', 'token_usage', 'simulated_at_ms'}}
            self._terminal['finished_at'] = _now()
            self._chains.clear()
            self._models.clear()
            self._tools.clear()
            self._emit('session_finished', data={'status': self._status, **self._terminal})

