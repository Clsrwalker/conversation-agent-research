"""Request-local progress facts derived exclusively from delivered messages.

This is a projection of the visible context, not a planner or evidence judge.
It cannot access WorldStore, hidden jobs, a benchmark rubric, or provider state.
Compacted history is not reconstructed; omitted history is explicitly unknown.
"""
from __future__ import annotations

from collections import Counter
import json

from langchain.agents.middleware import AgentMiddleware
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage


MARKER = 'investigation-progress-v1'
LIMIT = 6
MAX_FEEDBACK_CHARS = 6000


def _object(message):
    try:
        value = json.loads(message.content)
    except (TypeError, ValueError):
        return {}
    return value if isinstance(value, dict) else {}


def _short(value):
    text = str(value)
    return text if len(text) <= 180 else text[:180] + ' [truncated]'


def _window(rows):
    return {'recent': rows[-LIMIT:], 'omitted': max(0, len(rows) - LIMIT)}


def project_progress(messages):
    """Summarize facts in order; unmatched/unreturned tool calls are not receipts."""
    calls, receipts, events = {}, set(), set()
    attempts, sources, jobs, searches, cards = [], {}, {}, [], {}
    exact_queries = []
    publication = Counter()
    cursor = revision = None
    for message in messages:
        if isinstance(message, AIMessage):
            calls.update({call['id']: call for call in message.tool_calls})
        elif isinstance(message, HumanMessage) and (message.id or '').startswith('observation-'):
            payload = _object(message)
            try:
                cursor = int(message.id[len('observation-'):])
            except ValueError:
                continue
            revision = payload.get('context_revision')
            if isinstance(payload.get('active_cards'), dict):
                cards = dict(payload['active_cards'])
            # This snapshot is authoritative only for the delivered observation.
            pending = payload.get('pending_jobs', [])
            pending_ids = {job['job_id'] for job in pending if 'job_id' in job}
            for job_id, job in jobs.items():
                if job['status'] == 'pending' and job_id not in pending_ids:
                    job['status'] = 'not_pending_in_observation'
            for job in pending:
                if 'job_id' in job:
                    jobs.setdefault(job['job_id'], {}).update(
                        operation=job.get('operation'), status='pending')
            for event in payload.get('events', []):
                seq = event.get('seq')
                if not isinstance(seq, int) or seq > cursor or seq in events:
                    continue
                events.add(seq)
                if event.get('kind') != 'job_result':
                    continue
                job_id, operation = event.get('job_id'), event.get('operation')
                result = event.get('result', {})
                if not isinstance(result, dict):
                    continue
                if job_id:
                    jobs.setdefault(job_id, {}).update(operation=operation, status='arrived')
                if operation == 'search':
                    rows = result.get('sources', [])
                    ids = sorted({row['source_id'] for row in rows if 'source_id' in row})
                    searches.append({'job_id': job_id, 'source_ids': ids})
                    for row in rows:
                        source_id = row.get('source_id')
                        if source_id and sources.get(source_id, {}).get('level') != 'full':
                            sources[source_id] = {'source_id': source_id, 'level': 'snippet',
                                                  'truncated': row.get('truncated', 'unknown')}
                elif operation == 'read' and 'source_id' in result and 'text' in result:
                    source_id = result['source_id']
                    sources[source_id] = {'source_id': source_id, 'level': 'full', 'truncated': False}
        elif isinstance(message, ToolMessage):
            call_id = message.tool_call_id
            if call_id in receipts or call_id not in calls:
                continue
            call, result = calls[call_id], _object(message)
            if message.name is not None and message.name != call['name']:
                continue
            receipts.add(call_id)
            name, args = call['name'], call.get('args', {})
            if name in {'search', 'read_document'}:
                argument = args.get('query' if name == 'search' else 'source_id', '')
                if name == 'search' and isinstance(argument, str):
                    exact_queries.append(argument)
                if not isinstance(argument, str):
                    argument = f'[invalid argument type: {type(argument).__name__}]'
                outcome = result.get('error_code') or result.get('status') or ('error' if 'error' in result else 'unknown')
                attempt = {'tool': name, 'argument': argument, 'outcome': outcome}
                job_id = result.get('job_id')
                if job_id:
                    attempt['job_id'] = job_id
                    jobs.setdefault(job_id, {}).update(
                        operation='search' if name == 'search' else 'read',
                        argument=argument, status=outcome)
                attempts.append(attempt)
            elif name == 'cancel_job' and result.get('status') == 'cancelled':
                job_id = args.get('job_id')
                if job_id:
                    jobs.setdefault(job_id, {}).update(status='cancelled')
            elif name in {'publish_card', 'withdraw_card'}:
                status, card_id = result.get('status', 'unknown'), result.get('card_id')
                publication[f'{name}:{status}'] += 1
                if status == 'conflict' and card_id and 'current_card' in result:
                    if result['current_card'] is None:
                        cards.pop(card_id, None)
                    elif isinstance(result['current_card'], dict):
                        cards[card_id] = result['current_card']
                elif name == 'publish_card' and status in {'displayed', 'unchanged'}:
                    if card_id and isinstance(result.get('committed_card'), dict):
                        cards[card_id] = result['committed_card']
                elif name == 'withdraw_card' and status == 'withdrawn':
                    cards.pop(args.get('card_id'), None)

    query_counts = Counter(exact_queries)
    result_sets = Counter(tuple(row['source_ids']) for row in searches)
    recent_searches = []
    for row in searches:
        ids = row['source_ids']
        recent_searches.append({
            'job_id': _short(row['job_id']), 'source_ids': [_short(i) for i in ids[:LIMIT]],
            'omitted_source_ids': max(0, len(ids) - LIMIT),
            'same_id_set_arrivals': result_sets[tuple(ids)],
            'query': _short(jobs.get(row['job_id'], {}).get('argument', 'unknown in visible context'))})
    projection = {
        'kind': MARKER,
        'meaning': ('Activity in the visible message context only. Compacted or absent history is unknown. '
                    'Same source IDs do not mean unchanged text or sufficient evidence. '
                    'These facts do not judge usefulness or require an action. '
                    'Private prose is not a displayed card.'),
        'observation_cursor': cursor, 'conversation_revision': revision,
        'retrieval_attempts': len(attempts),
        'exact_query_repeats': sum(max(0, count - 1) for count in query_counts.values()),
        'attempts': _window([{key: _short(value) for key, value in row.items()} for row in attempts]),
        'search_arrivals': _window(recent_searches),
        'arrived_sources': _window([{**row, 'source_id': _short(row['source_id'])} for row in sources.values()]),
        'pending_jobs': _window([{'job_id': _short(job_id), 'operation': row.get('operation', 'unknown'),
                                 'argument': _short(row.get('argument', 'unknown in visible context'))}
                                for job_id, row in jobs.items() if row['status'] == 'pending']),
        'active_card_ids': _window([_short(card_id) for card_id in cards]),
        'publication_outcomes': dict(sorted(publication.items())),
    }
    # The upstream summarizer cannot count a downstream transient addition.
    # Bound this block without deleting any original message or source passage.
    windows = [value for value in projection.values() if isinstance(value, dict) and 'recent' in value]
    while len(json.dumps(projection, ensure_ascii=False, separators=(',', ':'))) > MAX_FEEDBACK_CHARS:
        populated = [value for value in windows if value['recent']]
        if not populated:
            raise ValueError('Progress metadata exceeded its bounded representation')
        largest = max(populated, key=lambda value: len(json.dumps(value['recent'], ensure_ascii=False)))
        largest['recent'].pop(0)
        largest['omitted'] += 1
    return projection


class InvestigationProgress(AgentMiddleware):
    """Add one transient data message to an already scheduled model request."""

    def wrap_model_call(self, request, handler):
        feedback = HumanMessage(id=MARKER, content=json.dumps(
            project_progress(request.messages), ensure_ascii=False, separators=(',', ':')))
        return handler(request.override(messages=[*request.messages, feedback]))
