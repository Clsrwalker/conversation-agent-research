"""B1: structured working notes, with schema/provenance checks only."""
import copy

POLICY = """
For this configuration, save_notes stores a structured investigation record.
When starting an investigation, record its current question and conditions.
As evidence or the question changes, update findings, evidence IDs and unresolved
gaps before publishing a result. Use the record to decide the next useful query
or when to stop. Preserve distinctions between current facts and past decisions.
Use only arrived source IDs. A structurally valid record is not proof that its
claims are correct: review the evidence and the current conversation yourself.
"""

TEXT = {"type":"string"}
TEXTS = {"type":"array","items":TEXT}
FIELDS = {
    "question":TEXT,
    "conditions":TEXTS,
    "findings":{"type":"array","items":{"type":"object","properties":{
        "claim":TEXT,"status":{"type":"string","enum":["supported","conflicting","unresolved"]},
        "evidence_ids":TEXTS},"required":["claim","status","evidence_ids"],"additionalProperties":False}},
    "gaps":TEXTS,
    "next_step":TEXT,
}


def configure(instructions, tools, baseline):
    if baseline == "B0":
        return instructions, tools
    if baseline != "B1":
        raise ValueError("Unsupported baseline")
    configured=copy.deepcopy(tools)
    note=next(t for t in configured if t["name"]=="save_notes")
    note["description"]="Replace structured working notes: current question, conditions, findings with evidence IDs, gaps and next step. Not user-visible."
    note["parameters"]["properties"]["notes"]={"type":"object","properties":FIELDS,
        "required":list(FIELDS),"additionalProperties":False}
    return instructions+POLICY, configured


def validate(notes, visible_sources):
    if not isinstance(notes,dict) or set(notes)!=set(FIELDS):
        return "Structured notes require question, conditions, findings, gaps and next_step."
    if not isinstance(notes["question"],str) or not isinstance(notes["next_step"],str):
        return "Question and next_step must be strings."
    for key in ("conditions","gaps"):
        if not isinstance(notes[key],list) or any(not isinstance(v,str) for v in notes[key]):
            return f"{key} must be a list of strings."
    if not isinstance(notes["findings"],list):
        return "Findings must be a list."
    for finding in notes["findings"]:
        if not isinstance(finding,dict) or set(finding)!={"claim","status","evidence_ids"}:
            return "Each finding requires claim, status and evidence_ids."
        if not isinstance(finding["claim"],str) or finding["status"] not in ("supported","conflicting","unresolved"):
            return "Invalid finding claim or status."
        ids=finding["evidence_ids"]
        if not isinstance(ids,list) or any(not isinstance(v,str) for v in ids):
            return "Evidence IDs must be a list of strings."
        if any(v not in visible_sources for v in ids):
            return "Finding cites a source that has not arrived."
    return None
