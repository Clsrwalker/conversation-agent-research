# Investigation progress experiment

Protocol written 8 October 2026 before held-out cases or answers are inspected.
This is a small controlled replay study, not a claim about real meetings or ASR.

## Question and intervention

Can a factual view of investigation progress help an agent decide whether to
continue, change its approach, publish useful help, or remain silent?

Compare A, `agent-led-recovery`, with B, `agent-led-progress`. Both use the same
native Deep Agents investigator, event delivery, optional failure continuation,
tools, private final prose, publication checks and base instructions. B adds one
request-local message before each existing investigator inference. It summarizes
only delivered messages still in that request: exact query repetition, arrived
source IDs and snippet/full status, pending jobs, and publication outcomes.
There is no new planner, forced step, evidence verdict, answer format, automatic
publication, additional continuation or budget reset. No new budget information
is supplied. The private-prose/card distinction repeats an existing instruction.

The projection cannot read the world database. It does not reconstruct compacted
history or classify an identical source-ID set as semantically redundant. Recent
rows and strings are bounded, with omissions labelled. Its 6,000-character cap
limits added context; this is a character bound, not a guaranteed token bound.
Projection tokens and any context compression remain part of B's cost.

## Data and freezing

The six old scenarios are exposed development material. Audit browser repeated
searches, route snippet-based errors, and the later power-specification no-card
run separately. Repeat these three diagnostic situations once per arm to examine
whether previously observed failures recur; do not pool them with held-out data.

An independent author prepares two development and ten new held-out scenarios
(seven requiring help, three requiring silence). Held-out answers and contents
are not read by the implementer until the mechanism, protocol and source hashes
are frozen. Cases include sufficient short evidence, a need for further reading,
query changes, useful uncertainty, delayed evidence and scope changes, plus
already-resolved needs, preferences and incidental mentions. No correct tool
sequence is required. Reference labels stay outside runtime inputs.

Use development cases for integration and limited diagnosis. Record changes and
all runs. Freeze source, prompts, data, model digest and dependencies before the
held-out batch. If a substantive defect requires changing the mechanism after
looking at held-out outcomes, label that batch exploratory and obtain new cases.

## Shared run conditions

Local Ollama Qwen2.5 14B Instruct, temperature 0, context 16,384, maximum 24 model
calls, soft 120,000 reported tokens and 1,200 output tokens per call. Virtual model
latency is 250 ms. Source latency, conversation timeline and deadline are fixed
per case. No paid fallback. Run serially on one GPU, interleaving arms with order
counterbalanced by case and repetition. Run each held-out case twice per arm:
40 runs total. Repeats measure variability; there are still only ten scenarios.

All calls, including optional reviews and summarization, use shared accounting.
The token limit is checked before calls and may be exceeded by the final call.
Record failures and unknown usage without selective retries. Preserve every run
directory and source snapshot. A valid completed run may correctly be silent,
miss useful help, or display a wrong answer.

## Evaluation

Primary help score: the current displayed result at the predeclared deadline
must address the final relevant need, include the required conclusions or useful
qualified uncertainty, and contain no material claim that is false or unsupported
by applicable arrived evidence. Serious extra errors invalidate success. A
private correct answer is not displayed help. Count each scenario opportunity
once per run, not once per card. Report help successes, missed help and material
wrong/unsupported publications separately; report any transient wrong or stale
card even if later corrected.

For silence cases, success requires no unnecessary card during the observation
window. Do not reward more tool calls, full reads or cards by themselves.
Use frozen case-specific rubrics and two independent, arm-anonymous AI reviews;
retain their disagreement and any adjudication. This is not a human assessment.

Report per-case outcomes and both repeats, alongside scenario-paired aggregate
counts. Do not present 40 runs as 40 independent scenarios or claim statistical
significance. Secondary measures: exact repeated queries, full-read arrivals,
searches, publications, tool failures, model calls, actual tokens, wall time,
budget exits, and whether progress was present in requests. Simulated time is
not real-time latency. Failures need chronological trace inspection.

This two-arm test evaluates the complete factual projection, not the separate
causal effects of query history, source status and publication reminders. A
positive result would motivate a targeted ablation; a null/negative result is
also a valid outcome. It does not establish performance on noisy ASR, live web
sources, long-term memory, real users, or other models.

## Validation and reporting

Test causal isolation, incomplete tool receipts, pending versus arrived reads,
source-level preservation, identical-ID semantics, bounded context, inner-loop
refresh, paired tool batches, private silence, unchanged controls, and recovery
from checkpoints. Scripted tests establish execution properties only.
Publish measured results and engineering checks on the existing research site,
retaining frozen baseline records and explicitly separating diagnostics.
