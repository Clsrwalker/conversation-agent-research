"""Verify the frozen study and persisted run artifacts without rerunning models."""
from pathlib import Path
import json

from run import fingerprint, read, sha, write


def main():
    root = Path(__file__).resolve().parent
    batch = root / 'benchmarks/results/local14-progress-heldout-v1'
    freeze = read(root / 'benchmarks/INVESTIGATION_PROGRESS_FREEZE_v1.json')
    manifest = read(batch / 'batch_manifest.json')
    results = read(batch / 'batch_results.json')
    assert len(results) == len(manifest['jobs']) == 40
    assert all(row['exit_code'] == 0 for row in results)
    assert manifest['fingerprint'] == freeze['fingerprint'] == fingerprint()
    assert manifest['batch_runner_sha256'] == freeze['runner_sha256'] == sha(root / 'bench.py')
    assert manifest['evaluation_protocol_sha256'] == freeze['protocol_sha256']
    assert sha(batch / 'evaluation_protocol.md') == freeze['protocol_sha256']
    for name, digest in manifest['dataset_sha256'].items():
        assert sha(Path(manifest['dataset']) / name) == digest
    source_checks = 0
    for job in manifest['jobs']:
        folder = batch / job['directory']
        run, summary = read(folder / 'manifest.json'), read(folder / 'summary.json')
        calls, tools = read(folder / 'model_calls.json'), read(folder / 'tool_calls.json')
        assert run['fingerprint'] == manifest['fingerprint']
        assert run['local_model'] == manifest['local_model']
        assert run['dataset_sha256'] == manifest['dataset_sha256']
        assert summary['status'] == 'completed' and summary['error_type'] is None
        assert summary['model_calls'] == len(calls)
        assert summary['model_calls'] <= manifest['max_calls']
        assert summary['model_usage_missing'] == 0 and summary['pending_or_failed_calls'] == 0
        for key in ('input_tokens','output_tokens','total_tokens'):
            assert summary['token_usage'][key] == sum(row[key] for row in calls)
        assert len({row['call_id'] for row in tools}) == len(tools)
        settings = run['settings']
        assert settings['max_calls'] == 24 and settings['max_tokens'] == 120000
        assert settings['max_output_tokens'] == 1200 and settings['context_window'] == 16384
        assert settings['provider'] == 'ollama'
        for name, digest in run['fingerprint']['source_sha256'].items():
            assert sha(folder / 'source' / name) == digest
            source_checks += 1
    report = {'passed':True, 'runs_checked':40, 'source_snapshot_hash_checks':source_checks,
              'frozen_code_protocol_runner_data_and_model_match':True,
              'usage_and_calls_match_ledgers':True, 'execution_errors':0,
              'missing_or_unknown_usage':0, 'duplicate_tool_receipts':0,
              'note':'Artifact integrity and execution checks do not establish semantic answer quality.'}
    write(batch / 'verification.json', report)
    print(json.dumps(report))


if __name__ == '__main__':
    main()
