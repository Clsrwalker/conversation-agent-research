"""Export anonymous, model-free scoring packets without prompts, arm names or notes."""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path
import random

from run import read, sha, write


def visible_cards(folder):
    events = read(folder / 'environment_log.json')
    requests = {call['call_id']: call.get('request') for call in read(folder / 'model_calls.json')}
    visible, consumed, cards = {}, {}, []

    def absorb(target, event):
        if event.get('kind') != 'job_result':
            return
        result = event['result']
        if event.get('operation') == 'search':
            for source in result.get('sources', []):
                if target.get(source['source_id'], {}).get('level') != 'full':
                    target[source['source_id']] = {'level': 'snippet', **source}
        elif event.get('operation') == 'read' and 'source_id' in result:
            target[result['source_id']] = {'level': 'full', **result}

    for item in events:
        if item['kind'] == 'model_call_reserved':
            # Actual inputs, not material merely available in the environment.
            # Include all model roles without exposing a reviewer's identity.
            for batch in requests.get(item['call_id']) or []:
                for message in batch:
                    if message.get('type') != 'human' or not isinstance(message.get('content'), str):
                        continue
                    try:
                        packet = json.loads(message['content'])
                    except json.JSONDecodeError:
                        continue
                    if not isinstance(packet, dict):
                        continue
                    for event in packet.get('events', []):
                        absorb(consumed, event)
                    for source_id, value in packet.get('visible_sources', {}).items():
                        if consumed.get(source_id, {}).get('level') != 'full' or value.get('level') == 'full':
                            consumed[source_id] = value
        if item['kind'] == 'environment_event':
            absorb(visible, item['event'])
        if item['kind'] in ['card_created', 'card_updated', 'card_withdrawn']:
            card = {key: value for key, value in item.items() if key not in ['seq']}
            card['visible_evidence_at_this_event'] = copy.deepcopy(visible)
            card['evidence_in_actual_model_inputs_before_publication'] = copy.deepcopy(consumed)
            cards.append(card)
    return cards


def export_batch(batch, output, seed=301019):
    manifest = read(batch / 'batch_manifest.json')
    dataset = Path(manifest['dataset'])
    cases = {case['case_id']: case for case in read(dataset / 'cases.json')}
    corpus = read(dataset / 'corpus.json')
    gold_raw = read(dataset / 'gold.json')
    gold_items = gold_raw if isinstance(gold_raw, list) else gold_raw['cases']
    gold = {case['case_id']: case for case in gold_items}
    jobs = list(manifest['jobs'])
    random.Random(seed).shuffle(jobs)
    output.mkdir(parents=True, exist_ok=False)
    mapping = []
    for index, job in enumerate(jobs, 1):
        folder = batch / job['directory']
        if not (folder / 'summary.json').exists():
            continue
        summary, case = read(folder / 'summary.json'), cases[job['case_id']]
        blind_id = f'item-{index:03d}'
        packet = {'blind_id': blind_id, 'case': case, 'rubric': gold[job['case_id']],
                  'shared_rubric': gold_raw.get('shared_rules', {}) if isinstance(gold_raw, dict) else {},
                  'corpus': [doc for doc in corpus if doc['id'] in case['corpus_ids']],
                  'display_events': visible_cards(folder), 'final_active_cards': summary['cards'],
                  'evaluation_deadline_ms': case['close_at_ms'],
                  'evaluation_rule': 'Cards persist to the fixed deadline even if the agent stops early. Normal assistant prose is never shown. Judge meaning and source applicability, not keyword overlap.',
                  'execution_error': summary['error_type']}
        write(output / f'{blind_id}.json', packet)
        mapping.append({'blind_id': blind_id, **job, 'run_directory': str(folder),
                        'packet_sha256': sha(output / f'{blind_id}.json')})
    # Mapping remains outside the blinded directory.
    write(batch / ('mapping-' + output.name + '.json'), mapping)
    return mapping


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('batch', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    mapping = export_batch(args.batch.resolve(), args.output.resolve())
    print(json.dumps({'packets': len(mapping), 'path': str(args.output.resolve())}))
