"""Analyze saved runs without model calls or reading unrequested benchmark labels.

Usage: progress_analysis.py BATCH_DIR OUTPUT_JSON [--ratings FILE --mapping FILE]
Without ratings, semantic outcomes remain pending. Only explicitly supplied
ratings and their matching review packets may provide help/silence labels.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


MARKER = 'investigation-progress-v1'
SCORE_FLAGS = ('primary_success', 'material_error', 'unnecessary_publication',
               'stale_publication', 'uncertain')
SUM_METRICS = ('model_calls', 'input_tokens', 'output_tokens', 'total_tokens',
               'model_wall_ms', 'budget_overshoot_tokens', 'search_query_count',
               'exact_duplicate_query_count', 'full_read_arrival_count', 'card_count',
               'publication_count', 'model_requests_with_progress', 'progress_message_count',
               'progress_total_chars', 'summary_model_calls', 'usage_missing')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def optional(path):
    return read(path) if path.is_file() else None


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _sum_known(rows, field):
    values = [row[field] for row in rows if row.get(field) is not None]
    return sum(values) if values else None


def _progress(calls):
    if calls is None:
        return {key: None for key in ('model_requests_with_progress', 'progress_message_count',
                                     'progress_max_chars', 'progress_total_chars')}
    request_count, lengths = 0, []
    for call in calls:
        current = []
        for batch in call.get('request') or []:
            for message in batch:
                if message.get('type') != 'human' or message.get('id') != MARKER:
                    continue
                content = message.get('content')
                if not isinstance(content, str):
                    continue
                try:
                    value = json.loads(content)
                except json.JSONDecodeError:
                    continue
                if isinstance(value, dict) and value.get('kind') == MARKER:
                    current.append(len(content))
        request_count += bool(current)
        lengths.extend(current)
    return {'model_requests_with_progress': request_count, 'progress_message_count': len(lengths),
            'progress_max_chars': max(lengths, default=0), 'progress_total_chars': sum(lengths)}


def _summary_calls(calls):
    """Identify the pinned default compaction request even if its role was generic."""
    if calls is None:
        return None
    from deepagents.middleware.summarization import DEEPAGENTS_DEFAULT_SUMMARY_PROMPT
    before, after = DEEPAGENTS_DEFAULT_SUMMARY_PROMPT.format(
        messages='__PROGRESS_ANALYSIS_HISTORY__').split('__PROGRESS_ANALYSIS_HISTORY__')
    count = 0
    for call in calls:
        messages = [message for batch in call.get('request') or [] for message in batch]
        exact_default = (len(messages) == 1 and messages[0].get('type') == 'human'
                         and isinstance(messages[0].get('content'), str)
                         and messages[0]['content'].startswith(before)
                         and messages[0]['content'].endswith(after.rstrip()))
        count += bool('summar' in call.get('role', '').lower() or exact_default)
    return count


def run_metrics(folder, job, manifest, batch_result=None):
    summary = optional(folder / 'summary.json')
    calls = optional(folder / 'model_calls.json')
    tools = optional(folder / 'tool_calls.json')
    events = optional(folder / 'environment_log.json')
    missing = [name for name in ('summary.json', 'model_calls.json', 'tool_calls.json', 'environment_log.json')
               if not (folder / name).is_file()]
    summary, batch_result = summary or {}, batch_result or {}
    has_batch_failure = bool(batch_result) and batch_result.get('exit_code') != 0
    status = summary.get('status') or ('error' if has_batch_failure else 'incomplete' if folder.exists() else 'pending')
    usage = summary.get('token_usage', {})
    counts = {key: (sum(call.get(key, 0) or 0 for call in calls) if calls is not None else usage.get(key))
              for key in ('input_tokens', 'output_tokens', 'total_tokens')}
    model_calls = len(calls) if calls is not None else summary.get('model_calls')
    wall = (sum(call.get('wall_ms', 0) or 0 for call in calls) if calls is not None
            else summary.get('api_wall_ms'))
    role_counts = dict(Counter(call.get('role', 'unknown') for call in calls)) if calls is not None else summary.get('role_counts')
    queries = [tool.get('args', {}).get('query') for tool in tools or [] if tool.get('name') == 'search']
    query_counts = Counter(query for query in queries if isinstance(query, str))
    tool_counts = dict(Counter(tool.get('name', 'unknown') for tool in tools)) if tools is not None else summary.get('domain_tool_counts')
    reads = [event['event'] for event in events or []
             if event.get('kind') == 'environment_event' and event.get('event', {}).get('kind') == 'job_result'
             and event['event'].get('operation') == 'read' and 'text' in event['event'].get('result', {})]
    cards = summary.get('cards')
    if cards is None and events is not None:
        cards = {}
        for event in events:
            if event.get('kind') in {'card_created', 'card_updated'}:
                cards[event['card_id']] = event.get('card', {})
            elif event.get('kind') == 'card_withdrawn':
                cards.pop(event.get('card_id'), None)
    limit = manifest.get('max_tokens_soft')
    overshoot = (max(0, counts['total_tokens'] - limit)
                 if counts['total_tokens'] is not None and isinstance(limit, (int, float))
                 else summary.get('known_token_budget_overshoot'))
    warnings = []
    if calls is not None and summary.get('model_calls') not in (None, len(calls)):
        warnings.append('Summary model-call count differs from the saved call ledger; ledger used.')
    if calls is not None and any(usage.get(key) not in (None, counts[key]) for key in counts):
        warnings.append('Summary token usage differs from the saved call ledger; ledger used.')
    return {
        **{key: job[key] for key in ('preset', 'case_id', 'repeat', 'directory')},
        'status': status, 'stop_reason': summary.get('stop_reason'),
        'error': summary.get('error_type') or batch_result.get('error'),
        'execution_error': status == 'error' or has_batch_failure,
        'model_calls': model_calls, **counts, 'model_wall_ms': round(wall, 3) if wall is not None else None,
        'budget_overshoot_tokens': overshoot, 'budget_stop': summary.get('stop_reason') == 'budget_exhausted',
        'tool_counts': tool_counts, 'role_counts': role_counts,
        'summary_model_calls': _summary_calls(calls),
        'usage_missing': (sum(not call.get('usage') for call in calls) if calls is not None
                          else summary.get('model_usage_missing')),
        'search_query_count': len(queries) if tools is not None else None,
        'distinct_query_count': len(query_counts) if tools is not None else None,
        'exact_duplicate_query_count': sum(count - 1 for count in query_counts.values()) if tools is not None else None,
        'repeated_query_group_count': sum(count > 1 for count in query_counts.values()) if tools is not None else None,
        'full_read_arrival_count': len(reads) if events is not None else None,
        'unique_full_read_sources': len({event['result'].get('source_id') for event in reads}) if events is not None else None,
        'card_count': len(cards) if isinstance(cards, dict) else None,
        'publication_count': sum(event.get('kind') in {'card_created', 'card_updated'} for event in events) if events is not None else None,
        **_progress(calls), 'opportunity_type': None, 'scoring_status': 'pending', 'rating': None,
        'missing_artifacts': missing, 'warnings': warnings,
    }


def _opportunity(value):
    return {'help': 'help', 'required_help': 'help',
            'silence': 'silence', 'silence_control': 'silence'}.get(value)


def _rubric_opportunity(rubric):
    if not isinstance(rubric, dict):
        return None
    explicit = _opportunity(rubric.get('opportunity_type'))
    if explicit:
        return explicit
    if type(rubric.get('intervention_required')) is bool:
        return 'help' if rubric['intervention_required'] else 'silence'
    windows = rubric.get('windows')
    if isinstance(windows, list) and windows and all(type(row.get('intervention_required')) is bool for row in windows):
        return 'help' if any(row['intervention_required'] for row in windows) else 'silence'
    return None


def _packet(identity, ratings_path, mapping_path, batch):
    blind_id = identity['blind_id']
    if not blind_id or any(character not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_' for character in blind_id):
        raise ValueError('Unsafe blind_id')
    candidates = [ratings_path.parent / f'{blind_id}.json', mapping_path.parent / f'{blind_id}.json']
    if mapping_path.stem.startswith('mapping-'):
        candidates.append(batch.parent.parent / 'reviews' / mapping_path.stem[len('mapping-'):] / f'{blind_id}.json')
    if identity.get('packet_path'):
        provided = Path(identity['packet_path'])
        candidates.insert(0, provided if provided.is_absolute() else mapping_path.parent / provided)
    for candidate in candidates:
        if candidate.is_file():
            expected = identity.get('packet_sha256')
            if expected and sha(candidate) != expected:
                raise ValueError('Review packet hash mismatch: ' + blind_id)
            packet = read(candidate)
            if packet.get('blind_id') != blind_id:
                raise ValueError('Review packet identity mismatch: ' + blind_id)
            return packet
    return None


def attach_ratings(rows, ratings_path, mapping_path, batch):
    if mapping_path is None:
        raise ValueError('--ratings requires --mapping')
    ratings, mapping = read(ratings_path), read(mapping_path)
    if not isinstance(ratings, list) or not isinstance(mapping, list):
        raise ValueError('Ratings and mapping must be JSON lists')
    identities, by_directory = {}, {row['directory']: row for row in rows}
    used_directories = set()
    for identity in mapping:
        blind_id, directory = identity['blind_id'], identity['directory']
        if blind_id in identities or directory in used_directories:
            raise ValueError('Duplicate mapping identity')
        if directory not in by_directory:
            raise ValueError('Mapping refers to a job outside this batch')
        row = by_directory[directory]
        if any(identity.get(key) != row[key] for key in ('preset', 'case_id', 'repeat')):
            raise ValueError('Mapping disagrees with the batch manifest')
        identities[blind_id] = identity
        used_directories.add(directory)
    seen, scenario_types = set(), {}
    for original in ratings:
        score = dict(original)
        blind_id = score['blind_id']
        if blind_id in seen or blind_id not in identities:
            raise ValueError('Duplicate or unmapped rating: ' + blind_id)
        seen.add(blind_id)
        # Compatibility with the older review exporter; semantics are unchanged.
        if 'stale_publication' not in score and 'stale_new_publication' in score:
            score['stale_publication'] = score['stale_new_publication']
        if any(type(score.get(key)) is not bool for key in SCORE_FLAGS):
            raise ValueError('Rating flags must be explicit booleans: ' + blind_id)
        identity = identities[blind_id]
        row = by_directory[identity['directory']]
        declared = _opportunity(score.get('opportunity_type'))
        if score.get('opportunity_type') is not None and declared is None:
            raise ValueError('opportunity_type must be required_help/silence_control or help/silence')
        packet = _packet(identity, ratings_path, mapping_path, batch)
        rubric_type = _rubric_opportunity(packet.get('rubric')) if packet else None
        if declared and rubric_type and declared != rubric_type:
            raise ValueError('Rating opportunity_type disagrees with rubric: ' + blind_id)
        opportunity = declared or rubric_type
        if opportunity is None:
            raise ValueError('No explicit help/silence label; supply opportunity_type or matching packet rubric: ' + blind_id)
        if row['case_id'] in scenario_types and scenario_types[row['case_id']] != opportunity:
            raise ValueError('Conflicting opportunity types for one scenario')
        scenario_types[row['case_id']] = opportunity
        row.update(scoring_status='rated', blind_id=blind_id,
                   rating={key: score.get(key) for key in (*SCORE_FLAGS, 'reason', 'evidence_refs')})
    # Share only the reviewed scenario's type across its repeats/arms. No score
    # is invented for missing ratings, and no dataset/gold file is opened.
    for row in rows:
        row['opportunity_type'] = scenario_types.get(row['case_id'])


def _score_group(rows, opportunity):
    group = [row for row in rows if row['opportunity_type'] == opportunity]
    rated = [row for row in group if row['scoring_status'] == 'rated']
    scores = [row['rating'] for row in rated]
    return {
        'independent_scenarios': len({row['case_id'] for row in group}),
        'runs': len(group), 'rated_runs': len(rated), 'pending_runs': len(group) - len(rated),
        'primary_successes': sum(score['primary_success'] for score in scores) if rated else None,
        'missed_help': sum(not score['primary_success'] for score in scores) if rated and opportunity == 'help' else None,
        'no_card_help_runs': sum(row['card_count'] == 0 for row in rated) if rated and opportunity == 'help' else None,
        'any_material_error_runs': sum(score['material_error'] for score in scores) if rated else None,
        'unnecessary_publication_runs': sum(score['unnecessary_publication'] for score in scores) if rated else None,
        'stale_publication_runs': sum(score['stale_publication'] for score in scores) if rated else None,
        'uncertain_runs': sum(score['uncertain'] for score in scores) if rated else None,
    }


def aggregate(rows):
    tools, roles = Counter(), Counter()
    for row in rows:
        tools.update(row['tool_counts'] or {})
        roles.update(row['role_counts'] or {})
    maxima = [row['progress_max_chars'] for row in rows if row['progress_max_chars'] is not None]
    return {
        'runs': len(rows), 'independent_scenarios': len({row['case_id'] for row in rows}),
        'complete_artifact_runs': sum(not row['missing_artifacts'] for row in rows),
        **{field: _sum_known(rows, field) for field in SUM_METRICS},
        'missing_metric_runs': {field: sum(row.get(field) is None for row in rows) for field in SUM_METRICS},
        'budget_stop_runs': sum(row['budget_stop'] for row in rows),
        'execution_error_runs': sum(row['execution_error'] for row in rows),
        'progress_max_chars': max(maxima) if maxima else None,
        'tool_counts': dict(tools), 'role_counts': dict(roles),
        'help': _score_group(rows, 'help'), 'silence': _score_group(rows, 'silence'),
        'unknown_opportunity_runs': sum(row['opportunity_type'] is None for row in rows),
    }


def analyze_batch(batch, *, ratings_path=None, mapping_path=None):
    batch = Path(batch).resolve()
    manifest = read(batch / 'batch_manifest.json')
    results = optional(batch / 'batch_results.json') or []
    by_directory = {row['directory']: row for row in results}
    rows, used, directories = [], set(), set()
    for job in manifest['jobs']:
        directory = job['directory']
        if not directory or '/' in directory or '\\' in directory or directory in {'.', '..'}:
            raise ValueError('Batch jobs must name direct run directories')
        identity = (job['preset'], job['case_id'], job['repeat'])
        if identity in used or directory in directories:
            raise ValueError('Duplicate arm/case/repeat job or run directory')
        used.add(identity)
        directories.add(directory)
        rows.append(run_metrics(batch / directory, job, manifest, by_directory.get(directory)))
    if ratings_path is not None:
        ratings_path = Path(ratings_path).resolve()
        mapping_path = Path(mapping_path).resolve() if mapping_path is not None else None
        attach_ratings(rows, ratings_path, mapping_path, batch)
    elif mapping_path is not None:
        raise ValueError('--mapping is only used together with --ratings')
    arm_names = list(dict.fromkeys(row['preset'] for row in rows))
    reference = 'agent-led-recovery' if 'agent-led-recovery' in arm_names else next(iter(arm_names), None)
    pairs = []
    for case, repeat in sorted({(row['case_id'], row['repeat']) for row in rows}):
        members = {row['preset']: row for row in rows if row['case_id'] == case and row['repeat'] == repeat}
        reference_row = members.get(reference)
        differences = {}
        for arm, row in members.items():
            if arm == reference or reference_row is None:
                continue
            differences[arm] = {field: row[field] - reference_row[field]
                                if row.get(field) is not None and reference_row.get(field) is not None else None
                                for field in SUM_METRICS}
        pairs.append({'case_id': case, 'repeat': repeat, 'opportunity_type': next(iter(members.values()))['opportunity_type'],
                      'reference_arm': reference, 'arms': {arm: row['directory'] for arm, row in members.items()},
                      'complete_pair': len(members) == len(arm_names) and all(not row['missing_artifacts'] for row in members.values()),
                      'outcomes': {arm: {'scoring_status': row['scoring_status'], 'rating': row['rating']} for arm, row in members.items()},
                      'metric_differences_vs_reference': differences})
    rated_count = sum(row['scoring_status'] == 'rated' for row in rows)
    return {
        'schema_version': 1, 'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'batch': batch.name, 'batch_manifest_sha256': sha(batch / 'batch_manifest.json'),
        'analysis_utility_sha256': sha(Path(__file__)),
        'scoring_status': 'pending' if not rated_count else 'complete' if rated_count == len(rows) else 'partial',
        'rating_source': 'Provided semantic ratings; no automatic content grading.' if ratings_path else None,
        'ratings_sha256': sha(ratings_path) if ratings_path else None,
        'mapping_sha256': sha(mapping_path) if mapping_path else None,
        'total_runs': len(rows), 'independent_scenarios': len({row['case_id'] for row in rows}),
        'arms': [{'preset': arm, **aggregate([row for row in rows if row['preset'] == arm])} for arm in arm_names],
        'rows': rows, 'paired_case_repeats': pairs,
        'scenarios': [{'case_id': case, 'arms': {arm: aggregate([row for row in rows if row['case_id'] == case and row['preset'] == arm])
                                               for arm in arm_names}}
                      for case in sorted({row['case_id'] for row in rows})],
        'metric_definitions': {
            'exact_duplicate_query_count': 'Additional exact query-string occurrences in the durable tool ledger, including failed attempts; no lowercasing or whitespace normalization.',
            'full_read_arrival_count': 'Environment read-result arrivals containing text; repeated full reads count separately.',
            'card_count': 'Active cards at the saved final observation; distinct from publication/update event count.',
            'model_requests_with_progress': 'Saved model requests containing the dedicated human message ID and JSON kind; summary text merely mentioning progress is not counted.',
            'summary_model_calls': 'Role-labelled summarization calls or a single human-message request exactly matching the pinned Deep Agents default summary prompt prefix and suffix. Custom unlabelled summarizers may be missed. No private model content is copied to this report.',
            'missed_help': 'Rated help runs that fail the final primary criterion, including missing, incorrect or unsupported help; overlaps any_material_error_runs.',
            'any_material_error_runs': 'Separate reviewer flag for any material error, including a transient error later corrected; it does not overwrite the final primary judgment.',
            'model_wall_ms': 'Sum of recorded model-call wall time, not end-to-end audio latency.',
        },
        'limits': ['Repeats do not increase the number of independent scenarios.',
                   'Help and silence are reported separately; there is no pooled success headline.',
                   'Without supplied ratings, semantic scores and opportunity types remain pending.',
                   'Missing artifacts/usage are reported; failures are not silently excluded.',
                   'No significance, real-ASR or real-user benefit is inferred.'],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('batch_dir', type=Path)
    parser.add_argument('output_json', type=Path)
    parser.add_argument('--ratings', type=Path)
    parser.add_argument('--mapping', type=Path)
    args = parser.parse_args()
    result = analyze_batch(args.batch_dir, ratings_path=args.ratings, mapping_path=args.mapping)
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: result[key] for key in ('batch', 'scoring_status', 'total_runs', 'independent_scenarios')}))


if __name__ == '__main__':
    main()
