"""Offline integration checks for transient investigation progress feedback.

The model doubles use delivered messages, never an in-memory action cursor.
These checks establish routing, visibility, accounting, and persistence behavior;
they do not measure assistance quality or invoke a local/hosted model service.
"""
from __future__ import annotations

import copy
import json
import unittest
from unittest.mock import patch

from langchain.agents.middleware import AgentMiddleware
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from langgraph.checkpoint.sqlite import SqliteSaver

from agent import RunContext, assert_paired
from agent_led import build_agent_led_graph
from config import Settings
from investigation_progress import MARKER
import test_agent_led_graph as protocol
from world import WorldStore


def progress_messages(messages):
    found = []
    for message in messages:
        if not isinstance(message, HumanMessage):
            continue
        try:
            payload = json.loads(message.content)
        except (TypeError, ValueError):
            continue
        if isinstance(payload, dict) and payload.get('kind') == MARKER:
            found.append((message, payload))
    return found


def visible_request(messages):
    """Compare meaningful model inputs, excluding generated message UUIDs."""
    result = []
    for message in messages:
        if progress_messages([message]):
            continue
        item = {'type': message.type, 'content': message.content}
        if isinstance(message, AIMessage):
            item['tool_calls'] = message.tool_calls
        elif isinstance(message, ToolMessage):
            item.update(tool_call_id=message.tool_call_id, name=message.name)
        elif isinstance(message, HumanMessage):
            item['id'] = message.id
        result.append(item)
    return result


class VisibleHistoryModel(protocol.AgentLedModel):
    model_name: str = 'local:investigation-progress-test'

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        if self.scenario == 'parallel_inner_loop':
            self._requests.append(copy.deepcopy(messages))
            assert_paired(messages)
            prior = [call for message in messages if isinstance(message, AIMessage)
                     for call in message.tool_calls]
            names = [call['name'] for call in prior]
            if not prior:
                actions = [('search', {'query': 'Beacon'}),
                           ('save_notes', {'notes': 'Private batch diagnostic.'})]
            elif names.count('search') == 1:
                actions = [('search', {'query': 'Beacon'})]
            else:
                actions = []
            calls = [{'name': name, 'args': args, 'type': 'tool_call',
                      'id': f'progress-batch-{len(prior) + index + 1}'}
                     for index, (name, args) in enumerate(actions)]
            answer = ChatResult(generations=[ChatGeneration(message=AIMessage(
                content='' if actions else 'A private working note.', tool_calls=calls))])
        else:
            answer = super()._generate(messages, stop=stop, run_manager=run_manager, **kwargs)
        # Synthetic but request-sensitive provider usage verifies that the
        # common accounting path includes feedback in the reported input cost.
        input_tokens = sum(max(1, len(str(message.content)) // 4) for message in messages)
        answer.generations[0].message.usage_metadata = {
            'input_tokens': input_tokens, 'output_tokens': 3,
            'total_tokens': input_tokens + 3}
        return answer


class RewriteLikeSummarization(AgentMiddleware):
    """Replace the default summary wrapper without making a summary model call."""

    def __init__(self):
        self.requests = []

    @property
    def name(self):
        return 'SummarizationMiddleware'

    def wrap_model_call(self, request, handler):
        self.requests.append(copy.deepcopy(request.messages))
        observation = {
            'events': [{'kind': 'job_result', 'operation': 'search', 'job_id': 'visible-job',
                        'seq': 499, 'result': {'sources': [
                            {'source_id': 'visible-after-compaction', 'text': 'Visible snippet.'}]}}],
            'pending_jobs': [], 'active_cards': {}, 'context_revision': 1,
        }
        return handler(request.override(messages=[HumanMessage(
            id='observation-500', content=json.dumps(observation))]))


class InvestigationProgressGraphTests(unittest.TestCase):
    setUp = protocol.AgentLedGraphTests.setUp
    tearDown = protocol.AgentLedGraphTests.tearDown
    new_world = protocol.AgentLedGraphTests.new_world
    one_card = protocol.AgentLedGraphTests.one_card

    def build(self, saver, model, *, preset='agent-led-progress', interrupt_after=(),
              extra_middleware=(), max_calls=25):
        return build_agent_led_graph(self.world,
            Settings(preset=preset, model=model.model_name, max_calls=max_calls,
                     max_tokens=250000), saver, model=model,
            extra_middleware=extra_middleware, interrupt_after=interrupt_after)

    def invoke(self, graph, accounting, *, initial=True, messages=None):
        value = {'messages': messages or [], 'event_cursor': -1} if initial else None
        return graph.invoke(value,
            config={'configurable': {'thread_id': 'investigation-progress'},
                    'recursion_limit': 120, 'callbacks': [accounting]},
            context=RunContext(), durability='sync')

    def run_model(self, scenario='retrieve', *, preset='agent-led-progress', max_calls=25):
        self.new_world(scenario)
        model = VisibleHistoryModel(scenario=scenario)
        with SqliteSaver.from_conn_string(':memory:') as saver:
            graph, _, accounting = self.build(saver, model, preset=preset, max_calls=max_calls)
            result = self.invoke(graph, accounting)
        return model, result

    def test_feedback_is_request_only_and_uses_common_call_accounting(self):
        model, result = self.run_model()
        self.assertTrue(model._requests)
        for request in model._requests:
            feedback = progress_messages(request)
            self.assertEqual(len(feedback), 1)
            self.assertIs(feedback[0][0], request[-1])
            assert_paired(request)
        self.assertFalse(progress_messages(result['messages']))
        records = self.world.export()['model_calls']
        self.assertEqual(len(records), len(model._requests))
        for record, request in zip(records, model._requests, strict=True):
            self.assertEqual(sum(message.get('id') == MARKER
                                 for batch in record['request'] for message in batch), 1)
            self.assertEqual(record['input_tokens'],
                             sum(max(1, len(str(message.content)) // 4) for message in request))
        self.assertEqual(self.world.metrics()['role_counts'], {'investigator': len(records)})
        self.assertEqual(self.one_card()['text'], 'Beacon desktop supports offline editing.')

    def test_same_script_preserves_inputs_tools_actions_and_calls_between_arms(self):
        original_root = self.root
        runs = {}
        for preset in ('agent-led-recovery', 'agent-led-progress'):
            self.root = original_root / preset
            model, result = self.run_model(preset=preset)
            exported = self.world.export()
            runs[preset] = {
                'requests': [visible_request(request) for request in model._requests],
                'feedback': [len(progress_messages(request)) for request in model._requests],
                'tools': model._bound_tools,
                'actions': [(row['name'], row['args'], row['result'])
                            for row in exported['tool_calls']],
                'cards': copy.deepcopy(self.world.snapshot()['cards']),
                'input_tokens': exported['metrics']['token_usage']['input_tokens'],
                'stop_reason': result['stop_reason'],
            }
            self.world.close()
        baseline, treatment = runs['agent-led-recovery'], runs['agent-led-progress']
        for field in ('requests', 'tools', 'actions', 'cards', 'stop_reason'):
            self.assertEqual(baseline[field], treatment[field], field)
        self.assertTrue(all(count == 0 for count in baseline['feedback']))
        self.assertTrue(all(count == 1 for count in treatment['feedback']))
        self.assertGreater(treatment['input_tokens'], baseline['input_tokens'])

    def test_inner_tool_loop_refreshes_after_complete_parallel_batch(self):
        model, result = self.run_model('parallel_inner_loop')
        second = model._requests[1]
        self.assertEqual(progress_messages(second)[0][1]['retrieval_attempts'], 1)
        first_batch = next(message for message in second if isinstance(message, AIMessage)
                           and len(message.tool_calls) == 2)
        start = second.index(first_batch)
        self.assertTrue(all(isinstance(message, ToolMessage) for message in second[start + 1:start + 3]))
        self.assertEqual({message.tool_call_id for message in second[start + 1:start + 3]},
                         {call['id'] for call in first_batch.tool_calls})
        third = progress_messages(model._requests[2])[0][1]
        self.assertEqual(third['retrieval_attempts'], 2)
        self.assertEqual(third['exact_query_repeats'], 1)
        self.assertTrue(third['pending_jobs']['recent'])
        self.assertFalse(self.world.snapshot()['cards'])
        self.assertFalse(progress_messages(result['messages']))
        for request in model._requests:
            assert_paired(request)

    def test_private_silence_adds_no_turn_and_minimal_publication_stays_optional(self):
        original_root = self.root
        for scenario in ('private_prose', 'minimal'):
            self.root = original_root / scenario
            model, result = self.run_model(scenario)
            names = [row['name'] for row in self.world.export()['tool_calls']]
            if scenario == 'private_prose':
                self.assertEqual(len(model._requests), 1)
                self.assertFalse(names)
                self.assertFalse(self.world.snapshot()['cards'])
            else:
                self.assertEqual(names, ['publish_card', 'wait'])
                self.assertEqual(self.one_card()['source_ids'], [])
                self.assertFalse({'search', 'read_document', 'calculate', 'evidence_check'} & set(names))
            self.assertEqual(result['stop_reason'], 'window_closed')
            self.world.close()

    def test_budget_exit_does_not_gain_calls_from_progress(self):
        model, result = self.run_model(max_calls=1)
        self.assertEqual(len(model._requests), 1)
        self.assertEqual(self.world.metrics()['model_calls'], 1)
        self.assertEqual(result['stop_reason'], 'budget_exhausted')
        self.assertEqual(len(progress_messages(model._requests[0])), 1)

    def test_outer_checkpoint_reopen_preserves_retrieval_without_feedback_history(self):
        world, model = self.new_world(), VisibleHistoryModel()
        checkpoint = str(self.root / 'progress-resume.sqlite')
        with SqliteSaver.from_conn_string(checkpoint) as saver:
            graph, _, accounting = self.build(saver, model, interrupt_after=['investigate'])
            paused = self.invoke(graph, accounting)
        self.assertFalse(progress_messages(paused['messages']))
        self.assertEqual(sum(row['name'] == 'search' for row in world.export()['tool_calls']), 1)
        world.close()
        self.world = WorldStore(self.root / 'world.sqlite')
        resumed_model = VisibleHistoryModel()
        with SqliteSaver.from_conn_string(checkpoint) as saver:
            graph, _, accounting = self.build(saver, resumed_model)
            result = self.invoke(graph, accounting, initial=False)
        calls = self.world.export()['tool_calls']
        self.assertEqual(sum(row['name'] == 'search' for row in calls), 1)
        self.assertEqual(sum(row['name'] == 'publish_card' for row in calls), 1)
        first_feedback = progress_messages(resumed_model._requests[0])[0][1]
        self.assertEqual(first_feedback['retrieval_attempts'], 1)
        self.assertTrue(first_feedback['arrived_sources']['recent'])
        self.assertFalse(progress_messages(result['messages']))
        assert_paired(result['messages'])

    def test_commit_then_crash_replay_does_not_duplicate_publication_or_feedback(self):
        world = self.new_world('minimal')
        checkpoint = str(self.root / 'progress-publication.sqlite')
        original_apply = world.apply
        failed = False

        def crash(call_id, name, args, *extra, **kwargs):
            nonlocal failed
            result = original_apply(call_id, name, args, *extra, **kwargs)
            if name == 'publish_card' and result.get('status') == 'displayed' and not failed:
                failed = True
                raise RuntimeError('Crash after durable progress publication')
            return result

        with SqliteSaver.from_conn_string(checkpoint) as saver:
            graph, _, accounting = self.build(saver, VisibleHistoryModel(scenario='minimal'))
            with patch.object(world, 'apply', side_effect=crash):
                with self.assertRaisesRegex(RuntimeError, 'durable progress publication'):
                    self.invoke(graph, accounting)
        self.assertTrue(failed)
        published = copy.deepcopy(world.snapshot()['cards'])
        world.close()
        self.world = WorldStore(self.root / 'world.sqlite')
        model = VisibleHistoryModel(scenario='minimal')
        with SqliteSaver.from_conn_string(checkpoint) as saver:
            graph, _, accounting = self.build(saver, model)
            result = self.invoke(graph, accounting, initial=False)
        self.assertEqual(self.world.snapshot()['cards'], published)
        self.assertEqual(sum(row['name'] == 'publish_card' for row in self.world.export()['tool_calls']), 1)
        self.assertEqual(progress_messages(model._requests[0])[0][1]['publication_outcomes'],
                         {'publish_card:displayed': 1})
        self.assertFalse(progress_messages(result['messages']))
        assert_paired(result['messages'])

    def test_progress_sees_effective_messages_after_summary_wrapper_not_raw_state(self):
        self.new_world()
        model = VisibleHistoryModel(scenario='private_prose')
        rewrite = RewriteLikeSummarization()
        old = HumanMessage(id='observation-0', content=json.dumps({
            'events': [{'kind': 'job_result', 'operation': 'search', 'job_id': 'old-job',
                        'seq': 0, 'result': {'sources': [{'source_id': 'old-raw-state-only'}]}}],
            'pending_jobs': [], 'active_cards': {}, 'context_revision': 0}))
        with SqliteSaver.from_conn_string(':memory:') as saver:
            graph, _, accounting = self.build(saver, model, extra_middleware=[rewrite])
            result = self.invoke(graph, accounting, messages=[old])
        self.assertEqual(len(model._requests), 1)
        feedback = progress_messages(model._requests[0])[0][1]
        self.assertEqual(feedback['observation_cursor'], 500)
        self.assertEqual([row['source_id'] for row in feedback['arrived_sources']['recent']],
                         ['visible-after-compaction'])
        self.assertNotIn('old-raw-state-only', json.dumps(feedback))
        self.assertTrue(any('old-raw-state-only' in str(message.content)
                            for message in rewrite.requests[0]))
        self.assertTrue(any('old-raw-state-only' in str(message.content)
                            for message in result['messages']))
        self.assertFalse(progress_messages(result['messages']))


if __name__ == '__main__':
    unittest.main()
