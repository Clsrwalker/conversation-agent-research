"""Ordering, serial dispatch and freeze checks without model/provider calls."""
from __future__ import annotations

from collections import Counter
import contextlib
import io
import json
from pathlib import Path
import random
import subprocess
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import bench


class BenchOrderTests(unittest.TestCase):
    def test_default_shuffled_matches_the_previous_algorithm_exactly(self):
        cases, arms = ['alpha', 'beta', 'gamma'], ['native', 'full', 'no-worklog']
        expected = [{'preset': arm, 'case_id': case, 'repeat': repeat,
                     'directory': f'{arm}__{case}__r{repeat}'}
                    for repeat in range(1, 3) for case in cases for arm in arms]
        random.Random(20261008).shuffle(expected)
        self.assertEqual(bench.build_jobs(cases, arms, 2, 20261008), expected)

    def test_two_repeats_cover_each_arm_order_per_case_without_duplicates(self):
        cases = [f'case-{i}' for i in range(10)]
        jobs = bench.build_jobs(cases, ['A', 'B'], 2, 71, order='counterbalanced')
        self.assertEqual(len(jobs), 40)
        self.assertEqual(len({job['directory'] for job in jobs}), 40)
        orders = {case: [] for case in cases}
        for first, second in zip(jobs[::2], jobs[1::2]):
            self.assertEqual((first['case_id'], first['repeat']), (second['case_id'], second['repeat']))
            self.assertEqual({first['preset'], second['preset']}, {'A', 'B'})
            orders[first['case_id']].append((first['preset'], second['preset']))
        for values in orders.values():
            self.assertCountEqual(values, [('A', 'B'), ('B', 'A')])

    def test_case_index_and_repeat_each_flip_the_order(self):
        cases = ['alpha', 'beta', 'gamma']
        jobs = bench.build_jobs(cases, ['A', 'B'], 3, 5, order='counterbalanced')
        first_by_pair = {(job['case_id'], job['repeat']): job['preset'] for job in jobs[::2]}
        for index, case in enumerate(cases):
            for repeat in range(1, 4):
                expected = 'A' if (index + repeat - 1) % 2 == 0 else 'B'
                self.assertEqual(first_by_pair[case, repeat], expected)

    def test_seed_shuffles_pairs_deterministically_without_changing_pair_order(self):
        options = (['alpha', 'beta', 'gamma', 'delta'], ['A', 'B'], 2)
        first = bench.build_jobs(*options, 7, order='counterbalanced')
        repeat = bench.build_jobs(*options, 7, order='counterbalanced')
        changed = bench.build_jobs(*options, 8, order='counterbalanced')
        self.assertEqual(first, repeat)
        self.assertNotEqual(first, changed)
        grouped = lambda rows: {(a['case_id'], a['repeat']): (a['preset'], b['preset'])
                                for a, b in zip(rows[::2], rows[1::2])}
        self.assertEqual(grouped(first), grouped(changed))

    def test_counterbalanced_requires_exactly_two_distinct_arms(self):
        for arms in [[], ['A'], ['A', 'A'], ['A', 'B', 'C']]:
            with self.subTest(arms=arms), self.assertRaisesRegex(ValueError, 'two distinct'):
                bench.build_jobs(['alpha'], arms, 2, 0, order='counterbalanced')

    def test_counterbalanced_rejects_duplicate_case_directories(self):
        with self.assertRaisesRegex(ValueError, 'distinct case'):
            bench.build_jobs(['alpha', 'alpha'], ['A', 'B'], 2, 0, order='counterbalanced')

    def test_unknown_order_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'Unknown run order'):
            bench.build_jobs(['alpha'], ['A', 'B'], 1, 0, order='unexpected')

    def test_counterbalanced_rejects_parallel_workers_before_provider_preflight(self):
        argv = ['bench.py', '--dataset', 'unused', '--output', 'unused', '--order', 'counterbalanced',
                '--presets', 'native', 'agent-led-recovery', '--workers', '2']
        with patch('sys.argv', argv), patch.object(bench, 'local_model_metadata') as preflight:
            with self.assertRaisesRegex(ValueError, 'workers=1'):
                bench.main()
            preflight.assert_not_called()

    def test_invalid_arm_count_is_rejected_before_provider_preflight(self):
        argv = ['bench.py', '--dataset', 'unused', '--output', 'unused', '--order', 'counterbalanced',
                '--presets', 'native']
        with patch('sys.argv', argv), patch.object(bench, 'local_model_metadata') as preflight:
            with self.assertRaisesRegex(ValueError, 'two distinct'):
                bench.main()
            preflight.assert_not_called()

    def fake_batch(self, *, order='counterbalanced', tamper=False, changed_fingerprint=False,
                   child_outcome='success', explicit_order=True):
        temporary = TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        dataset, output = root / 'data', root / 'results'
        dataset.mkdir()
        bench.write(dataset / 'cases.json', [{'case_id': case} for case in ['alpha', 'beta']])
        bench.write(dataset / 'corpus.json', [])
        (dataset / 'gold.json').write_text('not parsed: annotation hash only', encoding='utf-8')
        bench.write(dataset / 'freeze.json', {'files_sha256': {
            name: bench.sha(dataset / name) for name in ['cases.json', 'corpus.json', 'gold.json']}})
        protocol = root / 'protocol.md'
        protocol.write_text('Offline ordering test protocol', encoding='utf-8')
        if tamper:
            (dataset / 'gold.json').write_text('changed', encoding='utf-8')
        argv = ['bench.py', '--dataset', str(dataset), '--output', str(output),
                '--provider', 'scripted', '--presets', 'native', 'agent-led-recovery',
                '--repeats', '2', '--workers', '1', '--seed', '42',
                '--evaluation-protocol', str(protocol)]
        if explicit_order:
            argv.extend(['--order', order])
        dispatched = []

        def fake_process(command, **kwargs):
            value = lambda flag: command[command.index(flag) + 1]
            dispatched.append((value('--preset'), value('--case'), Path(value('--output')).name))
            if child_outcome == 'timeout':
                raise subprocess.TimeoutExpired(command, kwargs['timeout'])
            if child_outcome == 'failure':
                return SimpleNamespace(returncode=1)
            folder = Path(value('--output'))
            folder.mkdir()
            bench.write(folder / 'summary.json', {'status': 'completed', 'model_calls': 1,
                                                  'token_usage': {'total_tokens': 1}})
            return SimpleNamespace(returncode=0)

        fingerprint_calls = 0

        def fake_fingerprint():
            nonlocal fingerprint_calls
            fingerprint_calls += 1
            return {'test_version': 2 if changed_fingerprint and fingerprint_calls > 1 else 1}

        with patch('sys.argv', argv), patch.object(bench, 'fingerprint', side_effect=fake_fingerprint), \
                patch.object(bench.subprocess, 'run', side_effect=fake_process), \
                patch.object(bench, 'local_model_metadata') as preflight, contextlib.redirect_stdout(io.StringIO()):
            try:
                code = bench.main()
            finally:
                preflight.assert_not_called()
        return code, output, dispatched

    def test_manifest_and_actual_serial_dispatch_match_counterbalanced_order(self):
        code, output, dispatched = self.fake_batch()
        manifest = bench.read(output / 'batch_manifest.json')
        self.assertEqual(code, 0)
        self.assertEqual(manifest['order_mode'], 'counterbalanced')
        self.assertEqual(manifest['order_seed'], 42)
        expected = [(job['preset'], job['case_id'], job['directory']) for job in manifest['jobs']]
        self.assertEqual(dispatched, expected)
        self.assertEqual(len(dispatched), 8)
        self.assertEqual(manifest['batch_runner_sha256'], bench.sha(Path(bench.__file__)))
        self.assertFalse(manifest['gold_read_by_runner'])

    def test_omitted_cli_order_still_uses_shuffled(self):
        _, output, dispatched = self.fake_batch(explicit_order=False)
        manifest = bench.read(output / 'batch_manifest.json')
        self.assertEqual(manifest['order_mode'], 'shuffled')
        expected = bench.build_jobs(['alpha', 'beta'], ['native', 'agent-led-recovery'], 2, 42)
        self.assertEqual(manifest['jobs'], expected)

    def test_frozen_annotation_change_still_stops_before_dispatch(self):
        with self.assertRaisesRegex(ValueError, 'Frozen file changed: gold.json'):
            self.fake_batch(tamper=True)

    def test_fingerprint_change_still_stops_execution(self):
        with self.assertRaisesRegex(RuntimeError, 'changed during the batch'):
            self.fake_batch(changed_fingerprint=True)

    def test_failed_runs_remain_recorded_once_without_retry(self):
        code, output, dispatched = self.fake_batch(child_outcome='failure')
        self.assertEqual(code, 1)
        self.assertEqual(len(dispatched), 8)
        self.assertTrue(all(count == 1 for count in Counter(dispatched).values()))
        results = bench.read(output / 'batch_results.json')
        self.assertEqual(len(results), 8)
        self.assertTrue(all(row['exit_code'] == 1 and row['summary'] is None for row in results))

    def test_timeouts_remain_recorded_once_without_retry(self):
        code, output, dispatched = self.fake_batch(child_outcome='timeout')
        self.assertEqual(code, 1)
        self.assertEqual(len(dispatched), 8)
        results = bench.read(output / 'batch_results.json')
        self.assertTrue(all(row['exit_code'] is None and 'wall-time limit' in row['error'] for row in results))


if __name__ == '__main__':
    unittest.main()
