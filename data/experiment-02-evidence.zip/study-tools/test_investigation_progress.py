"""Causal projection tests, independent of reference answers and model quality."""
import json
import unittest

from langchain_core.messages import AIMessage, HumanMessage, ToolMessage

from investigation_progress import MAX_FEEDBACK_CHARS, project_progress


def observation(cursor, events=(), pending=(), cards=None):
    return HumanMessage(id=f'observation-{cursor}', content=json.dumps({
        'events': list(events), 'pending_jobs': list(pending),
        'active_cards': cards or {}, 'context_revision': 1}))


def call(call_id, name, argument):
    return AIMessage(content='', tool_calls=[{'id': call_id, 'name': name, 'args': argument}])


def receipt(call_id, name, result):
    return ToolMessage(tool_call_id=call_id, name=name, content=json.dumps(result))


def search_event(seq, job='j1', excerpt='one'):
    return {'seq': seq, 'kind': 'job_result', 'job_id': job, 'operation': 'search',
            'result': {'sources': [{'source_id': 'doc1', 'excerpt': excerpt, 'truncated': True}]}}


def read_event(seq):
    return {'seq': seq, 'kind': 'job_result', 'job_id': 'r1', 'operation': 'read',
            'result': {'source_id': 'doc1', 'text': 'arrived body'}}


class ProjectionTests(unittest.TestCase):
    def test_unreturned_or_unmatched_receipt_is_not_visible_activity(self):
        initial = [observation(1)]
        future_call = call('x', 'search', {'query': 'hidden'})
        unmatched = receipt('other', 'search', {'job_id': 'secret', 'status': 'pending'})
        self.assertEqual(project_progress(initial), project_progress([*initial, future_call, unmatched]))

    def test_pending_read_is_not_full_read_and_cancellation_is_not_arrival(self):
        messages = [observation(2, [search_event(2)]),
                    call('r', 'read_document', {'source_id': 'doc1'}),
                    receipt('r', 'read_document', {'job_id': 'r1', 'status': 'pending'})]
        progress = project_progress(messages)
        self.assertEqual(progress['arrived_sources']['recent'][0]['level'], 'snippet')
        self.assertEqual(progress['pending_jobs']['recent'][0]['job_id'], 'r1')
        cancelled = project_progress([*messages, call('c', 'cancel_job', {'job_id': 'r1'}),
                                     receipt('c', 'cancel_job', {'status': 'cancelled'})])
        self.assertEqual(cancelled['pending_jobs']['recent'], [])
        self.assertEqual(cancelled['arrived_sources']['recent'][0]['level'], 'snippet')
        arrived = project_progress([*messages, observation(4, [read_event(4)])])
        self.assertEqual(arrived['arrived_sources']['recent'][0]['level'], 'full')
        self.assertEqual(arrived['pending_jobs']['recent'], [])

    def test_arrival_cutoff_duplicates_and_full_level_preservation(self):
        messages = [observation(3, [search_event(2), read_event(4)])]
        self.assertEqual(project_progress(messages)['arrived_sources']['recent'][0]['level'], 'snippet')
        messages += [observation(4, [read_event(4)]), observation(6, [search_event(2), search_event(6, 'j2')])]
        progress = project_progress(messages)
        self.assertEqual(progress['arrived_sources']['recent'][0]['level'], 'full')
        self.assertEqual(len(progress['search_arrivals']['recent']), 2)

    def test_same_ids_do_not_assert_unchanged_content_and_distinct_queries_stay_distinct(self):
        messages = []
        for index, query in enumerate(['one', 'one', 'two'], 1):
            messages += [call(str(index), 'search', {'query': query}),
                         receipt(str(index), 'search', {'job_id': f'j{index}', 'status': 'pending'}),
                         observation(index, [search_event(index, f'j{index}', f'new content {index}')])]
        messages += [messages[1]]  # Redelivery is not a fourth attempt.
        progress = project_progress(messages)
        self.assertEqual(progress['retrieval_attempts'], 3)
        self.assertEqual(progress['exact_query_repeats'], 1)
        self.assertEqual(progress['search_arrivals']['recent'][-1]['same_id_set_arrivals'], 3)
        self.assertIn('do not mean unchanged text', progress['meaning'])

    def test_card_state_follows_observed_publication_and_conflict_receipts(self):
        messages = [observation(1), call('p', 'publish_card', {'text': 'x'}),
                    receipt('p', 'publish_card', {'status': 'displayed', 'card_id': 'c1', 'committed_card': {'text': 'x'}})]
        self.assertEqual(project_progress(messages)['active_card_ids']['recent'], ['c1'])
        messages += [call('q', 'publish_card', {'text': 'y', 'card_id': 'c1'}),
                     receipt('q', 'publish_card', {'status': 'conflict', 'card_id': 'c1', 'current_card': None})]
        self.assertEqual(project_progress(messages)['active_card_ids']['recent'], [])
        messages += [observation(2, cards={'c2': {'text': 'z'}}), call('w', 'withdraw_card', {'card_id': 'c2'}),
                     receipt('w', 'withdraw_card', {'status': 'withdrawn'})]
        self.assertEqual(project_progress(messages)['active_card_ids']['recent'], [])

    def test_invalid_query_schema_remains_feedback_not_projection_failure(self):
        messages = [call('bad', 'search', {'query': ['not', 'a', 'string']}),
                    ToolMessage(tool_call_id='bad', name='search', content='Error: query must be a string')]
        progress = project_progress(messages)
        self.assertEqual(progress['exact_query_repeats'], 0)
        self.assertIn('invalid argument type', progress['attempts']['recent'][0]['argument'])

    def test_long_activity_is_bounded_and_omissions_are_visible(self):
        messages = []
        for index in range(40):
            messages += [call(str(index), 'search', {'query': str(index) + '语' * 10000}),
                         receipt(str(index), 'search', {'job_id': f'j{index}', 'status': 'pending'}),
                         observation(index, [search_event(index, f'j{index}')])]
        progress = project_progress(messages)
        self.assertLessEqual(len(json.dumps(progress, ensure_ascii=False, separators=(',', ':'))), MAX_FEEDBACK_CHARS)
        self.assertEqual(progress['retrieval_attempts'], 40)
        self.assertGreater(progress['attempts']['omitted'], 0)
        self.assertEqual(len(messages), 120)


if __name__ == '__main__':
    unittest.main()
