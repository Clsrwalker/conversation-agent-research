"""Stream fixed-size chronological completed runs to condition-blind review.

All assignments are eventually included; no selection by output or score.
Packet IDs match the frozen scorer's deterministic shuffled mapping.
"""
from pathlib import Path
import json
import random
import sys

STUDY = Path(__file__).resolve().parents[1]


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def main():
    batch = int(sys.argv[1])
    manifest = read(STUDY / 'evaluation/manifest.json')
    assignments = manifest['assignments'][:]
    shuffled = assignments[:]
    random.Random(239107).shuffle(shuffled)
    identifiers = {item['run_id']: f'packet-{i+1:03d}' for i, item in enumerate(shuffled)}
    cases = {case['case_id']: case for case in read(STUDY / 'fixtures/cases.json')['cases']}
    selected = assignments[(batch-1)*12:batch*12]
    if len(selected) != 12:
        raise ValueError('Expected a complete fixed group of 12 assignments')
    packets = []
    for item in selected:
        result = read(STUDY / 'evaluation/runs' / item['run_id'] / 'result.json')
        if result['status'] != 'completed' or len(result['stages']) != 3:
            raise ValueError('Batch not complete; wait without substituting runs')
        case = cases[item['case_id']]
        packets.append({'packet_id': identifiers[item['run_id']],
                        'conversation': case['replay']['events'], 'documents': case['corpus'],
                        'gold': case['scoring']['stage_gold'][-1],
                        'final_visible_cards': result['stages'][-1]['active_cards']})
    random.Random(411+batch).shuffle(packets)
    destination = STUDY / f'scoring/blind-batches/batch-{batch:02d}.json'
    destination.parent.mkdir(parents=True, exist_ok=True)
    encoded = json.dumps(packets, ensure_ascii=False, indent=2) + '\n'
    if destination.exists() and destination.read_text(encoding='utf-8') != encoded:
        raise ValueError('Published blind batch changed')
    destination.write_text(encoded, encoding='utf-8')
    print(json.dumps({'batch': batch, 'packets': len(packets)}))


if __name__ == '__main__':
    main()
