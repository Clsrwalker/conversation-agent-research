"""Validate independent blind labels and prepare explicit disagreements."""
from pathlib import Path
import json

STUDY = Path(__file__).resolve().parents[1]
FIELDS = ('complete_and_correct', 'omission', 'scope_error', 'unnecessary_clarification', 'factual_error')


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def validated(name):
    rows = []
    for batch in range(1, 5):
        rows.extend(read(STUDY / f'scoring/{name}/batch-{batch:02d}.json'))
    ids = [row['packet_id'] for row in rows]
    assert len(rows) == len(set(ids)) == 48
    for row in rows:
        assert set(FIELDS) <= set(row)
        assert all(row[key] is None or type(row[key]) is bool for key in FIELDS)
        assert isinstance(row['reason'], str) and row['reason'].strip()
        assert isinstance(row['per_intent_coverage'], dict)
        assert all(x is None or type(x) is bool for x in row['per_intent_coverage'].values())
    return {row['packet_id']: row for row in rows}


def main():
    packets = {p['packet_id']: p for p in read(STUDY / 'scoring/blind-packets.json')}
    a, b = validated('reviewer-a'), validated('reviewer-b')
    assert set(a) == set(b) == set(packets)
    agreements, disagreements = [], []
    for identifier, packet in packets.items():
        expected_ids = {x['intent_id'] for x in packet['gold']['effective_intents']}
        assert set(a[identifier]['per_intent_coverage']) == set(b[identifier]['per_intent_coverage']) == expected_ids
        if (all(a[identifier][key] == b[identifier][key] for key in FIELDS)
                and a[identifier]['per_intent_coverage'] == b[identifier]['per_intent_coverage']):
            agreements.append({**a[identifier], 'decision_source': 'independent_agreement'})
        else:
            disagreements.append({'packet': packet, 'review_a': a[identifier], 'review_b': b[identifier]})
    write(STUDY / 'scoring/agreements.json', agreements)
    write(STUDY / 'scoring/disagreements.json', disagreements)
    print(json.dumps({'agreements': len(agreements), 'disagreements': len(disagreements)}))


if __name__ == '__main__':
    main()
