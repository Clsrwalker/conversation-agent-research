"""Secondary accounting declared in the prospective protocol; no model calls."""
from pathlib import Path
import json
from itertools import combinations

STUDY = Path(__file__).resolve().parents[1]
FIELDS = ('complete_and_correct', 'omission', 'scope_error', 'unnecessary_clarification', 'factual_error')


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def main():
    result = read(STUDY / 'analysis/results.json')
    scores_list = read(STUDY / 'scoring/final-scores.json')
    scores = {x['packet_id']: x for x in scores_list}
    assert len(scores) == len(scores_list) == 48
    for row in scores_list:
        assert all(key in row and (row[key] is None or type(row[key]) is bool) for key in FIELDS)
    groups = []
    for condition in ('unified', 'split', 'tracked'):
        rows = [x for x in result['rows'] if x['condition'] == condition]
        covered = [value for row in rows for value in scores[row['packet_id']]['per_intent_coverage'].values()]
        repeated = []
        for case_id in sorted({r['case_id'] for r in rows}):
            a, b = sorted([r for r in rows if r['case_id'] == case_id], key=lambda r: r['repeat'])
            repeated.append({'case_id': case_id,
                             'different_semantic_fields': [key for key in FIELDS if a[key] != b[key]],
                             'complete_in_both': a['complete_and_correct'] is True and b['complete_and_correct'] is True,
                             'run_ids': [a['run_id'], b['run_id']]})
        groups.append({'condition': condition,
                       'per_intent_coverage': {'total': len(covered), 'correct': sum(x is True for x in covered),
                                               'missing_or_incorrect': sum(x is False for x in covered),
                                               'uncertain': sum(x is None for x in covered)},
                       'families_with_semantic_repeat_disagreement': sum(bool(x['different_semantic_fields']) for x in repeated),
                       'repeats': repeated})
    comparisons = []
    indexed = {(r['case_id'],r['repeat'],r['condition']):r for r in result['rows']}
    for left, right in combinations(('unified','split','tracked'),2):
        paired = []
        for case_id, rep in sorted({(r['case_id'],r['repeat']) for r in result['rows']}):
            a, b = indexed[case_id,rep,left], indexed[case_id,rep,right]
            av, bv = a['complete_and_correct'], b['complete_and_correct']
            label = ('uncertain' if av is None or bv is None else 'tie' if av == bv
                     else 'left_only' if av else 'right_only')
            paired.append({'case_id': case_id, 'repeat': rep, 'outcome': label,
                           'left_run': a['run_id'], 'right_run': b['run_id']})
        comparisons.append({'left':left,'right':right,
                            'counts':{key:sum(x['outcome']==key for x in paired)
                                      for key in ('left_only','right_only','tie','uncertain')},'pairs':paired})
    value = {'kind':'secondary_descriptive_accounting','groups':groups,'paired_completion':comparisons,
             'independence_note':'Two repetitions are nested in eight families; no population significance inference.',
             'primary_score_identity_checked':True}
    secondary = [row for batch in range(1,5)
                 for row in read(STUDY / f'analysis/secondary-batch-{batch:02d}.json')]
    assert len(secondary) == len({x['run_id'] for x in secondary}) == 48
    indexed_rows = {r['run_id']: r for r in result['rows']}
    stage_groups = []
    for condition in ('unified','split','tracked'):
        for stage_id in ('stage-1','stage-2','stage-3'):
            items = [stage for row in secondary if indexed_rows[row['run_id']]['condition'] == condition
                     for stage in row['stages'] if stage['stage_id'] == stage_id]
            assert len(items) == 16
            stage_groups.append({'condition':condition,'stage_id':stage_id,'n':16,
                'delivered_complete':{'yes':sum(s['delivered_complete'] is True for s in items),
                                      'no':sum(s['delivered_complete'] is False for s in items),
                                      'uncertain':sum(s['delivered_complete'] is None for s in items)},
                'evidence_blocked':sum(s['evidence_blocked'] is True for s in items),
                'tracker_semantically_correct':{'yes':sum(s['tracker_semantically_correct'] is True for s in items),
                                                'no':sum(s['tracker_semantically_correct'] is False for s in items),
                                                'uncertain_or_not_applicable':sum(s['tracker_semantically_correct'] is None for s in items)},
                'redundant_semantic_updates':sum(s['redundant_semantic_update'] is True for s in items)})
    value['secondary_stage_review'] = {'kind':'nonblind_model_review', 'groups':stage_groups,
        'limitations':['One model review session knows the conditions; descriptive diagnostics only.',
                       'Early combined-workshop gold asks for a price before the explicit user request; affected snapshots retain uncertainty and sensitivity labels.',
                       'Primary final-delivery results come from the two separate blind review sessions, not these labels.'],
        'rows':secondary}
    (STUDY / 'analysis/additional-metrics.json').write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'conditions':len(groups),'comparisons':len(comparisons)}))


if __name__ == '__main__':
    main()
