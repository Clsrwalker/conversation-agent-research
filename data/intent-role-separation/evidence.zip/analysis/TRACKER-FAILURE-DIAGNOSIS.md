# Tracker rejection loop: observed failure and follow-up options

Date: 2026-10-23, America/Halifax. Status: read-only diagnosis during the frozen evaluation. No source, prompt, fixture, policy, or evaluation output was changed for this diagnosis. No repair has been implemented or tested. Dataset-wide frequencies remain pending until all frozen runs finish.

## What the inspected run actually shows

Inspected run: `irs-combined-workshop-change--tracked--r2`. Evidence: [step inputs, responses and errors](../evaluation/runs/irs-combined-workshop-change--tracked--r2/steps.jsonl), [actual model capture](../evaluation/runs/irs-combined-workshop-change--tracked--r2/model_capture.jsonl), [stage snapshots and metrics](../evaluation/runs/irs-combined-workshop-change--tracked--r2/result.json), and [actual execution ledger](../evaluation/runs/irs-combined-workshop-change--tracked--r2/execution.json).

The initial description “repeated withdrawal of an already withdrawn intention” is **not the mechanism in this run**. At steps 12–17 the model instead tries to `update` the already withdrawn old ID `workshop-info`, including `status: active`, and then `withdraw` the currently active replacement ID `workshop-info-2`. Validation fails at the first operation. An idempotent-withdraw change alone would therefore not fix this example.

| Stage / step | Original input or state | Observed proposal / outcome |
| --- | --- | --- |
| Stage 1, step 0 | Tuesday, cheapest option, at most $25, room and parking | Adds one bundled active intention, `workshop-info`; version becomes 1. |
| Stage 2, step 6 | Switch to Friday, remove parking, add step-free access, retain budget and cheapest rule | Withdraws `workshop-info` and adds `workshop-info-2`; accepted, version becomes 2, processed event seq 24. |
| Stage 3, event seq 43 | Final answer must identify workshop, price and room, and explain whether step-free access is met | Requires processing a further user clarification. The original words and the full source document are present. |
| Stage 3, steps 12–17 | Old ID is withdrawn; replacement ID is active | Every proposal updates the withdrawn old ID and withdraws the active replacement. Every patch is rejected atomically with `IntentValidationError: A withdrawn intention needs an explicit reopen operation.` |

Step 12 cites `[24, 43]` for its invalid update; steps 13–17 cite `[24]`. The final five operations objects are identical. None of the six accepted a patch; the intent version stays 2, processed seq stays 24, and observed seq stays 43. The model-generated revised text also does not explicitly add the newly requested actual price, so merely making the transition syntactically acceptable would not establish semantic correctness.

The six model input packets are identical after removing the top-level `at_ms`; their normalized SHA256 is `1dc6b035f9d979704529edaefd55bc93369a5e9d8ba1c7af99a568e7d6225c4b` using sorted-key JSON with Python's default separators/ASCII encoding. They are not byte-identical full requests: timestamps, message IDs/cursors and request metadata differ. Crucially, no failed proposal or validation feedback is added to the next model input.

Observed cost and delivery consequences in this run:

- Stage 3 spends all six allowed calls on rejected tracker proposals: **6 tracker, 0 work, 0 chat**. These are six actual completed model calls, not six network failures.
- Those calls consume **31,716 input + 538 output = 32,254 reported tokens** and **19,188.878 ms** of summed measured model-call wall time. Virtual stage time advances from 12,000 to 12,600 ms; virtual time is not wall latency.
- Whole-run counts are 18 model calls: 8 tracker, 5 work, 5 chat; 68,285 total reported tokens.
- The active card at the end of stage 3 is exactly the stage-2 card, last updated at 6,200 ms. It names Glaze Lab and Room G4 and states that the option meets step-free access, but gives only the $25 ceiling, not Glaze Lab's actual **$23** price. The full arrived source already contains that price. No delivery attempt addresses the stage-3 clarification.
- `result.status == completed` and `pending_or_failed_calls == 0` mean the run and model requests finished. They do not mean the state commits or final answer succeeded. Assistance scoring must inspect the displayed card separately.

These are observations about this one finished run. They are not a dataset-wide incidence estimate, proof that all tracked failures have this cause, or evidence that one proposed remedy would improve assistance.

## Why the loop persists

The runtime has a valid state-safety rule and an incomplete recovery path.

1. `IntentStore.commit_patch` validates the whole proposal in one transaction. `_apply_operation` rejects `update` and `withdraw` when the target is already withdrawn; only an explicit `reopen` can reactivate it. Rollback preserves both existing intentions and the processed cursor. This prevents an invalid patch from silently restoring a cancelled requirement.
2. `IntentRoleSession._role` selects tracker whenever `observed_event_seq > processed_event_seq`. Since rejection does not advance the processed cursor, tracker is selected again.
3. `step` writes the exception only to the external step log. Next-call inputs are reconstructed from arrived observations, conversation, tool receipts and the unchanged intention snapshot. The failure log is absent from those inputs. The retry therefore gets no new corrective information.
4. There is no tracker-specific retry cap or actor fallback. The overall shared budget bounds the loop, but it also removes every remaining work/chat opportunity in that stage.

Source locations in the frozen implementation are `intent_roles.py` `_role` (around line 169), packet construction (around line 256), tracker commit and exception logging (around lines 282–311), and `intention_state.py` `commit_patch`/`_apply_operation` (around lines 192–317). Verify exact source hashes against the evaluation manifest when reproducing this diagnosis.

A contributing hypothesis is unstable identity selection: stage 2 replaces the entire bundled task with a new ID, then stage 3 returns to the historical ID. The recorded proposals support investigating this hypothesis, but do not prove why the model selected that ID. Separate atomic requirements or clearer identity instructions could help, while also increasing representation and update complexity. That is a distinct intervention from error recovery.

## Candidate changes and their different effects

| Candidate | What it changes | What it could address | Main risks / what it does not establish |
| --- | --- | --- | --- |
| Structured validation feedback | Give the next tracker call the failed operation index, intent ID, current status, error code, committed version and explicit statement that the whole patch was rejected. Include the proposed operation as untrusted model output. | Gives a repair attempt information currently missing. In this run it can identify that `workshop-info` is withdrawn while `workshop-info-2` is active. | Feedback must describe state, not invent user intent. “Use reopen” alone can encourage an unjustified resurrection. A syntactically repaired patch may still omit price or cite the wrong turn. Adds input tokens and does not bound retries by itself. |
| Bounded retry | Limit attempts for the same arrived-conversation cursor, for example one initial attempt plus one corrective retry, with the rule fixed before running. Count all calls against the existing shared budget. | Prevents an unchanged failure from consuming all stage opportunities. | Stopping retries alone leaves a stale tracker and no answer; there must be an explicit consequence. A small cap can give up on repairable proposals. New raw conversation should create a new opportunity, without resetting the cap merely because model time advances. |
| Raw-conversation actor fallback after the cap | Continue the split chat/work policy using the same full arrived raw evidence. Mark the tracker unavailable/stale; omit it or supply it only with an explicit stale warning. Do not advance its processed cursor or pretend that the failed patch committed. | Can preserve some ability to answer when the controller cannot produce a valid state. | This becomes a hybrid policy and needs its own versioned comparison. Actors can still miss intentions, and stale state can anchor them if retained. The fallback must keep all cancellation, source and atomic card-commit checks. It must not copy a failed proposed patch into authoritative task state. |
| Idempotent `withdraw` for an already withdrawn ID | Treat an exact redundant withdrawal as an acknowledged no-op with an explicit receipt; preserve the original history unless deliberately recording a separate no-op audit event. | Could remove failures caused specifically by redundant withdrawals. The current patch-ID replay mechanism only makes the exact same committed patch replay idempotent; it does not make a new patch's redundant semantic operation valid. | **Does not fix this inspected run's invalid update.** Must still check expected version, latest input cursor and arrived source references. A stale withdrawal must not cancel an intention reopened by a newer event. Silent no-ops can conceal poor tracking or appear as genuine transitions in metrics. |
| Permit `update` to reactivate withdrawn intentions | Relaxes the state transition rule itself. | Would allow the first operation in these rejected proposals. | Not recommended as the first response: it removes a useful guard and can resurrect cancelled requirements without an explicit transition. In this run the model also withdraws the valid replacement and misses the price clarification. Structural acceptance alone is not recovery. |

The most directly motivated follow-up is **validation feedback plus a bounded repair opportunity**, with a separately declared raw-conversation fallback. Test feedback, retry policy and fallback as separable mechanisms where the budget permits; otherwise describe the result as the effect of their combined recovery policy. Consider idempotent withdrawal separately only if the completed corpus contains that exact failure class. Keep invalid updates to withdrawn items rejected unless a separately specified transition design proves suitable.

Do not partially apply the valid-looking operations from a rejected multi-operation patch as an unexamined shortcut. Their meaning can depend on each other; accepting a withdrawal without its replacement, or the reverse, can corrupt the effective request set. Do not silently mark an invalid proposal as a successful empty/no-change patch to unblock the scheduler.

## Complete the frozen study, then test a new version

1. Finish the frozen 48-trajectory matrix unchanged. Preserve rejected proposals, costs, cards and run statuses. Score actual displayed answers independently of tracker-schema success and include this failure in the study limitations.
2. After all runs finish, aggregate actual frequencies by **operation and target status**, not just the shared error text. In particular, separate `update` of withdrawn IDs from `withdraw` of withdrawn IDs, duplicate additions, invalid references, malformed JSON, stale-version conflicts and other errors. Inspect the proposal against its pre-call state to identify the first rejected operation.
3. Report affected families/runs/stages; failed tracker calls and tokens; longest consecutive rejection streak; stages with no actor opportunities; recovery before the stage ended; and final delivered coverage/omissions. Counts of six retries in one stage must not be presented as six independent failed cases. Distinguish a source/arrival conflict from a semantic-transition error.
4. Retain this example as an exposed regression case. Make any repair in a new version with archived code, prompts, rules and source hashes; do not overwrite frozen v1 outputs or count a later repaired rerun as its original result.
5. Before new model evaluation, verify targeted engineering contracts: exact error feedback is visible; failed patches roll back; retry counts persist across restart and reset only on the declared condition; fallback does not promote stale state; cancelled work stays cancelled; valid reopening survives an old withdrawal; no-op withdrawals have honest receipts; and all repair calls/tokens remain counted.
6. Compare the frozen policy with the versioned recovery policy under the same maximum call/token conditions and actual tool execution. Add fresh variants and no-change negatives beyond this exposed family. A counterfactual replay of this one captured failure is a useful diagnostic, but cannot establish a general improvement. Score semantic intent state and delivered answer quality separately from acceptance rate.

No dataset-wide aggregation or repaired-run conclusion is supplied here. Those remain outstanding until the frozen evaluation and any separately declared follow-up have actually completed.
