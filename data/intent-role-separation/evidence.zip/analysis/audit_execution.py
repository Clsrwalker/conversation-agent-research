"""Independent stdlib audit of the completed intent-role evaluation.

Run only once all assigned result/execution records exist. This program imports
no experiment implementation, calls no model, and does not assign semantic
quality scores. Incomplete ongoing work exits without writing a failure report.
The request capture is at the LangChain message boundary, not raw HTTP wire data.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys


DEFAULT_STUDY = Path(__file__).resolve().parent.parent
FORBIDDEN = {'scoring', 'stage_gold', 'effective_intents', 'inactive_intents',
             'expected_answer', 'forbidden_outcomes', 'allowed_unresolved'}
ARTIFACTS = ('result.json', 'execution.json', 'steps.jsonl', 'model_capture.jsonl', 'session.json')


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def lines(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def all_keys(value):
    if isinstance(value, dict):
        yield from value
        for item in value.values():
            yield from all_keys(item)
    elif isinstance(value, list):
        for item in value:
            yield from all_keys(item)


def projection(log, cursor):
    """Reconstruct only externally recorded effects up to an observed cursor."""
    events, cards, jobs, notes = [], {}, {}, ''
    for entry in log:
        if entry['seq'] > cursor:
            break
        kind = entry['kind']
        if kind == 'environment_event':
            event = {**entry['event'], 'seq': entry['seq'], 'at_ms': entry['at_ms']}
            events.append(event)
            if event.get('kind') == 'job_result':
                jobs.pop(event.get('job_id'), None)
        elif kind in {'card_created', 'card_updated'}:
            cards[entry['card_id']] = entry['card']
        elif kind == 'card_withdrawn':
            cards.pop(entry['card_id'], None)
        elif kind == 'job_started':
            job = entry['job']
            jobs[entry['job_id']] = {'job_id': entry['job_id'], 'operation': job['operation'],
                                     'due_ms': job['due_ms']}
        elif kind == 'job_cancelled':
            jobs.pop(entry['job_id'], None)
        elif kind == 'notes_saved':
            notes = entry['notes']
    conversation = []
    for event in events:
        if event.get('kind') == 'job_result' or not isinstance(event.get('text'), str):
            continue
        role = event.get('role', 'user')
        speaker = str(event.get('speaker') or event.get('participant') or
                      ('assistant' if role == 'assistant' else 'participant'))
        conversation.append({**event, 'role': role, 'speaker': speaker})
    return {'events': events, 'conversation': conversation, 'active_cards': cards,
            'notes': notes, 'pending_jobs': list(jobs.values()),
            'context_revision': sum(e.get('kind') != 'job_result' for e in events)}


def audit(study, *, check_only=False):
    root = study.parents[3]
    phase = study / 'evaluation'
    manifest = read(phase / 'manifest.json')
    assignments = manifest['assignments']
    missing = [f"{item['run_id']}/{name}" for item in assignments for name in ARTIFACTS
               if not (phase / 'runs' / item['run_id'] / name).exists()]
    if missing:
        print(json.dumps({'status': 'not_ready', 'missing_artifacts': missing,
                          'report_written': False}))
        return 2
    output = study / 'analysis/EXECUTION-AUDIT.json'
    if output.exists() and not check_only:
        raise FileExistsError('Preserve the existing execution audit; use --check-only to recheck.')
    issues = []

    def check(condition, code, **details):
        if not condition:
            issues.append({'code': code, **details})

    check(sha(phase / 'manifest.json') == (phase / 'manifest.sha256').read_text().strip(),
          'manifest_digest_changed')
    for name, expected in manifest['source_sha256'].items():
        check((root / name).exists() and sha(root / name) == expected,
              'runtime_frozen_source_changed', path=name)
        archived = phase / 'frozen-source' / name
        check(archived.exists() and sha(archived) == expected, 'archived_source_changed', path=name)
    cases = {case['case_id']: case for case in read(study / 'fixtures/cases.json')['cases']}
    check(len(assignments) == 48 and len(cases) == 8, 'unexpected_matrix_size')
    check(len({item['run_id'] for item in assignments}) == len(assignments), 'duplicate_assignment_id')
    check(Counter((a['case_id'], a['condition'], a['repeat']) for a in assignments) == Counter(
        (case, arm, repeat) for case in cases for arm in ('unified', 'split', 'tracked') for repeat in (1, 2)),
        'assignment_matrix_mismatch')
    run_details = []
    for assignment in assignments:
        folder = phase / 'runs' / assignment['run_id']
        result, execution, session = (read(folder / name) for name in ('result.json', 'execution.json', 'session.json'))
        steps, capture = lines(folder / 'steps.jsonl'), lines(folder / 'model_capture.jsonl')
        log, calls, tools = execution['environment_log'], execution['model_calls'], execution['tool_calls']
        name, case = assignment['run_id'], cases[assignment['case_id']]

        def require(condition, code, **details):
            check(condition, code, run_id=name, **details)

        require(session['identity']['settings'] == manifest['settings'], 'session_settings_differ')
        require(session['identity']['condition'] == assignment['condition'], 'session_arm_differs')
        require(result['metrics'] == execution['metrics'], 'metrics_records_differ')
        require(len({entry['seq'] for entry in log}) == len(log), 'duplicate_environment_sequence')
        require([e['seq'] for e in log] == sorted(e['seq'] for e in log), 'unordered_environment_log')
        require(len(calls) <= manifest['settings']['max_calls'], 'trajectory_call_ceiling_exceeded')
        require(all(c['max_calls'] == manifest['settings']['max_calls'] and
                    c['max_tokens'] == manifest['settings']['max_tokens'] for c in calls),
                'ledger_budget_settings_differ')
        requests = [r for r in capture if r['kind'] == 'request']
        responses = [r for r in capture if r['kind'] == 'response']
        provider_errors = [r for r in capture if r['kind'] == 'error']
        req_by_id = {r['run_id']: r for r in requests}
        resp_by_id = {r['run_id']: r for r in responses}
        error_by_id = {r['run_id']: r for r in provider_errors}
        require(len(req_by_id) == len(requests) == len(calls), 'capture_ledger_request_count_mismatch')
        require(len(resp_by_id) == len(responses), 'duplicate_response_capture')
        require(set(req_by_id) == {c['call_id'] for c in calls}, 'capture_ledger_ids_differ')
        require(set(resp_by_id) | set(error_by_id) == set(req_by_id), 'missing_terminal_capture')
        step_by_number = {s['step']: s for s in steps}
        require(len(step_by_number) == len(steps), 'duplicate_session_step')
        role_usage, stop, models, prompt_counts, output_counts = {}, Counter(), Counter(), [], []
        unknown_usage, call_step_counts = [], Counter()
        for call in calls:
            request = req_by_id.get(call['call_id'])
            if request is None:
                continue
            number = request['metadata']['role_step']
            call_step_counts[number] += 1
            step = step_by_number.get(number)
            require(step is not None, 'capture_step_missing', step=number)
            if step is None:
                continue
            require(request['messages'] == call['request'], 'capture_ledger_message_mismatch', step=number)
            require(request['metadata']['harness_role'] == step['role'] == call['role'],
                    'call_role_mismatch', step=number)
            require(request['metadata'].get('ls_model_name') == manifest['settings']['model'],
                    'request_model_mismatch', step=number)
            require(request['metadata'].get('ls_temperature') == 0.0, 'sampling_temperature_changed', step=number)
            packet = json.loads(request['messages'][0][-1]['content'])
            require(packet == step['input'], 'capture_step_packet_mismatch', step=number)
            require(not (set(all_keys(packet)) & FORBIDDEN), 'private_scoring_field_in_input', step=number)
            require(not ({'case_id', 'family_id', 'title', 'tags', 'stages'} & set(packet)),
                    'fixture_metadata_in_input', step=number)
            expected = projection(log, step['cursor'])
            for key in expected:
                require(packet.get(key) == expected[key], 'causal_projection_mismatch', step=number, field=key)
            require(all(e['at_ms'] <= step['at_ms'] for e in packet['events']), 'future_event_in_input', step=number)
            require(step['at_ms'] == call['started_at_ms'], 'call_start_time_mismatch', step=number)
            require(packet['at_ms'] == step['at_ms'], 'packet_clock_mismatch', step=number)
            for source in case['corpus']:
                if source['text'] in json.dumps(packet, ensure_ascii=False):
                    require(any(e.get('kind') == 'job_result' and e.get('operation') == 'read' and
                                e.get('result', {}).get('source_id') == source['id'] for e in expected['events']),
                            'undelivered_document_body_visible', step=number, source_id=source['id'])
            if call['call_id'] in resp_by_id:
                response = resp_by_id[call['call_id']]['generations'][0][0]['message']
                require(response == step.get('response'), 'capture_step_response_mismatch', step=number)
                meta = response['response_metadata']
                models[meta.get('model', 'unavailable')] += 1
                stop[str(meta.get('done_reason', 'unavailable'))] += 1
                require(meta.get('model') == manifest['settings']['model'], 'response_model_mismatch', step=number)
                usage = response.get('usage_metadata')
                if usage:
                    for key in ('input_tokens', 'output_tokens', 'total_tokens'):
                        require(usage.get(key) == call[key], 'response_usage_ledger_mismatch', step=number, field=key)
                else:
                    unknown_usage.append(number)
                if isinstance(meta.get('prompt_eval_count'), int):
                    prompt_counts.append(meta['prompt_eval_count'])
                    require(meta['prompt_eval_count'] == call['input_tokens'], 'provider_prompt_count_mismatch', step=number)
                if isinstance(meta.get('eval_count'), int):
                    output_counts.append(meta['eval_count'])
                    require(meta['eval_count'] == call['output_tokens'], 'provider_output_count_mismatch', step=number)
            totals = role_usage.setdefault(call['role'], {'calls': 0, 'input_tokens': 0, 'output_tokens': 0,
                                                          'total_tokens': 0, 'wall_ms': 0.0})
            totals['calls'] += 1
            for key in ('input_tokens', 'output_tokens', 'total_tokens', 'wall_ms'):
                totals[key] += call[key]
        require(all(count == 1 for count in call_step_counts.values()), 'multiple_model_calls_in_one_step')
        for step in steps:
            require(bool(call_step_counts.get(step['step'])) == bool(step.get('model_called')),
                    'step_model_called_flag_disagrees', step=step['step'])
        require(sum(c['total_tokens'] for c in calls) == result['metrics']['token_usage']['total_tokens'],
                'summed_token_ledger_mismatch')
        stages, prior_count = [], 0
        flattened = []
        for stage, definition in zip(result['stages'], case['stages']):
            flattened.extend(s for s in stage['steps'] if s.get('model_called'))
            count = stage['metrics']['model_calls'] - prior_count
            prior_count = stage['metrics']['model_calls']
            require(0 <= count <= manifest['calls_per_stage'], 'stage_call_ceiling_exceeded', stage=stage['stage_id'])
            require(definition['at_ms'] <= stage['at_ms'] < definition['end_at_ms'],
                    'stage_snapshot_outside_window', stage=stage['stage_id'])
            require(all(s['finished_at_ms'] < definition['end_at_ms'] for s in stage['steps'] if s.get('model_called')),
                    'step_crosses_stage_deadline', stage=stage['stage_id'])
            expected = projection(log, stage['cursor'])
            require(stage['active_cards'] == expected['active_cards'], 'stage_cards_do_not_match_effects', stage=stage['stage_id'])
            stages.append({'stage_id': stage['stage_id'], 'at_ms': stage['at_ms'], 'cursor': stage['cursor'],
                           'model_calls': count, 'active_cards': stage['active_cards'],
                           'pending_jobs_at_snapshot': expected['pending_jobs'],
                           'roles': dict(Counter(s.get('role') for s in stage['steps'] if s.get('model_called')))})
        require(flattened == steps, 'stage_step_records_differ_from_session_log')
        if result['status'] == 'completed':
            require(len(result['stages']) == len(case['stages']), 'completed_run_missing_stage')
        actual_by_id = {t['call_id']: t for t in tools}
        require(len(actual_by_id) == len(tools), 'duplicate_persisted_tool_id')
        receipts = [r for step in steps for r in step.get('receipts', [])]
        nonexecuted = []
        for receipt in receipts:
            actual = actual_by_id.get(receipt['call_id'])
            if actual is None:
                nonexecuted.append(receipt)
                require(receipt['result'].get('status') in {'rejected', 'stale', 'tool_error'},
                        'success_receipt_without_actual_tool', call_id=receipt['call_id'])
            else:
                require(all(receipt['result'].get(k) == v for k, v in actual['result'].items()),
                        'tool_receipt_differs_from_persisted_effect', call_id=receipt['call_id'])
        tracker_steps = [s for s in steps if s['role'] == 'tracker']
        late = None
        if case.get('setup_actions'):
            setup = [t for t in tools if t['call_id'].startswith('setup-')]
            reads = [t for t in setup if t['name'] == 'read_document']
            require(len(reads) == 1, 'late_fixture_seed_read_missing')
            if reads:
                seeded = reads[0]
                job_id = seeded['result'].get('job_id')
                arrivals = [e for e in log if e['kind'] == 'environment_event' and e['event'].get('job_id') == job_id]
                cancellations = [e for e in log if e['kind'] == 'job_cancelled' and e['job_id'] == job_id]
                require(seeded['result'].get('status') == 'pending', 'late_fixture_seed_not_pending')
                require(job_id in {j['job_id'] for j in steps[0]['input']['pending_jobs']}, 'late_seed_not_visible_as_pending')
                for arrival in arrivals:
                    require(arrival['at_ms'] > case['stages'][1]['at_ms'], 'seeded_result_not_late')
                # Cancellation is an actor outcome; do not misreport an unarrived
                # cancelled job as a successful late-result exposure.
                late = {'seed_call': seeded, 'setup_actions': setup, 'arrivals': arrivals,
                        'cancellations': cancellations, 'actually_arrived_late': bool(arrivals),
                        'cancelled_before_arrival': bool(cancellations) and not arrivals,
                        'state': 'arrived' if arrivals else 'cancelled' if cancellations else 'still_pending_or_unobserved'}
        role_errors = [dict(step=s['step'], role=s['role'], error=s.get('error'))
                       for s in steps if s.get('status') == 'error']
        outcomes = Counter((t['name'], str(t['result'].get('status', t['result'].get('error_code', 'unspecified')))) for t in tools)
        final_view = result['stages'][-1]['session'].get('intention_state') if result['stages'] else None
        run_details.append({'run_id': name, 'condition': assignment['condition'], 'case_id': assignment['case_id'],
            'repeat': assignment['repeat'], 'run_status': result['status'], 'metrics': result['metrics'],
            'role_usage': role_usage, 'capture_requests': len(requests), 'capture_responses': len(responses),
            'provider_error_captures': provider_errors, 'provider_or_accounting_failures': [c for c in calls if c['outcome'] != 'completed'],
            'step_errors': role_errors, 'invalid_tool_calls': [s for s in steps if s.get('invalid_tool_calls')],
            'nonexecuted_tool_receipts': nonexecuted, 'response_model_counts': dict(models), 'stop_reasons': dict(stop),
            'max_reported_prompt_tokens': max(prompt_counts, default=None),
            'max_reported_output_tokens': max(output_counts, default=None), 'unknown_usage_steps': unknown_usage,
            'context_limit': manifest['settings']['context_window'], 'output_limit': manifest['settings']['max_output_tokens'],
            'possible_truncation_signal': any(reason not in {'stop'} for reason in stop) or
                any(n >= manifest['settings']['context_window'] for n in prompt_counts) or
                any(n >= manifest['settings']['max_output_tokens'] for n in output_counts),
            'executed_tools': len(tools), 'actor_executed_tools': sum(not t['call_id'].startswith('setup-') for t in tools),
            'tool_outcomes': [{'name': n, 'status': s, 'count': count} for (n, s), count in sorted(outcomes.items())],
            'tool_error_results': [t for t in tools if 'error' in t['result'] or t['result'].get('status') in {'error', 'conflict', 'new_observations'}],
            'tracker_calls': len(tracker_steps), 'tracker_valid_commits': sum('tracker_commit' in s for s in tracker_steps),
            'stages': stages, 'final_intention_state': final_view, 'late_result_initialization': late,
            'withdrawal_effects': [e for e in log if e['kind'] == 'card_withdrawn'],
            'final_visible_cards': stages[-1]['active_cards'] if stages else {},
            'artifacts_sha256': {filename: sha(folder / filename) for filename in ARTIFACTS}})
    summary = []
    for arm in ('unified', 'split', 'tracked'):
        selected = [r for r in run_details if r['condition'] == arm]
        summary.append({'condition': arm, 'runs': len(selected),
            'completed_trajectories': sum(r['run_status'] == 'completed' for r in selected),
            'model_calls': sum(r['metrics']['model_calls'] for r in selected),
            'total_tokens': sum(r['metrics']['token_usage']['total_tokens'] for r in selected),
            'api_wall_ms': sum(r['metrics']['api_wall_ms'] for r in selected),
            'step_errors': sum(len(r['step_errors']) for r in selected),
            'provider_or_accounting_failures': sum(len(r['provider_or_accounting_failures']) for r in selected),
            'tracker_calls': sum(r['tracker_calls'] for r in selected),
            'tracker_valid_commits': sum(r['tracker_valid_commits'] for r in selected),
            'executed_tools': sum(r['executed_tools'] for r in selected),
            'actor_executed_tools': sum(r['actor_executed_tools'] for r in selected),
            'nonexecuted_tool_requests': sum(len(r['nonexecuted_tool_receipts']) for r in selected),
            'possible_truncation_runs': [r['run_id'] for r in selected if r['possible_truncation_signal']],
            'max_reported_prompt_tokens': max((r['max_reported_prompt_tokens'] or 0 for r in selected), default=0)})
    report = {'schema_version': 1, 'kind': 'independent_evaluation_execution_audit',
        'status': 'passed' if not issues else 'failed', 'date': manifest['study_date'],
        'display_timezone': manifest['display_timezone'], 'audited_at_utc': datetime.now(timezone.utc).isoformat(),
        'assigned_runs': len(assignments), 'families': len(cases), 'runs_audited': len(run_details),
        'real_model_calls': sum(r['metrics']['model_calls'] for r in run_details),
        'total_tokens': sum(r['metrics']['token_usage']['total_tokens'] for r in run_details),
        'frozen_source_files_checked': len(manifest['source_sha256']), 'manifest_sha256': sha(phase / 'manifest.json'),
        'auditor_sha256': sha(Path(__file__)), 'local_model_freeze': manifest['local_model'],
        'conditions': summary, 'issues': issues, 'runs': run_details,
        'quality_scored': False, 'completed_run_means_successful_answer': False,
        'capture_boundary': 'LangChain request/response messages, provider metadata, model accounting and simulated tool receipts; not raw HTTP wire capture.',
        'context_limit_assessment': 'Reported prompt/output counts and stop reasons can expose a truncation signal. Complete client messages and counts below limits do not independently prove server-side tokenizer or truncation behavior.',
        'late_result_assessment': 'Each inherited pending read is reported separately as arrived late, actor-cancelled, or still pending. Cancellation is an outcome, not evidence that late content was consumed.',
        'remaining_semantic_work': ['Blind final-delivery scoring is separate from this mechanical audit.',
            'Tracker valid commits do not establish accurate intention state or necessary state changes.',
            'Visible cards after a cancellation are preserved as facts; a reviewer must judge whether they improperly retain withdrawn requests.',
            'Per-intent and intermediate-stage semantic endpoints remain separate until explicitly scored.'],
        'limitations': ['All scenarios are authored, synthetic and short.', 'Same base model and call ceilings do not equalize actor opportunities, actual tokens or wall time.',
            'No LoRA, audio, user study, production deployment or external API execution is tested.']}
    if not check_only:
        output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': report['status'], 'runs': len(run_details), 'calls': report['real_model_calls'],
                      'tokens': report['total_tokens'], 'issues': len(issues), 'conditions': summary,
                      'report_written': not check_only}, ensure_ascii=False))
    return 0 if not issues else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--study', type=Path, default=DEFAULT_STUDY)
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    sys.exit(audit(args.study.resolve(), check_only=args.check_only))
