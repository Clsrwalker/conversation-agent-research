"""Combine explicit independent decisions; preserve all initial reviews."""
from pathlib import Path
import hashlib
import json

STUDY = Path(__file__).resolve().parents[1]
FIELDS = ('complete_and_correct', 'omission', 'scope_error',
          'unnecessary_clarification', 'factual_error')

def read(name):
    return json.loads((STUDY / name).read_text(encoding='utf-8-sig'))

def write(name, data):
    (STUDY / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

packets = {p['packet_id']: p for p in read('scoring/blind-packets.json')}
agreements = read('scoring/agreements.json')
disagreements = read('scoring/disagreements.json')
adjudication = read('scoring/adjudication.json')
assert {x['packet_id'] for x in adjudication} == {x['packet']['packet_id'] for x in disagreements}
rows = sorted(agreements + adjudication, key=lambda x: x['packet_id'])
assert len(rows) == len({x['packet_id'] for x in rows}) == 48
assert {x['packet_id'] for x in rows} == set(packets)
for row in rows:
    assert all(k in row and (row[k] is None or type(row[k]) is bool) for k in FIELDS)
    expected = {x['intent_id'] for x in packets[row['packet_id']]['gold']['effective_intents']}
    assert set(row['per_intent_coverage']) == expected
    assert all(v is None or type(v) is bool for v in row['per_intent_coverage'].values())
    assert row.get('reason', '').strip()
write('scoring/final-scores.json', rows)
sources = sorted((STUDY / 'scoring').glob('reviewer-*/*.json'))
sources += [STUDY / 'scoring/adjudication.json', STUDY / 'scoring/final-scores.json']
write('scoring/REVIEW-PROCESS-AUDIT.json', {
    'status': 'completed', 'date': '2026-10-23', 'timezone': 'America/Halifax',
    'method': 'Two separate condition-blind model review sessions; a fresh condition-blind model session adjudicated disagreements.',
    'packets': 48, 'independent_complete_agreements': len(agreements),
    'disagreements': len(disagreements), 'adjudicated': len(adjudication),
    'agreement_unit': 'All five final-delivery fields and every per-intent coverage field agree.',
    'blinding': 'Packets use deterministic randomized IDs and contain raw dialogue, source documents, final gold and final active cards; arm and repetition mapping was withheld from reviewers.',
    'batching': 'Four immutable batches of twelve assigned trajectories, selected by frozen assignment order and shuffled within each batch. No selection by outcome.',
    'clarification': 'Initial batch-1 instructions ambiguously described omission as not correctly answering. Both reviewers independently reapplied the frozen missing-content definition. Each changed only packet-001 omission from true to false. Initial files and separate clarification records are retained; other labels were unchanged.',
    'grounding': 'Raw user requests take precedence over paraphrased gold; extra true facts are not automatically a scope error.',
    'secondary_review': 'One condition-aware model session scored 144 stage snapshots separately; those diagnostic labels do not replace these primary scores.',
    'strict_schema_checked': True,
    'limitations': ['These are model judgments, not human labels or participant ratings.',
                   'Different sessions are procedurally independent but may share model biases.',
                   'Reviewers may infer an orchestration policy from answer style.',
                   'High inter-reviewer agreement does not establish annotation accuracy.'],
    'sha256': {p.relative_to(STUDY).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}})
print(json.dumps({'final_scores': len(rows), 'agreements': len(agreements), 'adjudicated': len(adjudication)}))
