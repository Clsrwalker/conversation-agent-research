# Tracker failures in the completed frozen evaluation

Date: 2026-10-23, America/Halifax. Read-only analysis; no new inference or repair.

The tracked arm made 69 tracker calls: 44 committed and **25 were rejected**. Those rejections cluster in **5/16 trajectories, 5/48 stages and 3/8 families**; they are not 25 independent failed cases.

| First rejected operation | Target before patch | Calls | Trajectories |
| --- | --- | ---: | ---: |
| `update` needing explicit `reopen` | withdrawn | 9 | 2 |
| `update` with prohibited `status: withdrawn` | withdrawn | 3 | 1 |
| second operation touches same ID after `update` (`withdraw`) | active | 12 | 2 |
| `update` cites arrived document result as conversation evidence | active | 1 | 1 |

**No first failure was repeated withdrawal of an already withdrawn intention.** Some rejected patches contain later duplicate additions, but those operations are never reached; counting them as extra executed failures would be wrong.

Rejected calls consumed **120,066 input + 2,292 output = 122,358 reported tokens** and **76.125 seconds** of summed model-call wall time. All 25 model calls themselves completed; these are state-validation failures, not provider failures.

| Affected family/repeat | Stage | Rejections | Work/chat calls | Same-stage valid recovery | Failed-call tokens |
| --- | --- | ---: | ---: | --- | ---: |
| irs-combined-workshop-change / r1 | stage-3 | 6 | 0 | no | 32,277 |
| irs-combined-workshop-change / r2 | stage-3 | 6 | 0 | no | 32,254 |
| irs-multiple-request-owners / r1 | stage-2 | 6 | 0 | no | 27,534 |
| irs-multiple-request-owners / r2 | stage-2 | 6 | 0 | no | 27,462 |
| irs-unaccepted-assistant-proposal / r2 | stage-2 | 1 | 4 | yes | 2,831 |

The longest rejection streak is **6 consecutive calls**. Four stages spend their entire allowance on rejected tracker updates and have **zero work or chat calls**. Only the source-type failure recovers within its stage. Both multiple-owner runs commit after the next stage's new input; neither workshop run recovers before the trajectory ends.

For all **21** inspected failure-to-next-tracker transitions, input packets are identical after removing only top-level `at_ms`; system prompts also match. No validation error is fed into the next packet. This directly supports the missing-feedback mechanism described in [the detailed diagnosis](TRACKER-FAILURE-DIAGNOSIS.md).

The two workshop final cards retain the stage-2 answer and omit the actual **$23** price requested in stage 3. The two multiple-owner final cards eventually include the three active answers, although the accepted tracker record still labels the withdrawn refund item active with cancellation wording. These are transparent log observations, not substitutes for blind semantic scoring.

## Late-result exposure did not occur

**0/6 seeded old desktop reads arrived.** Every run cancels the inherited read before its 6,550 ms due time: unified/split at 6,100 ms and tracked at 6,300 ms, in both repetitions. The formal matrix therefore tests cancellation of inherited obsolete work; it does **not** demonstrate handling of an old result after arrival. The earlier offline setup test is a separate engineering check.

## Interpretation and next step

Keep atomic rejection and explicit reopening. The directly motivated next version is structured validation feedback with bounded retries and an explicitly marked raw-conversation actor fallback. None of these remedies was implemented or tested in this frozen study. A valid commit, more tolerant transitions, or a completed run cannot establish correct intention state or successful delivery.

All counts, rejected proposals, pre-call target statuses, costs, recovery transitions, late-job receipts and file hashes are preserved in [the machine-readable aggregate](TRACKER-FAILURE-AGGREGATE.json).
