"""Run the frozen offline checks once and retain their actual output."""
from pathlib import Path
import json
import sys
import unittest

STUDY = Path(__file__).resolve().parents[1]
ROOT = STUDY.parents[3]
sys.path.insert(0, str(ROOT / 'experiments/deep_conversation'))
log = STUDY / 'engineering/offline-tests.txt'
if log.exists():
    raise SystemExit('Refusing to replace the retained test output')
suite = unittest.defaultTestLoader.loadTestsFromNames([
    'test_intention_state', 'test_intent_roles', 'test_run_intent_roles'])
with log.open('w', encoding='utf-8') as stream:
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
summary = {'tests_run': result.testsRun, 'failures': len(result.failures),
           'errors': len(result.errors), 'skipped': len(result.skipped),
           'passed': result.wasSuccessful(), 'evidence': 'engineering/offline-tests.txt'}
(STUDY / 'engineering/offline-tests.json').write_text(
    json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary))
raise SystemExit(0 if result.wasSuccessful() else 1)
