"""Read-only consistency checks for the generated study and public download."""
from pathlib import Path
from html.parser import HTMLParser
import hashlib
import json
import re
import zipfile

STUDY = Path(__file__).resolve().parents[1]
ROOT = STUDY.parents[3]
DIST = ROOT / 'sites/conversation-agent-research/dist'
DEST = DIST / 'data/intent-role-separation'

class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
    def handle_starttag(self, tag, attrs):
        for key, value in attrs:
            if key in {'href','src'} and value:
                self.links.append(value)

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))
def digest(data):
    return hashlib.sha256(data).hexdigest()

page = DIST / 'intent-role-separation.html'
body = page.read_text(encoding='utf-8')
links = Links(); links.feed(body)
for link in links.links:
    if not link.startswith(('http:', 'https:', '#', 'data:')):
        assert (page.parent / link.split('#')[0].split('?')[0]).is_file(), link
result = read(DEST / 'analysis/results.json')
assert result == read(STUDY / 'analysis/results.json')
expected = {'unified':12, 'split':14, 'tracked':12}
for group in result['conditions']:
    assert group['metrics']['complete_and_correct']['yes'] == expected[group['condition']]
    assert group['runs'] == 16 and group['model_calls'] == 288
assert '<strong>48</strong>' in body and '<strong>864</strong>' in body
assert '30.2%' in body and '25 were rejected' in body
for n in ('12/16','14/16','818,956','798,990','1,043,258'):
    assert n in body, n
index = read(DEST / 'export-index.json')
with zipfile.ZipFile(DEST / 'evidence.zip') as bundle:
    assert set(bundle.namelist()) == set(index)
    for name, hashes in index.items():
        assert digest((STUDY / name).read_bytes()) == hashes['source_sha256'], name
        assert digest(bundle.read(name)) == hashes['export_sha256'], name
for path in DEST.rglob('*'):
    if path.is_file() and path.suffix not in {'.zip'} and path.name != 'export-index.json':
        relative = path.relative_to(DEST).as_posix()
        assert digest(path.read_bytes()) == index[relative]['export_sha256'], relative
        assert '.' not in path.read_text(encoding='utf-8')
report = DEST / 'RESULTS.md'
for link in re.findall(r'\]\(([^)]+)\)', report.read_text(encoding='utf-8')):
    if not link.startswith(('http:', 'https:', '#')):
        assert (report.parent / link).is_file(), link
for source in ('index.html','summary-placement.html','source-authority.html','october-studies.html'):
    assert (DIST / source).is_file(), source
assert 'intent-role-separation.html' in (DIST / 'index.html').read_text(encoding='utf-8')
assert read(STUDY / 'engineering/validation.json')['unique_engineering_tests'] == 40
print(json.dumps({'status':'passed','date':'2026-10-23','timezone':'America/Halifax',
    'page':'intent-role-separation.html','page_sha256':digest(page.read_bytes()),
    'results_sha256':digest((DEST/'analysis/results.json').read_bytes()),
    'evidence_zip_sha256':digest((DEST/'evidence.zip').read_bytes()),
    'records_checked':len(index),'page_links_checked':len(links.links),
    'checks':['primary counts and costs match scored records','all page/report local links resolve',
              'every bundled source/export hash agrees','standalone downloads agree with bundle',
              'historical pages remain and new page appears in index'],
    'limitations':['No inference or semantic regrading','Browser layout and hosted deployment checked separately']}))
