"""Update the grouped engineering record from retained check outputs."""
from pathlib import Path
import json

STUDY = Path(__file__).resolve().parents[1]
path = STUDY / 'engineering/validation.json'
value = json.loads(path.read_text(encoding='utf-8-sig'))
tests = json.loads((STUDY / 'engineering/offline-tests.json').read_text(encoding='utf-8'))
audit = json.loads((STUDY / 'analysis/EXECUTION-AUDIT.json').read_text(encoding='utf-8'))
assert tests['passed'] and tests['tests_run'] == 40 and audit['status'] == 'passed'
value['status'] = 'passed'
value['id'] = 'intent-role-separation-validation'
value['type'] = 'engineering_validation'
value['tested_revision'] = {
    'evaluation_manifest_sha256': audit['manifest_sha256'],
    'frozen_files': audit['frozen_source_files_checked'],
    'identity': 'evaluation/manifest.json and its 40 hashed source/protocol/fixture files'}
value['checks'] = [x for x in value['checks'] if x['name'] not in
                   {'Integrated frozen offline suite', 'Formal execution integrity', 'Website export and browser checks'}]
value['checks'].extend([
    {'name':'Integrated frozen offline suite', 'command':'python -B analysis/run_offline_validation.py',
     'tests_run':40, 'passed':40, 'failed':0, 'errors':0, 'skipped':0,
     'unique_tests':40, 'deduplication':'Same 19 + 12 + 9 checks listed above; not 40 additional unique tests.',
     'evidence':'engineering/offline-tests.txt'},
    {'name':'Formal execution integrity', 'command':'python -B analysis/audit_execution.py',
     'passed':True, 'runs':48, 'model_calls':864, 'tokens':2712832, 'issues':0,
     'scope':'Freeze, causal inputs, actual tools/receipts, shared budgets, captures and accounting; no semantic answer proof.',
     'evidence':'analysis/EXECUTION-AUDIT.json'}])
value['research_outcomes'] = {'status':'completed_scored','record':'analysis/results.json',
    'note':'Research success/failure labels are separate from passing engineering checks.'}
value['observed_remaining_defects'] = [
    'Twenty-five tracker proposals were rejected; four stages had no actor opportunity. No recovery repair was applied to the frozen study.',
    'Private work conclusions are only shared when persisted by the model; one recorded run computes the right room but fails to hand it to chat.',
    'All six seeded old reads were cancelled before arrival, so obsolete-result consumption is untested.',
    'Early workshop gold over-specifies price relative to raw requests; secondary scores preserve uncertainty and sensitivity.']
value['publication'] = {
    'tracking':'A separate deployment receipt records the final source SHA, Sites deployment and matching Pages build; artifact verification is not itself publication.',
    'receipt':'output/publications/research-site/deployments/intent-role-separation-2026-10-23.json'}
path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status':value['status'],'unique_tests':40,'research_runs':48}))
