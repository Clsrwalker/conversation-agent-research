"""Prepare blinded final-delivery packets and aggregate explicit reviewer labels.

Never infer semantic quality from a completed run or a valid tool call.
"""
from __future__ import annotations

import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import random

from run_intent_roles import STUDY, read, write

FIELDS = ('complete_and_correct', 'omission', 'scope_error', 'unnecessary_clarification', 'factual_error')


def prepare():
    manifest = read(STUDY / 'evaluation/manifest.json')
    cases = {case['case_id']: case for case in read(STUDY / 'fixtures/cases.json')['cases']}
    assignments = manifest['assignments'][:]
    random.Random(239107).shuffle(assignments)
    mapping, packets = [], []
    for index, assignment in enumerate(assignments):
        result = read(STUDY / 'evaluation/runs' / assignment['run_id'] / 'result.json')
        if result['status'] != 'completed' or len(result['stages']) != 3:
            raise ValueError('Scoring requires every assigned trajectory and final stage')
        case = cases[assignment['case_id']]
        packet_id = f'packet-{index + 1:03d}'
        mapping.append({'packet_id': packet_id, **assignment})
        packets.append({'packet_id': packet_id,
                        'conversation': case['replay']['events'],
                        'documents': case['corpus'],
                        'gold': case['scoring']['stage_gold'][-1],
                        'final_visible_cards': result['stages'][-1]['active_cards']})
    write(STUDY / 'scoring/blind-packets.json', packets)
    write(STUDY / 'scoring/private-mapping.json', mapping)
    write(STUDY / 'scoring/rubric.json', {
        'unit': 'final visible cards after all three conversation stages',
        'fields': list(FIELDS), 'labels': 'true / false / null (uncertain)',
        'complete_and_correct': 'All currently effective requests answered correctly, without obsolete or unsupported recommendations. A fully cancelled request needs no answer; obsolete cards must be withdrawn or corrected.',
        'omission': 'At least one effective request or still-valid constraint is missing from the final visible help. A mere promise to look it up is not delivery.',
        'scope_error': 'Misattributes a request, promotes an unaccepted assistant suggestion, contradicts retained constraints, or retains withdrawn/superseded advice as current. Mentioning prior scope as history is allowed.',
        'unnecessary_clarification': 'Asks the user to confirm settled instructions or asks to start already requested work instead of delivering.',
        'factual_error': 'States a substantive fact contradicted by or invented beyond the supplied fictional evidence. Honest uncertainty is not factual error.',
        'instructions': 'Score every packet independently, allowing paraphrase. Return a list with packet_id, all five fields, and a short evidence-based reason. Do not read mapping or implementation. Same text may occur in independent runs; score its meaning consistently. This is model review, not human annotation.'})
    print(json.dumps({'blind_packets': len(packets)}))


def aggregate():
    manifest = read(STUDY / 'evaluation/manifest.json')
    mapping = read(STUDY / 'scoring/private-mapping.json')
    adjudicated = read(STUDY / 'scoring/final-scores.json')
    scores = {row['packet_id']: row for row in adjudicated}
    if len(scores) != len(mapping) or set(scores) != {p['packet_id'] for p in mapping}:
        raise ValueError('Every packet must have one final explicit score')
    rows, groups = [], []
    for item in mapping:
        run = read(STUDY / 'evaluation/runs' / item['run_id'] / 'result.json')
        execution = read(STUDY / 'evaluation/runs' / item['run_id'] / 'execution.json')
        score = scores[item['packet_id']]
        if any(score.get(key) not in (True, False, None) for key in FIELDS) or not score.get('reason'):
            raise ValueError('Invalid score')
        steps = [step for stage in run['stages'] for step in stage['steps']]
        row = {**item, **{key: score[key] for key in FIELDS}, 'reason': score['reason'],
               'model_calls': run['metrics']['model_calls'],
               'input_tokens': run['metrics']['token_usage']['input_tokens'],
               'output_tokens': run['metrics']['token_usage']['output_tokens'],
               'api_wall_ms': run['metrics']['api_wall_ms'],
               'executed_tools': len(execution['tool_calls']),
               'step_errors': sum(step.get('status') == 'error' for step in steps),
               'tracker_calls': run['metrics']['role_counts'].get('tracker', 0),
               'tracker_commits': sum('tracker_commit' in step for step in steps),
               'published_receipts': sum(t['result'].get('status') in ('displayed','unchanged') for t in execution['tool_calls'])}
        rows.append(row)
    for arm in ('unified', 'split', 'tracked'):
        subset = [row for row in rows if row['condition'] == arm]
        group = {'condition': arm, 'runs': len(subset), 'families': len({r['case_id'] for r in subset}),
                 'metrics': {field: {'yes': sum(r[field] is True for r in subset),
                                     'no': sum(r[field] is False for r in subset),
                                     'uncertain': sum(r[field] is None for r in subset)} for field in FIELDS}}
        group.update({key: sum(r[key] for r in subset) for key in
                      ('model_calls','input_tokens','output_tokens','api_wall_ms','executed_tools',
                       'step_errors','tracker_calls','tracker_commits','published_receipts')})
        group['family_complete_both_repeats'] = sum(all(r['complete_and_correct'] is True for r in subset if r['case_id'] == family)
                                                  for family in {r['case_id'] for r in subset})
        groups.append(group)
    result = {'status': 'completed_scored', 'date': manifest['study_date'],
              'kind': 'controlled_executed_synthetic_replay', 'runs': len(rows), 'families': 8,
              'repetitions': 2, 'conditions': groups, 'rows': rows,
              'new_model_calls': sum(row['model_calls'] for row in rows),
              'actual_simulator_tools_executed': True, 'default_harness_changed': False,
              'scoring': 'two model reviewers with blind condition IDs; explicit adjudication of disagreements',
              'limitations': ['Eight authored synthetic families, not independent real users.',
                             'Two repeats per family are correlated; report both and family-level outcomes.',
                             'All arms use the new stepping session, not the native DeepAgents baseline.',
                             'Role restriction, alternation and additional state/context are part of the treatment.',
                             'Equal call ceilings do not equalize input tokens or available actor calls.',
                             'Final-card scoring is the primary endpoint; intermediate user exposure may differ.',
                             'No LoRA, ASR, live Lab integration or production benefit established.']}
    write(STUDY / 'analysis/results.json', result)
    with (STUDY / 'analysis/rows.csv').open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    print(json.dumps({'runs': len(rows), 'calls': result['new_model_calls'], 'conditions': groups}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['prepare', 'aggregate'])
    args = parser.parse_args()
    prepare() if args.action == 'prepare' else aggregate()
