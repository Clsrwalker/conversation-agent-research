"""Scheduled answer delivery with explicit local edits and visible receipts."""
from __future__ import annotations

from copy import deepcopy
import json

from langchain_core.messages import AIMessage, HumanMessage

from answer_delivery import AnswerDelivery, DELIVERY_PROMPT, _digest
from agent import content_text
from budget_policy import BudgetPolicy
from card_updates import PATCH_DELIVERY_TOOL, prepare_card_update


PATCH_PROMPT = """
For an update, specify edits as old/new passages from the observed card; whitespace
may differ. Only those passages change. Use append_text for additional supported
help, not for a correction that would leave a conflicting answer behind. Keep all
other still-valid answers and their evidence. Source_ids adds citations; use
remove_source_ids only when a citation no longer supports any retained answer.
You may select the entire card text when all of it needs replacement. Do not
rewrite a whole card just to change one answer. Publishing a new card requires
text; updating requires edits or append_text, not a replacement text field.
Mere confirmations, meeting summaries and generic offers to help should receive
none. Repeated useful advice already visible also needs none. The shared budget
must cover later conversation; this is one opportunity, not a required review.
"""


class BudgetStateDelivery(AnswerDelivery):
    prompt = DELIVERY_PROMPT + PATCH_PROMPT
    tool_schema = PATCH_DELIVERY_TOOL

    def review_permission(self, packet):
        allowed, details = BudgetPolicy(self.world, self.settings).review_eligibility(packet)
        if not allowed:
            if details['reason'] in {'call_allowance_deferred', 'token_allowance_deferred'}:
                return {'pending': True, 'reason': details['reason'], 'scheduling': details}
            return {'outcome': 'budget_or_input_deferred', 'action': 'none',
                    'reason': details['reason'], 'scheduling': details}
        return None

    def review_started(self, packet):
        BudgetPolicy(self.world, self.settings).record_review_started(packet)

    def _parse(self, answer, packet):
        calls = getattr(answer, 'tool_calls', [])
        if (getattr(answer, 'invalid_tool_calls', []) or len(calls) != 1 or
                calls[0].get('name') != 'deliver_answer' or
                not isinstance(calls[0].get('args'), dict)):
            return super()._parse(answer, packet)
        args = calls[0]['args']
        if args.get('action') != 'update':
            # Publishing under an already visible ID must not bypass local edits.
            if args.get('action') == 'publish' and args.get('card_id') in packet['active_cards']:
                return {'outcome': 'edit_required', 'action': 'none',
                    'reason': 'The chosen card already exists. Use update with local edits or append_text.',
                    'observed_card': deepcopy(packet['active_cards'][args['card_id']])}
            return super()._parse(answer, packet)
        identifier = args.get('card_id')
        if not isinstance(identifier, str) or identifier not in packet['active_cards']:
            return {'outcome': 'unobserved_card', 'action': 'none',
                    'reason': 'Choose an existing observed card for an update.'}
        if args.get('text') and not args.get('edits') and not args.get('append_text'):
            return {'outcome': 'edit_required', 'action': 'none',
                'reason': 'A replacement text would discard unselected answers. Use edits with old/new passages or append_text.',
                'observed_card': deepcopy(packet['active_cards'][identifier])}
        prepared = prepare_card_update(packet['active_cards'][identifier], args.get('edits'),
            append_text=args.get('append_text', ''), source_ids=args.get('source_ids'),
            remove_source_ids=args.get('remove_source_ids'), visible_sources=packet['visible_sources'])
        if prepared['status'] != 'prepared':
            return {'outcome': 'invalid_edit', 'action': 'none',
                    'reason': prepared['reason'], 'edit_feedback': prepared}
        return {'outcome': 'reviewed', 'action': 'update', 'card_id': identifier,
                'reason': args.get('reason', ''), 'text': prepared['text'],
                'source_ids': prepared['source_ids'],
                'ignored_source_ids': prepared['ignored_source_ids'],
                'edit_request': deepcopy(args)}

    def __call__(self, state, config):
        if state.get('budget_deferred') and not state.get('delivery_pending'):
            return {}
        messages = state.get('messages', [])
        if not messages or not isinstance(messages[-1], AIMessage):
            return {'delivery_pending': ''}
        answer = messages[-1]
        content_hash = _digest(content_text(answer).strip())
        message_id = answer.id or f'message-{len(messages) - 1}-{content_hash}'
        candidate_key = _digest({'message_id': message_id, 'content_hash': content_hash})
        delegated = super().__call__(state, config)
        if delegated.get('delivery_pending'):
            return delegated
        log = self.world.export()['environment_log']
        # A receipt can predate this invocation if its graph checkpoint was lost.
        # Re-deliver its stable message ID, without repeating inference or commit.
        receipts = [e for e in log if e['kind'] == 'answer_delivery_receipt'
                    and e.get('candidate_key') == candidate_key]
        if not receipts:
            return {'delivery_pending': ''}
        receipt = receipts[-1]
        if any(message.id == f"delivery-{receipt['seq']}" for message in messages):
            return {'delivery_pending': ''}
        key = receipt['candidate_key']
        candidate = next(e for e in log if e['kind'] == 'answer_delivery_candidate' and e['candidate_key'] == key)
        decision = next(e['decision'] for e in log if e['kind'] == 'answer_delivery_decision' and e['candidate_key'] == key)
        packet, result = candidate['packet'], receipt['result']
        if (result.get('status') == 'not_published' and
                decision['outcome'] not in {'invalid_edit', 'edit_required', 'unobserved_card'}):
            # A scheduler defer or a deliberate silence is not a new observation.
            # Keep normal retrieval-failure continuation available in observe.
            return {'delivery_pending': ''}
        cards = deepcopy(packet['active_cards'])
        identifier = result.get('card_id', decision.get('card_id'))
        if identifier and isinstance(result.get('committed_card'), dict):
            cards[identifier] = deepcopy(result['committed_card'])
        elif identifier and result.get('status') == 'withdrawn':
            cards.pop(identifier, None)
        elif identifier and result.get('status') == 'conflict' and 'current_card' in result:
            if isinstance(result['current_card'], dict):
                cards[identifier] = deepcopy(result['current_card'])
            else:
                cards.pop(identifier, None)
        # This is an actual operation receipt, not an instruction to redo work.
        # The snapshot contains only cards observed in the packet or this receipt.
        feedback = {'kind': 'delivery_recovery', 'origin': 'budget_state_receipt',
                    'observation_cursor': packet['candidate']['event_cursor'],
                    'active_cards': cards, 'result': result, 'decision': decision,
                    'note': 'Delivery result for your last private answer. No extra action is required; consider a concrete failure on the next useful turn.'}
        return {'delivery_pending': '', 'messages': [HumanMessage(content=json.dumps(feedback, ensure_ascii=False),
                                          id=f"delivery-{receipt['seq']}")]}
