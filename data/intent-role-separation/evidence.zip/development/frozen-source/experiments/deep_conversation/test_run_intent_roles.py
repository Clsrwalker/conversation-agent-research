"""Independent offline audits of replay scheduling and evidence isolation.

The model here is an explicit scripted probe. No real inference is performed,
and correct probe outputs are not evidence of assistance quality.
"""
from __future__ import annotations

from contextlib import ExitStack, redirect_stdout
from copy import deepcopy
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from pydantic import PrivateAttr

import intent_roles
import run_intent_roles as runner
from world import WorldStore


class SchedulingProbe(BaseChatModel):
    model_name: str = 'local:offline-scheduling-probe'
    _requests: list = PrivateAttr(default_factory=list)

    @property
    def _llm_type(self):
        return 'scripted-offline-scheduling-probe'

    def bind_tools(self, tools, **kwargs):
        return self

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        self._requests.append(deepcopy(messages))
        packet = json.loads(messages[-1].content)
        newest = packet['conversation'][-1]['text']
        message = AIMessage(content='', tool_calls=[{
            'name': 'publish_card', 'args': {'text': newest, 'card_id': 'probe'},
            'id': f'probe-{len(self._requests)}', 'type': 'tool_call'}],
            usage_metadata={'input_tokens': 10, 'output_tokens': 5, 'total_tokens': 15})
        return ChatResult(generations=[ChatGeneration(message=message)])


class RunnerAuditTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.study = self.root / 'study'
        self.fixture = {
            'case_id': 'causal-probe',
            'gold': {'secret': 'SCORING_ONLY_SECRET'},
            'replay': {
                'case_id': 'causal-probe', 'corpus_ids': [], 'close_at_ms': 4000,
                'tool_latency_ms': {'search': 100, 'read': 100},
                'events': [
                    {'kind': 'asr_final', 'at_ms': 0, 'speaker': 'Ada', 'text': 'INITIAL_MESSAGE'},
                    {'kind': 'asr_final', 'at_ms': 2000, 'speaker': 'Ada', 'text': 'LATER_EVENT_SECRET'},
                ],
            },
            'corpus': [],
            'stages': [
                {'stage_id': 'initial', 'at_ms': 0, 'end_at_ms': 1000},
                {'stage_id': 'changed', 'at_ms': 2000, 'end_at_ms': 3000},
            ],
        }
        runner.write(self.study / 'fixtures/cases.json',
                     {'dev_cases': [self.fixture], 'cases': [self.fixture]})
        self.source = self.root / 'source.py'
        self.source.write_text('# fixed source\n', encoding='utf-8')
        self.stack = ExitStack()
        self.stack.enter_context(patch.object(runner, 'ROOT', self.root))
        self.stack.enter_context(patch.object(runner, 'STUDY', self.study))
        self.stack.enter_context(patch.object(runner, 'inputs', return_value={
            'source.py': self.source, 'study/fixtures/cases.json': self.study / 'fixtures/cases.json'}))
        self.stack.enter_context(patch.object(runner, 'local_model_metadata', return_value={'digest': 'offline-probe'}))
        self.stack.enter_context(patch.object(runner, 'fingerprint', return_value={'packages': {'probe': '1'}}))
        self.stack.enter_context(redirect_stdout(io.StringIO()))

    def tearDown(self):
        self.stack.close()
        self.temp.cleanup()

    def prepare(self):
        runner.prepare('development')
        return runner.verify('development')

    def test_manifest_and_runtime_inputs_are_frozen_before_generation(self):
        self.prepare()
        manifest_path = self.study / 'development/manifest.json'
        manifest = runner.read(manifest_path)
        manifest['calls_per_stage'] = 9
        runner.write(manifest_path, manifest)
        with self.assertRaisesRegex(ValueError, 'manifest'):
            runner.verify('development')

    def test_frozen_source_and_copy_are_both_checked(self):
        self.prepare()
        original = self.source.read_bytes()
        self.source.write_text('# changed runtime\n', encoding='utf-8')
        with self.assertRaisesRegex(ValueError, 'Frozen input'):
            runner.verify('development')
        self.source.write_bytes(original)
        copy = self.study / 'development/frozen-source/source.py'
        copy.write_text('# changed archive\n', encoding='utf-8')
        with self.assertRaisesRegex(ValueError, 'Frozen copy'):
            runner.verify('development')

    def test_prepare_cannot_overwrite_an_existing_freeze(self):
        self.prepare()
        before = (self.study / 'development/manifest.json').read_bytes()
        with self.assertRaises(FileExistsError):
            runner.prepare('development')
        self.assertEqual(before, (self.study / 'development/manifest.json').read_bytes())

    def test_runtime_or_dependency_drift_is_rejected(self):
        self.prepare()
        with patch.object(runner, 'local_model_metadata', return_value={'digest': 'changed'}):
            with self.assertRaisesRegex(ValueError, 'runtime changed'):
                runner.verify('development')
        with patch.object(runner, 'fingerprint', return_value={'packages': {'probe': '2'}}):
            with self.assertRaisesRegex(ValueError, 'Dependency'):
                runner.verify('development')

    def test_stage_snapshots_and_model_requests_exclude_future_events_and_gold(self):
        self.prepare()
        model = SchedulingProbe()
        closed = []
        real_close = intent_roles.IntentRoleSession.close

        def close(session):
            closed.append(session)
            return real_close(session)

        with patch('providers.make_model', return_value=model), \
                patch.object(intent_roles.IntentRoleSession, 'close', close):
            runner.run_batch('development', limit=1)
        self.assertEqual(1, len(closed))
        with self.assertRaisesRegex(RuntimeError, 'closed'):
            closed[0].world.snapshot()
        result = runner.read(self.study / 'development/runs/causal-probe--unified--r1/result.json')
        first, second = result['stages']
        self.assertEqual(12, result['metrics']['model_calls'])
        self.assertEqual(6, first['metrics']['model_calls'])
        self.assertLess(first['at_ms'], 1000)
        self.assertLess(second['at_ms'], 3000)
        self.assertEqual('INITIAL_MESSAGE', first['active_cards']['probe']['text'])
        self.assertEqual('LATER_EVENT_SECRET', second['active_cards']['probe']['text'])
        first_requests = json.dumps([[m.content for m in batch] for batch in model._requests[:6]])
        all_requests = json.dumps([[m.content for m in batch] for batch in model._requests])
        self.assertNotIn('LATER_EVENT_SECRET', first_requests)
        self.assertNotIn('LATER_EVENT_SECRET', json.dumps(first))
        self.assertNotIn('SCORING_ONLY_SECRET', all_requests)
        self.assertIn('LATER_EVENT_SECRET', all_requests)

    def test_interrupted_or_failed_run_is_not_silently_retried(self):
        self.prepare()
        folder = self.study / 'development/runs/causal-probe--unified--r1'
        folder.mkdir(parents=True)
        model = SchedulingProbe()
        with patch('providers.make_model', return_value=model):
            with self.assertRaisesRegex(RuntimeError, 'Interrupted'):
                runner.run_batch('development', limit=1)
            runner.write(folder / 'result.json', {'status': 'failed'})
            with self.assertRaisesRegex(RuntimeError, 'failed run'):
                runner.run_batch('development', limit=1)
        self.assertEqual([], model._requests)

    def test_initialization_failure_closes_world_and_retains_failure(self):
        self.prepare()
        worlds = []

        def world(*args, **kwargs):
            instance = WorldStore(*args, **kwargs)
            worlds.append(instance)
            return instance

        with patch('providers.make_model', return_value=SchedulingProbe()), \
                patch.object(runner, 'WorldStore', world), \
                patch.object(intent_roles, 'IntentRoleSession', side_effect=ValueError('probe initialization failure')):
            with self.assertRaisesRegex(ValueError, 'initialization failure'):
                runner.run_batch('development', limit=1)
        with self.assertRaisesRegex(RuntimeError, 'closed'):
            worlds[0].snapshot()
        result = runner.read(self.study / 'development/runs/causal-probe--unified--r1/result.json')
        self.assertEqual('failed', result['status'])

    def test_final_export_failure_still_closes_session_and_world(self):
        self.prepare()
        sessions = []
        real_session = intent_roles.IntentRoleSession

        class ExportFailureSession(real_session):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                sessions.append(self)

            def step(self, stage_deadline_ms=None):
                raise ValueError('probe execution failure')

        with patch('providers.make_model', return_value=SchedulingProbe()), \
                patch.object(intent_roles, 'IntentRoleSession', ExportFailureSession), \
                patch.object(WorldStore, 'export', side_effect=OSError('probe export failure')):
            try:
                with self.assertRaises(OSError):
                    runner.run_batch('development', limit=1)
                with self.assertRaisesRegex(RuntimeError, 'closed'):
                    sessions[0].world.snapshot()
            finally:
                # Ensure this adversarial test itself never leaks a connection,
                # even against an implementation that fails its assertion.
                for session in sessions:
                    session.close()
                    session.world.close()

    def test_authored_fixtures_have_authenticated_history_and_executable_late_setup(self):
        authored = runner.read(Path(__file__).resolve().parents[2] /
                               'output/research/2026-10-23/intent-role-separation/fixtures/cases.json')
        all_cases = authored['cases'] + authored['dev_cases']
        for case in all_cases:
            with self.subTest(case=case['case_id']):
                world = WorldStore(self.root / f"{case['case_id']}.sqlite",
                                   case['replay'], case['corpus'])
                try:
                    runner.advance(world, case['stages'][-1]['at_ms'])
                    history = intent_roles.normalize_history(world.history())
                    self.assertEqual(len(case['replay']['events']), len(history))
                    for event in history:
                        if event.get('kind') == 'assistant_proposal':
                            self.assertEqual('assistant', event['role'])
                    self.assertNotIn('scoring', case['replay'])
                finally:
                    world.close()
        late = next(case for case in all_cases if case.get('setup_actions'))
        runner.write(self.study / 'fixtures/cases.json', {'dev_cases': [late], 'cases': [late]})
        self.prepare()
        model = SchedulingProbe()
        with patch('providers.make_model', return_value=model):
            runner.run_batch('development', limit=1)
        run = self.study / 'development/runs' / f"{late['case_id']}--unified--r1"
        result = runner.read(run / 'result.json')
        first, second, _ = result['stages']
        self.assertEqual('completed', result['status'])
        self.assertEqual(18, result['metrics']['model_calls'])
        first_packet = first['steps'][0]['input']
        self.assertTrue(any(job['operation'] == 'read' for job in first_packet['pending_jobs']))
        self.assertFalse(any(e.get('operation') == 'read' and e.get('kind') == 'job_result'
                             for e in first_packet['events']))
        execution = runner.read(run / 'execution.json')
        full_arrivals = [item for item in execution['environment_log']
                         if item['kind'] == 'environment_event'
                         and item['event'].get('operation') == 'read']
        self.assertTrue(full_arrivals)
        self.assertGreaterEqual(full_arrivals[0]['at_ms'], late['stages'][1]['at_ms'])
        self.assertLess(full_arrivals[0]['at_ms'], late['stages'][1]['end_at_ms'])
        self.assertLess(first['at_ms'], late['stages'][1]['at_ms'])
        self.assertGreaterEqual(second['at_ms'], full_arrivals[0]['at_ms'])


if __name__ == '__main__':
    unittest.main()
