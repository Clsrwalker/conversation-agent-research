"""Prepare local edits to an observed answer without rewriting unrelated help.

This is an internal tool protocol, not a format for user-facing answers. The
model still decides which claims apply and writes ordinary prose. Code locates
the requested spans and preserves text the model did not select; it does not
infer truth, cancellation, ownership, or semantic equivalence.

Integration: prepare against the card actually shown to the model. On success,
pass ``text`` and ``source_ids`` to the existing guarded ``publish_card`` path,
using the *original* observed card as ``unchanged_card`` and the original input
cursor. Preparation is pure; only that existing transaction commits the edit.
On failure, return the diagnostic and observed snapshot to the model so it can
correct its request. Do not substitute current world state or retry blindly.
"""
from __future__ import annotations

from copy import deepcopy
import re


EDIT_ITEMS = {
    'type': 'array',
    'description': ('Local corrections or deletions in the observed card. Each old '
                    'passage must identify one unique location; whitespace may '
                    'differ. An empty new passage removes only the selected text. '
                    'Unselected conclusions remain unchanged.'),
    'items': {
        'type': 'object',
        'properties': {
            'old': {'type': 'string', 'description': 'A unique passage from the observed card to change.'},
            'new': {'type': 'string', 'description': 'Replacement prose, or empty text to delete this passage.'},
        },
        'required': ['old', 'new'],
        'additionalProperties': False,
    },
}

EDIT_CARD_PARAMETERS = {
    'type': 'object',
    'properties': {
        'card_id': {'type': 'string', 'description': 'The ID of an existing card you have observed.'},
        'edits': deepcopy(EDIT_ITEMS),
        'append_text': {'type': 'string', 'description': ('New, additional help to append, if any. To correct '
            'an old answer, edit its passage rather than append a contradictory answer.')},
        'source_ids': {'type': 'array', 'items': {'type': 'string'},
                       'description': 'Additional supporting sources you have observed. Existing citations are retained.'},
        'remove_source_ids': {'type': 'array', 'items': {'type': 'string'},
            'description': 'Existing citations that no longer support any retained text. Do not remove support for other answers.'},
    },
    'required': ['card_id'],
}

EDIT_CARD_TOOL = {
    'name': 'edit_card',
    'description': ('Edit selected parts of an observed card while preserving its other answers. '
        'Use local replacements or deletions for corrections and partial cancellation. '
        'The operation is atomic and checks for new input or a concurrent card change. '
        'A failed edit returns feedback and leaves the card unchanged.'),
    'parameters': deepcopy(EDIT_CARD_PARAMETERS),
}

PATCH_DELIVERY_TOOL = {
    'name': 'deliver_answer',
    'description': ('Choose at most one visible change, or none. For update, edit '
        'the relevant passages of the observed card; other answers are retained. '
        'This is a delivery decision, not a new investigation.'),
    'parameters': {
        'type': 'object',
        'properties': {
            'action': {'type': 'string', 'enum': ['publish', 'update', 'withdraw', 'none']},
            'text': {'type': 'string', 'description': 'Ordinary user-facing prose for a new publication.'},
            **deepcopy(EDIT_CARD_PARAMETERS['properties']),
            'reason': {'type': 'string', 'description': 'A short private explanation of this decision.'},
        },
        'required': ['action'],
    },
}


def _failure(card, code, reason, **details):
    return {'status': 'invalid_edit', 'code': code, 'reason': reason,
            'observed_card': deepcopy(card), **details,
            'next_step': ('Read the observed card and choose a unique passage to change. '
                          'No part of this update was applied. To remove an entire '
                          'obsolete card, use withdraw_card instead.')}


def _identifiers(value):
    if value is None:
        return []
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
        raise ValueError('Source identifiers must be text or a list of text identifiers.')
    return list(dict.fromkeys(value))


def _locations(text, passage):
    """Locate literal text with tolerant spacing; never evaluate regular expressions."""
    # Search with zero-width lookahead so repeated *overlapping* matches are also
    # ambiguous (e.g. old='aaa' in 'aaaa'). All model-supplied characters are escaped.
    pattern = r'\s+'.join(re.escape(part) for part in re.split(r'\s+', passage.strip()))
    return [(match.start(1), match.end(1))
            for match in re.finditer('(?=(' + pattern + '))', text)]


def prepare_card_update(observed_card, edits=None, *, append_text='', source_ids=None,
                        remove_source_ids=None, visible_sources=None):
    """Prepare one all-or-nothing update against an observed snapshot.

    ``edits`` contain ``old``/``new`` literal passages, all located in the original
    text. No fuzzy matching, unrequested whole-card rewrite, or implicit deletion
    is performed. New citations must occur in ``visible_sources`` (a mapping or
    iterable of identifiers). Previously attached citations survive unless the
    caller explicitly removes them. Retaining a citation is not a fact check.

    Returns ``status='prepared'`` with text/source_ids, or ``invalid_edit`` with
    a precise diagnostic and the unchanged *observed*, not current-world, card.
    The caller must still commit through its existing input/card CAS guard.
    """
    if not isinstance(observed_card, dict) or not isinstance(observed_card.get('text'), str):
        return _failure(observed_card, 'unobserved_card', 'The edit needs a card snapshot you have observed.')
    original = observed_card['text']
    if edits is None:
        edits = []
    if not isinstance(edits, list):
        return _failure(observed_card, 'invalid_edits', 'Edits must be a list of old/new passage pairs.')
    if not isinstance(append_text, str):
        return _failure(observed_card, 'invalid_addition', 'Additional help must be ordinary text.')
    try:
        previous = _identifiers(observed_card.get('source_ids'))
        requested = _identifiers(source_ids)
        removed = _identifiers(remove_source_ids)
        available = set(visible_sources or ())
        if any(not isinstance(item, str) for item in available):
            raise ValueError('Visible source identifiers must be text.')
    except (ValueError, TypeError) as error:
        return _failure(observed_card, 'invalid_sources', str(error))
    if set(requested) & set(removed):
        return _failure(observed_card, 'conflicting_sources',
            'The same citation cannot be added and removed in one update.')

    located = []
    for index, edit in enumerate(edits):
        if not isinstance(edit, dict) or set(edit) != {'old', 'new'}:
            return _failure(observed_card, 'invalid_passage',
                'Each edit needs exactly an old passage and its new replacement.', edit_index=index)
        old, new = edit['old'], edit['new']
        if not isinstance(old, str) or not old.strip() or not isinstance(new, str):
            return _failure(observed_card, 'invalid_passage',
                'Select a nonempty old passage and provide replacement text (empty is a deletion).', edit_index=index)
        matches = _locations(original, old)
        if not matches:
            return _failure(observed_card, 'unmatched_passage',
                'The selected old passage does not occur in the observed card.', edit_index=index)
        if len(matches) != 1:
            return _failure(observed_card, 'ambiguous_passage',
                'The selected old passage occurs more than once; include enough surrounding text to identify it.',
                edit_index=index, match_count=len(matches))
        start, end = matches[0]
        if any(start < prior_end and end > prior_start for prior_start, prior_end, _ in located):
            return _failure(observed_card, 'overlapping_edits',
                'Two edits select overlapping text. Combine them into one replacement.', edit_index=index)
        located.append((start, end, new))

    updated = original
    for start, end, replacement in sorted(located, reverse=True):
        updated = updated[:start] + replacement + updated[end:]
    addition = append_text.strip()
    if addition:
        updated = updated.rstrip() + ('\n\n' if updated.strip() else '') + addition
    # Do not silently turn a partial edit into withdrawal of the whole card.
    if not updated.strip():
        return _failure(observed_card, 'empty_update',
            'This edit would remove the whole card; choose an explicit withdrawal if it is obsolete.')
    retained = [item for item in previous if item not in removed]
    accepted = [item for item in requested if item in available]
    citations = list(dict.fromkeys([*retained, *accepted]))
    return {'status': 'prepared', 'text': updated, 'source_ids': citations,
            'ignored_source_ids': [item for item in requested if item not in available],
            'removed_source_ids': [item for item in removed if item in previous],
            'ignored_remove_source_ids': [item for item in removed if item not in previous],
            'changed': updated != original or citations != previous,
            'edit_count': len(located)}
