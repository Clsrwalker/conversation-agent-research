"""Optional, local-only controlled replay for independent same-model roles.

This does not change the Lab default. Gold is read only by offline scorers.
Each stage offers six total calls, including tracker calls, to every condition.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import random
import shutil

from config import Settings
from local_runtime import local_model_metadata
from run import fingerprint, source_files
from world import WorldStore

ROOT = Path(__file__).resolve().parents[2]
STUDY = ROOT / 'output/research/2026-10-23/intent-role-separation'
ARMS = ('unified', 'split', 'tracked')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def settings():
    return Settings(preset='agent-led', max_calls=18, max_tokens=180000,
                    max_output_tokens=1200, model_latency_ms=100)


def inputs():
    values = source_files()
    for name in ('intention_state.py', 'intent_roles.py', 'run_intent_roles.py',
                 'test_intention_state.py', 'test_intent_roles.py', 'test_run_intent_roles.py',
                 'INTENTION_ROLES.md', 'score_intent_roles.py'):
        path = ROOT / 'experiments/deep_conversation' / name
        values[path.relative_to(ROOT).as_posix()] = path
    for name in ('PROTOCOL.md', 'fixtures/cases.json'):
        path = STUDY / name
        values[path.relative_to(ROOT).as_posix()] = path
    return values


def prepare(phase):
    destination = STUDY / phase
    if (destination / 'manifest.json').exists():
        raise FileExistsError('Freeze already exists; preserve it and verify instead.')
    fixture = read(STUDY / 'fixtures/cases.json')
    selected = fixture['dev_cases' if phase == 'development' else 'cases']
    repetitions = 1 if phase == 'development' else 2
    assignments = []
    pairs = [(case['case_id'], rep) for case in selected for rep in range(1, repetitions + 1)]
    random.Random(20261023).shuffle(pairs)
    for index, (case_id, rep) in enumerate(pairs):
        arms = list(ARMS[index % 3:] + ARMS[:index % 3])
        if rep == 2:
            arms.reverse()
        assignments.extend({'run_id': f'{case_id}--{arm}--r{rep}', 'case_id': case_id,
                            'condition': arm, 'repeat': rep} for arm in arms)
    files = inputs()
    manifest = {'schema_version': 1, 'kind': 'controlled_executed_synthetic_replay',
                'phase': phase, 'created_at_utc': datetime.now(timezone.utc).isoformat(),
                'study_date': '2026-10-23', 'display_timezone': 'America/Halifax',
                'settings': asdict(settings()), 'local_model': local_model_metadata(settings()),
                'packages': fingerprint()['packages'],
                'source_sha256': {name: digest(path) for name, path in files.items()},
                'calls_per_stage': 6, 'repetitions': repetitions, 'assignments': assignments,
                'gold_model_visible': False, 'default_harness_changed': False,
                'training_or_lora': False}
    for name, source in files.items():
        dest = destination / 'frozen-source' / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, dest)
    write(destination / 'manifest.json', manifest)
    (destination / 'manifest.sha256').write_text(digest(destination / 'manifest.json') + '\n', encoding='ascii')
    print(json.dumps({'prepared': phase, 'assignments': len(assignments),
                      'source_files': len(files), 'model_digest': manifest['local_model']['digest']}), flush=True)


def verify(phase):
    expected_manifest = (STUDY / phase / 'manifest.sha256').read_text(encoding='ascii').strip()
    if digest(STUDY / phase / 'manifest.json') != expected_manifest:
        raise ValueError('Frozen experiment manifest changed')
    manifest = read(STUDY / phase / 'manifest.json')
    for name, expected in manifest['source_sha256'].items():
        if digest(ROOT / name) != expected:
            raise ValueError(f'Frozen input changed: {name}')
        if digest(STUDY / phase / 'frozen-source' / name) != expected:
            raise ValueError(f'Frozen copy changed: {name}')
    if local_model_metadata(settings()) != manifest['local_model']:
        raise ValueError('Local model/runtime changed after freeze')
    if fingerprint()['packages'] != manifest['packages']:
        raise ValueError('Dependency versions changed after freeze')
    return manifest


def advance(world, target):
    while world.now < target and not world.done:
        world.advance_until_or_event(target)


def run_batch(phase, limit=None):
    from intent_roles import IntentRoleSession
    from providers import make_model
    manifest = verify(phase)
    fixture = read(STUDY / 'fixtures/cases.json')
    cases = {c['case_id']: c for c in fixture['dev_cases' if phase == 'development' else 'cases']}
    model = make_model(settings())
    completed = 0
    for assignment in manifest['assignments']:
        folder = STUDY / phase / 'runs' / assignment['run_id']
        if (folder / 'result.json').exists():
            if read(folder / 'result.json')['status'] != 'completed':
                raise RuntimeError('Prior failed run retained; do not silently retry it.')
            continue
        if folder.exists():
            raise RuntimeError(f'Interrupted run retained; inspect before a new attempt: {folder.name}')
        folder.mkdir(parents=True)
        case = cases[assignment['case_id']]
        # Explicit selection prevents scoring annotations entering runtime state.
        world = WorldStore(folder / 'world.sqlite', case['replay'], case['corpus'],
                           model_latency_ms=settings().model_latency_ms)
        session = None
        result = {**assignment, 'status': 'running', 'stages': []}
        try:
            session = IntentRoleSession(world, settings(), folder, condition=assignment['condition'], model=model)
            for setup_index, setup in enumerate(case.get('setup_actions', [])):
                if setup['operation'] == 'advance_to_next_event':
                    world.advance_next()
                    continue
                if 'at_ms' in setup:
                    advance(world, setup['at_ms'])
                call_id = f'setup-{setup_index}'
                world.apply(call_id, setup['operation'], setup.get('arguments', {}))
                session.ingest_receipts([call_id])
            for stage in case['stages']:
                advance(world, stage['at_ms'])
                steps = []
                for _ in range(manifest['calls_per_stage']):
                    step = session.step(stage_deadline_ms=stage['end_at_ms'])
                    steps.append(step)
                    if step.get('status') in {'budget_exhausted', 'window_closed', 'stopped'}:
                        break
                # Score visible output immediately after the allocated calls;
                # later stage events must not enter this snapshot.
                observation, cursor = world.observation(-1)
                result['stages'].append({'stage_id': stage['stage_id'], 'at_ms': world.now,
                                         'cursor': cursor, 'active_cards': observation['active_cards'],
                                         'steps': steps, 'metrics': world.metrics(),
                                         'session': session.export()})
                write(folder / 'progress.json', result)
            result['status'] = 'completed'
        except Exception as error:
            result.update(status='failed', error=f'{type(error).__name__}: {error}')
            raise
        finally:
            try:
                exported = world.export()
                result['metrics'] = exported['metrics']
                write(folder / 'execution.json', exported)
                write(folder / 'result.json', result)
            finally:
                try:
                    if session is not None:
                        session.close()
                finally:
                    world.close()
        completed += 1
        print(json.dumps({'run_id': assignment['run_id'], 'status': result['status'],
                          'metrics': result['metrics']}), flush=True)
        if limit and completed >= limit:
            break
    verify(phase)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['prepare', 'verify', 'run'])
    parser.add_argument('--phase', choices=['development', 'evaluation'], default='evaluation')
    parser.add_argument('--limit', type=int)
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare(args.phase)
    elif args.action == 'verify':
        value = verify(args.phase)
        print(json.dumps({'verified': args.phase, 'source_files': len(value['source_sha256'])}))
    else:
        run_batch(args.phase, args.limit)
