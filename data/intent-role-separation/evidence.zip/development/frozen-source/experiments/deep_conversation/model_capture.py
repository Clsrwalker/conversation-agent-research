"""Local audit capture of real model requests and complete message subclasses.

This callback does not alter requests, tools, accounting or model behavior.
Serialize each message directly: dumping a generation through its BaseMessage
field can otherwise silently discard AIMessage.tool_calls and usage_metadata.
"""
from __future__ import annotations

import json
from pathlib import Path
from threading import RLock

from langchain_core.callbacks import BaseCallbackHandler


class ModelCapture(BaseCallbackHandler):
    raise_error = True
    run_inline = True

    def __init__(self, path):
        self.path = Path(path)
        self.lock = RLock()

    def emit(self, kind, run_id, **values):
        with self.lock, self.path.open('a', encoding='utf-8') as stream:
            stream.write(json.dumps({'kind': kind, 'run_id': str(run_id), **values},
                                   ensure_ascii=False, default=str) + '\n')

    def on_chat_model_start(self, serialized, messages, *, run_id,
                            parent_run_id=None, metadata=None, **kwargs):
        self.emit('request', run_id, parent_run_id=str(parent_run_id),
                  metadata=metadata or {},
                  messages=[[message.model_dump(mode='json') for message in batch]
                            for batch in messages])

    def on_llm_end(self, response, *, run_id, **kwargs):
        generations = []
        for batch in response.generations:
            entries = []
            for generation in batch:
                message = getattr(generation, 'message', None)
                entries.append({
                    'text': generation.text,
                    'generation_info': generation.generation_info,
                    'type': generation.type,
                    'message': message.model_dump(mode='json') if message is not None else None,
                })
            generations.append(entries)
        self.emit('response', run_id, generations=generations, llm_output=response.llm_output)

    def on_llm_error(self, error, *, run_id, **kwargs):
        self.emit('error', run_id, error_type=type(error).__name__)
