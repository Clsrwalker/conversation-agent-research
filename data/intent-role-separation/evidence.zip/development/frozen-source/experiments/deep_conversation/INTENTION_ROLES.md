# Independent intention state and same-model roles

This is an optional experimental path. The Lab default and historical frozen
harnesses are unchanged. No adapters are trained or loaded.

`intention_state.py` owns the SQLite intention ledger. Authenticated arrived
conversation events enter through `observe`; model proposals enter through
`commit_patch`. Proposals have stable intent IDs and arrived source references.
The transaction rejects stale versions, unknown sources and conflicting replay
IDs, and retains withdrawal/reopening history. It cannot verify the meaning of
a paraphrase or determine whether an interpretation is correct.

`intent_roles.py` connects this state to the existing causal WorldStore and
document/card tools. One model instance serves three functions:

- Tracker: propose intention changes; no domain tools or user-visible answer.
- Work: retrieve, read and calculate from arrived evidence; no publication.
- Chat: publish or withdraw visible answers using arrived evidence and receipts.

Chat and work see the same current intention view and raw conversation. The
state is advisory: source text remains available to challenge a mistaken
extraction. Actual tool receipts are stored separately and do not mark an intent
fulfilled. A message or stale proposal cannot impersonate a runtime receipt.

The controlled replay entry is `run_intent_roles.py`. Its three conditions are
one unified actor, split chat/work without a tracker, and split chat/work with
the tracker. The split scheduler alternates work/chat; this scheduling choice
is part of the treatment and may itself hurt performance. All conditions get
the same total call ceiling, context cap, output cap and underlying tools.
Tracker calls consume that ceiling. Equal ceilings do not imply equal input
tokens, available tools per call, or realized cost; those are recorded.

Run the independent engineering checks with the repository virtual environment:

```powershell
& .\experiments\deep_conversation\.venv\Scripts\python.exe -B -m unittest discover -s experiments/deep_conversation -p 'test_intention_state.py' -v
& .\experiments\deep_conversation\.venv\Scripts\python.exe -B -m unittest discover -s experiments/deep_conversation -p 'test_intent_roles.py' -v
```

The study protocol, fixture gold, frozen source and executed traces are in
`output/research/2026-10-23/intent-role-separation/`. Prepare a freeze only after
development and engineering checks. Existing run directories are never silently
overwritten or retried after unknown model outcomes.

```powershell
& .\experiments\deep_conversation\.venv\Scripts\python.exe -B experiments/deep_conversation/run_intent_roles.py prepare --phase development
& .\experiments\deep_conversation\.venv\Scripts\python.exe -B experiments/deep_conversation/run_intent_roles.py run --phase development
& .\experiments\deep_conversation\.venv\Scripts\python.exe -B experiments/deep_conversation/run_intent_roles.py prepare --phase evaluation
& .\experiments\deep_conversation\.venv\Scripts\python.exe -B experiments/deep_conversation/run_intent_roles.py run --phase evaluation
```

These are synthetic causal replay experiments, with actual simulator tool
execution and visible card commits. They are not a user study, ASR evaluation,
external-service exactly-once guarantee, or proof that LoRA would help. They
do not yet integrate the tracker into the live Lab or replace its default.
