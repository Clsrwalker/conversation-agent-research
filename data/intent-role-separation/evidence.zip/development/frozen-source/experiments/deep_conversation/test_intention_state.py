"""Offline state-boundary checks; these do not assess model interpretation."""
from __future__ import annotations

import tempfile
from pathlib import Path
import unittest

from intention_state import IntentConflictError, IntentStore, IntentValidationError


def event(seq, text='Keep it free.', **extra):
    return {'seq': seq, 'speaker': 'Alice', 'text': text, **extra}


def add(identifier='budget', text='Free', source=0, **extra):
    return {'op': 'add', 'intent_id': identifier, 'owner': 'Alice',
            'text': text, 'source_seqs': [source], **extra}


class IntentStateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / 'intentions.sqlite'
        self.store = IntentStore(self.path)

    def tearDown(self):
        self.store.close()
        self.temp.cleanup()

    def initial(self):
        self.store.observe([event(0)])
        return self.store.commit_patch('p1', 0, 0, [add(), add('platform', 'Desktop')])

    def test_update_preserves_other_intentions_and_unspecified_fields(self):
        before = self.initial()
        self.store.observe([event(1, 'Use mobile instead.')])
        after = self.store.commit_patch('p2', 1, 1, [{
            'op': 'update', 'intent_id': 'platform', 'text': 'Mobile', 'source_seqs': [1]}])
        self.assertEqual(before['intents'][0], after['intents'][0])
        mobile = after['intents'][1]
        self.assertEqual(('Alice', 'Mobile', 'active'),
                         (mobile['owner'], mobile['text'], mobile['status']))
        self.assertEqual(['Desktop', 'Mobile'], [h['state']['text'] for h in mobile['history']])

    def test_withdraw_and_reopen_retain_history_and_identity(self):
        self.initial()
        self.store.observe([event(2, 'Drop the mobile requirement.')])
        withdrawn = self.store.commit_patch('p2', 1, 2, [{
            'op': 'withdraw', 'intent_id': 'platform', 'source_seqs': [2]}])
        self.assertEqual('withdrawn', withdrawn['intents'][1]['status'])
        self.store.observe([event(3, 'Restore it.')])
        reopened = self.store.commit_patch('p3', 2, 3, [{
            'op': 'reopen', 'intent_id': 'platform', 'source_seqs': [3]}])
        value = reopened['intents'][1]
        self.assertEqual(('platform', 'Desktop', 'active'),
                         (value['intent_id'], value['text'], value['status']))
        self.assertEqual(['add', 'withdraw', 'reopen'], [h['op'] for h in value['history']])

    def test_uncertain_suggestion_is_distinct_from_active_requirement(self):
        self.store.observe([event(0, 'Maybe offline would help.', role='assistant')])
        view = self.store.commit_patch('suggestion', 0, 0, [add('offline', 'Offline', status='uncertain')])
        self.assertEqual('uncertain', view['intents'][0]['status'])
        self.store.observe([event(1, 'Yes, offline is required.')])
        view = self.store.commit_patch('accept', 1, 1, [{
            'op': 'update', 'intent_id': 'offline', 'status': 'active', 'source_seqs': [1]}])
        self.assertEqual('active', view['intents'][0]['status'])

    def test_no_change_advances_processed_cursor_without_rewriting_intentions(self):
        before = self.initial()
        self.store.observe([event(4, 'Thanks.')])
        after = self.store.commit_patch('no-change', 1, 4, [])
        self.assertEqual(2, after['version'])
        self.assertEqual(4, after['processed_event_seq'])
        self.assertEqual(before['intents'], after['intents'])

    def test_patch_replay_survives_restart_and_returns_original_result(self):
        first = self.initial()
        self.store.commit_patch('no-change', 1, 0, [])
        self.store.close()
        self.store = IntentStore(self.path)
        replay = self.store.commit_patch('p1', 0, 0, [add(), add('platform', 'Desktop')])
        self.assertEqual(first, replay)
        self.assertEqual(2, self.store.get_view()['version'])

    def test_patch_identifier_reuse_with_different_arguments_is_rejected(self):
        before = self.initial()
        with self.assertRaises(IntentConflictError):
            self.store.commit_patch('p1', 0, 0, [])
        self.assertEqual(before, self.store.snapshot())

    def test_stale_version_is_rejected_across_two_connections(self):
        self.store.observe([event(0)])
        with IntentStore(self.path) as other:
            self.store.commit_patch('first', 0, 0, [add()])
            with self.assertRaises(IntentConflictError):
                other.commit_patch('stale', 0, 0, [add('platform', 'Desktop')])
            self.assertEqual(['budget'], [i['intent_id'] for i in other.snapshot()['intents']])

    def test_new_observation_invalidates_old_patch_even_without_version_change(self):
        self.store.observe([event(0)])
        with IntentStore(self.path) as other:
            other.observe([event(2, 'Actually, paid is fine.')])
        with self.assertRaises(IntentConflictError):
            self.store.commit_patch('old-input', 0, 0, [add()])
        self.assertEqual([], self.store.snapshot()['intents'])

    def test_unknown_or_future_source_rejects_entire_patch(self):
        self.store.observe([event(0), event(5)])
        before = self.store.snapshot()
        for source in (3, 6):
            with self.subTest(source=source), self.assertRaises(IntentValidationError):
                self.store.commit_patch(f'bad-{source}', 0, 5,
                                        [add(), add('platform', 'Desktop', source=source)])
            self.assertEqual(before, self.store.snapshot())

    def test_future_or_unobserved_cursor_cannot_be_committed_or_read(self):
        self.store.observe([event(0), event(5)])
        for through in (3, 6):
            with self.subTest(through=through), self.assertRaises(IntentConflictError):
                self.store.commit_patch(f'bad-{through}', 0, through, [])
        with self.assertRaises(IntentValidationError):
            self.store.events(through_seq=6)
        self.assertEqual([0, 5], [e['seq'] for e in self.store.events()])

    def test_raw_events_are_immutable_and_replay_is_idempotent(self):
        self.assertEqual(1, self.store.observe([event(0)])['accepted'])
        self.assertEqual(0, self.store.observe([event(0, role='user')])['accepted'])
        with self.assertRaises(IntentConflictError):
            self.store.observe([event(0, 'Different text')])
        self.assertEqual('Keep it free.', self.store.events()[0]['text'])

    def test_late_backfill_and_invalid_batch_do_not_partially_insert(self):
        self.store.observe([event(0), event(5)])
        with self.assertRaises(IntentConflictError):
            self.store.observe([event(3), event(6)])
        with self.assertRaises(IntentValidationError):
            self.store.observe([event(6), event(7, role='system')])
        self.assertEqual([0, 5], [e['seq'] for e in self.store.events()])

    def test_runtime_receipt_cannot_complete_or_modify_intentions(self):
        before = self.initial()
        receipt = self.store.report_result('tool-1', 1, {
            'status': 'completed', 'intent_id': 'budget', 'text': 'Paid', 'artifact': 'receipt-123'})
        after = self.store.snapshot()
        self.assertEqual(before['intents'], after['intents'])
        self.assertEqual(before['version'], after['version'])
        self.assertEqual(before['processed_event_seq'], after['processed_event_seq'])
        self.assertEqual([receipt], after['receipts'])

    def test_receipt_replay_and_stale_version_preserve_actual_execution_record(self):
        self.initial()
        self.store.commit_patch('p2', 1, 0, [])
        first = self.store.report_result('r1', 1, {'status': 'failed'})
        self.store.close()
        self.store = IntentStore(self.path)
        self.assertEqual(first, self.store.report_result('r1', 1, {'status': 'failed'}))
        self.assertEqual(1, len(self.store.snapshot()['receipts']))
        with self.assertRaises(IntentConflictError):
            self.store.report_result('r1', 1, {'status': 'completed'})
        with self.assertRaises(IntentValidationError):
            self.store.report_result('future', 3, {'status': 'completed'})

    def test_unknown_completed_status_and_extra_fields_cannot_bypass_transitions(self):
        self.store.observe([event(0)])
        for operation in (add(status='completed'), {**add(), 'completed': True},
                          {'op': 'remove', 'intent_id': 'budget', 'source_seqs': [0]}):
            with self.subTest(operation=operation), self.assertRaises(IntentValidationError):
                self.store.commit_patch('bad', 0, 0, [operation])
        self.assertEqual(0, self.store.snapshot()['version'])

    def test_withdrawn_intention_cannot_be_silently_replaced(self):
        self.initial()
        self.store.commit_patch('withdraw', 1, 0, [{
            'op': 'withdraw', 'intent_id': 'budget', 'source_seqs': [0]}])
        for operation in (add(), {'op': 'update', 'intent_id': 'budget',
                                 'text': 'Paid', 'source_seqs': [0]}):
            with self.subTest(operation=operation), self.assertRaises(IntentValidationError):
                self.store.commit_patch('bad', 2, 0, [operation])
        self.assertEqual('withdrawn', self.store.snapshot()['intents'][0]['status'])

    def test_duplicate_target_and_boolean_sequence_are_rejected_atomically(self):
        with self.assertRaises(IntentValidationError):
            self.store.observe([event(True)])
        self.store.observe([event(0)])
        with self.assertRaises(IntentValidationError):
            self.store.commit_patch('duplicate', 0, 0, [add(), {
                'op': 'withdraw', 'intent_id': 'budget', 'source_seqs': [0]}])
        with self.assertRaises(IntentValidationError):
            self.store.commit_patch('boolean-source', 0, 0, [add(source=False)])
        self.assertEqual([], self.store.snapshot()['intents'])

    def test_snapshot_and_inputs_do_not_alias_durable_records(self):
        raw = event(0, metadata={'channel': 'chat'})
        self.store.observe([raw])
        raw['metadata']['channel'] = 'mutated'
        view = self.store.commit_patch('p1', 0, 0, [add()])
        view['intents'][0]['text'] = 'mutated'
        self.assertEqual('chat', self.store.events()[0]['metadata']['channel'])
        self.assertEqual('Free', self.store.snapshot()['intents'][0]['text'])

    def test_malformed_json_enum_values_have_validation_errors(self):
        with self.assertRaises(IntentValidationError):
            self.store.observe([event(0, role=[])])
        self.store.observe([event(0)])
        for operation in ({**add(), 'op': []}, add(status={})):
            with self.subTest(operation=operation), self.assertRaises(IntentValidationError):
                self.store.commit_patch('bad-json-value', 0, 0, [operation])
        self.assertEqual(0, self.store.snapshot()['version'])


if __name__ == '__main__':
    unittest.main()
