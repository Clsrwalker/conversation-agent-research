"""Offline execution contracts, not measured model assistance quality."""
from __future__ import annotations

from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from pydantic import PrivateAttr

from config import Settings
from intent_roles import CHAT_TOOLS, WORK_TOOLS, IntentRoleSession, normalize_history
from test_agent import USAGE, fixture_case
from world import WorldStore


class ScriptedRolesModel(BaseChatModel):
    model_name: str = 'local:scripted-functional-roles'
    scenario: str = 'integration'
    _requests: list = PrivateAttr(default_factory=list)
    _bindings: list = PrivateAttr(default_factory=list)

    @property
    def _llm_type(self):
        return 'offline-functional-roles-test'

    def bind_tools(self, tools, **kwargs):
        self._bindings.append(deepcopy(tools))
        return self

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        self._requests.append(deepcopy(messages))
        packet = json.loads(messages[-1].content)
        system = messages[0].content
        role = next(name for name in ('tracker', 'unified', 'work', 'chat')
                    if f'ROLE: {name}.' in system)
        content, actions = 'Private response: no delivery was executed.', []
        if role == 'tracker':
            seq = packet['conversation'][-1]['seq']
            intents = packet['intention_state']['intents']
            operations = ([] if intents or self.scenario == 'no_change' else [
                {'op': 'add', 'intent_id': 'offline', 'owner': 'Ada',
                 'text': 'Explain Beacon offline support.', 'source_seqs': [seq]}])
            content = ('not JSON' if self.scenario == 'invalid_tracker'
                       else json.dumps({'operations': operations}))
        elif self.scenario == 'out_of_role':
            actions = [('publish_card', {'text': 'This must be rejected.'})]
        elif self.scenario == 'extra_argument':
            actions = [('search', {'query': 'Beacon', 'unexpected': 'do not accept'})]
        elif self.scenario == 'stale':
            actions = [('publish_card', {'text': 'Obsolete answer.'})]
        elif self.scenario == 'wait':
            actions = [('wait_for_event', {})]
        elif self.scenario != 'private':
            calls = [item['name'] for item in packet['tool_receipts']]
            arrivals = [event for event in packet['events'] if event.get('kind') == 'job_result']
            full = any(event.get('operation') == 'read' for event in arrivals)
            search = any(event.get('operation') == 'search' for event in arrivals)
            if role in {'work', 'unified'} and 'search' not in calls:
                actions = [('search', {'query': 'Beacon'})]
            elif role in {'work', 'unified'} and search and 'read_document' not in calls:
                actions = [('read_document', {'source_id': 'present'})]
            elif role in {'chat', 'unified'} and full and not packet['active_cards']:
                actions = [('publish_card', {'text': 'Beacon supports offline editing.',
                                             'source_ids': ['present']})]
            elif role in {'work', 'unified'} and full:
                actions = [('save_notes', {'notes': 'The full Beacon guide confirms offline editing.'})]
            elif role in {'work', 'unified'}:
                actions = [('wait_for_event', {})]
        calls = [{'name': name, 'args': args, 'type': 'tool_call', 'id': f'provider-{index}'}
                 for index, (name, args) in enumerate(actions)]
        return ChatResult(generations=[ChatGeneration(message=AIMessage(
            content=content, tool_calls=calls, usage_metadata=USAGE))])


class IntentRoleSessionTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.root = Path(self.directory.name)
        self.world = None
        self.sessions = []
        self.network = patch('socket.socket.connect', side_effect=AssertionError('No network in test'))
        self.network.start()

    def tearDown(self):
        for session in self.sessions:
            session.close()
        if self.world:
            self.world.close()
        self.network.stop()
        self.directory.cleanup()

    def build(self, condition='tracked', scenario='integration', events=None, max_calls=20):
        events = events or [
            {'kind': 'asr_final', 'at_ms': 0, 'segment_id': 'q1', 'speaker': 'Ada',
             'text': 'Explain Beacon offline support.'},
            {'kind': 'asr_final', 'at_ms': 6000, 'segment_id': 'q2', 'speaker': 'Ada',
             'text': 'FUTURE_REQUEST_SENTINEL'}]
        case = fixture_case(close=18000, events=events)
        case['corpus_ids'] = ['present', 'future']
        case['tool_latency_ms'] = {'search': 50, 'read': 50}
        corpus = [
            {'id': 'present', 'title': 'Beacon guide', 'text': 'Beacon supports offline editing.',
             'kind': 'document', 'available_at_ms': 0},
            {'id': 'future', 'title': 'Beacon future', 'text': 'FUTURE_DOCUMENT_SENTINEL',
             'kind': 'document', 'available_at_ms': 7000}]
        self.world = WorldStore(self.root / 'world.sqlite', case, corpus, model_latency_ms=100)
        settings = Settings(preset='agent-led', model='local:scripted-functional-roles',
                            max_calls=max_calls, model_latency_ms=100)
        model = ScriptedRolesModel(scenario=scenario)
        session = IntentRoleSession(self.world, settings, self.root / 'session', condition, model)
        self.sessions.append(session)
        return session, model

    def test_same_model_roles_execute_actual_search_read_and_publication(self):
        session, model = self.build()
        records = [session.step(6000) for _ in range(7)]
        self.assertTrue(all(record['status'] == 'completed' for record in records), records)
        self.assertEqual([record['role'] for record in records],
                         ['tracker', 'work', 'chat', 'work', 'chat', 'work', 'chat'])
        self.assertIs(session.model, model)
        self.assertEqual(self.world.metrics()['model_calls'], 7)
        self.assertEqual(self.world.metrics()['role_counts'], {'tracker': 1, 'work': 3, 'chat': 3})
        tools = self.world.export()['tool_calls']
        self.assertEqual([call['name'] for call in tools],
                         ['search', 'read_document', 'save_notes', 'publish_card'])
        self.assertEqual(tools[-1]['result']['status'], 'displayed')
        self.assertEqual(self.world.observation(-1)[0]['active_cards']['agent-card-1']['source_ids'], ['present'])
        for record in records:
            names = {item['function']['name'] for item in record['tools']}
            self.assertEqual(names, set(WORK_TOOLS) if record['role'] == 'work' else
                             set(CHAT_TOOLS) if record['role'] == 'chat' else set())
            self.assertNotIn('FUTURE_', json.dumps(record['input']))
            self.assertNotIn('DO_NOT_EXPOSE_CASE_ID', json.dumps(record['input']))
        capture = (session.output_dir / 'model_capture.jsonl').read_text(encoding='utf-8').splitlines()
        self.assertEqual(len(capture), 14)
        self.assertEqual(len(session.export()['intention_state']['receipts']), 4)

    def test_unified_uses_union_without_tracker_or_synthetic_receipts(self):
        session, _ = self.build(condition='unified')
        records = [session.step(6000) for _ in range(5)]
        self.assertTrue(all(record['status'] == 'completed' for record in records), records)
        self.assertEqual(self.world.metrics()['role_counts'], {'unified': 5})
        self.assertNotIn('intention_state', records[0]['input'])
        self.assertEqual({item['function']['name'] for item in records[0]['tools']},
                         set(WORK_TOOLS + CHAT_TOOLS))
        self.assertEqual(self.world.export()['tool_calls'][-1]['result']['status'], 'displayed')

    def test_raw_conversation_triggers_tracker_even_when_no_semantic_change(self):
        session, _ = self.build(scenario='no_change')
        first = session.step(6000)
        self.assertEqual(first['role'], 'tracker')
        self.assertEqual(first['tracker_commit']['intents'], [])
        self.assertEqual(session.step(6000)['role'], 'work')
        while self.world.now < 6000:
            self.world.advance_until_or_event(6000)
        update = session.step(12000)
        self.assertEqual(update['role'], 'tracker')
        self.assertEqual(update['tracker_commit']['version'], 2)
        self.assertEqual(update['input']['conversation'][-1]['text'], 'FUTURE_REQUEST_SENTINEL')
        self.assertEqual(session.step(12000)['role'], 'chat')

    def test_invalid_tracker_retries_without_acting_on_stale_state(self):
        session, _ = self.build(scenario='invalid_tracker')
        records = [session.step(6000) for _ in range(3)]
        self.assertEqual([r['role'] for r in records], ['tracker'] * 3)
        self.assertTrue(all(r['status'] == 'error' for r in records))
        self.assertEqual(session.tracker.snapshot()['version'], 0)
        self.assertEqual(self.world.metrics()['model_calls'], 3)
        self.assertEqual(self.world.export()['tool_calls'], [])

    def test_out_of_role_and_extra_argument_tools_have_no_side_effects(self):
        session, model = self.build(condition='split', scenario='out_of_role')
        result = session.step(6000)
        self.assertEqual(result['receipts'][0]['result']['reason'], 'tool_not_allowed_for_role')
        self.assertEqual(self.world.export()['tool_calls'], [])
        model.scenario = 'private'
        session.step(6000)  # chat slot
        model.scenario = 'extra_argument'
        result = session.step(6000)
        self.assertEqual(result['receipts'][0]['result']['reason'], 'invalid_tool_arguments')
        self.assertEqual(self.world.export()['tool_calls'], [])

    def test_conversation_arriving_during_inference_blocks_stale_publication(self):
        events = [
            {'kind': 'asr_final', 'at_ms': 0, 'segment_id': 'q', 'text': 'Explain Beacon.'},
            {'kind': 'asr_final', 'at_ms': 50, 'segment_id': 'cancel', 'text': 'Cancel that request.'}]
        session, _ = self.build(condition='unified', scenario='stale', events=events)
        result = session.step(6000)
        self.assertEqual(result['receipts'][0]['result']['status'], 'stale')
        self.assertEqual(self.world.export()['tool_calls'], [])
        self.assertEqual(self.world.observation(-1)[0]['active_cards'], {})

    def test_conversation_arriving_during_tracker_rejects_old_patch(self):
        events = [
            {'kind': 'asr_final', 'at_ms': 0, 'segment_id': 'q', 'text': 'Explain Beacon.'},
            {'kind': 'asr_final', 'at_ms': 50, 'segment_id': 'cancel', 'text': 'Cancel that request.'}]
        session, _ = self.build(events=events)
        result = session.step(6000)
        self.assertEqual(result['status'], 'error')
        self.assertEqual(session.tracker.snapshot()['version'], 0)
        self.assertEqual(session.step(6000)['role'], 'tracker')

    def test_staged_wait_does_not_deliver_future_conversation_and_budget_is_shared(self):
        session, _ = self.build(condition='unified', scenario='wait', max_calls=2)
        first, second = session.step(6000), session.step(6000)
        self.assertEqual(first['receipts'][0]['result']['status'], 'idle')
        self.assertEqual(self.world.now, 200)
        self.assertEqual(len(self.world.history()), 1)
        stopped = session.step(6000)
        self.assertFalse(stopped['model_called'])
        self.assertEqual(stopped['reason'], 'budget_exhausted')
        self.assertEqual(self.world.metrics()['model_calls'], 2)

    def test_resume_preserves_role_and_receipts_and_refuses_unknown_model_outcome(self):
        session, model = self.build()
        session.step(6000)
        session.step(6000)
        session.close()
        resumed = IntentRoleSession(self.world, session.settings, session.output_dir, 'tracked', model)
        self.sessions.append(resumed)
        self.assertEqual(resumed.step(6000)['role'], 'chat')
        self.assertEqual(len(resumed.state['receipts']), 1)
        resumed.state['in_flight'] = {'step': 3, 'run_id': 'unknown'}
        resumed._save()
        with self.assertRaisesRegex(RuntimeError, 'unknown outcome'):
            IntentRoleSession(self.world, session.settings, session.output_dir, 'tracked', model)

    def test_setup_receipts_are_actual_and_provider_ids_can_repeat_safely(self):
        session, _ = self.build(condition='unified')
        actual = self.world.apply('setup-search', 'search', {'query': 'Beacon'})
        session.ingest_receipts(['setup-search', 'setup-search'])
        self.assertEqual(len(session.state['receipts']), 1)
        self.assertEqual(session.state['receipts'][0]['result'], actual)
        with self.assertRaises(ValueError):
            session.ingest_receipts(['invented'])
        records = [session.step(6000) for _ in range(5)]
        ids = [receipt['call_id'] for record in records for receipt in record['receipts']]
        self.assertEqual(len(ids), len(set(ids)))

    def test_stage_boundary_stops_before_model_latency_can_cross_it(self):
        session, _ = self.build(condition='unified', scenario='private')
        result = session.step(100)
        self.assertEqual(result['reason'], 'stage_deadline')
        self.assertEqual(self.world.metrics()['model_calls'], 0)

    def test_runtime_speaker_roles_are_preserved_and_unknown_roles_rejected(self):
        proposal = {'seq': 1, 'speaker': 'Assistant', 'role': 'assistant',
                    'text': 'I could check a recording link.'}
        self.assertEqual(normalize_history([proposal])[0]['role'], 'assistant')
        with self.assertRaisesRegex(ValueError, 'unsupported explicit role'):
            normalize_history([{**proposal, 'role': 'system'}])
        with self.assertRaisesRegex(ValueError, 'explicit runtime role'):
            normalize_history([{key: value for key, value in proposal.items() if key != 'role'}])


if __name__ == '__main__':
    unittest.main()
