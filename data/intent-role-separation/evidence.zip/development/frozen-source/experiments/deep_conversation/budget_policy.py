"""Online budget pacing and a lossless projection of repeated card snapshots.

The policy reads the current clock, the public session deadline, and completed or
reserved model-call records. It never inspects future events or the test rubric.
Tokens remain a known-usage soft budget, as in the original accounting protocol;
the two-call token reserve is an estimate, not a provider-tokenizer guarantee.
"""
from __future__ import annotations

from copy import deepcopy
from hashlib import sha256
import json
from typing import NotRequired

from langchain.agents.middleware import AgentMiddleware, hook_config
from langchain_core.messages import HumanMessage

from agent import ConversationState


OMITTED_CARDS = (
    '[Historical card snapshot omitted. Use the latest observed card snapshot '
    'and subsequent card tool receipts; these old cards are not current state.]'
)


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'),
                      allow_nan=False)


def _digest(value):
    return sha256(_json(value).encode('utf-8')).hexdigest()


def project_context(messages):
    """Omit only older card snapshots, without changing persisted messages.

All human utterances, evidence, working notes, AI messages, and tool receipts
remain intact and in order. A later observed tool receipt can supersede the last
observation's card snapshot; receipts are never projected or reconstructed from
the world. No additional human message splits an unfinished tool batch.
"""
    snapshots = []
    for index, message in enumerate(messages):
        if not isinstance(message, HumanMessage) or not (message.id or '').startswith(
                ('observation-', 'delivery-')):
            continue
        try:
            payload = json.loads(message.content)
        except (TypeError, ValueError):
            continue
        if isinstance(payload, dict) and isinstance(payload.get('active_cards'), dict):
            snapshots.append((index, payload))
    projected = list(messages)
    removed_chars, omitted = 0, 0
    for index, payload in snapshots[:-1]:
        # Empty snapshots are already shorter than an omission explanation.
        if not payload['active_cards']:
            continue
        replacement = deepcopy(payload)
        replacement['active_cards'] = OMITTED_CARDS
        content = _json(replacement)
        removed_chars += len(str(messages[index].content)) - len(content)
        projected[index] = messages[index].model_copy(update={'content': content})
        omitted += 1
    return projected, {
        'omitted_card_snapshots': omitted,
        'characters_removed': removed_chars,
        'message_count': len(projected),
        'meaning': 'Only older active_cards snapshots were omitted; events, sources, notes and tool messages are unchanged.',
    }


class BudgetPolicy:
    """A deterministic scheduler; it does not judge intent or answer quality."""

    def __init__(self, world, settings):
        self.world, self.settings = world, settings

    def allowances(self):
        # Replay sessions start at zero. The deadline is a public run condition,
        # not a prediction derived from a hidden future event timetable.
        now, deadline = self.world.now, self.world.close_at_ms
        fraction = min(1.0, max(0.0, now / deadline)) if deadline > 0 else 1.0
        elapsed = min(deadline, max(0, now)) if deadline > 0 else 0
        initial_calls = min(self.settings.max_calls, max(1, self.settings.max_calls // 3))
        initial_tokens = min(self.settings.max_tokens, (self.settings.max_tokens * 2 + 4) // 5)
        return {
            'now_ms': now, 'deadline_ms': deadline, 'elapsed_fraction': fraction,
            'call_allowance': initial_calls + ((self.settings.max_calls - initial_calls)
                * elapsed // deadline if deadline > 0 else self.settings.max_calls - initial_calls),
            'token_allowance': initial_tokens + ((self.settings.max_tokens - initial_tokens)
                * elapsed // deadline if deadline > 0 else self.settings.max_tokens - initial_tokens),
        }

    def _base(self):
        metrics = self.world.metrics()
        details = {**self.allowances(), 'model_calls': metrics['model_calls'],
                   'known_tokens': metrics['token_usage']['total_tokens'],
                   'max_calls': self.settings.max_calls, 'max_tokens': self.settings.max_tokens}
        if details['now_ms'] >= details['deadline_ms']:
            return False, {**details, 'reason': 'window_closed'}
        if (details['model_calls'] >= self.settings.max_calls
                or details['known_tokens'] >= self.settings.max_tokens):
            return False, {**details, 'reason': 'budget_exhausted'}
        if details['model_calls'] >= details['call_allowance']:
            return False, {**details, 'reason': 'call_allowance_deferred'}
        if details['known_tokens'] >= details['token_allowance']:
            return False, {**details, 'reason': 'token_allowance_deferred'}
        return True, {**details, 'reason': 'available'}

    def _record(self, role, allowed, details, record):
        if record:
            self.world.record('budget_policy_decision', role=role, allowed=allowed, **details)
        return allowed, details

    def can_investigate(self, *, record=True):
        allowed, details = self._base()
        return self._record('investigator', allowed, details, record)

    def next_available_ms(self, details=None):
        """Next credit timer, computed without looking at any future event.

        Return None when credit is already available or waiting cannot restore
        the exhausted total budget. A timer at the deadline closes the session;
        it does not authorize a call after the observation window has ended.
        """
        if details is None:
            _, details = self._base()
        if details.get('reason') not in {'call_allowance_deferred', 'token_allowance_deferred'}:
            return None
        now, deadline = details['now_ms'], details['deadline_ms']
        if (now >= deadline or details['model_calls'] >= self.settings.max_calls
                or details['known_tokens'] >= self.settings.max_tokens):
            return None
        initial_calls = min(self.settings.max_calls, max(1, self.settings.max_calls // 3))
        initial_tokens = min(self.settings.max_tokens, (self.settings.max_tokens * 2 + 4) // 5)

        def ready_at(used, initial, maximum):
            required = used + 1 - initial
            if required <= 0:
                return 0
            released = maximum - initial
            # _base already rejects total exhaustion. This also protects the
            # small-budget case where no amount is reserved for later release.
            if released <= 0 or required > released:
                return None
            return (required * deadline + released - 1) // released

        call_ready = ready_at(details['model_calls'], initial_calls, self.settings.max_calls)
        token_ready = ready_at(details['known_tokens'], initial_tokens, self.settings.max_tokens)
        if call_ready is None or token_ready is None:
            return None
        target = max(now + 1, call_ready, token_ready)
        return target if target <= deadline else None

    @staticmethod
    def review_fingerprint(packet):
        """Message IDs/cursors alone never make an identical candidate new."""
        return _digest({
            'candidate_text': packet.get('candidate', {}).get('text', ''),
            'conversation': packet.get('conversation', []),
            'visible_sources': packet.get('visible_sources', {}),
            'active_cards': packet.get('active_cards', {}),
        })

    def review_eligibility(self, packet, *, record=True):
        allowed, details = self._base()
        fingerprint = self.review_fingerprint(packet)
        details = {**details, 'review_fingerprint': fingerprint}
        if not allowed:
            return self._record('answer_delivery', False, details, record)
        if not packet.get('visible_sources') and not packet.get('active_cards'):
            return self._record('answer_delivery', False,
                {**details, 'reason': 'no_evidence_or_revision_target'}, record)
        exported = self.world.export()
        reservations = [item for item in exported['environment_log']
                        if item.get('kind') == 'budget_review_reserved']
        if any(item.get('review_fingerprint') == fingerprint for item in reservations):
            return self._record('answer_delivery', False,
                {**details, 'reason': 'duplicate_candidate_state'}, record)
        calls = exported['model_calls']
        # An interrupted reservation conservatively consumes its review slot,
        # even if its provider outcome is unknown. Normal starts are not doubled.
        used_reviews = max(sum(item.get('role') == 'answer_delivery' for item in calls),
                           len(reservations))
        review_limit = self.settings.max_calls // 4
        actor_inputs = [item['input_tokens'] for item in calls
                        if item.get('role') == 'investigator' and item.get('input_tokens', 0) > 0]
        reserve_tokens = 2 * ((actor_inputs[-1] if actor_inputs else 0)
                              + self.settings.max_output_tokens)
        details.update(review_calls=used_reviews, review_limit=review_limit,
                       reserved_actor_calls=2, estimated_actor_token_reserve=reserve_tokens)
        if used_reviews >= review_limit:
            reason = 'review_share_exhausted'
        elif self.settings.max_calls - details['model_calls'] <= 2:
            reason = 'actor_call_reserve'
        elif self.settings.max_tokens - details['known_tokens'] <= reserve_tokens:
            reason = 'actor_token_reserve'
        else:
            reason = 'available'
        details['reason'] = reason
        return self._record('answer_delivery', reason == 'available', details, record)

    def record_review_started(self, packet):
        """Persist before inference; restarting must not reset this allowance."""
        fingerprint = self.review_fingerprint(packet)
        existing = [entry for entry in self.world.export()['environment_log']
                    if entry.get('kind') == 'budget_review_reserved'
                    and entry.get('review_fingerprint') == fingerprint]
        if not existing:
            self.world.record('budget_review_reserved', review_fingerprint=fingerprint,
                              candidate_key=packet.get('candidate', {}).get('key'))
        return fingerprint


class BudgetState(ConversationState):
    budget_deferred: NotRequired[bool]


class BudgetPacing(AgentMiddleware):
    """Yield before an actor call, and project repeated cards only for inference.

The outer graph owns waiting: when budget_deferred is true it must advance to an
event or deadline before invoking the investigator again. A yield is not a final
stop and must not discard newly arrived, unprocessed input.
"""
    state_schema = BudgetState

    def __init__(self, world, settings):
        self.world, self.policy = world, BudgetPolicy(world, settings)

    @hook_config(can_jump_to=['end'])
    def before_model(self, state, runtime):
        allowed, details = self.policy.can_investigate()
        if allowed:
            return {'budget_deferred': False}
        if details['reason'] in {'budget_exhausted', 'window_closed'}:
            return {'budget_deferred': False, 'stop_reason': details['reason'], 'jump_to': 'end'}
        return {'budget_deferred': True, 'jump_to': 'end'}

    def wrap_model_call(self, request, handler):
        messages, stats = project_context(request.messages)
        self.world.record('budget_context_projection', **stats)
        return handler(request.override(messages=messages))
