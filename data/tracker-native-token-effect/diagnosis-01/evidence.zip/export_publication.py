"""Freeze the small reviewed teacher-forced diagnostic, never run a model.

The report remains byte-identical. Other JSON exports redact local paths and
omit any private token sequences or raw content while binding original hashes.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import ast
import copy
import hashlib
import importlib.util
import json
import re

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[5]
PARENT=HERE.parents[1]
PATH_PATTERN=re.compile(rb'(?<![A-Za-z0-9])[A-Za-z]:[\\/]+')
PRIVATE_KEYS={'messages','conversation','raw_dialogue','output_text','raw_output',
    'raw_report','raw_response','raw_prompt','canonical_completion','target_completion',
    'historical_generated_content','generated_operations','generated_token_ids',
    'historical_generated_token_ids','target_token_ids','full_input_ids','input_token_ids',
    'per_token','per_token_delta','target_token_text','top1_token_text','gold_token_text',
    'historical_token_text','common_prefix_decoded','target_token_window','generated_token_window'}

def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):
    with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def encode(v):return (json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')
def relative(v):
    if isinstance(v,dict):return {relative(k):relative(x) for k,x in v.items()}
    if isinstance(v,list):return [relative(x) for x in v]
    if isinstance(v,str):
        for prefix in (str(ROOT),ROOT.as_posix()):
            v=v.replace(prefix+'\\','').replace(prefix+'/','')
        v=re.sub(r'[A-Za-z]:[\\/][^\n\r\"]*?(?=\", line|\n|$)','[local environment path]',v)
        v=re.sub(r'[A-Za-z]:[\\/][^\s\"\'<>]+','[local environment path]',v)
    return v

def redact_private_fields(v,removed,path='$'):
    if isinstance(v,dict):
        clean={}
        for key,value in v.items():
            if key in PRIVATE_KEYS:
                removed.add(path+'.'+key)
            else:clean[key]=redact_private_fields(value,removed,path+'.'+key)
        return clean
    if isinstance(v,list):return [redact_private_fields(x,removed,path+'[]') for x in v]
    return v

def export_json(name,source):
    value=copy.deepcopy(source);removed=set()
    if name=='first-token-structural-summary.json':
        keep={'case_id','focus','language','source_row_index','longest_common_token_prefix',
            'first_divergence_completion_index_zero_based','observed_two_next_token_choices','category'}
        rows=[]
        for original in value['rows']:
            row={k:v for k,v in original.items() if k in keep}
            row['target_next_token_id']=original['target_next_token']['id']
            historic=original['historical_generated_next_token']
            row['historical_next_token_id']=historic['id'] if historic is not None else None
            rows.append(row)
        value['rows']=rows
        removed.add('$.rows[].decoded/vocab token fragments and per-case finding/boundary prose')
    value=redact_private_fields(value,removed)
    return encode(relative(value)),('JSON formatting and local path redaction; original source hash retained.'+
        (' Omitted fields: '+', '.join(sorted(removed))+'.' if removed else ' No content fields omitted.'))

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--report-sha256',required=True)
    args=parser.parse_args()
    assert re.fullmatch('[0-9a-f]{64}',args.report_sha256)
    report_path=HERE/'analysis/report.json'
    final_path=HERE/'review/final-report-review.json'
    report=read(report_path);final=read(final_path)
    assert sha(report_path)==args.report_sha256==final['reviewed_report_sha256']
    assert final['status']=='passed'
    assert final['reviewed_validation_sha256']==sha(HERE/'engineering/validation.json')
    assert report['status']=='completed' and report['kind']=='native_token_effect_diagnostic'
    assert report['new_forward_passes']==12 and report['new_model_generations']==report['new_training_runs']==0
    assert report['inputs']==6 and len(report['failure_rows'])==4
    assert read(HERE/'preflight-review.json')['status']=='passed'
    assert read(HERE/'post-review.json')['status']=='passed'
    result=read(HERE/'collection-01/result.json')
    assert result['status']=='completed' and result['logical_forwards_completed']==result['logical_forwards_attempted']==12
    assert result['new_generations']==result['new_training_runs']==0
    for rel,digest in final['source_hashes'].items():assert sha(ROOT/rel)==digest,rel
    paths={
        'report.json':report_path,
        'engineering-validation.json':HERE/'engineering/validation.json',
        'protocol.json':HERE/'protocol.json',
        'cpu-preparation.json':HERE/'cpu-preparation.json',
        'preflight-review.json':HERE/'preflight-review.json',
        'collection-config.json':HERE/'collection-01/config.json',
        'collection-result.json':HERE/'collection-01/result.json',
        'post-review.json':HERE/'post-review.json',
        'final-report-review.json':final_path,
        'measurement-summary.json':HERE/'measurement-summary.json',
        'first-token-structural-summary.json':HERE.parent/'first-token-divergence/diagnostic-summary.json',
        'score_native_fit_tokens.py':ROOT/'experiments/deep_conversation/tracker_lora/diagnostics/score_native_fit_tokens.py',
        'build_report.py':HERE/'build_report.py',
        'export_publication.py':Path(__file__),
    }
    checker_path=HERE/'release/check_release.py'
    spec=importlib.util.spec_from_file_location('native_token_release_contract',checker_path)
    checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
    dest=HERE/'publication/diagnosis-01'
    assert not dest.exists(),'Never overwrite a frozen publication.'
    payloads={};bindings={}
    for name,path in paths.items():
        assert Path(name).name==name and not name.startswith('PRIVATE-')
        data=path.read_bytes();transformation='none'
        if path.suffix=='.json' and name!='report.json':
            data,transformation=export_json(name,read(path))
        assert not PATH_PATTERN.search(data),name
        assert '\ufffd' not in data.decode('utf-8'),name
        if name.endswith('.json'):
            value=json.loads(data);checker.public_json(value)
            forbidden=set();redact_private_fields(value,forbidden);assert not forbidden,(name,forbidden)
        elif name.endswith('.py'):ast.parse(data.decode('utf-8'))
        payloads[name]=data
        bindings[name]={'source_path':path.relative_to(ROOT).as_posix(),'source_sha256':sha(path),
            'export_sha256':hashlib.sha256(data).hexdigest(),'transformation':transformation}
    assert payloads['report.json']==report_path.read_bytes()
    summary={**report,'independent_final_audit':'passed','reviewed_interpretation_source_sha256':sha(report_path),
        'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'source_and_export_files':bindings,
        'publication_policy':{'originals_preserved':True,'private_evidence_hashes_retained':True,
            'private_records_and_complete_token_sequences_exported':False,
            'new_forward_passes_during_export':0,'new_model_generations_during_export':0,
            'new_semantic_scoring_during_export':0,'release_checker_sha256':sha(checker_path)}}
    data=encode(summary);checker.public_json(summary)
    assert not PATH_PATTERN.search(data) and '\ufffd' not in data.decode('utf-8')
    dest.mkdir(parents=True)
    for name,payload in payloads.items():(dest/name).write_bytes(payload)
    (dest/'summary.json').write_bytes(data)
    for name,binding in bindings.items():
        assert sha(dest/name)==binding['export_sha256']
        assert sha(ROOT/binding['source_path'])==binding['source_sha256']
    assert len(list(dest.iterdir()))==len(payloads)+1
    print(json.dumps({'status':'frozen','files':len(payloads)+1,
        'report_sha256':sha(dest/'report.json'),'summary_sha256':sha(dest/'summary.json')}))

if __name__=='__main__':main()
