"""Twelve bounded native-target forwards; never generate or train.

--prepare uses a tokenizer and existing records only. The GPU path requires an
independent preflight bound to this source, protocol and prepared data.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import contextlib
import importlib.metadata
import json
import os
import sys
import time
import traceback

from collect_audit_adapter_off import (ROOT, STUDY, ADAPTER_RUN, MODEL_ID, REVISION,
    MODEL_PATH, BASE_RECEIPT, legacy, read, write, durable, emit, state, sha,
    quantized_base, prepare_frozen_base, adapter_artifacts, exclusive_collector)

HERE = STUDY/'followup/native-token-effect'
FIT = STUDY/'fit'
SOURCE = ROOT/'output/research/2026-10-24/tracker-lora-repair-v2'
ARMS = ('adapter_enabled','adapter_disabled')

def verified_sources(document):
    for rel,digest in document['source_hashes'].items():
        assert sha(ROOT/rel)==digest,rel

def bound(paths): return {p.relative_to(ROOT).as_posix():sha(p) for p in paths}

def prepare():
    # Set before any optional ML import; preparation never loads model weights.
    os.environ['CUDA_VISIBLE_DEVICES']=''
    from transformers import AutoTokenizer
    import torch
    assert not torch.cuda.is_initialized()
    HERE.mkdir(parents=True,exist_ok=True)
    for name in ('protocol.json','cpu-preparation.json','PRIVATE-prepared.json'):
        assert not (HERE/name).exists(),'Preserve every frozen preparation.'
    selection=read(FIT/'selection.json'); prior_review=read(FIT/'post-review.json')
    fit_config=read(FIT/'collection-01/config.json'); fit_result=read(FIT/'collection-01/result.json')
    assert prior_review['status']=='passed' and fit_result['status']=='completed'
    assert fit_result['calls']==fit_result['completed_calls']==fit_result['durable_calls']==6
    for artifact in (selection,fit_config): verified_sources(artifact)
    assert sha(FIT/'collection-01/PRIVATE-calls.jsonl')==fit_result['outputs_sha256']
    assert sha(FIT/'collection-01/config.json')==fit_result['config_sha256']
    sfts=legacy.jsonl(ROOT/selection['source_sft']); rows=legacy.jsonl(ROOT/selection['source_records'])
    calls=legacy.jsonl(FIT/'collection-01/PRIVATE-calls.jsonl')
    lengths=read(SOURCE/'training/formal-01/lengths.json')
    semantic={x['case_id']:x for x in prior_review['cases']}
    alignment_path=STUDY/'followup/first-token-divergence/PRIVATE-token-alignment.json'
    alignment=read(alignment_path); verified_sources(alignment)
    alignments={x['case_id']:x for x in alignment['cases']}
    tokenizer=AutoTokenizer.from_pretrained(str(MODEL_PATH),local_files_only=True,trust_remote_code=False)
    base=read(BASE_RECEIPT)
    assert base['model_id']==MODEL_ID and base['revision']==REVISION
    eos=read(MODEL_PATH/'generation_config.json')['eos_token_id']
    eos=eos if isinstance(eos,list) else [eos]
    versions={n:importlib.metadata.version(n) for n in fit_config['versions']}
    assert versions==fit_config['versions']
    assert adapter_artifacts(ADAPTER_RUN)==fit_config['adapter']
    prepared=[];checks=[]
    assert len(selection['cases'])==len(calls)==6
    for case,call in zip(selection['cases'],calls):
        identifier=case['case_id']; index=case['source_row_index']
        row,sft=rows[index],sfts[index]
        assert call['case_id']==identifier and call['status']=='completed'
        assert legacy.digest(row)==case['record_sha256'] and legacy.digest(sft)==case['sft_sha256']
        assert sft['prompt']==call['messages']
        assert legacy.digest(sft['prompt'])==call['input_messages_sha256']==case['canonical_prompt_sha256']
        assert sft['completion']==[{'role':'assistant','content':legacy.encode(row['target'])}]
        prefix=tokenizer.apply_chat_template(sft['prompt'],tokenize=True,add_generation_prompt=True,return_dict=False)
        full=tokenizer.apply_chat_template(sft['prompt']+sft['completion'],tokenize=True,add_generation_prompt=False,return_dict=False)
        assert full[:len(prefix)]==prefix
        gold=full[len(prefix):]
        assert legacy.digest(prefix)==call['input_token_ids_sha256']
        assert len(prefix)==call['input_tokens']==lengths[index]['prompt_tokens']
        assert len(gold)==lengths[index]['supervised_completion_tokens']
        assert len(full)<=2048
        historic=call['generated_token_ids']
        assert len(historic)==call['output_tokens'] and historic[-1]==call['last_generated_token'] in eos
        assert not call['hit_token_cap']
        assert gold==alignments[identifier]['target_token_ids']
        assert historic==alignments[identifier]['historical_generated_token_ids']
        eos_positions=[i for i,t in enumerate(gold) if t in eos]
        assert len(eos_positions)==1
        eos_index=eos_positions[0]
        assert gold[eos_index]==tokenizer.eos_token_id==151645
        assert tokenizer.decode(gold[eos_index+1:],skip_special_tokens=False)=='\n'
        gold_until_eos=gold[:eos_index+1]
        shared=0
        while shared<min(len(gold_until_eos),len(historic)) and gold_until_eos[shared]==historic[shared]:
            shared+=1
        matched=gold_until_eos==historic
        assert matched or (shared<len(gold_until_eos) and shared<len(historic))
        existing=semantic[identifier]
        if matched: interpretation='match_through_eos'
        elif existing['full_meaning_correct']: interpretation='successful_semantic_variant_not_an_error'
        else: interpretation='historical_failed_output_single_token_branch'
        divergence={'status':interpretation,'common_prefix_completion_tokens':shared,
            'existing_focal_full_meaning_correct':existing['full_meaning_correct'],
            'existing_focal_repair_omitted':existing['focal_repair_omitted'],
            'existing_unsupported_withdrawal':existing['unsupported_withdrawal']}
        if not matched:
            divergence.update(completion_index=shared,predicting_full_input_position=len(prefix)+shared-1,
                shared_full_prefix_sha256=legacy.digest(prefix+gold[:shared]),
                gold_token_id=gold[shared],historical_token_id=historic[shared],
                gold_token_text=tokenizer.decode([gold[shared]],skip_special_tokens=False),
                historical_token_text=tokenizer.decode([historic[shared]],skip_special_tokens=False),
                token_interpretation_limit='One next-token alternative only; BPE fragments are not probabilities of complete semantic actions.')
        item={'case_id':identifier,'source_example_id':case['source_example_id'],'source_row_index':index,
            'focus':case['focus'],'language':case['language'],'prompt_tokens':len(prefix),
            'input_token_ids_sha256':legacy.digest(prefix),'full_input_ids':full,
            'full_input_ids_sha256':legacy.digest(full),'target_token_ids':gold,
            'target_token_ids_sha256':legacy.digest(gold),'completion_tokens':len(gold),
            'eos_completion_index':eos_index,'historical_call_record_sha256':legacy.digest(call),
            'divergence':divergence}
        prepared.append(item)
        checks.append({k:v for k,v in item.items() if k not in ('full_input_ids','target_token_ids','divergence')})
        checks[-1]['divergence']={k:v for k,v in divergence.items() if not k.endswith('_text')}
    # Pure indexing check of the exact n+1 tail trick, without any model forward.
    indexing=[]
    for p,n in ((1,1),(3,2),(9,7),(20,5)):
        absolute=list(range(p+n))[-(n+1):][:-1]
        assert absolute==list(range(p-1,p+n-1))
        indexing.append({'prompt_tokens':p,'completion_tokens':n,'predicting_positions_match':True})
    # One tiny CPU arithmetic control, not a language-model forward.
    toy=torch.tensor([[[1.,0.,2.,2.,-1.],[0.,2.,1.,-1.,-2.],
        [3.,1.,0.,-1.,-2.],[0.,0.,0.,0.,0.]]])
    toy_case={'completion_tokens':3,'target_token_ids':[2,2,1],
        'eos_completion_index':1,'prompt_tokens':4,
        'divergence':{'status':'synthetic_arithmetic_control','completion_index':0,
            'gold_token_id':2,'historical_token_id':3}}
    toy_stats=token_statistics(toy,toy_case,tokenizer)
    reference=torch.nn.functional.cross_entropy(toy[0,:-1],torch.tensor([2,2,1])).item()
    assert abs(toy_stats['segments']['all_training_positions']['target_nll_mean']-reference)<1e-6
    assert [t['target_rank'] for t in toy_stats['per_token']]==[1,2,2]
    assert [t['target_logit_ties'] for t in toy_stats['per_token']]==[2,1,1]
    assert [t['top1_token_id'] for t in toy_stats['per_token']]==[2,1,0]
    assert toy_stats['first_divergence']['gold_minus_historical_logprob']==0
    arithmetic={'kind':'tiny_CPU_tensor_control_not_model_forward','tokens':3,
        'cross_entropy_absolute_difference':abs(toy_stats['segments']['all_training_positions']['target_nll_mean']-reference),
        'rank_ties_argmax_and_margin':'passed'}
    assert sum(c['divergence']['status']=='match_through_eos' for c in checks)==1
    assert sum(c['divergence']['status']=='successful_semantic_variant_not_an_error' for c in checks)==1
    assert sum(c['divergence']['status']=='historical_failed_output_single_token_branch' for c in checks)==4
    source_paths=[Path(__file__),Path(__file__).with_name('collect_audit_adapter_off.py'),
        CODEPATH('repair_v2/train_tracker.py'),CODEPATH('repair_v2/collect_three_arm.py'),
        CODEPATH('repair_v2/gates.py'),CODEPATH('evaluate_tracker.py'),CODEPATH('intent_audit/pipeline.py'),
        CODEPATH('intent_audit/audit.py'),ROOT/'experiments/deep_conversation/intention_state.py',
        FIT/'selection.json',FIT/'post-review.json',FIT/'preflight-review.json',
        FIT/'collection-01/config.json',FIT/'collection-01/result.json',FIT/'collection-01/PRIVATE-calls.jsonl',
        ROOT/selection['source_records'],ROOT/selection['source_sft'],SOURCE/'annotation/system_prompt.txt',
        SOURCE/'training/formal-01/lengths.json',ADAPTER_RUN/'result.json',
        ADAPTER_RUN/'adapter/adapter_config.json',ADAPTER_RUN/'adapter/adapter_model.safetensors',
        STUDY/'training/adapter-context-postcheck.json',alignment_path,BASE_RECEIPT,
        MODEL_PATH/'generation_config.json',MODEL_PATH/'tokenizer.json',MODEL_PATH/'tokenizer_config.json']
    hashes=bound(source_paths)
    private={'kind':'existing_exact_native_training_targets','cases':prepared,'source_hashes':hashes}
    write(HERE/'PRIVATE-prepared.json',private)
    assignments=[{'ordinal':i+1,'arm':arm,'case_id':case['case_id']}
        for i,(arm,case) in enumerate((a,c) for a in ARMS for c in prepared)]
    protocol={'id':'native-target-token-effect-protocol','status':'frozen_before_model_forward',
        'date':'2026-10-27','timezone':'America/Halifax','created_at_utc':datetime.now(timezone.utc).isoformat(),
        'kind':'bounded_teacher_forced_distribution_diagnostic_not_quality_acceptance',
        'scope':{'existing_inputs':6,'logical_forwards':12,'forwards_per_input_per_arm':1,
            'new_generations':0,'new_training_runs':0,'new_prompt_variants':0,'new_scenarios':0,
            'candidate_sequences_constructed':0,'retries':0},
        'assignments':assignments,'base_id':MODEL_ID,'base_revision':REVISION,
        'adapter':fit_config['adapter'],'versions':versions,
        'forward':{'use_cache':False,'logits_to_keep':'completion_tokens + 1','batch_size':1,
            'attention_mask':'all ones','autocast_dtype':'bfloat16','softmax_dtype':'float32',
            'maximum_full_input_tokens':2048,'seed':20261024,'eval':True,'inference_mode':True},
        'alignment':'For prompt P and completion L, target IDs at P..P+L-1 use predicting positions P-1..P+L-2. Request last L+1 logits and discard the final logit.',
        'segments':'Original SFT completion includes JSON body, first EOS, and trailing template newline. Preserve all training positions; report body/EOS/post-EOS newline separately and through-EOS aggregate.',
        'metrics':['Every target token log probability, strict-greater rank, tied-logit count, argmax token ID and its log probability.',
            'At the first token divergence before or at EOS, gold/historical token log probabilities and gold-minus-historical margin under the identical prior token prefix.',
            'On-minus-off change for identical target positions and existing branch; no complete-candidate or short-vs-long sequence ranking.'],
        'rank_definition':'1 + count(logit > target logit); tie count includes the target. Argmax uses the first maximum token ID; rank 1 does not alone imply unique top1.',
        'state_policy':'Six enabled forwards then six disabled forwards. Check 336-layer active adapter/eval/zero-trainability before each. Exit disable_adapter inside finally, immediately requires_grad_(False), then verify enabled frozen state.',
        'failure_policy':'Stop at the first failed forward or gate, retain all durable attempts, never retry or resume automatically.',
        'interpretation_limits':['Correct target prefixes are teacher-forced, including after a historical error; later scores do not establish autonomous repair.',
            'These are six exposed training samples. No held-out quality, generalization or whole-training-set fit claim.',
            'A canonical target is not the only valid answer. One semantically correct wording variant and one match through EOS are kept separate from the four historical failures.',
            'Single-token BPE alternatives are not probabilities of complete closures, empty patches or withdraw/update actions.',
            'Full-sequence use_cache=False forward can differ numerically from historical cached greedy generation; historical token need not remain current top1.',
            'On/off within this protocol shares settings, but fixed arm order is not randomized and no repeat is budgeted.',
            'The adapter toggle measures conditional distribution change here; it does not identify data/optimizer causes.'],
        'source_hashes':{**hashes,**bound([HERE/'PRIVATE-prepared.json'])}}
    write(HERE/'protocol.json',protocol)
    receipt={'id':'native-token-effect-cpu-preparation','status':'passed','date':'2026-10-27',
        'timezone':'America/Halifax','created_at_utc':datetime.now(timezone.utc).isoformat(),
        'new_model_forwards':0,'new_generations':0,'new_training_runs':0,'loaded_model_weights':False,
        'cuda_initialized':torch.cuda.is_initialized(),'cases':checks,'indexing_checks':indexing,'arithmetic_control':arithmetic,
        'source_hashes':{**hashes,**bound([HERE/'PRIVATE-prepared.json',HERE/'protocol.json'])}}
    assert receipt['cuda_initialized'] is False
    write(HERE/'cpu-preparation.json',receipt)
    emit('prepared',cases=6,logical_forwards_authorized_after_review=12,
        protocol_sha256=sha(HERE/'protocol.json'),cpu_preparation_sha256=sha(HERE/'cpu-preparation.json'))

def CODEPATH(relative): return ROOT/'experiments/deep_conversation/tracker_lora'/relative

def token_statistics(logits,case,tokenizer):
    """No model calls here: float32 statistics from one target forward."""
    import torch
    n=case['completion_tokens']
    assert logits.ndim==3 and logits.shape[0]==1 and logits.shape[1]==n+1
    values=logits[0,:-1,:].float()
    assert torch.isfinite(values).all().item()
    target=torch.tensor(case['target_token_ids'],device=values.device,dtype=torch.long)
    target_value=values.gather(1,target[:,None]).squeeze(1)
    logz=torch.logsumexp(values,dim=-1)
    target_lp=target_value-logz
    top_value,top_id=values.max(dim=-1)
    ranks=(values>target_value[:,None]).sum(dim=-1)+1
    ties=(values==target_value[:,None]).sum(dim=-1)
    numbers=list(zip(target_lp.tolist(),ranks.tolist(),ties.tolist(),top_id.tolist(),(top_value-logz).tolist()))
    per_token=[]
    for i,(lp,rank,tie,top,toplp) in enumerate(numbers):
        segment='body' if i<case['eos_completion_index'] else 'eos' if i==case['eos_completion_index'] else 'post_eos_newline'
        target_id=case['target_token_ids'][i]
        per_token.append({'completion_index':i,'predicting_full_input_position':case['prompt_tokens']+i-1,
            'segment':segment,'target_token_id':target_id,'target_token_text':tokenizer.decode([target_id],skip_special_tokens=False),
            'target_logprob':lp,'target_rank':rank,'target_logit_ties':tie,'top1_token_id':top,
            'top1_token_text':tokenizer.decode([top],skip_special_tokens=False),'top1_logprob':toplp,'target_is_argmax':target_id==top})
    segments={}
    for label,subset in [('all_training_positions',per_token),
        ('through_eos',[x for x in per_token if x['segment']!='post_eos_newline'])]+[
        (label,[x for x in per_token if x['segment']==label]) for label in ('body','eos','post_eos_newline')]:
        assert subset
        total=-sum(x['target_logprob'] for x in subset)
        segments[label]={'tokens':len(subset),'target_nll_sum':total,'target_nll_mean':total/len(subset),
            'target_argmax_tokens':sum(x['target_is_argmax'] for x in subset)}
    branch=dict(case['divergence'])
    if branch['status']!='match_through_eos':
        i=branch['completion_index']; alternative=branch['historical_token_id']
        assert case['target_token_ids'][i]==branch['gold_token_id']
        alternative_value=values[i,alternative]
        branch.update(gold_logprob=per_token[i]['target_logprob'],historical_logprob=(alternative_value-logz[i]).item(),
            gold_minus_historical_logprob=(target_value[i]-alternative_value).item(),
            gold_rank=per_token[i]['target_rank'],historical_rank=int((values[i]>alternative_value).sum().item())+1,
            top1_token_id=per_token[i]['top1_token_id'],top1_logprob=per_token[i]['top1_logprob'])
    return {'per_token':per_token,'segments':segments,'first_divergence':branch}

def collect(output):
    assert not output.exists(),'Preserve all runs; do not overwrite or resume.'
    output.mkdir(parents=True)
    started=time.perf_counter();attempted=0
    result={'status':'setup','date':'2026-10-27','timezone':'America/Halifax','assigned_logical_forwards':12,
        'logical_forwards_attempted':0,'new_generations':0,'new_training_runs':0,'retries':0}
    write(output/'result.json',result)
    try:
        review=read(HERE/'preflight-review.json');assert review['status']=='passed';verified_sources(review)
        protocol=read(HERE/'protocol.json');verified_sources(protocol)
        preparation=read(HERE/'cpu-preparation.json');assert preparation['status']=='passed';verified_sources(preparation)
        data=read(HERE/'PRIVATE-prepared.json');verified_sources(data)
        assert protocol['scope']['logical_forwards']==12 and len(data['cases'])==6
        import torch
        from transformers import AutoTokenizer
        from peft import PeftModel
        with exclusive_collector(output/'collector.lock'):
            versions={n:importlib.metadata.version(n) for n in protocol['versions']}
            assert versions==protocol['versions']
            artifacts=adapter_artifacts(ADAPTER_RUN);assert artifacts==protocol['adapter']
            base=read(BASE_RECEIPT);assert base['model_id']==MODEL_ID and base['revision']==REVISION
            for item in base['files']:
                p=MODEL_PATH/item['rfilename']
                assert p.stat().st_size==item['actual_bytes'] and sha(p)==item['actual_sha256']
            tokenizer=AutoTokenizer.from_pretrained(str(MODEL_PATH),local_files_only=True,trust_remote_code=False)
            for case in data['cases']:
                assert legacy.digest(case['full_input_ids'])==case['full_input_ids_sha256']
                assert legacy.digest(case['target_token_ids'])==case['target_token_ids_sha256']
                assert case['full_input_ids'][-case['completion_tokens']:]==case['target_token_ids']
            paths=[Path(__file__),HERE/'protocol.json',HERE/'cpu-preparation.json',HERE/'PRIVATE-prepared.json',HERE/'preflight-review.json']
            config={'kind':'teacher_forced_token_distribution_only','date':'2026-10-27','timezone':'America/Halifax',
                'base_id':MODEL_ID,'base_revision':REVISION,'adapter':artifacts,'versions':versions,
                'gpu':torch.cuda.get_device_name(0),'cuda':torch.version.cuda,'forward':protocol['forward'],
                'assignments':protocol['assignments'],'source_hashes':bound(paths)}
            write(output/'config.json',config);config_hash=sha(output/'config.json')
            emit('loading_model',logical_forwards=12,new_generations=0,training=False)
            model=prepare_frozen_base(quantized_base())
            model=PeftModel.from_pretrained(model,str(ADAPTER_RUN/'adapter'),adapter_name='tracker_lora_v2',is_trainable=False)
            model.requires_grad_(False);model.eval()
            if model.is_gradient_checkpointing:model.gradient_checkpointing_disable()
            state(model,False)
            for arm_index,arm in enumerate(ARMS):
                disabled=arm=='adapter_disabled'
                manager=model.disable_adapter() if disabled else contextlib.nullcontext()
                try:
                    with manager:
                        for case_index,case in enumerate(data['cases']):
                            ordinal=arm_index*6+case_index+1
                            assert protocol['assignments'][ordinal-1]=={'ordinal':ordinal,'arm':arm,'case_id':case['case_id']}
                            gate=state(model,disabled)
                            event={'ordinal':ordinal,'arm':arm,'case_id':case['case_id'],'config_sha256':config_hash,
                                'full_input_ids_sha256':case['full_input_ids_sha256'],
                                'target_token_ids_sha256':case['target_token_ids_sha256'],'started_at_utc':datetime.now(timezone.utc).isoformat()}
                            durable(output/'attempts.jsonl',{'event':'started',**event})
                            record={**event,'status':'failed','actual_adapter_state':gate};call_start=time.perf_counter()
                            try:
                                torch.manual_seed(20261024);torch.cuda.manual_seed_all(20261024)
                                ids=torch.tensor([case['full_input_ids']],device='cuda',dtype=torch.long)
                                attempted+=1
                                with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
                                    response=model(input_ids=ids,attention_mask=torch.ones_like(ids),use_cache=False,
                                        logits_to_keep=case['completion_tokens']+1)
                                    statistics=token_statistics(response.logits,case,tokenizer)
                                record.update(status='completed',**statistics)
                                del response,ids,statistics
                            except Exception as error:
                                record['error']={'type':type(error).__name__,'message':str(error)}
                                raise
                            finally:
                                record['elapsed_seconds']=time.perf_counter()-call_start
                                record['finished_at_utc']=datetime.now(timezone.utc).isoformat()
                                durable(output/'PRIVATE-forwards.jsonl',record)
                                durable(output/'attempts.jsonl',{'event':'ended','ordinal':ordinal,'status':record['status'],'record_sha256':legacy.digest(record)})
                            emit('forward_completed',ordinal=ordinal,arm=arm,case=case['case_id'])
                finally:
                    # PEFT context restoration enables requires_grad on active LoRA.
                    # No forward occurs after context exit until refreezing/checking.
                    model.requires_grad_(False)
                    state(model,False)
            records=legacy.jsonl(output/'PRIVATE-forwards.jsonl');journal=legacy.jsonl(output/'attempts.jsonl')
            assert len(records)==12 and len(journal)==24 and attempted==12
            assert all(r['status']=='completed' for r in records)
            assert [{'ordinal':r['ordinal'],'arm':r['arm'],'case_id':r['case_id']} for r in records]==protocol['assignments']
            verified_sources(config);verified_sources(protocol)
            assert adapter_artifacts(ADAPTER_RUN)==artifacts
            pairs=[]
            for on,off in zip(records[:6],records[6:]):
                assert on['case_id']==off['case_id']
                positions=[]
                for a,b in zip(on['per_token'],off['per_token']):
                    assert (a['completion_index'],a['target_token_id'],a['segment'])==(b['completion_index'],b['target_token_id'],b['segment'])
                    positions.append({'completion_index':a['completion_index'],'segment':a['segment'],
                        'on_minus_off_target_logprob':a['target_logprob']-b['target_logprob']})
                a,b=on['first_divergence'],off['first_divergence']
                branch={'status':a['status']}
                if a['status']!='match_through_eos':
                    branch.update(on_margin=a['gold_minus_historical_logprob'],off_margin=b['gold_minus_historical_logprob'],
                        on_minus_off_margin=a['gold_minus_historical_logprob']-b['gold_minus_historical_logprob'])
                pairs.append({'case_id':on['case_id'],'per_token_delta':positions,'first_divergence':branch})
            write(output/'paired-deltas.json',{'kind':'arithmetic_distribution_differences_not_semantic_scores','cases':pairs})
            result.update(status='completed',logical_forwards_completed=12,adapter_weights_unchanged=True,
                config_sha256=config_hash,forward_records_sha256=sha(output/'PRIVATE-forwards.jsonl'),
                paired_deltas_sha256=sha(output/'paired-deltas.json'),journal_sha256=sha(output/'attempts.jsonl'),
                quality_acceptance_assessed=False)
    except Exception as error:
        result.update(status='failed',error={'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()})
        raise
    finally:
        result.update(logical_forwards_attempted=attempted,
            durable_forward_records=len(legacy.jsonl(output/'PRIVATE-forwards.jsonl')) if (output/'PRIVATE-forwards.jsonl').exists() else 0,
            elapsed_seconds=time.perf_counter()-started,finished_at_utc=datetime.now(timezone.utc).isoformat())
        write(output/'result.json',result);emit('finished',status=result['status'],logical_forwards_attempted=attempted)

def main():
    if not __debug__:raise RuntimeError('Run without -O/-OO.')
    parser=argparse.ArgumentParser();mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--prepare',action='store_true');mode.add_argument('--output',type=Path)
    args=parser.parse_args()
    if args.prepare:prepare()
    else:collect(args.output)

if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8');main()
