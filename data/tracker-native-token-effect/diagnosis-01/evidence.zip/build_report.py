"""Describe the completed paired token measurements; no model or scoring calls."""
from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[5]
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def main():
    result=read(HERE/'collection-01/result.json')
    review=read(HERE/'post-review.json')
    assert result['status']=='completed' and result['logical_forwards_completed']==12
    assert review['status']=='passed'
    records=[json.loads(line) for line in (HERE/'collection-01/PRIVATE-forwards.jsonl').read_text(encoding='utf-8').splitlines()]
    assert len(records)==12 and all(r['status']=='completed' for r in records)
    on={r['case_id']:r for r in records if r['arm']=='adapter_enabled'}
    off={r['case_id']:r for r in records if r['arm']=='adapter_disabled'}
    labels={'native-fit-owner-zh':'归属·中文','native-fit-owner-en':'归属·英文',
      'native-fit-wrong_withdrawn-zh':'撤销恢复·中文','native-fit-wrong_withdrawn-en':'撤销恢复·英文',
      'native-fit-uncertain_status-zh':'不确定状态·中文','native-fit-uncertain_status-en':'不确定状态·英文'}
    notes={
      'native-fit-owner-zh':'历史完整输出在普通新增之后漏掉归属修复。此处比较开始下一对象的 token 与仅结束当前对象的 token；后者本身不强制关闭整个列表。关闭适配器后的 top-1 是第三种 token，不能推断它会修复成功。',
      'native-fit-owner-en':'历史完整输出为空列表；此处历史 token 只是引号加冒号，而非完整空列表。标准 token 将冒号、开列表与开对象合并，属于 BPE 路径比较，不能把其概率称为“要不要修复”的完整动作概率。',
      'native-fit-wrong_withdrawn-en':'历史完整输出完成新增后漏掉 reopen。这里仍只是下一对象与当前对象结束的首个 token 分歧；关闭适配器后的 top-1 为第三种 token，未验证其自由生成。',
      'native-fit-uncertain_status-en':'标准下一 token 是 update，历史输出为 withdraw；当前开启适配器仍偏向 withdraw。这里只比较 op 字段的这个 token，不推断余下操作字段必然正确。'}
    failure_rows=[];body_rows=[]
    for case,label in labels.items():
        a,b=on[case],off[case]
        body_rows.append({'case_id':case,'label':label,'body_tokens':a['segments']['body']['tokens'],
          'on_body_nll':a['segments']['body']['target_nll_mean'],'off_body_nll':b['segments']['body']['target_nll_mean'],
          'definition':'Mean negative log probability over canonical JSON body tokens with teacher-forced gold prefixes; excludes EOS and template newline.'})
        x,y=a['first_divergence'],b['first_divergence']
        if x['status']!='historical_failed_output_single_token_branch':continue
        assert x['gold_token_id']==y['gold_token_id'] and x['historical_token_id']==y['historical_token_id']
        failure_rows.append({'case_id':case,'label':label,'completion_index_zero_based':x['completion_index'],
          'target_token_id':x['gold_token_id'],'historical_token_id':x['historical_token_id'],
          'target_token_label':x['gold_token_text'],'historical_token_label':x['historical_token_text'],
          'on_margin':x['gold_minus_historical_logprob'],'off_margin':y['gold_minus_historical_logprob'],
          'on_minus_off_margin':x['gold_minus_historical_logprob']-y['gold_minus_historical_logprob'],
          'on_target_logprob':x['gold_logprob'],'off_target_logprob':y['gold_logprob'],
          'on_historical_logprob':x['historical_logprob'],'off_historical_logprob':y['historical_logprob'],
          'on_top1_token_id':x['top1_token_id'],'off_top1_token_id':y['top1_token_id'],
          'historical_top1_reproduced':x['top1_token_id']==x['historical_token_id'],'note':notes[case]})
    assert len(failure_rows)==4 and all(x['historical_top1_reproduced'] for x in failure_rows)
    assert all(x['on_margin']<0<x['off_margin'] for x in failure_rows)
    assert all(x['on_body_nll']<x['off_body_nll'] for x in body_rows)
    bindings={str((HERE/p).relative_to(ROOT)).replace('\\','/'):sha(HERE/p) for p in [
      'protocol.json','cpu-preparation.json','preflight-review.json','post-review.json','measurement-summary.json',
      'collection-01/config.json','collection-01/result.json','collection-01/PRIVATE-forwards.jsonl','collection-01/attempts.jsonl']}
    report={'status':'completed','kind':'native_token_effect_diagnostic','date':'2026-10-27','timezone':'America/Halifax',
      'title':'整体目标拟合改善，但四个失败分歧处的相对偏好变差',
      'lead':'同一冻结底座上开关当前 LoRA：六条标准目标的正文损失都下降，但四个历史失败分歧处，标准 token 相对历史 token 的偏好全部由正转负。已确认的是这些固定前缀上的适配器负面作用，尚不能将它归因于某项训练配方。',
      'problem':'原生 operations 接口下，当前适配器是否只是不够强，还是在既有失败的具体选择处改变了概率分布？整体训练目标拟合与关键选择是否一致？',
      'conditions':'使用前一诊断的六条精确训练 prompt 与原标准 completion；单个已加载的 Qwen2.5-14B、原 NF4/bfloat16 设置，先六次 LoRA 开启，再六次关闭。全程 eval、inference_mode、无梯度与参数更新；不使用 generate、不构造新候选，不重跑原答案。',
      'new_forward_passes':12,'new_model_generations':0,'new_training_runs':0,'inputs':6,'new_scenarios':0,
      'failure_rows':failure_rows,'body_nll_rows':body_rows,
      'findings':[
        '在四个历史失败的首次 token 分歧处，on 模式的 top-1 全部与历史生成 token 相同。这里只复现了这些局部选择，没有重新生成完整答案，也没有重新计算修复成功率。',
        '标准 token 减历史 token 的 margin，关闭→开启 LoRA 分别为：中文归属 0.375→−1.125，英文归属 8→−1.375，英文撤销恢复 0.625→−1.625，英文不确定状态 1.25→−0.125。四个相对偏好都翻转，且 on 模式仍将标准 token 排在第二。',
        '不能写成“四个标准 token 的绝对概率都下降”：中文归属与英文撤销恢复的标准 token 概率实际上提高，但历史 token 提高更多；另外两例标准 token 概率才下降。',
        '六条标准 JSON 正文的平均 NLL 均在开启适配器后降低，逐例数值见完整记录。这证明在这批给定标准前缀的测量中，整体目标似然改善可以与关键分歧恶化同时出现；平均 loss 不能替代归属、恢复和不确定状态的行为验收。',
        '关闭适配器时，英文归属和英文不确定状态的标准 token 为 top-1；另两例的 top-1 是第三种 token 2198。因此不能将四个正 margin 写成底座能正确修复四条，更不能据此更换底座或移除岗位 LoRA。',
        '上一轮确认的接口错配不能解释这次原接口下的局部负面影响。也不能笼统声称 LoRA 完全没学到：六条目标的整体似然确实改善。具体监督、样本权重和优化过程如何形成这些相对偏好，仍未被识别。'],
      'limitations':[
        '六条都是训练中见过且已暴露的样本，四条失败不是随机抽样；不推断总体负迁移率、泛化、实际用户收益或全量欠拟合。',
        '只有第一次分歧之前，标准与历史生成共享完全相同的 token 前缀；后续 teacher forcing 提供了标准答案，不能解释为模型自主发现修复内容。',
        'BPE 首 token 不是完整动作：9207 只结束当前对象，788 只给出冒号；本表不测完整关闭列表、空 patch 或整段修复的概率。',
        '完整序列 use_cache=False 与历史缓存生成数值路径不同。四个失败点的 top-1 相同不等于所有 logits 或完整输出逐位复现；没有增加生成来追求这种保证。',
        '同一模型对象的开关比较识别的是当前适配器在固定前缀的分布作用；固定开关顺序、一次测量，不能量化运行波动或拆分数据、学习率、训练时长、loss 权重与量化的训练因果。',
        '原生六例的历史修复结果仍为 2/6，原核查能力验收仍失败。此次测量不改变这两项结果，也不构成启用依据。'],
      'next_action':{'status':'planned_not_run','text':'本轮止于预定 12 次前向计算，继续冻结当前底座和 LoRA。具体数据结构、修复顺序、目标权重与训练预算的因果贡献需要额外可比 checkpoint 或训练干预，目前均未执行；不自动扩展训练、解码或 prompt 搜索。'},
      'index_text':'12 次前向、零生成与训练：整体目标损失下降，四个失败点的标准 token 相对偏好却全部翻转；训练成因仍待受控干预。',
      'source_hashes':bindings}
    write(HERE/'analysis/report.json',report)
    validation={'id':'tracker-native-token-effect-engineering','type':'engineering_validation',
      'date':'2026-10-27','timezone':'America/Halifax','status':'bounded_measurements_verified_quality_not_reassessed',
      'tested_run':'followup/native-token-effect/collection-01','new_forward_passes':12,'new_model_generations':0,'new_training_runs':0,
      'checks':[
        {'name':'Six exact prompts and target alignment','status':'passed','detail':'CPU tokenization plus independent preflight; four failure divergences, one semantically correct wording variant, one match through EOS. No new semantic labels.'},
        {'name':'Bounded paired forward collection','status':'passed','detail':'12/12 forwards completed, 24 durable journal events; same model object and unchanged weights. Each call checks the expected 336-layer adapter state and zero trainable parameters.'},
        {'name':'Adapter context restoration','status':'passed','detail':'Immediately refroze parameters after leaving disable_adapter and passed the final enabled/eval/frozen gate. No optimizer, backward or generate called.'},
        {'name':'Local arithmetic and provenance review','status':'passed','detail':'Independent review of per-token arithmetic, four branch deltas and six body NLL comparisons; previous semantic scores retained.'}],
      'source_hashes':bindings,
      'limitations':['This is a probability diagnostic, not a fresh quality acceptance.','First differing token probability does not equal complete action probability.','Website validation and publication follow separately.']}
    write(HERE/'engineering/validation.json',validation)
    print(json.dumps({'report_sha256':sha(HERE/'analysis/report.json'),'validation_sha256':sha(HERE/'engineering/validation.json')}))
if __name__=='__main__':main()
