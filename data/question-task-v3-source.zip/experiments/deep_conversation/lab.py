"""Local browser Run Lab. Starts only bounded, fixed-model experiment workers."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import secrets
import subprocess
import sys
import threading
import time
from urllib.parse import parse_qs, urlsplit
import uuid

from config import Settings
from local_runtime import local_model_metadata
from monitor_store import RunCatalog, _run_id

HERE = Path(__file__).resolve().parent
UI = HERE / 'lab_ui'
PROFILE = dict(provider='ollama', model='qwen2.5:14b-instruct', context_window=16384,
               temperature=0, max_calls=24, max_tokens=120000, max_output_tokens=1200,
               request_timeout=180, model_latency_ms=250, reasoning_effort='none',
               local_base_url='http://127.0.0.1:11434')
HARNESSES = [
    dict(id='native', label='Native reference', preset='native', source='current',
         description='Direct question using the native tool set and shared response delivery.'),
    dict(id='agent-led', label='Agent-led', preset='agent-led', source='current',
         description='Direct question with agent-led tool choice and shared response delivery.'),
    dict(id='frozen-baseline', label='Recovery baseline · question adapted', preset='agent-led-recovery',
         source='2026-10-07-agent-led-recovery-v1',
         description='Verified frozen recovery code with the shared question adapter. This run is not an original conversation-baseline result.'),
    dict(id='progress', label='Investigation progress', preset='agent-led-progress', source='current',
         description='Direct question with bounded failure recovery and investigation-progress feedback.'),
]
for _harness in HARNESSES:
    _harness['input_mode'] = 'direct_request'
ACTIVE = {'starting', 'running'}
MAX_BODY = 128 * 1024
ASSETS = {'/': ('index.html', 'text/html; charset=utf-8'),
          '/index.html': ('index.html', 'text/html; charset=utf-8'),
          '/lab.js': ('lab.js', 'text/javascript; charset=utf-8'),
          '/lab.css': ('lab.css', 'text/css; charset=utf-8')}


def now():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


class LabError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def validate_submission(value):
    if not isinstance(value, dict) or set(value) - {'question', 'documents', 'harness', 'request_id'}:
        raise LabError('Supply only question, documents, harness and request_id.')
    question, documents = value.get('question'), value.get('documents', [])
    if not isinstance(question, str) or not 1 <= len(question.strip()) <= 12000:
        raise LabError('Question must contain 1–12000 characters.')
    if value.get('harness') not in {item['id'] for item in HARNESSES}:
        raise LabError('Choose a listed harness.')
    request_id = value.get('request_id')
    if not isinstance(request_id, str) or not re.fullmatch(r'[A-Za-z0-9_-]{8,100}', request_id):
        raise LabError('A request_id of 8–100 letters, digits, underscores or hyphens is required.')
    if not isinstance(documents, list) or len(documents) > 8:
        raise LabError('Supply at most eight documents.')
    clean = []
    for index, document in enumerate(documents):
        if not isinstance(document, dict) or set(document) - {'title', 'text'}:
            raise LabError('Each document accepts only title and text.')
        title = document.get('title', f'Provided document {index + 1}')
        text = document.get('text')
        if not isinstance(title, str) or not 1 <= len(title.strip()) <= 200:
            raise LabError('Document titles must contain 1–200 characters.')
        if not isinstance(text, str) or not 1 <= len(text.strip()) <= 20000:
            raise LabError('Document text must contain 1–20000 characters.')
        clean.append({'title': title.strip(), 'text': text.strip()})
    if sum(len(document['text']) for document in clean) > 60000:
        raise LabError('Combined document text is limited to 60000 characters.')
    return dict(question=question.strip(), documents=clean, harness=value['harness'], request_id=request_id)


def make_fixture(directory, job_id, question, documents, *, input_mode='human_human_transcript'):
    if input_mode not in {'direct_request', 'human_human_transcript'}:
        raise ValueError('Unsupported input mode.')
    directory.mkdir(parents=True, exist_ok=False)
    corpus = [dict(id=f'provided-{index + 1}', title=doc['title'], text=doc['text'],
                   kind='document', available_at_ms=0,
                   provenance='User-provided local Run Lab input') for index, doc in enumerate(documents)]
    case_id = f'custom-{job_id}'
    case = dict(case_id=case_id, family_id='browser-local', language='auto',
                input_mode=input_mode,
                events=[dict(at_ms=0, kind='utterance', speaker='User', text=question, is_final=True)],
                close_at_ms=45000, corpus_ids=[doc['id'] for doc in corpus],
                tool_latency_ms=dict(search=5000, read=1000),
                clarifications='disabled_for_this_diagnostic_pilot')
    write_json(directory / 'cases.json', [case])
    write_json(directory / 'corpus.json', corpus)
    return case_id


def process_identity(pid):
    """Read liveness and OS creation evidence without signalling a process."""
    if type(pid) is not int or pid <= 0:
        return {'status': 'unknown', 'pid': pid}
    if os.name == 'nt':
        import ctypes
        from ctypes import wintypes
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.GetProcessTimes.argtypes = [wintypes.HANDLE, *([ctypes.POINTER(wintypes.FILETIME)] * 4)]
        kernel.GetProcessTimes.restype = wintypes.BOOL
        kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
        kernel.WaitForSingleObject.restype = wintypes.DWORD
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        handle = kernel.OpenProcess(0x1000 | 0x00100000, False, pid)
        if not handle:
            return {'status': 'exited' if ctypes.get_last_error() == 87 else 'unknown', 'pid': pid}
        try:
            if kernel.WaitForSingleObject(handle, 0) == 0:
                return {'status': 'exited', 'pid': pid}
            stamps = [wintypes.FILETIME() for _ in range(4)]
            if not kernel.GetProcessTimes(handle, *(ctypes.byref(stamp) for stamp in stamps)):
                return {'status': 'unknown', 'pid': pid}
            created = (stamps[0].dwHighDateTime << 32) | stamps[0].dwLowDateTime
            return {'status': 'running', 'pid': pid, 'created': str(created)}
        finally:
            kernel.CloseHandle(handle)
    # Linux starttime distinguishes PID reuse. Unsupported platforms fail closed.
    stat_path = Path('/proc') / str(pid) / 'stat'
    try:
        fields = stat_path.read_text(encoding='utf-8').rsplit(')', 1)[1].split()
        boot_id = Path('/proc/sys/kernel/random/boot_id').read_text(encoding='ascii').strip()
        return {'status': 'exited' if fields[0] == 'Z' else 'running', 'pid': pid,
                'created': f'{boot_id}:{fields[19]}'}
    except FileNotFoundError:
        return {'status': 'exited' if Path('/proc').is_dir() else 'unknown', 'pid': pid}
    except (OSError, IndexError, ValueError):
        return {'status': 'unknown', 'pid': pid}


class LabManager:
    def __init__(self, *, jobs_root=None, runs_root=None, worker=None, python=None,
                 popen=None, preflight=None, catalog=None, output_reader=None,
                 watch=True, wall_timeout=4440, process_probe=None):
        self.jobs_root = Path(jobs_root or HERE / 'lab_jobs').resolve()
        self.runs_root = Path(runs_root or HERE / 'runs').resolve()
        self.worker = Path(worker or HERE / 'lab_worker.py').resolve()
        self.python = str(python or sys.executable)
        self.popen = popen or subprocess.Popen
        self.preflight = preflight or local_model_metadata
        self.catalog = catalog or RunCatalog([self.runs_root], cache_seconds=0)
        self.output_reader = output_reader
        self.watch, self.wall_timeout = watch, wall_timeout
        self.process_probe = process_probe or process_identity
        self.token = secrets.token_urlsafe(32)
        self._lock = threading.RLock()
        self._jobs, self._processes, self._handles, self._orphan_guards = {}, {}, {}, {}
        self._preflight_value, self._preflight_at = None, 0
        self._model_identity = None
        if self.jobs_root.exists():
            for path in self.jobs_root.glob('*/state.json'):
                try:
                    item = json.loads(path.read_text(encoding='utf-8'))
                    if not re.fullmatch(r'[a-f0-9]{32}', item['id']) or path.parent.name != item['id']:
                        continue
                    if item['status'] in ACTIVE:
                        item.update(status='interrupted', error='Lab restarted; the prior worker is not managed by this session.', updated_at=now())
                        self._orphan_guards[item['id']] = item.get('worker_identity')
                    elif item.get('worker_identity'):
                        self._orphan_guards[item['id']] = item['worker_identity']
                    self._jobs[item['id']] = item
                except (OSError, ValueError, KeyError, TypeError):
                    continue

    def check_model(self, *, fresh=False):
        with self._lock:
            if not fresh and self._preflight_value is not None and time.monotonic() - self._preflight_at < 10:
                return self._preflight_value
            settings = Settings(**{key: value for key, value in PROFILE.items() if key != 'temperature'})
            try:
                metadata = self.preflight(settings)
                self._preflight_value = {'status': 'available', 'model': metadata}
            except Exception:
                self._preflight_value = {'status': 'unavailable', 'error': 'Local Qwen2.5 14B is unavailable or its configuration is incompatible.'}
            self._preflight_at = time.monotonic()
            return self._preflight_value

    def configuration(self):
        return {'csrf_token': self.token, 'profile': dict(PROFILE),
                'default_harness': 'agent-led', 'task_contract_version': 3,
                'harnesses': [dict(item) for item in HARNESSES], 'preflight': self.check_model(),
                'input_note': 'Question test uses a direct request. Original research presets retain their conversation-replay task. Search uses only supplied documents; there is no live web retrieval.',
                'max_documents': 8, 'max_question_chars': 12000, 'max_document_chars': 20000,
                'max_total_document_chars': 60000}

    def _save(self, item):
        write_json(self.jobs_root / item['id'] / 'state.json', item)

    def _public(self, item):
        keys = ('id', 'harness', 'preset', 'status', 'created_at', 'updated_at', 'question',
                'run_id', 'error', 'exit_code', 'input_sha256', 'model_profile_sha256', 'model', 'input_mode')
        process = self._processes.get(item['id'])
        return {**{key: item.get(key) for key in keys},
                'can_cancel': process is not None and process.poll() is None,
                'blocks_new_runs': item['id'] in self._orphan_guards}

    def _close_log(self, job_id):
        handle = self._handles.pop(job_id, None)
        if handle:
            handle.close()

    def _refresh_orphans(self):
        for job_id, recorded in list(self._orphan_guards.items()):
            if not recorded:
                # Older state or a crash between spawn and recording the PID:
                # use the worker's runtime receipt if it has appeared. Never
                # infer that a stale heartbeat proves the process has exited.
                try:
                    runtime = json.loads((self.runs_root / f'lab-{job_id}' / 'runtime_status.json').read_text(encoding='utf-8'))
                    if type(runtime.get('pid')) is int:
                        recorded = {'pid': runtime['pid']}
                        self._orphan_guards[job_id] = recorded
                except (OSError, ValueError, TypeError):
                    pass
            current = self.process_probe(recorded.get('pid')) if isinstance(recorded, dict) else {'status': 'unknown'}
            different = (recorded and recorded.get('created') and current.get('created') and
                         recorded['created'] != current['created'])
            if current.get('status') == 'exited' or different:
                del self._orphan_guards[job_id]
            else:
                self._jobs[job_id]['error'] = ('A worker from the previous Lab session is still running or cannot yet be verified as exited. '
                                              'New runs are blocked until it exits; this session will not terminate an unowned process.')

    def _finish(self, job_id, code):
        item = self._jobs[job_id]
        if item['status'] not in ACTIVE:
            self._close_log(job_id)
            return
        summary_path = self.runs_root / f'lab-{job_id}' / 'summary.json'
        try:
            summary = json.loads(summary_path.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            summary = {}
        status = summary.get('status')
        if code == 0 and status in {'completed', 'paused'}:
            item.update(status=status, error=None)
        else:
            item.update(status='error', error='Worker failed or did not produce a completed summary.')
        item.update(exit_code=code, updated_at=now())
        try:
            self._save(item)
        finally:
            self._close_log(job_id)

    def _refresh(self):
        self._refresh_orphans()
        for job_id, process in list(self._processes.items()):
            code = process.poll()
            if code is not None:
                self._finish(job_id, code)

    def _watch(self, job_id, process):
        try:
            code = process.wait(timeout=self.wall_timeout)
            with self._lock:
                self._finish(job_id, code)
        except subprocess.TimeoutExpired:
            self._stop(job_id, 'error', 'Run exceeded its wall-time limit.')

    def submit(self, value):
        payload = validate_submission(value)
        digest = hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
        with self._lock:
            self._refresh()
            for item in self._jobs.values():
                if item.get('request_id') == payload['request_id']:
                    if item.get('submission_sha256') != digest:
                        raise LabError('That request_id was already used for different input.', 409)
                    return self._public(item)
            if self._orphan_guards:
                raise LabError('A worker from a previous Lab session has not been confirmed exited. Wait for it to finish before starting another run.', 409)
            if any(process.poll() is None for process in self._processes.values()) or any(item['status'] in ACTIVE for item in self._jobs.values()):
                raise LabError('A run is already active. Wait or stop it before starting another.', 409)
            readiness = self.check_model(fresh=True)
            if readiness['status'] != 'available':
                raise LabError(readiness['error'], 503)
            metadata = readiness['model']
            if self._model_identity is not None and metadata != self._model_identity:
                raise LabError('The local model or runtime changed during this Lab session. Restart the Lab to establish a new comparison profile.', 409)
            self._model_identity = metadata
            job_id = uuid.uuid4().hex
            job_dir = self.jobs_root / job_id
            job_dir.mkdir(parents=True, exist_ok=False)
            dataset = job_dir / 'dataset'
            harness = next(item for item in HARNESSES if item['id'] == payload['harness'])
            case_id = make_fixture(dataset, job_id, payload['question'], payload['documents'],
                                   input_mode=harness['input_mode'])
            self.runs_root.mkdir(parents=True, exist_ok=True)
            output = self.runs_root / f'lab-{job_id}'
            job = dict(id=job_id, harness=harness['id'], preset=harness['preset'],
                       input_mode=harness['input_mode'],
                       question=payload['question'], documents=payload['documents'], dataset=str(dataset),
                       case_id=case_id, output=str(output), settings=dict(PROFILE), expected_local_model=metadata)
            write_json(job_dir / 'job.json', job)
            item = dict(id=job_id, harness=harness['id'], preset=harness['preset'], question=payload['question'],
                        input_mode=harness['input_mode'],
                        created_at=now(), updated_at=now(), status='starting', run_id=_run_id(output),
                        request_id=payload['request_id'], submission_sha256=digest, error=None, exit_code=None,
                        input_sha256=hashlib.sha256(json.dumps({**{key: payload[key] for key in ('question', 'documents')},
                            'input_mode': harness['input_mode']},
                            ensure_ascii=False, sort_keys=True).encode()).hexdigest(),
                        model_profile_sha256=hashlib.sha256(json.dumps({'settings': PROFILE, 'local_model': metadata},
                            ensure_ascii=False, sort_keys=True).encode()).hexdigest(),
                        model={key: metadata.get(key) for key in ('model', 'digest', 'ollama_version', 'context_window')})
            self._jobs[job_id] = item
            self._save(item)
            command = [self.python, '-B', str(self.worker), '--job', str(job_dir / 'job.json')]
            handle, process = None, None
            try:
                handle = (job_dir / 'worker.log').open('wb')
                kwargs = dict(cwd=str(HERE), stdin=subprocess.DEVNULL, stdout=handle, stderr=subprocess.STDOUT,
                              shell=False, env={**os.environ, 'PYTHONIOENCODING': 'utf-8'})
                if os.name == 'nt':
                    kwargs['creationflags'] = subprocess.CREATE_NO_WINDOW
                process = self.popen(command, **kwargs)
                self._processes[job_id], self._handles[job_id] = process, handle
                identity = self.process_probe(process.pid)
                item.update(status='running', updated_at=now(), worker_identity={
                    'pid': process.pid, 'created': identity.get('created')})
                self._save(item)
                if self.watch:
                    threading.Thread(target=self._watch, args=(job_id, process), daemon=True,
                                     name=f'lab-worker-{job_id[:8]}').start()
            except Exception:
                stopped = process is None or self._terminate_owned(process)
                if stopped:
                    self._close_log(job_id)
                    if handle and not handle.closed:
                        handle.close()
                    item.update(status='error', error='Worker could not be started or its launch could not be recorded.', updated_at=now())
                else:
                    item.update(status='running', error='Launch bookkeeping failed and the worker has not stopped. New runs remain blocked.', updated_at=now())
                try:
                    self._save(item)
                except OSError:
                    # Retain ownership and the in-memory guard even if disk is
                    # unavailable; close() must still stop this exact child.
                    pass
            return self._public(item)

    def list_jobs(self):
        with self._lock:
            self._refresh()
            return [self._public(item) for item in sorted(self._jobs.values(), key=lambda x: x['created_at'], reverse=True)]

    def detail(self, job_id, **cursors):
        with self._lock:
            self._refresh()
            if job_id not in self._jobs:
                raise LabError('Unknown Lab run.', 404)
            job = self._public(self._jobs[job_id])
        snapshot = self.catalog.read_run(job['run_id'], **{k: v for k, v in cursors.items() if k != 'after_output_seq'})
        if snapshot.get('read_status') == 'not_found':
            snapshot = None
        reader = self.output_reader
        if reader is None:
            try:
                from lab_output import read_output
                reader = read_output
            except ImportError:
                pass
        outputs = {'events': [], 'next_seq': cursors.get('after_output_seq', 0)}
        if reader:
            outputs = reader(self.runs_root / f'lab-{job_id}', cursors.get('after_output_seq', 0))
        response = None
        if job.get('input_mode') == 'direct_request' or (
                not job.get('input_mode') and job.get('harness') == 'direct-help'):
            try:
                from monitor_store import _safe
                candidate = json.loads((self.runs_root / f'lab-{job_id}' / 'direct_response.json').read_text(encoding='utf-8'))
                if (isinstance(candidate, dict) and candidate.get('status') in {'response', 'no_response'}
                        and isinstance(candidate.get('text'), str)):
                    response = _safe(candidate)
            except (OSError, ValueError, TypeError):
                pass
        return {'job': job, 'snapshot': snapshot, 'output_events': outputs, 'direct_response': response}

    @staticmethod
    def _terminate_owned(process):
        if process.poll() is not None:
            return True
        try:
            process.terminate()
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=2)
        except (OSError, subprocess.TimeoutExpired):
            pass
        return process.poll() is not None

    def _stop(self, job_id, status, error):
        with self._lock:
            item = self._jobs.get(job_id)
            if item is None:
                raise LabError('Unknown Lab run.', 404)
            process = self._processes.get(job_id)
            if process is None:
                if item['status'] not in ACTIVE:
                    return self._public(item)
                raise LabError('This worker is not managed by this session.', 409)
            if process.poll() is not None:
                self._finish(job_id, process.poll())
                return self._public(item)
            if not self._terminate_owned(process):
                item.update(status='running', error='The worker has not stopped yet; new runs remain blocked.', updated_at=now())
                raise LabError('The worker has not stopped yet; try again.', 503)
            item.update(status=status, error=error, exit_code=process.poll(), updated_at=now())
            try:
                self._save(item)
            finally:
                self._close_log(job_id)
            return self._public(item)

    def cancel(self, job_id):
        return self._stop(job_id, 'cancelled', 'Stopped by user. Preserved records may include an unfinished model call; automatic resume is unavailable.')

    def close(self):
        with self._lock:
            for job_id, process in list(self._processes.items()):
                if process.poll() is None:
                    try:
                        self._stop(job_id, 'interrupted', 'Lab server stopped.')
                    except (LabError, OSError):
                        # Continue stopping every owned child even when one
                        # termination or final state write fails.
                        pass
                else:
                    self._close_log(job_id)


def create_server(port=8769, manager=None):
    manager = manager or LabManager()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def send(self, status, body, content_type='application/json; charset=utf-8'):
            if not isinstance(body, bytes):
                body = json.dumps(body, ensure_ascii=False).encode('utf-8')
            self.send_response(status)
            for name, value in {'Content-Type': content_type, 'Content-Length': str(len(body)),
                                'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff',
                                'Referrer-Policy': 'no-referrer',
                                'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'"}.items():
                self.send_header(name, value)
            self.end_headers()
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                pass

        def boundary(self, write=False):
            hosts = {f'127.0.0.1:{self.server.server_port}', f'localhost:{self.server.server_port}'}
            if len(self.headers.get_all('Host', [])) != 1 or self.headers.get('Host') not in hosts:
                raise LabError('Loopback host required.', 403)
            origin = self.headers.get('Origin')
            # A user clicking the research site's link is a cross-site document
            # navigation. It may open the static shell, which contains no run
            # data or session token. Fetches from that shell are same-origin;
            # API reads and writes retain the boundary below.
            landing_navigation = (
                not write and self.command == 'GET'
                and urlsplit(self.path).path in {'/', '/index.html'}
                and self.headers.get('Sec-Fetch-Mode') == 'navigate'
                and self.headers.get('Sec-Fetch-Dest') == 'document'
                and self.headers.get('Sec-Fetch-User') == '?1'
            )
            if (origin and origin != 'http://' + self.headers['Host']) or (
                    self.headers.get('Sec-Fetch-Site') == 'cross-site' and not landing_navigation):
                raise LabError('Open the Lab directly on this computer.', 403)
            if write and (origin != 'http://' + self.headers['Host'] or
                          not secrets.compare_digest(self.headers.get('X-Lab-Token', ''), manager.token)):
                raise LabError('A same-origin Lab session token is required.', 403)

        def do_GET(self):
            try:
                self.boundary()
                parsed = urlsplit(self.path)
                if parsed.path == '/api/lab/config':
                    return self.send(200, manager.configuration())
                if parsed.path == '/api/health':
                    return self.send(200, {'status': 'ok', 'service': 'harness-run-lab', 'local_only': True})
                if parsed.path == '/api/lab/runs':
                    return self.send(200, {'runs': manager.list_jobs()})
                match = re.fullmatch(r'/api/lab/runs/([a-f0-9]{32})', parsed.path)
                if match:
                    query = parse_qs(parsed.query)
                    if set(query) - {'after_seq', 'after_runtime_seq', 'after_output_seq'}:
                        raise LabError('Unknown cursor.')
                    cursors = {}
                    for key, values in query.items():
                        if len(values) != 1 or not re.fullmatch(r'\d{1,12}', values[0]):
                            raise LabError('Cursors must be nonnegative integers.')
                        cursors[key] = int(values[0])
                    return self.send(200, manager.detail(match[1], **cursors))
                asset = ASSETS.get(parsed.path)
                if asset:
                    try:
                        return self.send(200, (UI / asset[0]).read_bytes(), asset[1])
                    except OSError:
                        raise LabError('Lab interface is temporarily unavailable.', 503)
                raise LabError('Not found.', 404)
            except LabError as error:
                self.send(error.status, {'error': str(error)})
            except Exception:
                self.send(503, {'error': 'Lab data is temporarily unavailable.'})

        def do_POST(self):
            try:
                self.boundary(write=True)
                if self.headers.get('Transfer-Encoding') or len(self.headers.get_all('Content-Length', [])) != 1:
                    raise LabError('A single Content-Length is required.')
                if self.headers.get('Content-Type', '').split(';')[0].strip().lower() != 'application/json':
                    raise LabError('Content-Type must be application/json.', 415)
                try:
                    length = int(self.headers['Content-Length'])
                except ValueError:
                    raise LabError('Invalid Content-Length.')
                if length <= 0 or length > MAX_BODY:
                    raise LabError('Request body is too large or empty.', 413)
                try:
                    value = json.loads(self.rfile.read(length).decode('utf-8'))
                except (ValueError, UnicodeDecodeError):
                    raise LabError('Request body must be valid UTF-8 JSON.')
                path = urlsplit(self.path).path
                if path == '/api/lab/runs':
                    job = manager.submit(value)
                    return self.send(202, {'id': job['id'], 'status': job['status'], 'job': job})
                match = re.fullmatch(r'/api/lab/runs/([a-f0-9]{32})/cancel', path)
                if match:
                    if value != {}:
                        raise LabError('Cancel accepts an empty JSON object.')
                    return self.send(200, {'job': manager.cancel(match[1])})
                raise LabError('Not found.', 404)
            except LabError as error:
                self.send(error.status, {'error': str(error)})
            except Exception:
                self.send(503, {'error': 'The Lab action could not be completed.'})

    server = ThreadingHTTPServer(('127.0.0.1', port), Handler)
    server.lab_manager = manager
    return server


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', type=int, default=8769)
    args = parser.parse_args()
    server = create_server(args.port)
    print(f'Local Run Lab: http://127.0.0.1:{server.server_port}', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.lab_manager.close()
        server.server_close()


if __name__ == '__main__':
    main()
