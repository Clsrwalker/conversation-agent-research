"""No model generation: real selected graphs under the labelled plumbing model."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from lab import make_fixture, PROFILE, HARNESSES
from lab_worker import BASELINE, FIXED, HERE, ObservedGraph, run_job, verify_baseline


class WorkerTests(unittest.TestCase):
    def test_observer_keeps_invocation_and_original_callbacks(self):
        class Graph:
            name = 'original'
            def invoke(self, value, config, **kwargs):
                return value, config, kwargs
        original = {'callbacks': ['accounting'], 'configurable': {'thread_id': 'same'}}
        proxy = ObservedGraph(Graph(), ['output', 'runtime'])
        value, config, kwargs = proxy.invoke({'messages': []}, original, durability='sync')
        self.assertEqual(original['callbacks'], ['accounting'])
        self.assertEqual(config['callbacks'], ['accounting', 'output', 'runtime'])
        self.assertEqual(kwargs, {'durability': 'sync'})
        self.assertEqual(proxy.name, 'original')
        self.assertEqual(value, {'messages': []})

    def test_profiles_cannot_drift_or_accept_arbitrary_source(self):
        self.assertEqual(FIXED, PROFILE)
        for job in [{'harness': '../bad'}, {'harness': 'native', 'preset': 'native', 'settings': {}}]:
            with self.assertRaises(ValueError):
                run_job(job, scripted=True)

    def test_baseline_checksum_detects_edit(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / 'run.py').write_text('changed')
            (root / 'checksums.json').write_text(json.dumps({'files_sha256': {'run.py': 'wrong'}}))
            with self.assertRaisesRegex(ValueError, 'integrity'):
                verify_baseline(root)

    def test_caught_runner_failure_propagates_exit_code(self):
        runner = SimpleNamespace(Settings=lambda **kwargs: kwargs, build_graph=lambda: None,
                                 main=lambda: 1)
        spec = SimpleNamespace(loader=SimpleNamespace(exec_module=lambda module: None))
        with tempfile.TemporaryDirectory() as temp, patch('lab_worker.importlib.util.spec_from_file_location', return_value=spec), patch('lab_worker.importlib.util.module_from_spec', return_value=runner):
            job = dict(id='failure', harness='native', preset='native', settings=FIXED,
                       output=str(Path(temp) / 'run'), dataset=temp, case_id='failure')
            before = list(sys.path)
            try:
                self.assertEqual(run_job(job, scripted=True), 1)
            finally:
                sys.path[:] = before

    def test_selected_graphs_and_preserved_baseline(self):
        before = verify_baseline()
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            configurations = [*HARNESSES, dict(id='direct-help', preset='agent-led', input_mode='direct_request')]
            for harness in configurations:
                with self.subTest(harness=harness['id']):
                    folder = root / harness['id']
                    dataset = root / (harness['id'] + '-dataset')
                    case_id = make_fixture(dataset, 'diagnostic', 'Find the offline note.',
                                           [{'title': 'offline', 'text': 'Offline integration fixture only.'}],
                                           input_mode=harness['input_mode'])
                    job = dict(id='diagnostic', harness=harness['id'], preset=harness['preset'],
                               input_mode=harness['input_mode'],
                               settings=FIXED, dataset=str(dataset), case_id=case_id, output=str(folder))
                    path = root / (harness['id'] + '.json')
                    path.write_text(json.dumps(job), encoding='utf-8')
                    process = subprocess.run([sys.executable, '-B', str(HERE / 'lab_worker.py'),
                                              '--job', str(path), '--scripted'], capture_output=True,
                                             text=True, encoding='utf-8', timeout=90)
                    self.assertEqual(process.returncode, 0, process.stderr[-4000:])
                    provenance = json.loads((folder / 'lab_provenance.json').read_text())
                    manifest = json.loads((folder / 'manifest.json').read_text())
                    summary = json.loads((folder / 'summary.json').read_text())
                    self.assertTrue(provenance['scripted_diagnostic'])
                    self.assertFalse(provenance['quality_evaluated'])
                    self.assertEqual(manifest['provider'], 'scripted')
                    self.assertEqual(manifest['settings']['preset'], harness['preset'])
                    self.assertEqual(summary['status'], 'completed')
                    self.assertEqual(provenance['input_mode'], 'direct_request')
                    adapter = provenance['task_adapter']
                    self.assertEqual(adapter['task_contract_version'], 3)
                    recovery = harness['id'] in {'frozen-baseline', 'progress'}
                    self.assertEqual('consider_recovery' in summary['outer_graph_nodes'], recovery)
                    self.assertIn('deliver_response', summary['outer_graph_nodes'])
                    self.assertEqual(adapter['capabilities']['failure_recovery'], recovery)
                    self.assertEqual(adapter['capabilities']['investigation_progress'], harness['id'] == 'progress')
                    self.assertEqual(adapter['capabilities']['calculate'], harness['id'] != 'native')
                    delivery = json.loads((folder / 'direct_response.json').read_text())
                    # SmokeModel deliberately never emits a normal final answer.
                    self.assertEqual(delivery['status'], 'no_response')
                    self.assertFalse(delivery['quality_evaluated'])
                    environment = json.loads((folder / 'environment_log.json').read_text())
                    catalog_events = [row for row in environment if row['kind'] == 'source_catalog_registered']
                    self.assertEqual(len(catalog_events), 1)
                    self.assertNotIn('Offline integration fixture only.', json.dumps(catalog_events))
                    tools = [row['tool_names'] for row in environment if row['kind'] == 'native_model_boundary']
                    self.assertTrue(tools)
                    self.assertEqual('calculate' in tools[0], harness['id'] != 'native')
                    model_calls = json.loads((folder / 'model_calls.json').read_text())
                    progress = [message for call in model_calls for batch in call['request'] for message in batch
                                if message.get('id') == 'investigation-progress-v1']
                    self.assertEqual(bool(progress), harness['id'] == 'progress')
                    if progress:
                        projections = [json.loads(message['content']) for message in progress]
                        self.assertTrue(any(p['arrived_sources']['recent'] for p in projections))
                    self.assertTrue((folder / 'monitor_events.jsonl').exists())
                    self.assertTrue((folder / 'assistant_output.jsonl').exists())
                    self.assertTrue((folder / 'graph.json').exists())
                    expected = before if harness['id'] == 'frozen-baseline' else None
                    self.assertEqual(provenance['baseline_checksums_sha256'], expected)
                    if expected:
                        from lab_worker import sha
                        for name in ['run.py', 'world.py', 'agent.py', 'agent_led_tools.py']:
                            key = 'experiments/deep_conversation/' + name
                            self.assertEqual(manifest['fingerprint']['source_sha256'][key],
                                             sha(BASELINE / 'source' / key))
                        self.assertEqual(adapter['selected_source'], 'verified_frozen_with_external_task_adapter')
                    from lab_worker import sha
                    key = 'experiments/deep_conversation/direct_request.py'
                    self.assertEqual(manifest['fingerprint']['source_sha256'][key], sha(HERE / 'direct_request.py'))
                    self.assertEqual(sha(folder / 'source' / key), sha(HERE / 'direct_request.py'))
        self.assertEqual(verify_baseline(), before)

    def test_historical_conversation_job_keeps_original_graph_and_no_direct_delivery(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            dataset = root / 'dataset'
            folder = root / 'run'
            case_id = make_fixture(dataset, 'history', 'A conversation fragment.', [],
                                   input_mode='human_human_transcript')
            job = dict(id='history', harness='frozen-baseline', preset='agent-led-recovery',
                       input_mode='human_human_transcript', settings=FIXED,
                       dataset=str(dataset), case_id=case_id, output=str(folder))
            path = root / 'job.json'
            path.write_text(json.dumps(job), encoding='utf-8')
            process = subprocess.run([sys.executable, '-B', str(HERE / 'lab_worker.py'),
                                      '--job', str(path), '--scripted'], capture_output=True,
                                     text=True, encoding='utf-8', timeout=90)
            self.assertEqual(process.returncode, 0, process.stderr[-4000:])
            summary = json.loads((folder / 'summary.json').read_text())
            provenance = json.loads((folder / 'lab_provenance.json').read_text())
            self.assertNotIn('deliver_response', summary['outer_graph_nodes'])
            self.assertNotIn('task_adapter', provenance)
            self.assertFalse((folder / 'direct_response.json').exists())


if __name__ == '__main__':
    unittest.main()
