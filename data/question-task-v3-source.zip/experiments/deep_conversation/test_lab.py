"""Offline Run Lab checks. Fake processes; no model generation or Ollama access."""
from __future__ import annotations

import copy
from http.client import HTTPConnection
import json
import os
from pathlib import Path
import subprocess
import tempfile
import threading
import unittest
from unittest.mock import Mock, patch

import lab


class FakeProcess:
    def __init__(self):
        self.returncode = None
        self.terminated = False
        self.killed = False

    def poll(self):
        return self.returncode

    def terminate(self):
        self.terminated = True
        self.returncode = -15

    def kill(self):
        self.killed = True
        self.returncode = -9

    def wait(self, timeout=None):
        if self.returncode is None:
            raise subprocess.TimeoutExpired('fake-worker', timeout)
        return self.returncode


def submission(**overrides):
    return dict(question='Does the supplied plan permit offline editing?',
                documents=[dict(title='Example plan', text='The plan permits offline reading only.')],
                harness='progress', request_id='request-test-0001', **overrides)


class LabFixture(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.processes, self.commands = [], []

        def spawn(command, **kwargs):
            process = FakeProcess()
            process.pid = 10000 + len(self.processes)
            self.processes.append(process)
            self.commands.append((command, kwargs))
            return process

        def probe(pid):
            process = next((p for p in self.processes if p.pid == pid), None)
            return {'status': 'running' if process and process.poll() is None else 'exited',
                    'pid': pid, 'created': f'fixture-start-{pid}'}

        self.probe = Mock(side_effect=probe)

        self.preflight = Mock(return_value={'model': lab.PROFILE['model'], 'digest': 'fixture-digest',
                                            'ollama_version': 'fixture-version', 'inference_location': 'local'})
        self.manager = lab.LabManager(jobs_root=self.root / 'jobs', runs_root=self.root / 'runs',
                                      popen=spawn, preflight=self.preflight, watch=False, process_probe=self.probe)

    def tearDown(self):
        self.manager.close()
        self.temp.cleanup()

    def complete(self, job, status='completed', code=0):
        output = self.root / 'runs' / f"lab-{job['id']}"
        output.mkdir()
        lab.write_json(output / 'summary.json', {'status': status})
        self.processes[-1].returncode = code


class LabTests(LabFixture):
    def test_configuration_is_read_only_and_fixes_profile(self):
        result = self.manager.configuration()
        self.assertEqual(result['profile']['provider'], 'ollama')
        self.assertEqual(result['profile']['model'], 'qwen2.5:14b-instruct')
        self.assertEqual(result['profile']['max_tokens'], 120000)
        self.assertEqual(result['profile']['max_output_tokens'], 1200)
        self.assertEqual(result['profile']['temperature'], 0)
        self.assertEqual(result['preflight']['status'], 'available')
        self.assertEqual(len(result['csrf_token']), 43)
        self.assertFalse((self.root / 'jobs').exists())
        self.assertEqual(self.commands, [])
        self.assertEqual([item['id'] for item in result['harnesses']],
                         ['native', 'agent-led', 'frozen-baseline', 'progress'])
        self.assertEqual(result['default_harness'], 'agent-led')
        self.assertEqual(result['task_contract_version'], 3)
        self.assertTrue(all(item['input_mode'] == 'direct_request' for item in result['harnesses']))

    def test_direct_question_task_is_explicit_and_does_not_invent_sources(self):
        payload = submission()
        payload.update(harness='agent-led', documents=[])
        direct = self.manager.submit(payload)
        saved = json.loads((self.root / 'jobs' / direct['id'] / 'job.json').read_text(encoding='utf-8'))
        case = json.loads((Path(saved['dataset']) / 'cases.json').read_text(encoding='utf-8'))[0]
        self.assertEqual(case['input_mode'], 'direct_request')
        self.assertEqual(case['corpus_ids'], [])
        self.assertEqual(direct['input_mode'], 'direct_request')
        self.assertEqual(saved['preset'], 'agent-led')
        self.manager.cancel(direct['id'])
        for item in lab.HARNESSES:
            payload.update(harness=item['id'], request_id='request-question-' + item['id'])
            other = self.manager.submit(payload)
            self.assertEqual(other['input_mode'], 'direct_request')
            self.assertEqual(other['input_sha256'], direct['input_sha256'])
            self.manager.cancel(other['id'])

    def test_only_direct_task_returns_delivered_response_not_debug_output(self):
        payload = submission()
        payload.update(harness='agent-led')
        direct = self.manager.submit(payload)
        self.complete(direct)
        folder = self.root / 'runs' / f"lab-{direct['id']}"
        lab.write_json(folder / 'direct_response.json', dict(status='response', text='An explanation.', quality_evaluated=False))
        response = self.manager.detail(direct['id'])['direct_response']
        self.assertEqual(response['text'], 'An explanation.')
        self.assertFalse(response['quality_evaluated'])
        payload.update(harness='agent-led', request_id='request-replay-003')
        replay = self.manager.submit(payload)
        self.complete(replay)
        # Historical records must not inherit today's task mode from the ID.
        self.manager._jobs[replay['id']].pop('input_mode')
        folder = self.root / 'runs' / f"lab-{replay['id']}"
        lab.write_json(folder / 'direct_response.json', dict(status='response', text='Must stay private.'))
        self.assertIsNone(self.manager.detail(replay['id'])['direct_response'])

    def test_missing_or_malformed_delivery_does_not_become_success(self):
        payload = submission()
        payload.update(harness='agent-led')
        job = self.manager.submit(payload)
        self.complete(job)
        self.assertIsNone(self.manager.detail(job['id'])['direct_response'])
        folder = self.root / 'runs' / f"lab-{job['id']}"
        lab.write_json(folder / 'direct_response.json', dict(status='response', text={'unexpected': 'object'}))
        self.assertIsNone(self.manager.detail(job['id'])['direct_response'])

    def test_submission_writes_bounded_causal_fixture_and_safe_command(self):
        payload = submission()
        payload['question'] = '资料是否支持这个结论？'
        job = self.manager.submit(payload)
        self.assertEqual(job['status'], 'running')
        saved = json.loads((self.root / 'jobs' / job['id'] / 'job.json').read_text(encoding='utf-8'))
        case = json.loads((Path(saved['dataset']) / 'cases.json').read_text(encoding='utf-8'))[0]
        docs = json.loads((Path(saved['dataset']) / 'corpus.json').read_text(encoding='utf-8'))
        self.assertEqual(case['events'], [dict(at_ms=0, kind='utterance', speaker='User',
                                               text=payload['question'], is_final=True)])
        self.assertEqual(case['corpus_ids'], ['provided-1'])
        self.assertEqual(docs[0]['text'], payload['documents'][0]['text'])
        self.assertEqual(saved['settings'], lab.PROFILE)
        self.assertEqual(saved['expected_local_model']['digest'], 'fixture-digest')
        self.assertFalse(Path(saved['output']).exists())
        command, options = self.commands[0]
        self.assertEqual(command[1], '-B')
        self.assertEqual(command[-2], '--job')
        self.assertEqual(Path(command[-1]).parent, self.root / 'jobs' / job['id'])
        self.assertFalse(options['shell'])
        self.assertNotIn(payload['question'], command)
        self.assertNotIn('gold', saved)

    def test_empty_documents_remain_empty_no_fixture_evidence_invented(self):
        payload = submission()
        payload['documents'] = []
        job = self.manager.submit(payload)
        path = self.root / 'jobs' / job['id'] / 'dataset' / 'corpus.json'
        self.assertEqual(json.loads(path.read_text(encoding='utf-8')), [])

    def test_repeated_request_is_idempotent_even_while_active(self):
        first = self.manager.submit(submission())
        again = self.manager.submit(submission())
        self.assertEqual(first['id'], again['id'])
        self.assertEqual(len(self.commands), 1)
        changed = submission()
        changed['question'] = 'Different question'
        with self.assertRaises(lab.LabError) as caught:
            self.manager.submit(changed)
        self.assertEqual(caught.exception.status, 409)
        self.assertEqual(len(self.commands), 1)

    def test_concurrent_runs_rejected_until_owned_worker_stops(self):
        first = self.manager.submit(submission())
        second = submission()
        second['request_id'] = 'request-test-0002'
        with self.assertRaises(lab.LabError) as caught:
            self.manager.submit(second)
        self.assertEqual(caught.exception.status, 409)
        cancelled = self.manager.cancel(first['id'])
        self.assertEqual(cancelled['status'], 'cancelled')
        self.assertTrue(self.processes[0].terminated)
        self.assertFalse(cancelled['can_cancel'])
        self.assertEqual(self.manager.submit(second)['status'], 'running')

    def test_invalid_inputs_and_unlisted_settings_cannot_spawn(self):
        values = [None, [], {'question': 'a'}, {**submission(), 'provider': 'openai'},
                  {**submission(), 'output': 'C:/outside'}, {**submission(), 'harness': '../run.py'},
                  {**submission(), 'request_id': '../../escape'}, {**submission(), 'question': ' '},
                  {**submission(), 'question': 'a' * 12001}, {**submission(), 'documents': [{}] * 9},
                  {**submission(), 'documents': [{'title': 'x', 'text': 'x', 'path': 'secret'}]},
                  {**submission(), 'documents': [{'title': 'x', 'text': ''}]},
                  {**submission(), 'documents': [{'title': 'x', 'text': 'x' * 20001}]},
                  {**submission(), 'documents': [{'title': 'x', 'text': 'x' * 20000}] * 4}]
        for value in values:
            with self.subTest(value_type=type(value).__name__):
                with self.assertRaises(lab.LabError):
                    self.manager.submit(value)
        self.assertEqual(self.commands, [])
        self.preflight.assert_not_called()

    def test_preflight_failure_preserves_no_job_and_no_inference(self):
        self.preflight.side_effect = RuntimeError('SECRET_PROVIDER_BODY')
        with self.assertRaises(lab.LabError) as caught:
            self.manager.submit(submission())
        self.assertEqual(caught.exception.status, 503)
        self.assertNotIn('SECRET', str(caught.exception))
        self.assertEqual(self.commands, [])
        self.assertFalse((self.root / 'jobs').exists())

    def test_changed_model_identity_cannot_silently_join_session(self):
        first = self.manager.submit(submission())
        self.manager.cancel(first['id'])
        self.preflight.return_value = {**self.preflight.return_value, 'digest': 'different'}
        payload = submission()
        payload['request_id'] = 'request-test-0002'
        with self.assertRaises(lab.LabError) as caught:
            self.manager.submit(payload)
        self.assertEqual(caught.exception.status, 409)
        self.assertEqual(len(self.commands), 1)

    def test_completed_requires_successful_exit_and_summary(self):
        first = self.manager.submit(submission())
        self.processes[-1].returncode = 0
        self.assertEqual(self.manager.list_jobs()[0]['status'], 'error')
        payload = submission()
        payload['request_id'] = 'request-test-0002'
        second = self.manager.submit(payload)
        self.complete(second, status='completed', code=1)
        self.assertEqual(self.manager.list_jobs()[0]['status'], 'error')
        payload['request_id'] = 'request-test-0003'
        third = self.manager.submit(payload)
        self.complete(third)
        self.assertEqual(self.manager.list_jobs()[0]['status'], 'completed')

    def test_worker_spawn_failure_is_saved_and_reported(self):
        self.manager.popen = Mock(side_effect=OSError('SECRET_PATH'))
        job = self.manager.submit(submission())
        self.assertEqual(job['status'], 'error')
        self.assertNotIn('SECRET', job['error'])
        saved = json.loads((self.root / 'jobs' / job['id'] / 'state.json').read_text(encoding='utf-8'))
        self.assertEqual(saved['status'], 'error')

    def test_wall_timeout_terminates_worker_and_records_failure(self):
        job = self.manager.submit(submission())
        self.manager._watch(job['id'], self.processes[0])
        self.assertTrue(self.processes[0].terminated)
        saved = self.manager.list_jobs()[0]
        self.assertEqual(saved['status'], 'error')
        self.assertIn('wall-time', saved['error'])

    def test_cancel_escalates_when_owned_process_ignores_terminate(self):
        job = self.manager.submit(submission())
        process = self.processes[0]
        process.terminate = Mock()
        cancelled = self.manager.cancel(job['id'])
        self.assertTrue(process.killed)
        self.assertEqual(cancelled['status'], 'cancelled')

    def test_restart_does_not_claim_or_cancel_old_process(self):
        job = self.manager.submit(submission())
        reopened = lab.LabManager(jobs_root=self.root / 'jobs', runs_root=self.root / 'runs',
                                  preflight=self.preflight, watch=False, process_probe=self.probe,
                                  popen=self.manager.popen)
        self.assertEqual(reopened.list_jobs()[0]['status'], 'interrupted')
        self.assertEqual(reopened.cancel(job['id'])['status'], 'interrupted')
        self.assertFalse(self.processes[0].terminated)
        self.assertEqual(reopened.submit(submission())['id'], job['id'])
        second = submission()
        second['request_id'] = 'request-test-0002'
        with self.assertRaises(lab.LabError) as caught:
            reopened.submit(second)
        self.assertEqual(caught.exception.status, 409)
        self.assertTrue(reopened.list_jobs()[0]['blocks_new_runs'])
        self.assertEqual(len(self.commands), 1)
        self.processes[0].returncode = 0
        try:
            self.assertEqual(reopened.submit(second)['status'], 'running')
        finally:
            reopened.close()

    def test_reused_pid_does_not_claim_unrelated_process_as_old_worker(self):
        self.manager.submit(submission())
        probe = Mock(return_value={'status': 'running', 'pid': 10000, 'created': 'different-creation'})
        reopened = lab.LabManager(jobs_root=self.root / 'jobs', runs_root=self.root / 'runs',
                                  preflight=self.preflight, watch=False, process_probe=probe)
        self.assertFalse(reopened.list_jobs()[0]['blocks_new_runs'])
        self.assertFalse(self.processes[0].terminated)

    def test_unknown_prior_liveness_blocks_new_work(self):
        self.manager.submit(submission())
        reopened = lab.LabManager(jobs_root=self.root / 'jobs', runs_root=self.root / 'runs',
                                  preflight=self.preflight, watch=False,
                                  process_probe=Mock(return_value={'status': 'unknown'}))
        payload = submission()
        payload['request_id'] = 'request-test-0002'
        with self.assertRaises(lab.LabError) as caught:
            reopened.submit(payload)
        self.assertEqual(caught.exception.status, 409)
        self.assertFalse(self.processes[0].terminated)

    def test_post_spawn_state_save_failure_reaps_owned_worker(self):
        original = self.manager._save
        count = 0

        def save(item):
            nonlocal count
            count += 1
            if count == 2:
                raise OSError('Disk unavailable after spawn')
            return original(item)

        with patch.object(self.manager, '_save', side_effect=save):
            job = self.manager.submit(submission())
        self.assertEqual(job['status'], 'error')
        self.assertTrue(self.processes[0].terminated)
        self.assertEqual(self.manager._handles, {})

    def test_post_spawn_watcher_failure_reaps_owned_worker(self):
        self.manager.watch = True
        with patch.object(lab.threading.Thread, 'start', side_effect=RuntimeError('Cannot start watcher')):
            job = self.manager.submit(submission())
        self.assertEqual(job['status'], 'error')
        self.assertTrue(self.processes[0].terminated)

    def test_failed_launch_cleanup_retains_guard_until_worker_exits(self):
        spawn = self.manager.popen

        def stubborn_spawn(*args, **kwargs):
            process = spawn(*args, **kwargs)
            process.terminate = Mock(side_effect=OSError('still alive'))
            return process

        self.manager.popen = stubborn_spawn
        self.manager.watch = True
        with patch.object(lab.threading.Thread, 'start', side_effect=RuntimeError('Cannot start watcher')):
            job = self.manager.submit(submission())
        self.assertEqual(job['status'], 'running')
        second = submission()
        second['request_id'] = 'request-test-0002'
        with self.assertRaises(lab.LabError):
            self.manager.submit(second)
        self.processes[0].terminate = lambda: setattr(self.processes[0], 'returncode', -15)
        self.manager.close()
        self.assertEqual(self.processes[0].poll(), -15)

    def test_close_stops_own_live_process_even_if_job_status_is_terminal(self):
        job = self.manager.submit(submission())
        self.manager._jobs[job['id']]['status'] = 'error'
        self.manager.close()
        self.assertTrue(self.processes[0].terminated)

    def test_input_hash_excludes_harness_and_request_id_but_tracks_documents(self):
        first = self.manager.submit(submission())
        self.manager.cancel(first['id'])
        second = submission()
        second.update(harness='native', request_id='request-test-0002')
        other = self.manager.submit(second)
        self.assertEqual(first['input_sha256'], other['input_sha256'])
        self.assertEqual(first['model_profile_sha256'], other['model_profile_sha256'])
        self.assertEqual(other['model']['digest'], 'fixture-digest')
        self.manager.cancel(other['id'])
        second['request_id'] = 'request-test-0003'
        second['documents'][0]['text'] += ' Updated.'
        self.assertNotEqual(self.manager.submit(second)['input_sha256'], first['input_sha256'])

    def test_os_identity_reads_current_process_without_signalling_it(self):
        identity = lab.process_identity(os.getpid())
        self.assertEqual(identity['status'], 'running')
        self.assertTrue(identity['created'])

    def test_detail_joins_run_projection_and_output_cursor(self):
        job = self.manager.submit(submission())
        self.manager.catalog = Mock()
        self.manager.catalog.read_run.return_value = {'read_status': 'ok', 'run': {'status': 'running'}}
        self.manager.output_reader = Mock(return_value={'events': [{'seq': 4}], 'next_seq': 4})
        result = self.manager.detail(job['id'], after_seq=2, after_runtime_seq=3, after_output_seq=3)
        self.assertEqual(result['snapshot']['run']['status'], 'running')
        self.assertEqual(result['output_events']['next_seq'], 4)
        self.manager.catalog.read_run.assert_called_once_with(job['run_id'], after_seq=2, after_runtime_seq=3)
        self.manager.output_reader.assert_called_once_with(self.root / 'runs' / f"lab-{job['id']}", 3)


class LabHttpTests(LabFixture):
    def setUp(self):
        super().setUp()
        self.server = lab.create_server(0, self.manager)
        self.thread = threading.Thread(target=self.server.serve_forever, kwargs={'poll_interval': 0.01}, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(2)
        super().tearDown()

    def request(self, path, method='GET', body=None, headers=None):
        connection = HTTPConnection('127.0.0.1', self.server.server_port, timeout=3)
        try:
            connection.request(method, path, body=body, headers=headers or {})
            response = connection.getresponse()
            return response.status, dict(response.getheaders()), response.read()
        finally:
            connection.close()

    def post(self, payload, *, path='/api/lab/runs', headers=None):
        base = {'Content-Type': 'application/json', 'Origin': f'http://127.0.0.1:{self.server.server_port}',
                'X-Lab-Token': self.manager.token}
        base.update(headers or {})
        return self.request(path, 'POST', json.dumps(payload).encode(), base)

    def test_post_security_blocks_cross_site_missing_token_and_dns_rebinding(self):
        for headers in [{'Origin': 'https://example.org'}, {'Origin': 'null'}, {'Origin': ''},
                        {'X-Lab-Token': ''}, {'X-Lab-Token': 'wrong'},
                        {'Host': f'evil.example:{self.server.server_port}'}, {'Sec-Fetch-Site': 'cross-site'}]:
            with self.subTest(headers=headers):
                self.assertEqual(self.post(submission(), headers=headers)[0], 403)
        self.assertEqual(self.commands, [])

    def test_user_activated_cross_site_document_navigation_serves_landing_only(self):
        navigation = {'Sec-Fetch-Site': 'cross-site', 'Sec-Fetch-Mode': 'navigate',
                      'Sec-Fetch-Dest': 'document', 'Sec-Fetch-User': '?1'}
        for path in ['/', '/index.html', '/?from=research']:
            with self.subTest(path=path):
                status, headers, raw = self.request(path, headers=navigation)
                self.assertEqual(status, 200)
                self.assertTrue(headers['Content-Type'].startswith('text/html'))
                self.assertIn(b'<html', raw.lower())
                self.assertIn("frame-ancestors 'none'", headers['Content-Security-Policy'])
                self.assertNotIn('Access-Control-Allow-Origin', headers)
        self.preflight.assert_not_called()
        self.assertEqual(self.commands, [])
        self.assertEqual(self.manager._jobs, {})
        self.assertFalse((self.root / 'jobs').exists())

    def test_cross_site_landing_rejects_iframe_fetch_and_unactivated_navigation(self):
        navigation = {'Sec-Fetch-Site': 'cross-site', 'Sec-Fetch-Mode': 'navigate',
                      'Sec-Fetch-Dest': 'document', 'Sec-Fetch-User': '?1'}
        denied = [{**navigation, 'Sec-Fetch-Dest': 'iframe'},
                  {**navigation, 'Sec-Fetch-Dest': 'frame'},
                  {**navigation, 'Sec-Fetch-Mode': 'cors'},
                  {**navigation, 'Sec-Fetch-Mode': 'no-cors', 'Sec-Fetch-Dest': 'empty'},
                  {key: value for key, value in navigation.items() if key != 'Sec-Fetch-User'},
                  {**navigation, 'Sec-Fetch-User': '?0'}, {'Sec-Fetch-Site': 'cross-site'}]
        for path in ['/', '/index.html']:
            for headers in denied:
                with self.subTest(path=path, headers=headers):
                    self.assertEqual(self.request(path, headers=headers)[0], 403)
        self.preflight.assert_not_called()
        self.assertEqual(self.commands, [])
        self.assertEqual(self.manager._jobs, {})

    def test_cross_site_document_navigation_does_not_grant_api_or_write_privileges(self):
        navigation = {'Sec-Fetch-Site': 'cross-site', 'Sec-Fetch-Mode': 'navigate',
                      'Sec-Fetch-Dest': 'document', 'Sec-Fetch-User': '?1'}
        for path in ['/api/lab/config', '/api/lab/runs', '/api/health',
                     '/api/lab/runs/' + 'a' * 32, '/lab.js', '/lab.css']:
            with self.subTest(path=path):
                self.assertEqual(self.request(path, headers=navigation)[0], 403)
        for extra in [{'Host': f'evil.example:{self.server.server_port}'},
                      {'Host': '127.0.0.1:1'}, {'Origin': 'https://research.example'},
                      {'Origin': 'null'}]:
            with self.subTest(extra=extra):
                self.assertEqual(self.request('/', headers={**navigation, **extra})[0], 403)
        # Even a correct local Origin and token do not turn this landing-page
        # navigation exception into permission to submit cross-site actions.
        self.assertEqual(self.post(submission(), headers=navigation)[0], 403)
        self.assertEqual(self.post({}, path='/', headers=navigation)[0], 403)
        self.preflight.assert_not_called()
        self.assertEqual(self.commands, [])
        self.assertEqual(self.manager._jobs, {})

    def test_config_lists_and_successful_start_cancel_contract(self):
        status, headers, raw = self.request('/api/lab/config')
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(raw)['csrf_token'], self.manager.token)
        self.assertIn("frame-ancestors 'none'", headers['Content-Security-Policy'])
        status, _, raw = self.post(submission())
        self.assertEqual(status, 202)
        job_id = json.loads(raw)['id']
        status, _, raw = self.request('/api/lab/runs')
        self.assertEqual(json.loads(raw)['runs'][0]['id'], job_id)
        status, _, raw = self.post({}, path=f'/api/lab/runs/{job_id}/cancel')
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(raw)['job']['status'], 'cancelled')

    def test_bad_mime_oversized_json_and_traversal_rejected(self):
        self.assertEqual(self.post(submission(), headers={'Content-Type': 'text/plain'})[0], 415)
        self.assertEqual(self.post({'question': 'x' * lab.MAX_BODY})[0], 413)
        for path in ['/../config.py', '/api/lab/runs/../../private', '/api/lab/runs/%2e%2e']:
            self.assertEqual(self.request(path)[0], 404)
        job = self.manager.submit(submission())
        for query in ['after_output_seq=-1', 'after_seq=NaN', 'after_seq=1&after_seq=2', 'path=private']:
            self.assertEqual(self.request(f"/api/lab/runs/{job['id']}?{query}")[0], 400)


if __name__ == '__main__':
    unittest.main()
